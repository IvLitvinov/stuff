[call GenerateFileHeader("AltovaMapforce.cpp")]


#include "StdAfx.h"
#include "AltovaMapforce.h"

using namespace altova::mapforce;

RefCounted::RefCounted() : ref(0) 
{
}

RefCounted::~RefCounted() 
{
}

void RefCounted::AddRef()
{
	ref++;
}

void RefCounted::RemoveRef()
{
	--ref; 
	if (ref == 0) 
		delete this;
}



Enumerable::Enumerable() : RefCounted() 
{
}

Enumerable::~Enumerable() 
{
}




Enumerator::Enumerator(Enumerable* e) : closure(e), pos(0)
{
	if (closure) closure->AddRef();
}

Enumerator::~Enumerator() 
{
	if (closure) closure->RemoveRef();
}



MFNode::MFNode(const QName& name) : RefCounted(), qname(name)
{
}

MFNode::~MFNode() 
{
}

Enumerable* MFDocument::Select(MFQueryKind kind, const QName&) const
{
	switch (kind)
	{
		case k_All:
			return children;
			
		default:
			throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

void MFElement::CreateCache() const
{
	if (childrenCache)
		return;

	childrenCache = new ChildrenCache;
	childrenCache->AddRef();
	for (IEnumerator en = children; en.MoveNext();)
		childrenCache->Append(en.GetCurrent());

	children->RemoveRef(); // something might die right now

	children = childrenCache;
}

Enumerable* MFElement::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
		case k_All:
			return new MFNodeByKindFilter(children, k_AllChildrenAndAttributes);
			
		case k_AllChildren:
			CreateCache();
			return new MFNodeByKindFilter(children, k_Children);
			
		case k_AllAttributes:
			CreateCache();
			return new MFNodeByKindFilter(children, k_AttributeOrField);

		case k_AttributeByQName:
			CreateCache();
			return new MFNodeByKindAndQNameFilter(children, k_AttributeOrField, query);

		case k_ChildrenByQName:
			CreateCache();
			return new MFNodeByKindAndQNameFilter(children, k_Element, query);

		case k_SelfByQName:
			if (query == GetQName())
				return new MFSingletonSequence(this);
			else
				return MFEmptySequence::Instance();

		default:
			throw altova::CAltovaException(0, _T("Unsupported query type."));
	} 
}



string_type MFElement::GetValue() const 
{ 
	return altova::mapforce::GetValue(Select(k_AllChildren));
}

altova::QName MFElement::GetQNameValue()
{
	mapforce::IEnumerator en = Select( k_AllChildren )->GetEnumerator();

	if(!en.MoveNext())
		throw altova::CAltovaException(0, _T("Trying to convert NULL to QName."));

	altova::QName qn = altova::mapforce::GetQNameValue( en.GetCurrent() );

	if(en.MoveNext())
		throw altova::CAltovaException(0, _T("Trying to convert multiple values to QName."));

	return qn;
}



Enumerable* MFAttribute::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
	case k_AllChildren:
		return new MFNodeByKindFilter(children, k_TextOrSimple);

	case k_AllAttributes:
	case k_AttributeByQName:
		return MFEmptySequence::Instance();

	case k_ChildrenByQName:
		return MFEmptySequence::Instance();

	case k_SelfByQName:
		if (query == GetQName())
			return new MFSingletonSequence(this);
		else
			return MFEmptySequence::Instance();

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

string_type MFAttribute::GetValue() const
{
	string_type s; 
	bool isfirst = true;
	for (IEnumerator i(Select(k_AllChildren)); i.MoveNext();)
	{
		if (isfirst)
			isfirst = false;
		else
			s += _T(" ");

		s += altova::mapforce::GetValue(i.GetCurrent());
	}
	return s;
}

string_type MFAttribute::GetStringValue() const 
{ 
	return altova::mapforce::GetValue(Select(k_AllChildren));
}

altova::QName MFAttribute::GetQNameValue()
{
	mapforce::IEnumerator en = Select( k_AllChildren )->GetEnumerator();

	if(!en.MoveNext())
		throw altova::CAltovaException(0, _T("Trying to convert NULL to QName."));

	altova::QName qn = altova::mapforce::GetQNameValue( en.GetCurrent() );

	if(en.MoveNext())
		throw altova::CAltovaException(0, _T("Trying to convert multiple values to QName."));

	return qn;
}



Enumerable* MFTextNode::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
	case k_AllChildren:
		return new MFNodeByKindFilter(children, k_Text);

	case k_AttributeByQName:
		return MFEmptySequence::Instance();

	case k_ChildrenByQName:
		return MFEmptySequence::Instance();

	case k_SelfByQName:
		return MFEmptySequence::Instance();

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}



string_type MFTextNode::GetValue() const 
{ 
	return altova::mapforce::GetValue(Select(k_AllChildren));
}


bool SequenceJoin::Enum::MoveNext()
{
	if (first)
	{
		if(first->MoveNext())
		{
			pos++;
			return true;
		}
		
		delete first;
		first = 0;
	}
		
	if (second->MoveNext())
	{
		pos++;
		return true;
	}
	
	return false;
}

Enumerable* MFComment::Select(MFQueryKind kind, const QName& query) const
{
	return new MFSingletonSequence(IMFNode(new MFSimpleNode<string_type>(content)));
}

Enumerable* MFProcessingInstruction::Select(MFQueryKind kind, const QName& query) const
{
	return new MFSingletonSequence(IMFNode(new MFSimpleNode<string_type>(content)));
}

Enumerable* MFCData::Select(MFQueryKind kind, const QName& query) const
{
	return new MFSingletonSequence(IMFNode(new MFSimpleNode<string_type>(content)));
}
