[call GenerateFileHeader("AltovaMapforce.h")]

#pragma once
#ifndef ALTOVA_MAPFORCE_H
#define ALTOVA_MAPFORCE_H

#include "Altova.h"
#include "AltovaException.h"
#include "SchemaTypes.h"
#include <list>
#include <vector>
#include <algorithm>
#include <iostream>
#include <map>

#if defined(UNICODE) || defined(_UNICODE)
	typedef std::wstring string_type;
#else
	typedef std::string string_type;
#endif

typedef string_type::value_type char_type;

namespace altova
{
	namespace mapforce
	{
	
		struct ALTOVA_DECLSPECIFIER blob
		{
		public:
			typedef unsigned char value_type;
			typedef const unsigned char& const_reference;
			typedef unsigned char& reference;
			
			blob() : _blob() {}
			explicit blob(size_t count, unsigned char c) :_blob(count, c) {}
			blob(const blob& b) : _blob(b._blob) {}
			blob(const std::vector<unsigned char>& v) : _blob(v) {}

			operator std::vector<unsigned char>() { return _blob; }
			operator const std::vector<unsigned char>() const { return _blob; }
			
			
			unsigned char& operator\[\](size_t i) { return _blob\[i\]; }
			const unsigned char& operator\[\](size_t i) const { return _blob\[i\]; }
			std::vector<unsigned char>::iterator begin() { return _blob.begin(); }
			std::vector<unsigned char>::iterator end() { return _blob.end(); }
			std::vector<unsigned char>::const_iterator begin() const { return _blob.begin(); }
			std::vector<unsigned char>::const_iterator end() const { return _blob.end(); }
			size_t size() const { return _blob.size(); }
			void resize(size_t size) { _blob.resize(size); }
			void push_back(unsigned char c) { _blob.push_back(c); }
			void reserve(size_t size) { _blob.reserve(size); }
			
		private:
			std::vector<unsigned char> _blob;
		};
	
		class Enumerator;
		class Enumerable;
		class MFNode;
		class MFEmptySequence;

		enum MFQueryKind
		{
			k_All,
			k_AllChildren,
			k_AllAttributes,
			k_AttributeByQName,
			k_ChildrenByQName,
			k_SelfByQName,
			k_ChildrenByDbCommand
		};

		enum MFNodeKind
		{
			k_Unknown = 0,
			k_Attribute = 1 << 0,
			k_Field = 1 << 1,
			k_Element = 1 << 2,
			k_Text = 1 << 4,
			k_CData = 1 << 5,
			k_Comment = 1 << 6,
			k_ProcessingInstruction = 1 << 7,
			k_Document = 1 << 8,
			k_Connection = 1 << 9,
			k_Simple = 1 << 10,

			k_AttributeOrField = k_Attribute|k_Field,
			k_TextOrCData = k_Text|k_CData,
			k_TextOrSimple = k_Text|k_Simple,

			k_Children = k_Element|k_Text|k_CData|k_Comment|k_ProcessingInstruction|k_Simple,
			k_AllChildrenAndAttributes = k_Children|k_Attribute
		};

		struct ALTOVA_DECLSPECIFIER Prefix
		{	
			Prefix(const string_type& p) : prefix(p), isNull(false) {}
			Prefix() : prefix(_T("")), isNull(true) {}
			Prefix(const Prefix& o) : prefix(o.prefix), isNull(o.isNull) {}
			Prefix& operator= (const Prefix& o) {if (this == &o) return *this; prefix = o.prefix; isNull = o.isNull; return *this;}
			bool IsNull() const { return isNull; }
			bool IsEmpty() const { return prefix.empty(); }
			const string_type& GetPrefix() const { return prefix; }
			operator const string_type&() const { return prefix; }
		private:
			string_type prefix;
			bool isNull;
		};
		
		struct ALTOVA_DECLSPECIFIER QName
		{
			string_type localName;
			string_type namespaceUri;
			Prefix prefix;
			QName(const string_type& local = _T(""), const string_type& uri = _T(""), const Prefix& pre = Prefix()) : localName(local), namespaceUri(uri), prefix(pre) {}	
			QName(const QName& o) : localName(o.localName), namespaceUri(o.namespaceUri), prefix(o.prefix) {}
			QName& operator= (const QName& o) {if (this == &o) return *this; localName = o.localName; namespaceUri = o.namespaceUri; prefix = o.prefix; return *this;}
		};

		inline bool operator==(const QName& q1, const QName& q2)
		{
			return q1.localName == q2.localName && q1.namespaceUri == q2.namespaceUri;
		}
		
		// Refcounted base class
		class ALTOVA_DECLSPECIFIER RefCounted
		{
		public:
			RefCounted();
			virtual ~RefCounted();
			void AddRef();
			void RemoveRef(); 
		private:
			int ref;
		};

		class IMFNode;
		class MFNode;
		class Enumerator;

		// Enumerable base class
		class ALTOVA_DECLSPECIFIER Enumerable : public RefCounted
		{
		public:
			Enumerable();
			virtual ~Enumerable();
			virtual Enumerator* GetEnumerator() = 0;
		};

		// Enumerator base class
		class ALTOVA_DECLSPECIFIER Enumerator
		{
		public:
			Enumerator(Enumerable* e);
			virtual ~Enumerator();
			virtual bool MoveNext() = 0;
			virtual IMFNode GetCurrent() = 0;
			int GetPosition() const {return pos;}
		
		protected:
			int pos;
			
		private:
			Enumerable* closure;
		};



		// conversion test and type selector

		#ifdef _MSC_VER	// suppress annoying warnings in Visual C++ (for does_conversion_exist and for IMFNode)
		#pragma warning ( push )
		#pragma warning ( disable : 4800 )	// forcing value to bool 'true' or 'false' (performance warning)
		#pragma warning ( disable : 4244 )	// 'argument' : conversion from 'double' to 'int', possible loss of data
		#endif // _MSC_VER

		typedef bool yes_type;
		typedef long no_type;

		template< typename From >
		struct does_conversion_exist
		{
			template< typename To > struct result
			{
				static no_type _m_check(...);
				static yes_type _m_check(To);
				static From _m_from;
				enum { value = sizeof( _m_check(_m_from) ) == sizeof(yes_type) };
			};
		};

		template< class C_true, class C_false >
		struct select
		{
			template< bool b >
			struct if_ { typedef C_true type; };

			template<>
			struct if_< false > { typedef C_false type; };
		};



		// 
		// Nodes
		// 

		// Node base class
		class ALTOVA_DECLSPECIFIER MFNode : public RefCounted
		{
		public: 
			MFNode(const QName& name);
			virtual ~MFNode();

			virtual MFNodeKind GetNodeKind() const = 0;
			inline const string_type& GetLocalName() const {return qname.localName;}
			inline const string_type& GetNamespaceURI() const {return qname.namespaceUri;}
			inline const Prefix& GetPrefix() const {return qname.prefix;}
			inline const QName& GetQName() const {return qname;}
			virtual Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const = 0;
			virtual string_type GetValue() const = 0;
			virtual string_type GetStringValue() const { return GetValue(); }
			virtual altova::QName GetQNameValue() {return altova::QName();}
			
		private:
			QName qname;
		};
		
		class ALTOVA_DECLSPECIFIER MFDocumentNode
		{
		public:
			MFDocumentNode(const string_type& f) : filename(f) {}
			virtual ~MFDocumentNode() {}
			const string_type& GetDocumentUri() const {return filename;}
			
		private:
			string_type filename;
		};
		
		// Document
		class ALTOVA_DECLSPECIFIER MFDocument : public MFNode
		{
		public:
			MFDocument(const string_type& f, Enumerable* c) 
				: MFNode(string_type(_T("Document"))), filename(f), children(c) {children->AddRef();}
			~MFDocument() {children->RemoveRef();}
			
			MFNodeKind GetNodeKind() const {return k_Document;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const {return _T(""); }
			const string_type& GetFilename() const {return filename; }
		
		private:
			string_type filename;
			Enumerable* children;
		};


		class ChildrenCache;
	
		// Element
		class ALTOVA_DECLSPECIFIER MFElement : public MFNode
		{
		public:
			MFElement(const QName name, Enumerable* c) 
				: MFNode(name), children(c), childrenCache(0) {children->AddRef();}
			~MFElement() {children->RemoveRef();}

			MFNodeKind GetNodeKind() const {return k_Element;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const;
			altova::QName GetQNameValue();
			
		private:
			void CreateCache() const;
			mutable Enumerable* children;
			mutable ChildrenCache* childrenCache;
		};

		// Attribute
		class ALTOVA_DECLSPECIFIER MFAttribute : public MFNode
		{
		public:
			MFAttribute(QName name, Enumerable* c)
				: MFNode(name), children(c) {children->AddRef();}
			~MFAttribute() {children->RemoveRef();}
			
			MFNodeKind GetNodeKind() const {return k_AttributeOrField;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const;
			string_type GetStringValue() const;
			altova::QName GetQNameValue();
			
		private:
			Enumerable* children;
		};

		// Text node
		class ALTOVA_DECLSPECIFIER MFTextNode : public MFNode
		{
		public:
			MFTextNode(bool cdata, Enumerable* c) 
				: MFNode(QName(_T("#text"))), children(c), kind(cdata ? k_TextOrCData : k_Text) {children->AddRef();}
			~MFTextNode() {children->RemoveRef();}

			MFNodeKind GetNodeKind() const {return kind;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const;
			
		private:
			Enumerable* children;
			MFNodeKind kind;
		};
		
		// comment
		class ALTOVA_DECLSPECIFIER MFComment : public MFNode
		{
		public:
			MFComment(string_type c) : MFNode(QName(_T("#comment"))), content(c) {}
			~MFComment() {}
			
			MFNodeKind GetNodeKind() const {return k_Comment;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const {return content;}
			
		private:
			string_type content;
		};
		
		// PI
		class ALTOVA_DECLSPECIFIER MFProcessingInstruction : public MFNode
		{
		public:
			MFProcessingInstruction(string_type c, string_type name) : MFNode(QName(name)), content (c) {}
			~MFProcessingInstruction() {}
			
			MFNodeKind GetNodeKind() const {return k_ProcessingInstruction;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const {return content;}
		
		private:
			string_type content;
		};

		// cdata
		class ALTOVA_DECLSPECIFIER MFCData : public MFNode
		{
		public:
			MFCData(string_type c) : MFNode(QName(_T("#cdata"))), content(c) {}
			~MFCData() {}

			MFNodeKind GetNodeKind() const {return k_CData;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const {return content;}

		private:
			string_type content;
		};

		class MFSimpleNodeBase : public MFNode
		{
		public :
			MFSimpleNodeBase() : MFNode( QName() )
			{  }

			#define CAST_TO( T, Name ) virtual T GetValueAs##Name() const = 0;
			CAST_TO(int, Int)
			CAST_TO(unsigned, Uint)
			CAST_TO(bool, Bool)
			CAST_TO(double, Double)
			CAST_TO(__int64, Int64)
			CAST_TO(unsigned __int64, Uint64)
			CAST_TO(altova::DateTime, DateTime)
			CAST_TO(blob, Blob)
			CAST_TO(altova::Duration, Duration)
			CAST_TO(altova::QName, QName)
			#undef CAST_TO
		};

		// simple value node		
		template <typename T>
		class MFSimpleNode : public MFSimpleNodeBase
		{
		public:
			MFSimpleNode(T v) : value(v) 
			{
				value = v;
			};
			~MFSimpleNode() {};
			MFNodeKind GetNodeKind() const {return k_Simple;}
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const
            {
                switch (kind)
                {
                case k_AllChildren:
                case k_AttributeByQName:
                case k_ChildrenByQName:
                    return MFEmptySequence::Instance();

                case k_SelfByQName:
                    return new MFSingletonSequence(this);

                default:
                    throw altova::CAltovaException(0, _T("Unsupported query type."));
                }
            }

			string_type GetValue() const 
			{ 
				return CoreTypes::CastToString(value); 
			}

			altova::QName GetQNameValue() { return GetValueAsQName(); }

			T value;

			template< typename T, typename U >
			struct Convert { static U Get( const T& n ) { return n; } };

			template<>
			struct Convert< unsigned __int64, double > { static double Get( __int64 n ) { return n; } };

			template< typename T, typename U >
			struct NoConvert { static U Get( const T& n ) { throw altova::CAltovaException(0, _T("type not compatible")); /*return U();*/ } };

			template< typename U >
			struct ValueGetter
			{
				static U GetValueAs( const MFSimpleNode<T>* node )
				{
					return
					select< Convert<T, U>, NoConvert<T, U> >::if_<
						does_conversion_exist< T >::result< U >::value
					>::type::
					Get( node->value );
				}
			};

			#define CAST_TO( Ty, Name ) virtual Ty GetValueAs##Name() const { return ValueGetter<Ty>::GetValueAs( this ); }
			CAST_TO(int, Int)
			CAST_TO(unsigned, Uint)
			CAST_TO(bool, Bool)
			CAST_TO(double, Double)
			CAST_TO(__int64, Int64)
			CAST_TO(unsigned __int64, Uint64)
			CAST_TO(altova::DateTime, DateTime)
			CAST_TO(blob, Blob)
			CAST_TO(altova::Duration, Duration)
			CAST_TO(altova::QName, QName)
			#undef CAST_TO
		};


#define OPERATOR_CAST_TO( T, Name ) operator T() \\
		{ \\
			MFSimpleNodeBase* n = dynamic_cast<MFSimpleNodeBase*> (item); \\
			if( !n ) \\
				throw altova::CAltovaException(0, _T("type not compatible")); \\
			return n->GetValueAs##Name(); \\
		}

#define OPERATOR_ASSIGN(X) IMFNode& operator= (const X & s) {if (item) item->RemoveRef(); setItem(new MFSimpleNode<X>(s)); return *this;}

		static string_type GetValue(const MFNode* n) { return n->GetValue();}
		static string_type GetValue(const IMFNode& n);
		static altova::QName GetQNameValue(const IMFNode& n);

		class Group;
		class ALTOVA_DECLSPECIFIER IMFNode
		{
			friend inline bool operator==(const IMFNode& n1, const IMFNode& n2);
			friend static string_type GetValue(const IMFNode& n);
			friend static altova::QName GetQNameValue(const IMFNode& n);

		public:
			IMFNode() : item(0)
			{
			}
			
			~IMFNode()
			{
				if (item) 
					item->RemoveRef();
			}
			
			IMFNode(MFNode* n)
			{
				setItem(n);
			}

			IMFNode(const MFNode* n)
			{
				setItem(const_cast<MFNode*> (n));
			}

			IMFNode(const IMFNode& n)
			{
				setItem(n.item);
			}
			
			IMFNode(RefCounted* i)
			{
				setItem(i);
			}

			IMFNode& operator=( const IMFNode& n )
			{
				if( this != &n )
				{
					if( item ) item->RemoveRef();
					setItem( n.item );
				}
				return *this;
			}
			
			IMFNode& operator=(MFNode* n) 
			{
				if (node) node->RemoveRef();
				setItem(n);
				return *this;
			}

			bool exists() const {return node != 0;}

			MFNode* operator->() {return node;}
			operator MFNode*() {return node;}
			operator Group*() {return (Group*) item;}
			operator RefCounted*() {return item;}

			operator string_type() {return node->GetValue();}
			OPERATOR_CAST_TO(int, Int)
			OPERATOR_CAST_TO(unsigned, Uint)
			OPERATOR_CAST_TO(bool, Bool)
			OPERATOR_CAST_TO(double, Double)
			OPERATOR_CAST_TO(__int64, Int64)
			OPERATOR_CAST_TO(unsigned __int64, Uint64)
			OPERATOR_CAST_TO(altova::DateTime, DateTime)
			OPERATOR_CAST_TO(blob, Blob)
			OPERATOR_CAST_TO(altova::Duration, Duration)
			OPERATOR_CAST_TO(altova::QName, QName)
			
			OPERATOR_ASSIGN(string_type)
			OPERATOR_ASSIGN(int)
			OPERATOR_ASSIGN(unsigned)
			OPERATOR_ASSIGN(bool)
			OPERATOR_ASSIGN(double)
			OPERATOR_ASSIGN(__int64)
			OPERATOR_ASSIGN(unsigned __int64)
			OPERATOR_ASSIGN(altova::DateTime)
			OPERATOR_ASSIGN(blob)
			OPERATOR_ASSIGN(altova::Duration)
			OPERATOR_ASSIGN(altova::QName)

		private:
			void setItem(RefCounted* i)
			{
				item = i;
				if (item)
					item->AddRef();
			}

			union
			{
				MFNode* node;
				RefCounted* item;
			};
		};
		
        static string_type GetValue(const IMFNode& n) { return n.node->GetValue();}
		static altova::QName GetQNameValue(const IMFNode& n) { return n.node->GetQNameValue();}

		#ifdef _MSC_VER	// end of suppressing annoying warnings in Visual C++ (for does_conversion_exist and for IMFNode)
		#pragma warning ( pop )
		#endif // _MSC_VER

		template< class T >
		struct RefCountedPtr
		{
		private :
			mutable T* m_ptr;

		public :
			RefCountedPtr() : m_ptr( 0 ) {  }
			~RefCountedPtr() { if( m_ptr ) m_ptr->RemoveRef(); }

			RefCountedPtr( T* p ) : m_ptr( p ) { if( m_ptr ) m_ptr->AddRef(); }
			RefCountedPtr& operator=( T* p ) { if( m_ptr ) m_ptr->RemoveRef(); m_ptr = p; if( m_ptr ) m_ptr->AddRef(); return *this; }

			RefCountedPtr( const RefCountedPtr& n ) : m_ptr( n.m_ptr ) { if( m_ptr ) m_ptr->AddRef(); }
			RefCountedPtr& operator=( const RefCountedPtr& n ) { if( m_ptr ) m_ptr->RemoveRef(); m_ptr = n.m_ptr; if( m_ptr ) m_ptr->AddRef(); return *this; }

			RefCountedPtr( IMFNode i ) : m_ptr( (T*) (altova::mapforce::RefCounted*) i ) { if( m_ptr ) m_ptr->AddRef(); }
			RefCountedPtr& operator =( IMFNode i ) { if( m_ptr ) m_ptr->RemoveRef(); m_ptr = (T*) (altova::mapforce::RefCounted*) i; if( m_ptr ) m_ptr->AddRef(); return *this; }

			T* operator ->() { return m_ptr; }
			operator T* () const { return m_ptr; }
		};

		class ALTOVA_DECLSPECIFIER IEnumerator
		{
		public:
			IEnumerator(Enumerator* e) : poorEnumerator(e) {}
			IEnumerator(Enumerable* e) : poorEnumerator(e->GetEnumerator()) {}
			~IEnumerator() {delete poorEnumerator;}

			bool MoveNext() {return poorEnumerator->MoveNext();}
			IMFNode GetCurrent() const {return poorEnumerator->GetCurrent();}
			int GetPosition() const {return poorEnumerator->GetPosition();}
			
		private:
			IEnumerator() : poorEnumerator(0) {}
			IEnumerator(const IEnumerator& e) : poorEnumerator(0) {}
			IEnumerator& operator=(Enumerator*) {return *this;}
			Enumerator* poorEnumerator;
		};
		
		class ALTOVA_DECLSPECIFIER IEnumerable
		{
		public: 
			IEnumerable() : poorEnumerable(0) {}
			IEnumerable(const IEnumerable& ie) {setEnumerable(ie.poorEnumerable);}
			IEnumerable(Enumerable* e) {setEnumerable(e);}
			~IEnumerable() {deref();}
			IEnumerable& operator= (const IEnumerable& ie) 
			{
				if (this == &ie) 
					return *this; 
				deref(); 
				setEnumerable(ie.poorEnumerable);
				return *this;
			}
			IEnumerable& operator= (Enumerable* e) 
			{
				deref(); 
				setEnumerable(e);
				return *this;
			}
			Enumerable* operator->() {return poorEnumerable;}
			operator Enumerable*()  {return poorEnumerable;}

		private:
			void setEnumerable(Enumerable* e)
			{
				poorEnumerable = e;
				if (poorEnumerable)
					poorEnumerable->AddRef();
			}
			void deref() {if (poorEnumerable) poorEnumerable->RemoveRef();}
			Enumerable* poorEnumerable;
		};

		//
		// Sequences and filters
		//

		// Empty sequence
		class ALTOVA_DECLSPECIFIER MFEmptySequence : public Enumerable
		{
		public:
			class Enum : public Enumerator
			{
			public:
				Enum(Enumerable* cls) : Enumerator(cls) {} 
				~Enum() {}
				IMFNode GetCurrent() {throw altova::CAltovaException(0, _T("No current in empty sequence."));}
				bool MoveNext() {return false;}
			};

			static MFEmptySequence* Instance()
			{
				return new MFEmptySequence(); 
			}
			~MFEmptySequence() {}
			
			Enumerator* GetEnumerator() 
			{
				return new Enum(this);
			}

		private:
			MFEmptySequence() : Enumerable() {}
		};

		// Node by kind filter
		class ALTOVA_DECLSPECIFIER MFNodeByKindFilter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(Enumerator* base, MFNodeKind kind, Enumerable* cls) : Enumerator(cls), baseEnum(base), nodeKind(kind) {}
				~Enum() 
				{
					delete baseEnum;
				}

				IMFNode GetCurrent() {return baseEnum->GetCurrent();}
				bool MoveNext() 
				{
					while (baseEnum->MoveNext())
					{
						IMFNode node = baseEnum->GetCurrent();
						if (node.exists())
						{
							if((nodeKind & node->GetNodeKind()) != 0)
							{
								pos++;
								return true;
							}
						}
					}
					return false;
				}
			private:
				Enumerator* baseEnum;
				MFNodeKind nodeKind;
			};

		public:
			MFNodeByKindFilter(Enumerable* base, MFNodeKind kind) 
				: Enumerable(), baseSet(base), nodeKind(kind) 
			{
				baseSet->AddRef();
			}
			~MFNodeByKindFilter() 
			{
				baseSet->RemoveRef();
			}

			Enumerator* GetEnumerator() {return new Enum(baseSet->GetEnumerator(), nodeKind, this);}
		
		private:
			Enumerable* baseSet;
			MFNodeKind nodeKind;
		};

		// Node by kind and name filter
		class ALTOVA_DECLSPECIFIER MFNodeByKindAndQNameFilter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(Enumerator* base, MFNodeKind kind, const QName& name, Enumerable* cls) : Enumerator(cls), baseEnum(base), nodeKind(kind), qname(name) {}
				~Enum()
				{
					delete baseEnum;
				}

				IMFNode GetCurrent() {return baseEnum->GetCurrent();}
				bool MoveNext() 
				{
					while (baseEnum->MoveNext())
					{
						IMFNode node = baseEnum->GetCurrent();
						if (node.exists() && (nodeKind & node->GetNodeKind()) != 0 && node->GetQName() == qname)
						{
							pos++;
							return true;
						}
					}
					return false;
				}
			private:
				Enumerator* baseEnum;
				MFNodeKind nodeKind;
				QName qname;
			};

		public:
			MFNodeByKindAndQNameFilter(Enumerable* base, MFNodeKind kind, const QName& name) 
				: Enumerable(), baseSet(base), nodeKind(kind), qname(name) 
			{
				baseSet->AddRef();
			}

			~MFNodeByKindAndQNameFilter() 
			{
				baseSet->RemoveRef();
			}

			Enumerator* GetEnumerator() {return new Enum(baseSet->GetEnumerator(), nodeKind, qname, this);}
		private:
			Enumerable* baseSet;
			MFNodeKind nodeKind;
			QName qname;
		};

		// Singleton sequence
		class ALTOVA_DECLSPECIFIER MFSingletonSequence : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(const IMFNode& i, Enumerable* cls) : Enumerator(cls), b(true) 
				{
					item = i;
					pos = 1;
				} 
				~Enum() {}
				IMFNode GetCurrent() {return item;}
				bool MoveNext() {if (b) {b=false; return true;} return false;}

			private:
				IMFNode item;
				bool b;
			};

		public:
			MFSingletonSequence(const IMFNode& i) : Enumerable()
			{
				item = i;
			}
			~MFSingletonSequence() {}

			Enumerator* GetEnumerator() {return new Enum(item, this);}

		private: 
			IMFNode item;
		};
		
		template <typename T>
		class Invokable : public RefCounted
		{
		public:
			Invokable() : RefCounted() {}
			virtual ~Invokable() {}
			virtual T Invoke(IMFNode& n) = 0;
		};
		
		class ALTOVA_DECLSPECIFIER SequenceJoin : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(Enumerator* a, Enumerator* b, Enumerable* cls) : Enumerator(cls), first(a), second(b)
				{
				}
				
				~Enum()
				{
					delete first;
					delete second;
				}
				
				bool MoveNext();
								
				IMFNode GetCurrent() 
				{
					return first ? first->GetCurrent() : second->GetCurrent();
				}
								
			private:
				Enumerator* first;
				Enumerator* second;
			};
			
		public:
			SequenceJoin(Enumerable* a, Enumerable* b) : Enumerable(), first(a), second(b) 
			{
				first->AddRef();
				second->AddRef();
			}
			
			~SequenceJoin()
			{
				first->RemoveRef();
				second->RemoveRef();
			}
			
			Enumerator* GetEnumerator() {return new Enum(first->GetEnumerator(), second->GetEnumerator(), this);}
			
		private:
			Enumerable* first;
			Enumerable* second;
		};
	
		static string_type GetValue(const string_type& v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(int v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(unsigned v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(bool v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(double v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(__int64 v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(unsigned __int64 v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(const altova::DateTime& v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(const blob& v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(const altova::Duration& v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(const altova::QName& v) {return CoreTypes::CastToString(v);}
		static string_type GetValue(Enumerable* e) 
		{
			string_type s; 
			for (IEnumerator i(e); i.MoveNext();) 
				s += GetValue(i.GetCurrent()); 
				return s;
		}
		
		class ALTOVA_DECLSPECIFIER RuntimeContext
		{
		public:
			struct TEntry
			{
				long current;
				string_type restartOnChange;
				TEntry(long n, const string_type& restart) : current(n), restartOnChange(restart) {}
				TEntry() : current(0) {}
			};
			
			typedef std::map<string_type, TEntry> TAutoNumberStateMap;
			TAutoNumberStateMap autoNumberStateMap;
			
			static void Dispose(RuntimeContext* context) { delete context; }
			static RuntimeContext* Construct() { return new RuntimeContext; }
		private:
			RuntimeContext() {}
			~RuntimeContext() {}
		};

		class ALTOVA_DECLSPECIFIER Group : public RefCounted
		{
		public:
			Group(const string_type& k, Enumerable* i) : RefCounted(), key(k), items(i)
			{
				items->AddRef();
			}
			
			~Group()
			{
				items->RemoveRef();
			}
			
		const string_type& Key() const {return key;}
		Enumerable* Items() const {return items;}
		
		private:
			string_type key;
			Enumerable* items;
		};
		
		// ChildrenCache for element
		class ALTOVA_DECLSPECIFIER ChildrenCache : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(std::list<IMFNode>::iterator i, std::list<IMFNode>::iterator e, Enumerable* cls) : Enumerator(cls), it(i), end(e) {}
				~Enum() {}
				
				virtual bool MoveNext() 
				{
					if (pos > 0) ++it; 
					if (it == end) return false; 
					pos++; return true;
				}
				
				virtual IMFNode GetCurrent() {return *it;}
				
			private:
				std::list<IMFNode>::iterator it;
				std::list<IMFNode>::iterator end;
			};
			
			public:
				ChildrenCache() : Enumerable() {}
				virtual ~ChildrenCache() {};
				virtual Enumerator* GetEnumerator() { return new Enum(cache.begin(), cache.end(), this); }
				void Append(IMFNode& n) {cache.push_back(n);}
			private:
				std::list<IMFNode> cache;
		};
	} // namespace mapforce
} // namespace altova

#endif
