#include "StdAfx.h"
#include "StructInfo.h"

