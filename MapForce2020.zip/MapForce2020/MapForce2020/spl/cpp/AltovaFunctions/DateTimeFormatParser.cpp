[call GenerateFileHeader("DateTimeFormatParser.cpp")]
#include "stdafx.h"

#include "DateTimeFormatParser.h"
#include "Lang.h"
#include <sstream>
#include <iomanip>

namespace altova
{

char_type* DateTimeFormatParser::DayNames\[\] = { 
	_T("Monday"),
	_T("Tuesday"),
	_T("Wednesday"),
	_T("Thursday"),
	_T("Friday"),
	_T("Saturday"),
	_T("Sunday")
};

char_type* DateTimeFormatParser::MonthNames\[\] = { 
	_T("January"),
	_T("February"),
	_T("March"),
	_T("April"),
	_T("May"),
	_T("June"),
	_T("July"),
	_T("August"),
	_T("September"),
	_T("October"),
	_T("November"),
	_T("December")
};

const unsigned DateTimeFormatParser::monthStart\[13\] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
const unsigned DateTimeFormatParser::monthStartLeap\[13\] = { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 };

void DateTimeFormatParser::FieldInfo::Reset()
{
	mComponent = 0;
	mWidth = _T("");
	mModifier = _T("");
	mMinWidth = 0;
	mMaxWidth = 0;
	mMinusPos = 0;
}

bool DateTimeFormatParser::FieldInfo::Analyze()
{
	mMinusPos = mWidth.find( _T('-') );

	if( mMinusPos == -1 )
	{
		tstringstream ssMin;
		ssMin.str( mWidth);
		ssMin >> mMinWidth;
		mMinusPos = mWidth.length();
	}
	else
	{
		tstringstream ssMin, ssMax;
		ssMin.str( mWidth.substr( 0, mMinusPos ) );
		ssMin >> mMinWidth;
		ssMax.str( mWidth.substr( mMinusPos + 1) );
		ssMax >> mMaxWidth;
	}

	return true;
}

string_type DateTimeFormatParser::FormatDateTime(const altova::DateTime& dateTime) const
{
	string_type sOutput;

	string_type::size_type nLength = m_sPattern.length();
	ParseState state = k_NORMAL;
	ArgumentState argState = k_COMPONENT;
	FieldInfo fieldInfo;
	for( string_type::size_type i = 0; i < nLength; ++i)
	{
		char_type cCurrent = m_sPattern\[i\];
		char_type cNext = i + 1 < nLength ? m_sPattern\[i + 1\] : 0;

		switch( state )
		{
			case k_NORMAL:
			{
				if( cCurrent == m_cFieldOpen )
				{
					if( cNext != m_cFieldOpen )
					{
						state = k_INFIELD;
						argState = k_COMPONENT;
						fieldInfo.Reset();
					}
					else
					{
						sOutput += cCurrent;
						i++;
					}
				}
				else if( cCurrent == m_cFieldClose )
				{
					if( cNext != m_cFieldClose )
					{
						//error something is wrong with the pattern
						throw CAltovaException( 0, string_type(_T("Incorrect pattern: '")) + m_sPattern + _T("'"));
					}
					else
					{
						sOutput += cCurrent;
						i++;
					}
				}
				else
				{
					sOutput += cCurrent;
				}
			}
			break;
			case k_INFIELD:
			{
				if( cCurrent == m_cFieldClose )
				{
					if( cNext != m_cFieldClose )
					{
						state = k_NORMAL;

						if( fieldInfo.mComponent > 0 )
						{
							string_type sValue = GetComponentValue(dateTime, fieldInfo.mComponent);
							if ((fieldInfo.mComponent != 'z' && fieldInfo.mComponent != 'Z') || dateTime.HasTimezone())
								sValue = ProcessFormatModifier( dateTime, sValue, fieldInfo);
							sValue = ProcessWidth( sValue, fieldInfo);

							sOutput += sValue;
						}
					}
					else
					{
						//error ]] in field
						throw CAltovaException( 0, string_type(_T("Incorrect pattern: '")) + m_sPattern + _T("'"));
					}
				}
				else
				{
					switch( argState )
					{
						case k_COMPONENT:
						{
							fieldInfo.mComponent = cCurrent;
							argState = k_FORMAT;
						}
						break;
						case k_FORMAT:
						{
							if( cCurrent == _T(',') )
								argState = k_WIDTH;
							else
								fieldInfo.mModifier += cCurrent;
						}
						break;
						case k_WIDTH:
						{
							fieldInfo.mWidth += cCurrent;
						}
						break;
					}
				}
			}
			break;
		}
	}

	if( state != k_NORMAL )
		throw CAltovaException( 0, string_type(_T("Incorrect pattern: '")) + m_sPattern + _T("'"));

	return sOutput;
}

string_type DateTimeFormatParser::ProcessFormatModifier(
	const altova::DateTime& dtData,	
	const string_type& sValue,
	FieldInfo& fieldInfo) const
{
	if( fieldInfo.mModifier.empty() )
	{
		// set presentation defaults
		if( fieldInfo.mComponent == _T('F') || fieldInfo.mComponent == _T('P') )
			fieldInfo.mModifier = _T('n');
		else if( fieldInfo.mComponent == _T('m') || fieldInfo.mComponent == _T('s') )
			fieldInfo.mModifier = _T("01");
		else
			fieldInfo.mModifier = _T('1');
	}

	string_type sResult = sValue;
	string_type::size_type nZeroPad = 0;
	while( fieldInfo.mModifier.at(nZeroPad) == _T('0') ) nZeroPad++;

	if( fieldInfo.mModifier.substr(nZeroPad) == _T("1") )
	{
		if( fieldInfo.mComponent == _T('F') )
		{
			tstringstream ssTmp;
			ssTmp << (dtData.Weekday() + 1);
			sResult = ssTmp.str();
			fieldInfo.mComponent = _T('D'); //prevent processWidth to handle the output as string
		}

		//add padding zeros
		if( sResult.length() < nZeroPad + 1 )
			sResult.insert( static_cast<string_type::size_type>(0), static_cast<string_type::size_type>(nZeroPad + 1 - sResult.length()), _T('0') );
	}
	else if( fieldInfo.mModifier == _T("N") || fieldInfo.mModifier == _T("n") || fieldInfo.mModifier == _T("Nn"))
	{
		sResult = GetComponentNameValue( dtData, fieldInfo);
		if( fieldInfo.mModifier == _T("N") )
			std::transform( sResult.begin(), sResult.end(), sResult.begin(), toupper);
		else if ( fieldInfo.mModifier == _T("n") )
			std::transform( sResult.begin(), sResult.end(), sResult.begin(), tolower);
	}
	else
	{
		throw CAltovaException( 0, string_type(_T("Unknown format modifier: '")) + fieldInfo.mModifier + _T("'"));
	}

	return sResult;
}

string_type DateTimeFormatParser::ProcessWidth( const string_type& sValue, FieldInfo& fieldInfo) const
{
	if( fieldInfo.mWidth.empty() )
		return sValue;

	string_type sResult = sValue;
	fieldInfo.Analyze();

	string_type::size_type nLength = sResult.length();
	if( fieldInfo.mMaxWidth > 0 )
	{
		if( fieldInfo.mMaxWidth >= fieldInfo.mMinWidth )
		{
			if( nLength > fieldInfo.mMaxWidth )
			{
				if( fieldInfo.mComponent != _T('Y') )
					sResult = sResult.substr( 0, fieldInfo.mMaxWidth );
				else
					sResult = sResult.substr( nLength - fieldInfo.mMaxWidth );
			}
		}
	}

	if( fieldInfo.mMinWidth > nLength )
	{
		if( fieldInfo.mComponent != _T('F') ) // F day of week, is currently the only text and should be padded with ' '
			sResult.insert( static_cast<string_type::size_type>(0), static_cast<string_type::size_type>(fieldInfo.mMinWidth - sResult.length()), _T('0') );
		else
			sResult.insert( sResult.end(), static_cast<string_type::size_type>( fieldInfo.mMinWidth - sResult.length() ), _T(' ') );
	}

	return sResult;
}

string_type DateTimeFormatParser::GetComponentNameValue(
	const altova::DateTime& dtData,
	FieldInfo& fieldInfo) const
{
	string_type sValue;

	switch( fieldInfo.mComponent )
	{
		case _T('M'): 
			sValue = MonthNames\[dtData.Month() - 1\]; 
			fieldInfo.mComponent = _T('F'); //this allows the process width to handle the result as Text
		break;
		case _T('D'):
			sValue = DayNames\[ dtData.Weekday() \]; 
			fieldInfo.mComponent = _T('F'); //this allows the process width to handle the result as Text	
		break;
		default:
			sValue = GetComponentValue(dtData, fieldInfo.mComponent);
	}

	return sValue;
}

string_type DateTimeFormatParser::GetComponentValue(
	const altova::DateTime& dtData,
	const char_type cComponent) const
{
	tstringstream ssValue;

	switch( cComponent )
	{
		case _T('d'): ssValue << static_cast<long>( dtData.DayOfYear() ); break;
		case _T('D'): ssValue << static_cast<long>( dtData.Day() ); break;
		case _T('F'): ssValue << DayNames\[ dtData.Weekday() \]; break;
		case _T('M'): ssValue << static_cast<long>( dtData.Month() ); break;
		case _T('Y'): ssValue << static_cast<long>( dtData.Year() ); break;
		case _T('W'): ssValue << static_cast<long>( dtData.Weeknumber() ); break;
		case _T('w'): ssValue << static_cast<long>( dtData.WeekOfMonth() ); break;
		case _T('P'): ssValue << (dtData.Hour() < 12 ?_T("A.M.") : _T("P.M.")); break;
		case _T('H'): ssValue << static_cast<long>( dtData.Hour() ); break;
		case _T('h'): 
		{
			long h = static_cast<long>( dtData.Hour() );
			if (h > 12)
				h -= 12;
			else if (h == 0)
				h = 12;
			ssValue << h;
		}
		break;
		case _T('m'): 
		{
			tstringstream ssMin;
			ssMin << static_cast<long>( dtData.Minute() );
			string_type sMin = ssMin.str();
			if( sMin.length() < 2)
				sMin.insert( sMin.begin(), _T('0') );
			ssValue << sMin;
		}
		break;
		case _T('s'):
		{
			tstringstream ssSec;
			ssSec << static_cast<long>(dtData.Second());
			string_type sSec = ssSec.str();
			if( sSec.length() < 2)
				sSec.insert( sSec.begin(), _T('0') );
			ssValue << sSec;
		}
		break;
		case _T('f'):
		{
			short nSecs = static_cast<short>(dtData.Second());
			double nMilSecs = dtData.Second();
			nMilSecs -= nSecs;
			tstringstream ssTemp;
			ssTemp << std::setiosflags(std::ios_base::left);
			ssTemp << std::setiosflags(std::ios_base::showpoint);
			ssTemp << std::setprecision(3) << nMilSecs;
			tstring sTemp = ssTemp.str();
			sTemp.erase(sTemp.begin(), sTemp.begin() + 2);
			ssValue << std::setiosflags(std::ios_base::left) << std::setfill(_T('0')) << std::setw(3) << sTemp.substr(0, 3);
		}
		break;
		case _T('z'): if( dtData.HasTimezone() ) ssValue << _T("GMT");
		case _T('Z'):
		{
			if( dtData.HasTimezone() )
			{
				tstringstream sshour;
				sshour << static_cast<long> ( abs(dtData.Timezone() / 60) );
				tstringstream ssmins;
				ssmins << static_cast<long> ( abs(dtData.Timezone() % 60 ) );
				ssValue << (dtData.Timezone() >= 0 ? _T('+') : _T('-'));
				ssValue << (sshour.str().length() < 2 ? _T('0') + sshour.str() : sshour.str());
				ssValue << _T(':');
				ssValue << (ssmins.str().length() < 2 ? _T('0') + ssmins.str() : ssmins.str());
			}
		}
		break;
		default:
			throw CAltovaException( 0, string_type(_T("Unknown component specifier: '")) + cComponent + _T("'"));
	}
	return ssValue.str();
}

altova::DateTime DateTimeFormatParser::ParseDateTime(
	const string_type& sInputString) const
{
	string_type sPattern = m_sPattern;
	string_type sInput = sInputString;
	Lang::LeftTrim(sPattern);
	Lang::RightTrim(sPattern);
	ParseState state = k_NORMAL;
	ArgumentState argState = k_COMPONENT;
	FieldInfo fieldInfo;
	DateTimeData dt;

	string_type::size_type nLength = sPattern.length();
	for( string_type::size_type i = 0; i < nLength; ++i)
	{
		char_type cCurrent = sPattern\[i\];
		char_type cNext = i + 1 < nLength ? sPattern\[i + 1\] : 0;

		switch( state )
		{
		case k_NORMAL:
			{
				if( cCurrent == m_cFieldOpen )
				{
					if( cNext != m_cFieldOpen )
					{
						state = k_INFIELD;
						argState = k_COMPONENT;
						fieldInfo.Reset();
					}
					else
					{
						i++;
						if( cCurrent == sInput\[0\] )
						{
							sInput.erase(0, 1);
						}
						else
						{
							tstring sError = _T("Pattern not matching field opening '");
							sError += m_cFieldOpen;
							sError += _T("' doesn't match! Unable to read: ") + sInput;
							throw CAltovaException(
								0,
								sError
							);
						}
					}
				}
				else
				{
					if( cCurrent == sInput\[0\] )
					{
						sInput.erase(0, 1);
					}
					else
					{
						throw CAltovaException(
							0,
							_T("Pattern doesn't match! Unable to read: ") + sInput
						);
					}
				}
			}
			break;
		case k_INFIELD:
			{
				if( cCurrent == m_cFieldClose )
				{
					if( cNext != m_cFieldClose )
					{
						state = k_NORMAL;

						if( fieldInfo.mComponent > 0 )
						{
							//Analyze field read min and max width
							fieldInfo.Analyze();
							//Read the field from input and apply correct value
							ReadField( dt, fieldInfo, sInput, cNext);
						}
					}
					else
					{
						i++;
					}
				}
				else
				{
					switch( argState )
					{
					case k_COMPONENT:
						{
							fieldInfo.mComponent = cCurrent;
							argState = k_FORMAT;
						}
						break;
					case k_FORMAT:
						{
							if( cCurrent == _T(',') )
								argState = k_WIDTH;
							else
								fieldInfo.mModifier += cCurrent;
						}
						break;
					case k_WIDTH:
						{
							fieldInfo.mWidth += cCurrent;
						}
						break;
					}
				}
			}
			break;
		}
	}

	bool b2400 = dt.Hour == 24 && dt.Minute == 0 && dt.Second == 0;
	if (b2400)
		dt.Hour = 0;

	const unsigned* monthTable = altova::DateTime::IsLeapYear( dt.Year ) ? monthStartLeap : monthStart;
	if( dt.DayOfYear > 0 && dt.DayOfYear <= monthTable\[12\] )
	{
		unsigned int i = 12;
		while( monthTable\[i\] >= dt.DayOfYear ) i--;
		dt.Day = dt.DayOfYear - monthTable\[i\];
		dt.Month = i + 1;
	}

	altova::DateTime result = altova::DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second, dt.TimeZone);
	if (b2400)
	{
		__int64 v = result.Value();
		v += altova::TicksPerDay;
		result = altova::DateTime(v);
	}
	return result;
}

bool DateTimeFormatParser::StringToRead( const string_type& sModifier) const
{
	if( sModifier == _T("N") || sModifier == _T("n") || sModifier == _T("Nn") )
		return true;
	else
		return false;
}

long DateTimeFormatParser::ReadNumber( string_type& sInput, string_type::size_type nMax ) const
{
	long nNum;
	ReadNumberWithSize(sInput, nMax, nNum);
	return nNum;
}

long DateTimeFormatParser::ReadFieldNumber( string_type& sInput, FieldInfo& fieldinfo ) const
{
	long nNum;
	string_type sNumber;
	sInput = Lang::LeftTrim(sInput);
	string_type::size_type i = 0;
	string_type::size_type nMax = fieldinfo.mMaxWidth;

	nMax = nMax == 0 ? sInput.length() : nMax > sInput.length() ? sInput.length() : nMax;
	for (;i < nMax && _istdigit( sInput\[i\] ); ++i)
	{
		sNumber += sInput\[i\];
	}
	if( fieldinfo.mMinWidth > 0 && i < fieldinfo.mMinWidth )
	{
		tstring sError = _T("Pattern component '");
		sError += fieldinfo.mComponent;
		sError += _T("' has minimum length of ");
		sError += fieldinfo.mWidth.substr(0, fieldinfo.mMinusPos);
		sError += _T("! Unable to read: ") + sInput;
		throw CAltovaException(
			0,
			sError
			);
	}
	if( i > 0)
	{
		sInput.erase(0, i);
		tstringstream ssNumber;
		ssNumber.str( sNumber);
		ssNumber >> nNum;
	}
	else
	{
		nNum = 0;
	}

	return nNum;
}

size_t DateTimeFormatParser::ReadNumberWithSize( string_type& sInput, string_type::size_type nMax, long& nNumber ) const
{
	string_type sNumber;
	sInput = Lang::LeftTrim(sInput);
	string_type::size_type i = 0;

	nMax = nMax == 0 ? sInput.length() : nMax > sInput.length() ? sInput.length() : nMax;
	for (;i < nMax && _istdigit( sInput\[i\] ); ++i)
	{
		sNumber += sInput\[i\];
	}
	if( i > 0)
	{
		sInput.erase(0, i);
		tstringstream ssNumber;
		ssNumber.str( sNumber);
		ssNumber >> nNumber;
	}
	else
	{
		nNumber = 0;
	}
	return i;
}

string_type DateTimeFormatParser::ReadStringUntil( string_type& sInput, string_type::size_type nMax, char_type cUntil ) const
{
	string_type sRead;
	string_type::size_type i = 0;

	nMax = nMax == 0 ? sInput.length() : nMax > sInput.length() ? sInput.length() : nMax;
	for (;i < nMax && sInput\[i\] != cUntil; ++i)
	{
		sRead += sInput\[i\];
	}
	sInput.erase(0, i);

	return sRead;
}

void DateTimeFormatParser::ReadField(
	DateTimeData& dtData,
	FieldInfo& fieldinfo,
	string_type& sInput,
	char_type cNext) const
{
	string_type sInputBackup = sInput;
	switch( fieldinfo.mComponent )
	{
	case _T('d'): //day of the year
		{
			dtData.DayOfYear = static_cast<unsigned int>(ReadFieldNumber(sInput, fieldinfo));
		}
		break;

	case _T('D'):
		{
			if( !StringToRead(fieldinfo.mModifier) )
			{
				dtData.Day = static_cast<unsigned int>(ReadFieldNumber(sInput, fieldinfo));
			}
		}
		break;
	case _T('M'):
		{
			string_type sInputBackup = sInput;
			if( !StringToRead(fieldinfo.mModifier) )
			{
				dtData.Month = static_cast<unsigned int>(ReadFieldNumber(sInput, fieldinfo));
			}
			else
			{
				string_type sMonth = ReadStringUntil( sInput, fieldinfo.mMaxWidth, cNext);

				//find the month from the table
				unsigned int i = 0;
				string_type::size_type nMax = fieldinfo.mMaxWidth == 0 ? sMonth.length() : fieldinfo.mMaxWidth;
				while( i < 12 && Lang::StringCompareIgnoreCase(sMonth,(string_type(MonthNames\[i\]).substr(0, nMax))) ) i++;

				dtData.Month = i + 1;
			}

			if( dtData.Month > 12)
			{
				tstring sError = _T("Pattern component '");
				sError += fieldinfo.mComponent;
				sError += _T("' doesn't match! Unable to read: ") + sInputBackup;
				throw CAltovaException(
					0,
					sError
				);
			}
		}
		break;
	case _T('Y'):
		{
			dtData.Year = ReadFieldNumber(sInput, fieldinfo);
			if( fieldinfo.mMaxWidth == 2)
			{
				//change this in the year 2050;
				if( dtData.Year > 50)
					dtData.Year += 1900;
				else
					dtData.Year += 2000;
			}
		}
		break;
	case _T('P'):
		{
			string_type sPM = ReadStringUntil( sInput, 4, 0);
			dtData.Hour += !Lang::StringCompareIgnoreCase(sPM, _T("p.m.")) && dtData.Hour != 12 ? 12 : 0;
		}
		break;
	case _T('h'):
	case _T('H'):
		{
			dtData.Hour = static_cast<unsigned int>(ReadFieldNumber(sInput, fieldinfo));
		}
		break;
	case _T('m'):
		{
			dtData.Minute = static_cast<unsigned int>(ReadFieldNumber(sInput, fieldinfo));
		}
		break;
	case _T('s'):
		{
			dtData.Second = ReadFieldNumber(sInput, fieldinfo);
		}
		break;
	case _T('f'):
		{
			long nMilli;
			size_t nLength = ReadNumberWithSize(sInput, fieldinfo.mMaxWidth, nMilli);
			dtData.Second += nMilli / pow( 10.0f, static_cast<float>(nLength));
		}
		break;
	case _T('z'):
		{
			if( sInput.substr(0, 3) == _T("GMT") )
				sInput.erase( 0, 3);
			else
			{
				tstring sError = _T("Pattern component '");
				sError += fieldinfo.mComponent;
				sError += _T("' doesn't match! Unable to read: ") + sInput;
				throw CAltovaException(
					0,
					sError
				);
			}
		}
	case _T('Z'):
		{
			int nMinus = 1;
			if( sInput\[0\] == _T('-') )
				nMinus = -1;
			sInput.erase(0, 1);

			unsigned int nHour = static_cast<unsigned int>(ReadNumber(sInput, 2));

			if( sInput\[0\] != _T(':') )
			{
				//error
				tstring sError = _T("Pattern component '");
				sError += fieldinfo.mComponent;
				sError += _T("' doesn't match! Unable to read: ") + sInput;
				throw CAltovaException(
					0,
					sError
				);
			}
			else
				sInput.erase(0, 1);

			unsigned int nMinutes = static_cast<unsigned int>(ReadNumber(sInput, 2));

			dtData.TimeZone = (nHour * 60 + nMinutes) * nMinus;
		}
		break;
	case _T('i'):
	case _T('I'):
		{
			ReadStringUntil(sInput, fieldinfo.mMaxWidth, cNext);
		}
		break;
	default:
		throw CAltovaException(
			0,
			_T("Unknown component specifier! Please check pattern: ") + m_sPattern
		);
	}
}

} // namespace altova

