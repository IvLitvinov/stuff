[call GenerateFileHeader("DateTimeFormatParser.h")]
#ifndef __DATETIMEFORMATPARSER_H
#define __DATETIMEFORMATPARSER_H

#include "../Altova/AltovaMapforce.h"

namespace altova
{

class DateTimeFormatParser
{
private:
	class FieldInfo
	{
		public:
			FieldInfo() : mComponent(0), mWidth(_T("")), mModifier(_T("")), mMinWidth(0), mMaxWidth(0), mMinusPos(0) {}
			void Reset();
			bool Analyze();

			char_type mComponent;
			string_type mWidth;
			string_type mModifier;
			string_type::size_type mMinWidth;
			string_type::size_type mMaxWidth;
			string_type::size_type mMinusPos;
	};

	class DateTimeData
	{
	public:
		DateTimeData() :
		  Day(1), Month(1), Year(0), Hour(0),
			  Minute(0), Second(0.0), TimeZone(altova::DateTime::NO_TIMEZONE), DayOfYear(0)
		  {}

		  unsigned int Day;
		  unsigned int Month;
		  long Year;
		  unsigned int Hour;
		  unsigned int Minute;
		  double Second;
		  unsigned int TimeZone;

		  unsigned int DayOfYear; //this value is stored for later processing
	};

public:
	DateTimeFormatParser( const string_type& sPattern) : m_sPattern( sPattern), m_cFieldOpen( _T('\[') ), m_cFieldClose( _T('\]') )
	{ };

	string_type FormatDateTime(const altova::DateTime& dateTime) const;
	altova::DateTime ParseDateTime(
		const string_type& sInputString
		) const;


	static char_type* DayNames\[\];
	static char_type* MonthNames\[\];
	static const unsigned DateTimeFormatParser::monthStart\[13\];
	static const unsigned DateTimeFormatParser::monthStartLeap\[13\];


protected:
	string_type ProcessFormatModifier(
		const altova::DateTime& dateTime,
		const string_type& sValue,
		FieldInfo& fieldInfo) const;
	string_type ProcessWidth(
		const string_type& sValue,
		FieldInfo& fieldInfo) const;
	string_type GetComponentValue(
		const altova::DateTime& dtData,
		const char_type cComponent) const;
	string_type GetComponentNameValue(
		const altova::DateTime& dateTime,
		FieldInfo& fieldInfo) const;

	void ReadField(
		DateTimeData& dtData,
		FieldInfo& fieldinfo,
		string_type& sInput,
		char_type cNext) const;


	bool StringToRead( const string_type& sModifier) const;
	long ReadNumber( string_type& sInput, string_type::size_type nMax) const;
	long ReadFieldNumber( string_type& sInput, FieldInfo& fieldinfo) const;
	size_t ReadNumberWithSize( string_type& sInput, string_type::size_type nMax, long& nNumber ) const;
	string_type ReadStringUntil( string_type& sInput, string_type::size_type nMax, char_type cUntil) const;

private:
	enum ParseState {
		k_NORMAL = 0,
		k_INFIELD,
	};

	enum ArgumentState {
		k_COMPONENT = 0,
		k_FORMAT,
		k_WIDTH
	};

	string_type						m_sPattern;
	const char_type					m_cFieldOpen;
	const char_type					m_cFieldClose;

};

}

#endif // __DATETIMEFORMATPARSER_H

