[call GenerateFileHeader("DecimalFormatParser.cpp")]
#include "stdafx.h"

#include "DecimalFormatParser.h"

#include "Lang.h"
#include <sstream>
#include <float.h>

namespace altova
{

string_type RoundHalfUp( const double fvalue, const int precision )
{
	tstringstream numstream;
	numstream << std::fixed << fvalue;
	string_type result( numstream.str() );

	bool bNegativ = result\[0\] == _T('-');
	if( bNegativ )
		result.erase(0, 1);
	string_type::size_type nDecPos = result.find( _T('.') );

	if( nDecPos != string_type::npos )
	{
		string_type::size_type nLength = result.length();
		if( nDecPos + precision + 1< nLength)
		{
			int i = static_cast<int>(nDecPos + precision + 1);
			bool bCarry = false;
			result.erase(i + 1, nLength - (i + 1)); //remove everything after precision + 1
			
			bCarry = result\[i\] >= _T('5');
			result\[i\] = _T('0');
			i--;

			while( bCarry && i >= 0 )
			{
				if( result\[i\] != _T('.') )
				{
					if( bCarry = ( result\[i\] == _T('9') ) )
						result\[i\] = _T('0');
					else
						result\[i\] += 1;
				}
				i--;
			}
			string_type::size_type pos = result.find_last_not_of( _T('0') );
			if( result.at(pos) == _T('.') ) pos--; //remove the unnecessary .
			if( pos != string_type::npos && (pos + 1) < result.size())
				result.erase( pos + 1);
			if( i < 0 && bCarry)
				result.insert( static_cast<string_type::size_type>(0), static_cast<string_type::size_type>(1), _T('1') );
		}
	}
	if( bNegativ )
		result.insert(static_cast<string_type::size_type>(0), static_cast<string_type::size_type>(1), _T('-') );
	return result;
}

DecimalFormat::DecimalFormat()
{
	m_sName = _T("");

	// decimal-separator specifies the character used for the decimal sign; the default value is the period character (.)
	m_cDecimalSeparator = _T('.');

	// grouping-separator specifies the character used as a grouping (e.g. thousands) separator; the default value is the comma character (,)
	m_cGroupingSeparator = _T(',');

	// percent specifies the character used as a percent sign; the default value is the percent character (%)
	m_cPercent = _T('%');

	// per-mille specifies the character used as a per mille sign; the default value is the Unicode per-mille character (#x2030)
#ifdef _UNICODE
	m_cPerMille = 0x2030;
#else
	m_cPerMille = '?';
#endif

	// zero-digit specifies the character used as the digit zero; the default value is the digit zero (0)
	m_cZeroDigit = _T('0');

	// The following attributes control the interpretation of characters in the format pattern:

	// digit specifies the character used for a digit in the format pattern; the default value is the number sign character (#)
	m_cDigit = _T('#');

	// pattern-separator specifies the character used to separate positive and negative sub patterns in a pattern; the default value is the semi-colon character (;)
	m_cPatternSeparator = _T(';');

	// The following attributes specify characters or strings that may appear in the result of formatting the number:

	// infinity specifies the string used to represent infinity; the default value is the string Infinity 
	m_sInfinity = _T("Infinity");

	// NaN specifies the string used to represent the NaN value; the default value is the string NaN 
	m_sNaN = _T("NaN");

	// minus-sign specifies the character used as the default minus sign; the default value is the hyphen-minus character (-, #x2D)
	m_cMinusSign = _T('-');
}

DecimalFormat::~DecimalFormat()
{

}

const DecimalFormat& DecimalFormat::operator=( const DecimalFormat& rRight )
{
	if ( &rRight != this )
	{
		m_sName					= rRight.m_sName;
		m_cDecimalSeparator		= rRight.m_cDecimalSeparator;
		m_cGroupingSeparator	= rRight.m_cGroupingSeparator;
		m_sInfinity				= rRight.m_sInfinity;
		m_cMinusSign			= rRight.m_cMinusSign;
		m_sNaN					= rRight.m_sNaN;
		m_cPercent				= rRight.m_cPercent;
		m_cPerMille				= rRight.m_cPerMille;
		m_cZeroDigit			= rRight.m_cZeroDigit;
		m_cDigit				= rRight.m_cDigit;
		m_cPatternSeparator		= rRight.m_cPatternSeparator;
	}

	return *this;
}

bool DecimalFormat::operator==( const DecimalFormat& rRight ) const
{
	if ( m_sName != rRight.m_sName )
	{
		return false;
	}
	else if ( m_cDecimalSeparator != rRight.m_cDecimalSeparator )
	{
		return false;
	}
	else if ( m_cGroupingSeparator != rRight.m_cGroupingSeparator )
	{
		return false;
	}
	else if ( m_sInfinity != rRight.m_sInfinity )
	{
		return false;
	}
	else if ( m_cMinusSign != rRight.m_cMinusSign )
	{
		return false;
	}
	else if ( m_sNaN != rRight.m_sNaN )
	{
		return false;
	}
	else if ( m_cPercent != rRight.m_cPercent )
	{
		return false;
	}
	else if ( m_cPerMille != rRight.m_cPerMille )
	{
		return false;
	}
	else if ( m_cZeroDigit != rRight.m_cZeroDigit )
	{
		return false;
	}
	else if ( m_cDigit != rRight.m_cDigit )
	{
		return false;
	}
	else if ( m_cPatternSeparator != rRight.m_cPatternSeparator )
	{
		return false;
	}

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
// pattern    := subpattern{;subpattern}
bool DecimalFormatParser::Pattern( string_type& sExpr, bool bTrim )
{
	if( bTrim )
	{
		sExpr = Lang::LeftTrim(sExpr);
	}
	if ( sExpr.empty() )
		return false;

	m_sPrefixText = _T("");
	m_sSuffixText = _T("");

	if( !SubPattern( sExpr ) )
		return false;
	
	if( bTrim )
	{
		m_sSuffixText = Lang::LeftTrim(m_sSuffixText);
	}

	if( !sExpr.empty() )
	{
		if( sExpr\[0\] == m_DecimalFormat.GetPatternSeparator() )
			sExpr = sExpr.substr(1);
		else
			return true;

		m_bNegativePattern = true;
		m_pFormat = &m_oNegativeFormat;

		if( bTrim )
		{
			sExpr = Lang::LeftTrim(sExpr);
			sExpr = Lang::RightTrim(sExpr);
		}
		return SubPattern( sExpr );
	}

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
// subpattern := {prefix}integer{.fraction}{suffix}
bool DecimalFormatParser::SubPattern( string_type& sExpr )
{					
	if ( sExpr.empty() )
		return false;

	PrefixText( sExpr );	

	Prefix( sExpr );
	
	if( !Integer( sExpr ) )
		return false;

	if( !sExpr.empty() && sExpr\[0\] == m_DecimalFormat.GetDecimalSeparator() )
	{
		m_pFormat->m_bDecimalSeperator = true;

		sExpr = sExpr.substr(1);

		if( !Fraction( sExpr ) )
			return false;
	}
	
	Suffix( sExpr );
	SuffixText( sExpr );

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::Prefix( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	if ( sExpr\[0\] == m_DecimalFormat.GetPercent() ) 
	{
		sExpr = sExpr.substr(1);
		m_pFormat->m_bPrefix = true;
		m_pFormat->m_bPercent = true;
		m_pFormat->m_bPerMille = false;
		return true;
	}
	else if ( sExpr\[0\] == m_DecimalFormat.GetPerMille() ) 
	{
		sExpr = sExpr.substr(1);
		m_pFormat->m_bPrefix = true;
		m_pFormat->m_bPercent = false;
		m_pFormat->m_bPerMille = true;
		return true;
	}

	return false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::PrefixText( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	bool bInQuotes = false;
	string_type::size_type i = 0;
	string_type::size_type nLength = sExpr.length();
	while ( ( i < nLength ) && ( bInQuotes || NotSpecialChar(sExpr\[i\]) || AddMinusSignIfAllowed(sExpr\[i\]) ) )
	{
		if ( sExpr\[i\] == _T('\\'') )
		{
			i++;
			
			if ( i < nLength )
			{
				bInQuotes = !bInQuotes;
				break;
			}
			else if ( sExpr\[i\] != _T('\\'') )
				bInQuotes = !bInQuotes;
		}
		
		if( m_bNegativePattern )
			m_sNegPrefixText += sExpr\[i\];
		else
			m_sPrefixText += sExpr\[i\];

		i++;
	}
	
	sExpr = sExpr.substr(i);
	return !bInQuotes;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::Integer( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	char_type cLast = m_DecimalFormat.GetZeroDigit();

	// how many Non Zero Digits
	string_type::size_type i = 0;
	string_type::size_type nLength = sExpr.length();
	while ( ( i < nLength ) && ( ( sExpr\[i\] == m_DecimalFormat.GetDigit() ) || ( sExpr\[i\] == m_DecimalFormat.GetGroupingSeparator() ) ) )
	{
		if ( sExpr\[i\] == m_DecimalFormat.GetGroupingSeparator() )
		{
			m_pFormat->m_nGroupSpace = 0;
			m_pFormat->m_bGroup = true;
		}
		else
		{
			m_pFormat->m_nGroupSpace++;
			m_pFormat->m_nNonZeroDigits++;
		}

		cLast = sExpr\[i\];
		i++;
	}

	/* java 1.1.8  needs this but every implementation allows formating without specifying the minlength 
	if ( ( **pszExpr != 0 ) && ( **pszExpr != m_pDecimalFormat->GetZeroDigit() ) )
	{
		return false;
	}*/

	// how many Zero Digits
	while ( ( i < nLength ) && ( ( sExpr\[i\] == m_DecimalFormat.GetZeroDigit() ) || ( sExpr\[i\] == m_DecimalFormat.GetGroupingSeparator() ) ))
	{
		if ( sExpr\[i\] == m_DecimalFormat.GetGroupingSeparator() )
		{
			m_pFormat->m_nGroupSpace = 0;
			m_pFormat->m_bGroup = true;
		}
		else
		{
			m_pFormat->m_nGroupSpace++;
			m_pFormat->m_nZeroDigits++;
		}

		cLast = sExpr\[i\];

		i++;
	}
	sExpr = sExpr.substr(i);

	if ( cLast == m_DecimalFormat.GetGroupingSeparator() ) 
		return false;
	else
		return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::Fraction( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	// how many Zero Digits in the fraction
	string_type::size_type i = 0;
	string_type::size_type nLength = sExpr.length();
	while ( ( i < nLength ) && ( sExpr\[i\] == m_DecimalFormat.GetZeroDigit() ) )
	{
		m_pFormat->m_nZeroDigitsFraction++;
		i++;
	}

	// how many Non Zero Digits
	while ( ( i < nLength ) && ( sExpr\[i\] == m_DecimalFormat.GetDigit() ) )
	{
		m_pFormat->m_nNonZeroDigitsFraction++;
		i++;
	}
	sExpr = sExpr.substr(i);

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::Suffix( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	if( sExpr\[0\] > 0xFFFD )
		return false;

	if ( sExpr\[0\] == m_DecimalFormat.GetPercent() ) 
	{
		sExpr.erase(0, 1);
		m_pFormat->m_bSuffix = true;
		m_pFormat->m_bPercent = true;
		m_pFormat->m_bPerMille = false;
		return true;
	}
	else if ( sExpr\[0\] == m_DecimalFormat.GetPerMille() ) 
	{
		sExpr.erase(0, 1);
		m_pFormat->m_bSuffix = true;
		m_pFormat->m_bPercent = false;
		m_pFormat->m_bPerMille = true;
		return true;
	}

	return false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////
bool DecimalFormatParser::SuffixText( string_type& sExpr )
{
	if ( sExpr.empty() )
		return false;

	bool bInQuotes = false;
	string_type::size_type i = 0;
	string_type::size_type nLength = sExpr.length();
	while ( ( i < nLength ) && ( bInQuotes || NotSpecialChar( sExpr\[i\] ) || AddMinusSignIfAllowed( sExpr\[i\] ) ) )
	{
		if ( sExpr\[i\] == _T('\\'') )
		{
			i++;
			
			if ( i < nLength )
			{
				bInQuotes = !bInQuotes;
				break;
			}
			else if ( sExpr\[i\] != _T('\\'') )
			{
				bInQuotes = !bInQuotes;
			}
		}
		if( m_bNegativePattern )
			m_sNegSuffixText += sExpr\[i\];
		else
			m_sSuffixText += sExpr\[i\];
		i++;
	}
	sExpr = sExpr.substr(i);
	return !bInQuotes;
}

bool	DecimalFormatParser::NotSpecialChar( const char_type& cChar ) const
{
	if ( cChar == m_DecimalFormat.GetDecimalSeparator() )		return false;
	else if ( cChar == m_DecimalFormat.GetDigit() )			return false;
	else if ( cChar == m_DecimalFormat.GetGroupingSeparator())return false;
	else if ( cChar == m_DecimalFormat.GetMinusSign() )		return false;
	else if ( cChar == m_DecimalFormat.GetPatternSeparator() )return false;
	else if ( cChar == m_DecimalFormat.GetZeroDigit() )		return false;
	else if ( cChar == m_DecimalFormat.GetPercent() )			return false;
	else if ( cChar == m_DecimalFormat.GetPerMille() )		return false;

	return true;
}

const string_type DecimalFormatParser::FormatNumber( double nNumber )
{
	string_type sFormat = _T("");

	//this needs to be rewritten for codegens
	switch( _fpclass( nNumber ) ) 
	{
		case _FPCLASS_SNAN:
		case _FPCLASS_QNAN:
			return m_DecimalFormat.GetNaN();
		case _FPCLASS_NINF:
			sFormat = m_DecimalFormat.GetMinusSign() + m_DecimalFormat.GetInfinity();
			return sFormat;
		case _FPCLASS_PINF:
			sFormat = m_DecimalFormat.GetInfinity();
			return sFormat;
	}

	// \[HRS\] Migrating and reproducing original functionality.
	// But shouldn't it be a test for a numeric character?
	//TODO
	//if ( ICUnicode::IsLetter( m_pDecimalFormat->GetZeroDigit() ) )
	//{
	//	m_nDigitTranslation = m_pDecimalFormat->GetZeroDigit() - _T('0');
	//}
	//else
	{
		m_nDigitTranslation = 0;
	}
	
	if ( m_pFormat->m_bPercent )
		nNumber *= 100;
	else if ( m_pFormat->m_bPerMille )
		nNumber *= 1000;

	if ( ( nNumber < 0.0 ) && m_bNegativePattern )
		m_pFormat = &m_oNegativeFormat;
	else
		m_pFormat = &m_oPositiveFormat;

	m_pFormat->m_cDecimal = 0;
	m_pFormat->m_cSign = 0;

	string_type::size_type iSign = 0;
	int iDecimalPos = -1;

	string_type sRight;
	string_type sLeft;

	string_type sNumber = RoundHalfUp( nNumber, m_pFormat->m_nZeroDigitsFraction + m_pFormat->m_nNonZeroDigitsFraction);

	string_type::size_type decPos = sNumber.find( _T('.') );
	if( decPos != string_type::npos )
	{
		sNumber.erase( decPos, 1);
		iDecimalPos = static_cast<int>(decPos);
	}
	else
	{
		if( sNumber == _T("0") || sNumber == _T("-0") )
			iDecimalPos = 0;
		else
			iDecimalPos = static_cast<int>(sNumber.length());
	}

	if( nNumber < 0.0)
	{
		iSign = sNumber.find( _T('-') );
		if ( iSign != string_type::npos )
		{
			sNumber.erase(iSign, 1);
			iSign = 1;
			iDecimalPos--;
		}
	}
	else
		iSign = 0;

	if ( iDecimalPos <= 0 )
	{
		// add preceding number of 0s
		int iAbsDecimalPos = abs( iDecimalPos );
		sRight.assign( iAbsDecimalPos, _T('0') );

		sRight += sNumber;
	}
	else
	{
		sLeft = sNumber.substr( 0, iDecimalPos );
		sRight = sNumber.substr( iDecimalPos );
	}

	// remove extra zero padding off the end
	string_type::size_type nLastZero = sRight.find_last_not_of( _T("0") ) + 1;
	if( nLastZero != -1 && nLastZero < sRight.length())
		sRight = sRight.substr( 0, nLastZero );

	// now add correct amount
	string_type::size_type iRightLen = sRight.length();
	if ( iRightLen < m_pFormat->m_nZeroDigitsFraction )
		sRight.insert( sRight.length(), m_pFormat->m_nZeroDigitsFraction - iRightLen, _T('0'));

	// prefix zero padding if needed
	sLeft = Lang::LeftTrim( sLeft, _T("0") );
	string_type::size_type iLeftLen = sLeft.length();
	if ( iLeftLen < m_pFormat->m_nZeroDigits )
		sLeft.insert( static_cast<string_type::size_type>(0),  static_cast<string_type::size_type>(m_pFormat->m_nZeroDigits - iLeftLen), _T('0'));

	if ( sLeft.empty() && sRight.empty() )
		sLeft = _T("0");

	// translate left and right sides
	string_type::size_type i = 0;
	for( i = 0; i < sLeft.length(); ++i)
		sLeft\[i\] += ( char_type )m_nDigitTranslation;

	for( i = 0; i < sRight.length(); ++i)
		sRight\[i\] += ( char_type )m_nDigitTranslation;
	
	// do the grouping, ','
	if ( ( m_pFormat->m_bGroup ) && ( m_pFormat->m_nGroupSpace > 0 ) && ( sLeft.length() > m_pFormat->m_nGroupSpace ) )
	{
		string_type sTemp;
		char_type cFormat = m_DecimalFormat.GetGroupingSeparator();

		string_type::size_type niLeftPos = 0;
		long nFirstGroupPos = sLeft.length() % m_pFormat->m_nGroupSpace;
		
		if ( nFirstGroupPos > 0 )
		{
			sTemp = sLeft.substr( 0, nFirstGroupPos );
			niLeftPos = nFirstGroupPos;
			sTemp += cFormat;
		}

		while( niLeftPos < sLeft.length() )
		{
			sTemp += sLeft.substr( niLeftPos, m_pFormat->m_nGroupSpace );
			niLeftPos += m_pFormat->m_nGroupSpace;

			if ( niLeftPos < sLeft.length() )
				sTemp += cFormat;
		}
		sLeft = sTemp;
	}

	// start to assemble the string in sFormat
	sFormat = _T("");

	// add the sign
	if ( !m_bNegativePattern && ( iSign != 0 ) )
		sFormat = m_DecimalFormat.GetMinusSign();

	// add the prefix
	if ( m_pFormat->m_bPrefix )
	{
		if ( m_pFormat->m_bPercent )
			sFormat += m_DecimalFormat.GetPercent();
		else if ( m_pFormat->m_bPerMille )
			sFormat += m_DecimalFormat.GetPerMille();
	}

	// prefix text
	if ( ( nNumber >= 0.0 ) || !m_bNegativePattern )
		sFormat += m_sPrefixText;
	else
		sFormat += m_sNegPrefixText;

	// add the left side
	sFormat += sLeft;
	
	if ( m_pFormat->m_bDecimalSeperator && !sRight.empty() )
		sFormat += m_DecimalFormat.GetDecimalSeparator() + sRight;

	// add the suffix
	if ( m_pFormat->m_bSuffix )
	{
		if ( m_pFormat->m_bPercent )
			sFormat += m_DecimalFormat.GetPercent();
		else if ( m_pFormat->m_bPerMille )
			sFormat += m_DecimalFormat.GetPerMille();
	}

	// suffix text
	if ( ( nNumber >= 0.0 ) || !m_bNegativePattern )
		sFormat += m_sSuffixText;
	else
		sFormat += m_sNegSuffixText;

	// if the zero digit or digit symbol is alpha translate the string

	return sFormat;
}

double DecimalFormatParser::ParseNumber( const string_type& sInput )
{
	double decimal;
	string_type sReadInput = sInput;
	string_type sUsedPrefixText = m_sPrefixText;
	string_type sUsedSuffixText = m_sSuffixText;
	bool bIsNegative;
	sReadInput = Lang::RightTrim(Lang::LeftTrim(sReadInput));

	m_pFormat = &m_oPositiveFormat;
	if( bIsNegative = IsNegativeNumber(sReadInput) )
	{
		if( m_bNegativePattern )
		{
			sUsedPrefixText = m_sNegPrefixText;
			sUsedSuffixText = m_sNegSuffixText;
			m_pFormat = &m_oNegativeFormat;
		}
	}

	if( !sUsedPrefixText.empty() )
	{
		if( sReadInput.substr(0, sUsedPrefixText.length()) == sUsedPrefixText )
			sReadInput.erase(0, sUsedPrefixText.length() );
		else
			throw CAltovaException(
				0,
				_T("Prefix doesn't match: '") + sUsedPrefixText + _T("'")
			);
	}

	if( !sUsedSuffixText.empty() )
	{
		if( sReadInput.substr(sReadInput.length() - sUsedSuffixText.length()) == sUsedSuffixText )
			sReadInput.erase( sReadInput.length() - sUsedSuffixText.length(), sUsedSuffixText.length() );
		else
			throw CAltovaException(
				0,
				_T("Suffix doesn't match: '") + sUsedSuffixText + _T("'")
			);
	}

	if( m_pFormat->m_bGroup )
	{
		sReadInput = Lang::Replace(sReadInput, string_type(1, m_DecimalFormat.GetGroupingSeparator()), _T(""));
	}

	//check if rest of string a valid number
	tstringstream testStream;
	double nNum = 0.0;
	testStream.str(sReadInput);
	if( testStream >> nNum )
	{
		string_type sRest;
		testStream >> sRest;

		if( !sRest.empty() )
			throw CAltovaException(
				0,
				_T("Value is not a number: '") + sReadInput + _T("'")
			);
		else
			decimal = nNum;
	}
	else
		throw CAltovaException(
			0,
			_T("Value is not a number: '") + sReadInput + _T("'")
		);

	if( bIsNegative && decimal >= 0.0f )
		decimal *= -1.0f;
	return decimal;
}

bool DecimalFormatParser::IsNegativeNumber(const string_type& sNumber) const
{
	if( !m_sNegPrefixText.empty() && sNumber.substr(0, m_sNegPrefixText.length()) == m_sNegPrefixText )
	{
		if( !m_sNegSuffixText.empty()
			&& sNumber.substr(sNumber.length() - m_sNegSuffixText.length()) == m_sNegSuffixText )
				return true;
	}
	else if( !m_sPrefixText.empty() && sNumber.substr(0, m_sPrefixText.length()) == m_sPrefixText )
	{
		if( sNumber.find( m_DecimalFormat.GetMinusSign(), m_sPrefixText.length() ) != string_type::npos )
			return true;
		else
			return false;
	}
	else if( sNumber.find( m_DecimalFormat.GetMinusSign() ) != string_type::npos )
		return true;

	return false;
}

bool DecimalFormatParser::AddMinusSignIfAllowed( char_type cCurrent )
{
	if ( ( m_bHasMinusSign == false )
		&& ( cCurrent == m_DecimalFormat.GetMinusSign() ) )
	{
		m_bHasMinusSign = m_bNegativePattern;
		return true;
	}
	return false;
}

}

