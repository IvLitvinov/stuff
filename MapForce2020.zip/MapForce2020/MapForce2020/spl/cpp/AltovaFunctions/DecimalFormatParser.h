[call GenerateFileHeader("DecimalFormatParser.h")]
#ifndef __DECIMALFORMATPARSER_H
#define __DECIMALFORMATPARSER_H

#include "../Altova/AltovaMapforce.h"

namespace altova
{

class DecimalFormat
{
public:

	DecimalFormat();
	virtual ~DecimalFormat();

	const string_type GetName() const {	return m_sName;	}
	void SetName( const char_type* szName ) {	m_sName = szName; }

	char_type GetDecimalSeparator() const {	return m_cDecimalSeparator;	}
	void SetDecimalSeparator( char_type cDecimalSeparator ) 
		{ m_cDecimalSeparator = cDecimalSeparator; }

	char_type GetGroupingSeparator() const {	return m_cGroupingSeparator; }
	void SetGroupingSeparator( char_type cGroupingSeparator )
		{ m_cGroupingSeparator = cGroupingSeparator; }

	const string_type GetInfinity() const { return m_sInfinity; }
	void SetInfinity( const char_type* szInfinity )
		{ m_sInfinity = szInfinity; }

	char_type GetMinusSign() const { return m_cMinusSign; }
	void SetMinusSign( char_type cMinusSign )
		{ m_cMinusSign = cMinusSign; }

	const string_type GetNaN() const { return m_sNaN; }
	void SetNaN( const char_type* szNaN ) { m_sNaN = szNaN; }

	char_type GetPercent()	const { return m_cPercent; }
	void SetPercent( char_type cPercent ) { m_cPercent = cPercent; }

	char_type GetPerMille() const { return m_cPerMille; }
	void SetPerMille( char_type cPerMille ) { m_cPerMille = cPerMille;	}

	char_type GetZeroDigit() const { return m_cZeroDigit; }
	void SetZeroDigit( char_type cZeroDigit ) { m_cZeroDigit = cZeroDigit; }

	char_type GetDigit() const { return m_cDigit; }
	void SetDigit( char_type cDigit ) { m_cDigit = cDigit; }

	char_type GetPatternSeparator() const { return m_cPatternSeparator; }
	void SetPatternSeparator( char_type cPatternSeparator ) 
		{ m_cPatternSeparator = cPatternSeparator; }

	bool HasDistinctValues() const
	{
		if ( m_cDecimalSeparator == m_cGroupingSeparator || m_cDecimalSeparator == m_cPercent ||
			m_cDecimalSeparator == m_cPerMille || m_cDecimalSeparator == m_cZeroDigit ||
			m_cDecimalSeparator == m_cDigit || m_cDecimalSeparator == m_cPatternSeparator )
		{
			return false;
		}
		else if ( m_cGroupingSeparator == m_cPercent || m_cGroupingSeparator == m_cPerMille ||
			m_cGroupingSeparator == m_cZeroDigit || m_cGroupingSeparator == m_cDigit ||
			m_cGroupingSeparator == m_cPatternSeparator )
		{
			return false;
		} 
		else if ( m_cPercent == m_cPerMille || m_cPercent == m_cZeroDigit || m_cPercent == m_cDigit ||
			m_cPercent == m_cPatternSeparator )
		{
			return false;
		}
		else if ( m_cPerMille == m_cZeroDigit || m_cPerMille == m_cDigit || m_cPerMille == m_cPatternSeparator )
		{
			return false;
		}
		else if ( m_cZeroDigit == m_cDigit || m_cZeroDigit == m_cPatternSeparator )
		{
			return false;	
		}
		else if ( m_cDigit == m_cPatternSeparator )
		{
			return false;
		}
		return true;
	}

	const DecimalFormat& operator=( const DecimalFormat& rRight );
	bool operator==( const DecimalFormat& rRight ) const;

protected:

	string_type			m_sName;					// = qname 
	char_type				m_cDecimalSeparator;		// = char 
	char_type				m_cGroupingSeparator;		// = char 
	string_type			m_sInfinity;				// = string 
	char_type				m_cMinusSign;				// = char 
	string_type			m_sNaN;						// = string 
	char_type				m_cPercent;					// = char 
	char_type				m_cPerMille;				// = char 
	char_type				m_cZeroDigit;				// = char 
	char_type				m_cDigit;					// = char 
	char_type				m_cPatternSeparator;		// = char
};

class DecimalFormatParser
{
public:
	DecimalFormatParser( const DecimalFormat& rFormat) : m_DecimalFormat( rFormat)
	{ 
		m_bNegativePattern = false;
		m_bHasMinusSign = false;
	};

	bool SetPattern ( const string_type& sExpr, bool bTrim = false )
	{
		string_type sPattern = sExpr;

		m_sPrefixText = _T("");
		m_sSuffixText = _T("");
		m_sNegPrefixText = _T("");
		m_sNegSuffixText = _T("");

		m_oNegativeFormat.Reset();
		m_oPositiveFormat.Reset();
		m_bNegativePattern = false;

		m_pFormat = &m_oPositiveFormat;

		bool bRet = Pattern( sPattern, bTrim );

		if ( !sPattern.empty() )
			bRet = false;

		return bRet;
	}

	const string_type FormatNumber ( double nNumber );
	double ParseNumber( const string_type& sInput );

	const string_type& GetPrefixText() { return m_sPrefixText; }
	const string_type& GetSuffixText() { return m_sSuffixText;	}

protected:
	bool AddMinusSignIfAllowed(char_type cCurrent);
	bool IsNegativeNumber(const string_type& sNumber) const;

	class Format
	{
	public:

		Format()
		{
			Reset();
		}

		void Reset()
		{
			m_bPrefix = false;
			m_bSuffix = false;
			m_bDecimalSeperator = false;
			m_nNonZeroDigits = 0;			// #
			m_nZeroDigits = 0;				// 0
			m_nNonZeroDigitsFraction = 0;	// #
			m_nZeroDigitsFraction = 0;		// 0
			m_nGroupSpace = 0;				// ,
			m_bGroup = false;
			m_cDecimal = _T('.');
			m_cSign = _T('-');
			m_bPercent = false;
			m_bPerMille = false;
		}

		bool m_bPrefix;
		bool m_bSuffix;
		bool m_bDecimalSeperator;
		long m_nNonZeroDigits;			// #
		unsigned long m_nZeroDigits;	// 0
		long m_nNonZeroDigitsFraction;	// #
		unsigned long m_nZeroDigitsFraction;		// 0
		unsigned long m_nGroupSpace;	// ,
		bool m_bGroup;
		char_type m_cSuffix;
		char_type m_cDecimal;
		char_type m_cSign;
		bool m_bPercent;
		bool m_bPerMille;
	};

	bool	Pattern				( string_type& sExpr, bool bTrim );
	bool	SubPattern			( string_type& sExpr );
	bool	Prefix				( string_type& sExpr );
	bool	PrefixText			( string_type& sExpr );
	bool	Suffix				( string_type& sExpr );
	bool	SuffixText			( string_type& sExpr );
	bool	Integer				( string_type& sExpr );
	bool	Fraction			( string_type& sExpr );
	bool	NotSpecialChar		( const char_type& cChar ) const;

	Format					m_oPositiveFormat;
	Format					m_oNegativeFormat;
	Format*					m_pFormat;

	bool					m_bNegativePattern;
	bool					m_bHasMinusSign;
	DecimalFormat			m_DecimalFormat;

	string_type				m_sPrefixText;
	string_type				m_sSuffixText;
	string_type				m_sNegPrefixText;
	string_type				m_sNegSuffixText;
	long					m_nDigitTranslation;
};

}

#endif // __DECIMALFORMATPARSER_H
