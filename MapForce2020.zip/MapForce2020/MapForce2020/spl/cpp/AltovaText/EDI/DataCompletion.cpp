[call GenerateFileHeader("DataCompletion.cpp")]
#include "StdAfx.h"
#include "DataCompletion.h"
#include "TextNode.h"

namespace altova
{
namespace text
{
namespace edi
{

CDataCompletion::CDataCompletion(const CTextDocument& rDocument, const tstring& structurename, bool completeSingleValues)
:	m_rDocument(rDocument)
,	m_StructureName(structurename)
,	m_bCompleteSingleValues(completeSingleValues)
{}

CTextNode* CDataCompletion::MakeSureExists(CTextNode& parent, const tstring& name, ENodeClass cl)
{
	CTextNodeContainer* children= parent.GetChildren();
	CTextNode* result = children->GetFirstNodeByName(name);

	if (result == NULL)
	{
		//create also appends to parent
		result = CTextNodeFactory::GetInstance().Create(&parent, name);

		if (cl != Undefined)
			result->SetClass(cl);
		else if ((name == _T("GS")) ||
			(name == _T("GE")) ||
			(name == _T("ST")) ||
			(name == _T("SE")))
			result->SetClass(Segment);
		else if ((3 == name.length()) && (name\[0\]==_T('I')))
			result->SetClass(Segment);
		else if (name\[0\]==_T('F'))
			result->SetClass(DataElement);
		else if (name\[0\]==_T('S'))
			result->SetClass(Composite);
		else if ((name\[0\]==_T('U')) && (3==name.size()))
			result->SetClass(Segment);
		else
			result->SetClass(Group);
	}
	return result;
}

CTextNode* CDataCompletion::MakeSureExists(CTextNode* parent, const tstring& name, ENodeClass cl)
{
	return MakeSureExists(*parent, name, cl);
}

CTextNode* CDataCompletion::GetKid(CTextNode& parent, const tstring& name)
{
	CTextNodeContainer tmp;
	parent.GetChildren()->FilterByName(name, tmp);
	return tmp.GetAt(0);
}

bool CDataCompletion::HasKid(CTextNode& parent, const tstring& name)
{
	CTextNodeContainer tmp;
	parent.GetChildren()->FilterByName(name, tmp);
	return (0<tmp.GetCount());
}

bool CDataCompletion::HasKid(CTextNode* parent, const tstring& name)
{
	return HasKid(*parent, name);
}

void CDataCompletion::ConservativeSetValue(CTextNode* node, CTextNode* sourceNode)
{
	ConservativeSetValue(node, sourceNode ? sourceNode->GetValue() : _T(""));
}

void CDataCompletion::ConservativeSetValue(CTextNode* node, const tstring& value)
{
	if (node && 0 == node->GetValue().length())
		node->SetValue(value);
}

void CDataCompletion::ConservativeSetValue(CTextNode* node, TCHAR value)
{
	if (node && 0 == node->GetValue().length())
	{
		tstring newvalue = node->GetValue();
		newvalue += value;
		node->SetValue(newvalue);
	}
}
void CDataCompletion::ConservativeSetValue(CTextNode* node, size_t value)
{
	if (node && 0 == node->GetValue().length())
	{
		tstringstream tmp;
		tmp << value;
		node->SetValue(tmp.str());
	}
}
namespace Functors
{
	class SegmentCountingFunctor
	{
	public:
		SegmentCountingFunctor()
			:	m_Count(0)
		{}
		size_t GetCount() const
		{
			return m_Count;
		}
	public:
		void operator() (CTextNode* node)
		{
			if (Segment==node->GetClass())
				++m_Count;
			node->GetChildren()->ApplyToAll(*this);
		}
	private:
		size_t m_Count;
	};
}

size_t CDataCompletion::GetSegmentChildrenCount(CTextNode& node)
{
	Functors::SegmentCountingFunctor functor;
	node.GetChildren()->ApplyToAll(functor);
	return functor.GetCount();
}

size_t CDataCompletion::GetNamedChildrenCount(CTextNode& node, const tstring& name)
{
	CTextNodeContainer tmp;
	node.GetChildren()->FilterByName(name, tmp);
	return tmp.GetCount();
}

tstring CDataCompletion::GetCurrentDateAsEDIString( size_t syntaxVersion)
{
	SYSTEMTIME now;
	GetLocalTime(&now);
	TCHAR buffer\[10\];
	GetDateFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, (syntaxVersion < 4)? _T("yyMMdd") : _T("yyyyMMdd"), buffer, 10);
	return buffer;
}

tstring CDataCompletion::GetCurrentTimeAsEDIString()
{
	SYSTEMTIME now;
	GetLocalTime(&now);
	TCHAR buffer\[10\];
	GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, _T("HHmm"), buffer, 10);
	return buffer;
}

const tstring& CDataCompletion::GetStructureName() const
{
	return m_StructureName;
}

bool CDataCompletion::CompleteMandatory(CTextNode& dataNode, const CEDIParticle& particle)
{
	CTextNodeContainer* dataChildren = dataNode.GetChildren();
	const CEDIStructureItem& currentItem = *particle.GetNode();
	dataNode.SetClass(currentItem.GetNodeClass());

	if (currentItem.GetNodeClass() == DataElement)
	{
		return (dataNode.GetValue().size() != 0);
	}
	else
	{
		size_t childCount = dataNode.GetChildren()->GetCount(); 
		bool anyExisted = false;
		bool bContainsSelect = false;
		const CEDIParticle* children = currentItem.GetChildren();
		const CEDIParticle* childrenEnd = children + currentItem.GetChildCount();

		for (; children != childrenEnd; ++children)
		{
			const CEDIParticle& childParticle = *children;
			bContainsSelect = !bContainsSelect ? childParticle.GetNode()->GetNodeClass() == Select : true;
			const tstring& name = childParticle.GetTargetName();
			CTextNodeContainer container;

			size_t occurs = 0;
			dataChildren->FilterByName(name, container);

			for (int index = 0; index != container.GetCount(); ++index)
			{
				CTextNode* childNode = container.GetAt(index);
				childCount -= 1;
				dataChildren->MoveNode(childNode, dataChildren->GetCount());

				bool childExists = CompleteMandatory(*childNode, childParticle);
				anyExisted |= childExists;
				if (!childExists && childParticle.GetMergedEntries() == 1)
					dataChildren->RemoveAt(dataChildren->GetCount()-1);
				else
					++occurs;
			}
		
			if (currentItem.GetNodeClass() == Group && childParticle.GetNode()->GetNodeClass() != Select && name != _T("Message") )
			{
				for (; occurs < childParticle.GetMinOccurs(); ++occurs)
				{
					CTextNode* emptyNode = CTextNodeFactory::GetInstance().Create(&dataNode, name);
					emptyNode->SetClass(childParticle.GetNode()->GetNodeClass());
					CompleteMandatory(*emptyNode, childParticle);
				}
			}
		}
		
		if( !bContainsSelect )
		{
			for ( ; childCount; )
			{
				dataChildren->RemoveAt(--childCount);
			}
		}
		else
			return true;

		return anyExisted;
	}
}

void CDataCompletion::CompleteConditionsAndValues(CTextNode* pNode, const CEDIParticle& particle)
{
	pNode->SetClass( particle.GetNode()->GetNodeClass() );

	if (pNode->GetClass() == Segment)
	{
		if (m_bCompleteSingleValues && !particle.GetNode()->GetConditionPath().empty())
		{
			CTextNode* n = GetChildNodeByPath(pNode, particle.GetNode()->GetConditionPath());
			if (n == NULL)
				n = CreateTree(pNode, particle.GetNode()->GetConditionPath(), particle);

			if (!particle.GetNode()->GetConditionValue().empty())
				ConservativeSetValue(n, particle.GetNode()->GetConditionValue());
			else
			{
				const CEDIParticle* p = GetParticleByPath(particle, particle.GetNode()->GetConditionPath());
				if (p != NULL && p->GetCodeValues().size() == 1)
					ConservativeSetValue(n, p->GetCodeValues()\[0\]);
			}
		}
	}

	if (pNode->GetClass() == Segment || pNode->GetClass() == Composite)
	{
		for( size_t i = 0 ; i < particle.GetNode()->GetChildCount() ; ++i )
		{
			const CEDIParticle& p = particle.GetNode()->GetChildren()\[i\];
			if (p.GetMinOccurs() > 0)
			{
				if (p.GetNode()->GetNodeClass() == DataElement && p.GetCodeValues().size() != 1)
					continue;

				CTextNode* n = MakeSureExists(pNode, p.GetTargetName(), p.GetNode()->GetNodeClass());
				CompleteConditionsAndValues(n, p);
			}
		}
	}
	else if (pNode->GetClass() == DataElement)
	{
		if (m_bCompleteSingleValues && particle.GetCodeValues().size() == 1)
			ConservativeSetValue(pNode, particle.GetCodeValues()\[0\]);
	}

	CTextNodeContainer* pChildren = pNode->GetChildren();
	for( size_t i = 0 ; i < pChildren->GetCount() ; ++i )
	{
		CTextNode* n = pChildren->GetAt(i);

		const CEDIParticle* p = GetParticleByPath(particle, n->GetName());
		if (p == NULL)
			throw altova::Exception(_T("Invalid parameter"));

		CompleteConditionsAndValues(n, *p);
	}
}

const CEDIParticle* CDataCompletion::GetParticleByPath(const CEDIParticle& p, const tstring& path)
{
	for( size_t k = 0 ; k < p.GetNode()->GetChildCount() ; ++k )
	{
		const CEDIParticle& childParticle = p.GetNode()->GetChildren()\[k\];

		const tstring& sName = childParticle.GetTargetName();
		size_t i = sName.find(_T('/'));
		if (i != tstring::npos)
		{
			if (childParticle.GetTargetName() == path.substr(0, i))
				return GetParticleByPath(childParticle, path.substr(i + 1));
		}

		if (childParticle.GetTargetName() == path)
			return &childParticle;
	}

	return NULL;
}

CTextNode* CDataCompletion::GetChildNodeByPath(CTextNode* pNode, const tstring& path)
{
	CTextNodeContainer* pChildren = pNode->GetChildren();
	for( size_t k = 0 ; k < pChildren->GetCount() ; ++k )
	{
		CTextNode* n = pChildren->GetAt(k);

		size_t i = path.find(_T('/'));
		if (i != tstring::npos)
		{
			if (n->GetName() == path.substr(0, i))
				return GetChildNodeByPath(n, path.substr(i + 1));
		}

		if (n->GetName() == path)
			return n;
	}

	return NULL;
}

CTextNode* CDataCompletion::CreateTree(CTextNode* pNode, const tstring& path, const CEDIParticle& particle)
{
	size_t i = path.find(_T('/'));
	if (i != tstring::npos)
	{
		tstring name = path.substr(0, i);
		const CEDIParticle* p = GetParticleByPath(particle, name);
		CTextNode* n = MakeSureExists(pNode, name, p->GetNode()->GetNodeClass());
		return CreateTree(n, path.substr(i + 1), *p);
	}

	return MakeSureExists(pNode, path, particle.GetNode()->GetNodeClass());
}

} // namespace edi
} // namespace text
} // namespace altova
