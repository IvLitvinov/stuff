[call GenerateFileHeader("DataCompletion.h")]
#ifndef __DATACOMPLETION_H
#define __DATACOMPLETION_H

#include "AltovaTextAPI.h"
#include "Parser.h"

namespace altova
{
namespace text
{

class CTextNode;

namespace edi
{
class CTextDocument;

class ALTOVATEXT_DECLSPECIFIER CDataCompletion
{
public: // descendant obligations:
	virtual void CompleteData(CTextNode*, const CEDIParticle&) = 0;

protected:
	CDataCompletion(const CTextDocument& rDocument, const tstring&, bool completeSingleValues = false);
	const tstring& GetStructureName() const;
	
	static CTextNode* MakeSureExists(CTextNode&, const tstring&, ENodeClass cl = Undefined);
	static CTextNode* MakeSureExists(CTextNode*, const tstring&, ENodeClass cl = Undefined);
	static bool HasKid(CTextNode&, const tstring&);
	static bool HasKid(CTextNode*, const tstring&);
	static CTextNode* GetKid(CTextNode&, const tstring&);
	static void ConservativeSetValue(CTextNode*, const tstring&);
	static void ConservativeSetValue(CTextNode*, TCHAR);
	static void ConservativeSetValue(CTextNode*, size_t);
	static void ConservativeSetValue(CTextNode*, CTextNode*);
	static size_t GetSegmentChildrenCount(CTextNode&);
	static size_t GetNamedChildrenCount(CTextNode&, const tstring&);
	static tstring GetCurrentDateAsEDIString( size_t syntaxVersion = 4);
	static tstring GetCurrentTimeAsEDIString();

	static bool CompleteMandatory(CTextNode&, const CEDIParticle&);
	void CompleteConditionsAndValues(CTextNode* pNode, const CEDIParticle& particle);
	const CEDIParticle* GetParticleByPath(const CEDIParticle& p, const tstring& path);
	CTextNode* GetChildNodeByPath(CTextNode* pNode, const tstring& path);
	CTextNode* CreateTree(CTextNode* pNode, const tstring& path, const CEDIParticle& particle);

	const CTextDocument& m_rDocument;
	bool m_bCompleteSingleValues;
private:
	tstring m_StructureName;
};

} // namespace edi
} // namespace text
} // namespace altova
	
#endif