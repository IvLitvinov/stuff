[call GenerateFileHeader("DataTypeValidator.cpp")]

#include "StdAfx.h"
#include "DataTypeValidator.h"
#include "EDIDateTimeHelpers.h"
#include "EDIReadContext.h"
#include "Writer.h"

#include <math.h>

namespace altova
{
namespace text
{
namespace edi
{

	bool CEDIDataValueCodeListValidator::HasValue( tstring value ) const
	{
		if( m_CodeList != NULL)
		{
			for (int i = 0; i < m_nCodeListSize; i++)
			{
				if( value == m_CodeList\[i\])
					return true;
			}
		}
		else
			return true;

		return false;
	}

	tstring CEDIDataValueCodeListValidator::GetCodeListValues() const
	{
		tstring sb;
		if( m_CodeList != NULL)
		{
			int i;
			for( i = 0; i < m_nCodeListSize; ++i) {
				if (sb.size() > 0)
					sb += _T(", ");
				sb += m_CodeList\[i\];
			}
		}
		return sb;
	}

	bool CEDIDataValueSubCodeListValidator::HasValue( tstring value ) const
	{
		if (m_CodeList != NULL)
		{
			if (m_nPosOffset > 0)
			{
				if (value.size() > m_nPosOffset - 1)
					value = value.substr(m_nPosOffset - 1, m_nPosLength);
				else
					value = _T("");
			}
			for (int i = 0; i < m_nCodeListSize; i++)
			{
				if (value == m_CodeList\[i\])
					return true;
			}
		}
		else
			return true;

		return false;
	}

	bool CEDIDataValueGroupValidator::IsIncomplete() const
	{
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
			if (m_Validators\[i\]->IsIncomplete())
				return true;
		}
		return false;
	}

	bool CEDIDataValueGroupValidator::HasValue( tstring value ) const
	{
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
				if (!m_Validators\[i\]->HasValue(value))
				{
					return false;
				}
		}
		return true;
	}

	tstring CEDIDataValueGroupValidator::GetCodeListValues() const
	{
		if (m_sName.size() > 0)
			return tstring( _T("Values from code list ") ) + m_sName;

		tstring sb;
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
			tstring s = m_Validators\[i\]->GetCodeListValues();
			if (s.size() > 0)
			{
				if (sb.size() > 0)
					sb += _T("; ");
				sb += s;
			}
		}
		return sb;
	}

	bool CEDIDataValueGroupsValidator::IsIncomplete() const
	{
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
			if (m_Validators\[i\]->IsIncomplete())
				return true;
		}
		return false;
	}

	bool CEDIDataValueGroupsValidator::HasValue( tstring value ) const
	{
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
			if (m_Validators\[i\]->HasValue(value))
				return true;
		}
		return false;
	}

	tstring CEDIDataValueGroupsValidator::GetCodeListValues() const
	{
		tstring sb;
		for (int i = 0; i < m_nValidatorsSize; i++)
		{
			tstring s = m_Validators\[i\]->GetCodeListValues();
			if (s.size() > 0)
			{
				if (sb.size() > 0)
					sb += _T("; ");
				sb += s;
			}
		}
		return sb;
	}

	bool CEDIDataTypeValidator::IsIncomplete() const
	{
		if (m_pValidator != NULL)
			return m_pValidator->IsIncomplete();
		return false;
	}

	bool CEDIDataTypeValidator::HasValue( tstring value) const
	{
		if (m_pValidator != NULL)
			return m_pValidator->HasValue( value );
		return true;
	}

	tstring CEDIDataTypeValidator::GetCodeListValues() const
	{
		if (m_pValidator != NULL)
			return m_pValidator->GetCodeListValues();
		return tstring();
	}

	void CEDIDataTypeValidator::ValidateLength( const tstring::size_type effLen, const tstring& s, const CTextNode* const pNode, const CEDIWriter& writer) const
	{
		//report error/warning
		if( effLen > m_nMaxLength )
		{
			writer.HandleError(
				pNode,
				CEDIParser::DataElementTooLong,
				CEDIErrorMessages::GetDataElementTooLongMessage( pNode->GetName(), m_nMaxLength, s)
			);
		}
		else if( effLen < m_nMinLength )
		{
			writer.HandleError(
				pNode,
				CEDIParser::DataElementTooShort,
				CEDIErrorMessages::GetDataElementTooShortMessage( pNode->GetName(), m_nMinLength, s)
			);
		}
	}

	void CEDIDataTypeValidator::ValidateLength( 
		const tstring::size_type effLen,
		const tstring& s,
		const CEDIReadContext& context,
		const CEDIErrorPosition& errPos) const
	{
		//report error/warning
		if( effLen > m_nMaxLength )
		{
			context.HandleError(
				CEDIParser::DataElementTooLong,
				errPos,
				CEDIErrorMessages::GetDataElementTooLongMessage( context.GetParticle().GetNode()->GetName(), m_nMaxLength, s),
				s
			);
		}
		else if( effLen < m_nMinLength )
		{
			context.HandleError(
				CEDIParser::DataElementTooShort,
				errPos,
				CEDIErrorMessages::GetDataElementTooShortMessage( context.GetParticle().GetNode()->GetName(), m_nMinLength, s),
				s
			);
		}
	}

namespace {
	void trimRight( tstring& s, const tstring& sTrim )
	{
		for(tstring::reverse_iterator i = s.rbegin(); i != s.rend(); ++i)
		{
			if (sTrim.find( *i ) == tstring::npos)
			{
				s.erase(i.base(), s.end());
				return;
			}
		}

		s.erase(s.begin(), s.end());
	}

	void trimLeft( tstring& s, const tstring& sTrim )
	{
		for(tstring::iterator i = s.begin(); i != s.end(); ++i)
		{
			if (sTrim.find( *i ) == tstring::npos)
			{
				s.erase(s.begin(), i);
				return;
			}
		}
		s.erase(s.begin(), s.end());
	}

	void trim( tstring& sValue, const tstring& sTrim )
	{
		trimLeft(sValue, sTrim); 
		trimRight(sValue, sTrim);
	}
}

void CEDIDataTypeValidatorString::MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const
{
	if( context.GetParser().GetSettings().GetStandard() == EDIFixed)
	{
		trimRight( sValue, _T(" \\r"));
	}

	ValidateLength( sValue.length(), sValue, context, errPos);
}


bool CEDIDataTypeValidatorString::MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const
{
	if( EDIFixed == writer.GetStandard() && sValue.length() > m_nMaxLength)
		sValue.erase( m_nMaxLength);

	if( EDITRADACOMS == writer.GetStandard() )
		std::transform( sValue.begin(), sValue.end(), sValue.begin(), toupper);

	size_t padSize = writer.GetStandard() == EDIFixed ? m_nMaxLength : m_nMinLength;
	if (sValue.length() < padSize)
		sValue.append (padSize - sValue.length(), _T(' '));

	ValidateLength( sValue.length(), sValue, pNode, writer);
	return true;
}

bool CEDIDataTypeValidatorDecimal::checkNumber (const tstring& s)
{
	// EDI allows only ASCII digits for numbers
	for (size_t i = 0; i < s.length(); ++i)
	{
		if (s\[i\] < _T('0') || s\[i\] > _T('9'))
			return false;
	}
	return true;
}

size_t EffectiveLength(const tstring& s, TCHAR point)
{
	size_t effLength = s.length();
	if (s\[0\] == _T('-') || s\[0\] == _T('+'))
		effLength--;
	if (point != 0 && s.find(point) != tstring::npos)
		effLength--;

	return effLength;
}

void CEDIDataTypeValidatorDecimal::MakeValidOnRead (tstring& s, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const
{
	size_t effectiveLength = EffectiveLength(s, context.GetScanner().separators.GetDecimalNotation());
	ValidateLength(effectiveLength, s, context, errPos);

	tstring str = s;
	trim(str, _T(" \t"));

	if (str.length() == 0)
	{
		context.HandleError (
			CEDIParser::FieldValueInvalid,
			errPos,
			CEDIErrorMessages::GetInvalidFieldValueMessage(
				context.GetParticle().GetNode()->GetName(),
				s,
				_T("decimal")
				),
			s
			);
		return;
	}

	s = str;

	bool negative = false;

	// first character could be sign.
	if (s\[0\] == '+' || s\[0\] == '-')
	{
		negative = s\[0\] == '-';
		s.erase (0, 1);
	}

	if (s.length() == 0)	// treat as null value; it is invalid beyond repair anyways
	{
		context.HandleError (
			CEDIParser::FieldValueInvalid,
			errPos,
			CEDIErrorMessages::GetInvalidFieldValueMessage(
				context.GetParticle().GetNode()->GetName(),
				s,
				_T("decimal")
			),
			s
		);
		return;
	}

	TCHAR decimalMark = context.GetScanner().separators.GetServiceChar(EDISERVICECHAR_DECIMALMARK);
	tstring::size_type decimalPoint = s.find_last_of(decimalMark);
	if (decimalPoint == tstring::npos)
		decimalPoint = s.find_last_of(_T('.'));
	if (decimalPoint == tstring::npos)
		decimalPoint = s.find_last_of(_T(','));

    tstring integral;
	tstring fractional;

	if (decimalPoint != tstring::npos)
	{
		integral = s.substr(0, decimalPoint);
		fractional = s.substr(decimalPoint + 1);
	}
	else if (m_nImplicitDecimals > 0)
	{
		// make string at least the number of decimals required in length
		if (m_nImplicitDecimals > s.length())
			s.insert((tstring::size_type) 0, m_nImplicitDecimals - s.length(), _T('0'));
		integral = s.substr(0, s.length() - m_nImplicitDecimals);
		fractional = s.substr(s.length() - m_nImplicitDecimals);
	}
	else
	{
		integral = s;
	}

	if (integral.length() == 0)
		integral = _T("0");

	if (!checkNumber (integral) || !checkNumber (fractional))
	{
		context.HandleError (
			CEDIParser::FieldValueInvalid,
			errPos,
			CEDIErrorMessages::GetInvalidFieldValueMessage(
				context.GetParticle().GetNode()->GetName(),
				s,
				_T("decimal")
			),
			s
		);
		return;
	}

	if (fractional.length() > 0)
		fractional = _T(".") + fractional;

	// reassemble properly
	if (negative)
		s = _T("-") + integral + fractional;
	else
		s = integral + fractional;
}

bool CEDIDataTypeValidatorDecimal::MakeValidOnWrite (tstring& s, const CTextNode* const pNode, CEDIWriter& writer) const
{
	if (s.length() == 0)
		return true; // do not pad nulls.

	bool negative = false;

	// first character could be sign.
	if (s\[0\] == '+' || s\[0\] == '-')
	{
		negative = s\[0\] == '-';
		s.erase(0,1);
	}

	if (s.length() == 0)
		return false;

	// this is a safety measure:
	tstring::size_type decimalPoint = s.find_last_of(_T(','));
	if (decimalPoint != tstring::npos)
		s = s.replace(decimalPoint, 1, 1, _T('.'));

	if (m_nImplicitDecimals > 0)
	{
		double d = altova::CoreTypes::CastToDouble(s);
		d = (double)floor(d*pow(10.0, (int)m_nImplicitDecimals)+0.5)/pow(10.0, (int)m_nImplicitDecimals);
		s = altova::CoreTypes::CastToString(d);
	}

	decimalPoint = s.find_last_of(_T('.'));
	
	tstring integral;
	tstring fractional;

	if (decimalPoint != tstring::npos)
	{
		integral = s.substr(0, decimalPoint);
		fractional = s.substr(decimalPoint + 1);
	}
	else
	{
		integral = s;
	}

	// remove leading and trailing zeroes.
	tstring::size_type zero = integral.find_first_not_of(_T('0'));
	integral.erase(0, zero);
			
	zero = fractional.find_last_not_of(_T('0'));
	if (zero != tstring::npos)
		fractional.erase(zero + 1);

	if (m_nImplicitDecimals > 0)
	{
		if (fractional.length() < m_nImplicitDecimals)
			fractional.append (m_nImplicitDecimals - fractional.length(), _T('0'));

		if (m_nMinLength > fractional.length() + integral.length())
			integral = integral.insert((tstring::size_type) 0, m_nMinLength - fractional.length() - integral.length(), _T('0'));
	}
	else
	{
		if (m_nMinLength > fractional.length() + integral.length())
			integral = integral.insert((tstring::size_type) 0, m_nMinLength - fractional.length() - integral.length(), _T('0'));

		if (fractional.length() > 0)
			fractional.insert((tstring::size_type) 0, (tstring::size_type) 1, _T('.'));
	}

	if(writer.GetStandard() != EDIX12)
	{
		if(integral.empty())
			integral = _T("0");
	}
	
	
	if (negative)
		s = _T("-") + integral + fractional;
	else
		s = integral + fractional;
	
	if (fractional.length() > 0 && EffectiveLength(s, _T('.')) > m_nMaxLength)
	{
		double d = altova::CoreTypes::CastToDouble(s);
		int places = (int)(m_nMaxLength - integral.length());
		if (negative) 
			places++;
		if (places > 0) // don't round if maxlength is smaller than integral part
		{   
			d = (double)floor(d*pow(10.0, places)+0.5)/pow(10.0, places);
			s = altova::CoreTypes::CastToString(d);
		}
	}

	TCHAR decimalMark = writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_DECIMALMARK);
	tstring::size_type point = s.find(_T('.'));
	if (point != tstring::npos)
		s = s.replace(point, 1, 1, decimalMark);
	
	ValidateLength( EffectiveLength(s, decimalMark), s, pNode, writer);
	return true;
}


void CEDIDataTypeValidatorDate::MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const
{
	ValidateLength( sValue.length(), sValue, context, errPos);
	tstring::size_type firstValid = sValue.find_first_not_of(_T(' '));
	sValue.erase(0, firstValid);

	if (sValue.size() != 6 && sValue.size() != 8)
	{
		context.HandleError( 
			CEDIParser::InvalidDate,
			errPos,
			CEDIErrorMessages::GetInvalidDateMessage(
			context.GetParticle().GetNode()->GetName(),
			sValue,
			_T("date")
			),
			sValue
		);
		return;
	}
	
	if( !EDIDateTimeHelpers::IsDateCorrect( sValue) )
		context.HandleError( 
			CEDIParser::InvalidDate,
			errPos,
			CEDIErrorMessages::GetInvalidDateMessage(
			context.GetParticle().GetNode()->GetName(),
			sValue,
			_T("date")
			),
			sValue
		);

	if (sValue.size() == 6)
	{
		if (sValue.substr(0, 2) <= _T("50"))
			sValue = _T("20") + sValue;
		else
			sValue = _T("19") + sValue;
	}

	sValue.insert((tstring::size_type)6, (tstring::size_type)1, _T('-'));
	sValue.insert((tstring::size_type)4, (tstring::size_type)1, _T('-'));
}


bool CEDIDataTypeValidatorDate::MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const
{
	if (sValue.size() >= 10)
	{
		// schema dateTime
		sValue = sValue.substr(0,4) + sValue.substr(5,2) + sValue.substr(8,2);
	}

	if (sValue.size() != 6 && sValue.size() != 8)
	{
		if (sValue.size() > 8)
			sValue.erase((tstring::size_type)8);
		else
			return false;
	}

	if (m_nMaxLength == 6 && sValue.size() == 8)
		sValue.erase((tstring::size_type)0, (tstring::size_type)2);

	if (sValue.size() < m_nMinLength)
		sValue.append(m_nMinLength - sValue.size(), _T(' '));

	return true;
}


void CEDIDataTypeValidatorTime::MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const
{
	ValidateLength( sValue.length(), sValue, context, errPos);
	tstring::size_type firstValid = sValue.find_first_not_of(_T(' '));
	sValue.erase(0, firstValid);

	if (sValue.size() < 4 || sValue.size() == 5)
		context.HandleError( 
			CEDIParser::InvalidTime,
			errPos,
			CEDIErrorMessages::GetInvalidTimeMessage(
			context.GetParticle().GetNode()->GetName(),
			sValue,
			_T("time")
			),
			sValue
		);

	if( !EDIDateTimeHelpers::IsTimeCorrect( sValue) )
		context.HandleError( 
			CEDIParser::InvalidTime,
			errPos,
			CEDIErrorMessages::GetInvalidTimeMessage(
			context.GetParticle().GetNode()->GetName(),
			sValue,
			_T("time")
			),
			sValue
		);

	if (sValue.size() <= 6)
		sValue.append(((tstring::size_type)6) - sValue.size(), _T('0'));
	else
		sValue.insert((tstring::size_type)6, (tstring::size_type)1, _T('.'));

	sValue.insert((tstring::size_type)4, (tstring::size_type)1, _T(':'));
	sValue.insert((tstring::size_type)2, (tstring::size_type)1, _T(':'));
}


bool CEDIDataTypeValidatorTime::MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const
{
	for (tstring::size_type p = 0; p != sValue.size();)
	{
		if (sValue\[p\] == ':' || sValue\[p\] == '.')
			sValue.erase(p, 1);
		else
			++p;
	}

	tstring::size_type suffix = sValue.find_first_of(_T('Z'));
	if (suffix == tstring::npos)
		suffix = sValue.find_first_of(_T('+'));
	if (suffix == tstring::npos)
		suffix = sValue.find_first_of(_T('-'));
	if (suffix != tstring::npos)
		sValue.erase(suffix);

	if (sValue.size() > m_nMaxLength)
			sValue = sValue.substr(0, m_nMaxLength);

	// pad to minimum length
	if (sValue.size() < m_nMinLength)
		sValue.append(m_nMinLength - sValue.size(), _T('0'));

	return true;
}

}
}
}
