[call GenerateFileHeader("DataTypeValidator.h")]
#ifndef __DATATYPEVALIDATOR_H
#define __DATATYPEVALIDATOR_H

#include "Parser.h"

namespace altova
{
namespace text
{
class CTextNode;
namespace edi
{

class CEDIReadContext;
class CEDIWriter;
class CEDIErrorPosition;

class ALTOVATEXT_DECLSPECIFIER CEDIDataValueValidator
{
public:
	virtual bool IsIncomplete() const { return false; }

	virtual bool HasValue( tstring value ) const { return true; }
	virtual tstring GetCodeListValues() const { return tstring(); }
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataValueCodeListValidator : public CEDIDataValueValidator
{
public:
	CEDIDataValueCodeListValidator(bool bComplete, tstring pCodeList\[\] = NULL, long nCodeListSize = 0)
		: m_bComplete(bComplete), m_CodeList(pCodeList), m_nCodeListSize( nCodeListSize)
	{ 
	}

	virtual bool IsIncomplete() const { return !m_bComplete; }

	virtual bool HasValue( tstring value) const;
	virtual tstring GetCodeListValues() const;

protected:
	bool m_bComplete;
	tstring* m_CodeList;
	long m_nCodeListSize;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataValueSubCodeListValidator : public CEDIDataValueCodeListValidator
{
public:
	CEDIDataValueSubCodeListValidator(bool bComplete, 
		tstring::size_type nPosOffset, tstring::size_type nPosLength,
		tstring pCodeList\[\] = NULL, long nCodeListSize = 0)
		: CEDIDataValueCodeListValidator(bComplete, pCodeList, nCodeListSize), m_nPosOffset(nPosOffset), m_nPosLength(nPosLength)
	{ 
	}

	virtual bool HasValue( tstring value) const;

protected:
	tstring::size_type m_nPosOffset;
	tstring::size_type m_nPosLength;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataValueGroupValidator : public CEDIDataValueValidator
{
public:
	CEDIDataValueGroupValidator(const tstring& sName, const CEDIDataValueValidator* pValidators\[\] = NULL, long nValidatorsSize = 0)
		: m_sName(sName), m_Validators(pValidators), m_nValidatorsSize(nValidatorsSize)
	{
	}

	virtual bool IsIncomplete() const;

	virtual bool HasValue( tstring value) const;
	virtual tstring GetCodeListValues() const;

protected:
	tstring m_sName;
	const CEDIDataValueValidator** m_Validators;
	long m_nValidatorsSize;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataValueGroupsValidator : public CEDIDataValueValidator
{
public:
	CEDIDataValueGroupsValidator(const CEDIDataValueValidator* pValidators\[\] = NULL, long nValidatorsSize = 0)
		: m_Validators(pValidators), m_nValidatorsSize(nValidatorsSize)
	{
	}

	virtual bool IsIncomplete() const;

	virtual bool HasValue( tstring value) const;
	virtual tstring GetCodeListValues() const;

protected:
	const CEDIDataValueValidator** m_Validators;
	long m_nValidatorsSize;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataTypeValidator
{
public:
	CEDIDataTypeValidator( tstring::size_type nMinLength, tstring::size_type nMaxLength, const CEDIDataValueValidator* pValidator = NULL)
		: m_nMinLength( nMinLength), m_nMaxLength( nMaxLength), m_pValidator( pValidator )
	{ 
	}
	virtual void MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const { }
	virtual bool MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const { return true; }

	virtual bool IsIncomplete() const;
	bool HasValue( tstring value) const;
	tstring GetCodeListValues() const;

	tstring::size_type GetMaxLength() const { return m_nMaxLength; }

protected:
	void ValidateLength( const tstring::size_type effLen, const tstring& s, const CTextNode* const pNode, const CEDIWriter& writer) const;
	void ValidateLength( const tstring::size_type effLen, const tstring& s, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const;

protected:
	tstring::size_type m_nMinLength;
	tstring::size_type m_nMaxLength;
	const CEDIDataValueValidator* m_pValidator;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataTypeValidatorString : public CEDIDataTypeValidator
{
public:
	CEDIDataTypeValidatorString (tstring::size_type nMinLength, tstring::size_type nMaxLength, const CEDIDataValueValidator* pValidator = NULL)
		: CEDIDataTypeValidator(nMinLength, nMaxLength, pValidator)
	{
	}

	virtual void MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const;
	virtual bool MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataTypeValidatorDecimal : public CEDIDataTypeValidator
{
public:
	CEDIDataTypeValidatorDecimal(tstring::size_type nMinLength, tstring::size_type nMaxLength, tstring::size_type nImplicitDecimals)
		: CEDIDataTypeValidator(nMinLength, nMaxLength), m_nImplicitDecimals(nImplicitDecimals)
	{ }


	virtual void MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const;
	virtual bool MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const;

private:
	static bool checkNumber (const tstring& s);
	tstring::size_type m_nImplicitDecimals;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataTypeValidatorDate : public CEDIDataTypeValidator
{
public:
	CEDIDataTypeValidatorDate(tstring::size_type nMinLength, tstring::size_type nMaxLength)
		: CEDIDataTypeValidator(nMinLength, nMaxLength) { }

	virtual void MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const;
	virtual bool MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const;
};

class ALTOVATEXT_DECLSPECIFIER CEDIDataTypeValidatorTime : public CEDIDataTypeValidator
{
public:
	CEDIDataTypeValidatorTime(tstring::size_type nMinLength, tstring::size_type nMaxLength)
		: CEDIDataTypeValidator(nMinLength, nMaxLength) { }

	virtual void MakeValidOnRead (tstring& sValue, const CEDIReadContext& context, const CEDIErrorPosition& errPos) const;
	virtual bool MakeValidOnWrite (tstring& sValue, const CTextNode* const pNode, CEDIWriter& writer) const;
};

}
}
}
#endif