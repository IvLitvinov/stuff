[call GenerateFileHeader("EDIDateTimeHelpers.cpp")]
#include "StdAfx.h"
#include "EDIDateTimeHelpers.h"

#include <iomanip>
#include <ctype.h>

namespace EDIDateTimeHelpers
{

	bool IsYearCorrect( const tstring& sRhs )
	{
		for (unsigned int i=0; i<sRhs.size(); ++i)
			if ( !_istdigit( sRhs\[i\] ) ) return false;

		return true;
	}

	bool IsMonthCorrect( const tstring& sRhs )
	{
		try
		{
			long nMonth = altova::CoreTypes::CastToInt( sRhs );
			if ( ( 1 > nMonth ) || ( 12 < nMonth ) ) return false;
				return true;
		}
		catch (altova::OutOfRangeException)
		{
			return false;
		}
		catch(altova::StringParseException)
		{
			return false;
		}
	}

	bool IsDayCorrect( const tstring& sRhs )
	{
		try
		{
			long nDay = altova::CoreTypes::CastToInt( sRhs );
			if ( ( 1 > nDay ) || ( 31 < nDay ) ) return false;
				return true;
		}
		catch (altova::OutOfRangeException)
		{
			return false;
		}
		catch(altova::StringParseException)
		{
			return false;
		}
	}

	bool IsHourCorrect( const tstring& sRhs )
	{
		try
		{
			long nHour = altova::CoreTypes::CastToInt( sRhs );
			if ( ( 0 > nHour ) || ( 23 < nHour ) ) return false;
				return true;
		}
		catch (altova::OutOfRangeException)
		{
			return false;
		}
		catch(altova::StringParseException)
		{
			return false;
		}
	}

	bool IsMinuteCorrect( const tstring& sRhs )
	{
		try
		{
			long nMinute = altova::CoreTypes::CastToInt( sRhs );
			if ( ( 0 > nMinute ) || ( 59 < nMinute ) ) return false;
				return true;
		}
		catch (altova::OutOfRangeException)
		{
			return false;
		}
		catch(altova::StringParseException)
		{
			return false;
		}
	}

	bool IsDateCorrect( const tstring& sRhs )
	{
		// year can be YYYYMMDD or YYMMDD
		size_t yLen = 2;
		if ( sRhs.size() == 8)
			yLen = 4;
		else if ( sRhs.size() == 6)
			yLen = 2;
		else if ( sRhs.size() == 5) // special case for 0YMMDD where zero was removed because it is decimal type
			yLen = 1;
		else
			return false; // bad length

		if ( !IsYearCorrect( sRhs.substr( 0, yLen ) ) ) return false;
		if ( !IsMonthCorrect( sRhs.substr( yLen, 2 ) ) ) return false;
		if ( !IsDayCorrect( sRhs.substr( sRhs.size() - 2 ) ) ) return false;
		return true;
	}

	bool IsTimeCorrect( const tstring& sRhs )
	{
		if ( sRhs.find_first_not_of( _T("0123456789") ) != tstring::npos )
			return false;

		size_t len = sRhs.size();

		// Time is HHMM\[SSd...d\]
		if ( !IsHourCorrect( sRhs.substr( 0, 2 ) ) ) return false;
		if ( !IsMinuteCorrect( sRhs.substr( 2, 2 ) ) ) return false;
		if ( len > 4 ) // have secs?
			if ( len < 6 || !IsMinuteCorrect( sRhs.substr( 4, 2 ) ) ) return false; // seconds same as minutes 0..59

		return true;
	}

} // namespace ICTextParserEDIDateTimeHelpers
