[call GenerateFileHeader("EDIDateTimeHelpers.h")]
#ifndef __ICTEXTPARSEREDIDATETIMEHELPERS_H
#define __ICTEXTPARSEREDIDATETIMEHELPERS_H

#include <string>

namespace EDIDateTimeHelpers
{
	bool		IsYearCorrect( const tstring& );
	bool		IsMonthCorrect( const tstring& );
	bool		IsDayCorrect( const tstring& );
	bool		IsHourCorrect( const tstring& );
	bool		IsMinuteCorrect( const tstring& );
	bool		IsDateCorrect( const tstring& );
	bool		IsTimeCorrect( const tstring& );
}
#endif //__ICTEXTPARSEREDIDATETIMEHELPERS_H
