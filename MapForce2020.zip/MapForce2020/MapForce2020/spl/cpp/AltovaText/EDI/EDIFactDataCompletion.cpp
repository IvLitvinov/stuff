[call GenerateFileHeader("EDIFactDataCompletion.cpp")]
#include "StdAfx.h"
#include "EDIFactDataCompletion.h"
#include "EDIFactSettings.h"
#include "TextNode.h"
#include "TextException.h"
#include "TextDocument.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIFactDataCompletion::CEDIFactDataCompletion( const CTextDocument& rDocument,
												const CEDIFactSettings& settings,
												const tstring &structurename)
:	CDataCompletion(rDocument, structurename), m_Settings(settings)
{
}
	
void CEDIFactDataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);
	CompleteEnvelope(*dataroot, rootParticle);
}
	
void CEDIFactDataCompletion::CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle)
{
	if (envelope.GetName() != rootParticle.GetName())
		throw CTextException(CAltovaException::eError1, _T("CompleteEnvelope: root node is not an envelope"));


	const CEDIParticle& interchangeParticle = rootParticle.GetNode()->GetChildren()\[0\];
	MakeSureExists(envelope, interchangeParticle.GetName());

	CTextNodeContainer interchanges; 
	envelope.GetChildren()->FilterByName(interchangeParticle.GetName(), interchanges);
	for (size_t i=0; i< interchanges.GetCount(); ++i)
			CompleteInterchange(*interchanges.GetAt(i), interchangeParticle);
}

void CEDIFactDataCompletion::CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle)
{
	const CEDIParticle* interchangeHeader = interchangeParticle.GetFirstChildByName(_T("UNB"))  ? interchangeParticle.GetFirstChildByName(_T("UNB")) : interchangeParticle.GetFirstChildByName(_T("UIB"));
	const CEDIParticle* interchangeTrailer = interchangeParticle.GetFirstChildByName(_T("UNZ")) ? interchangeParticle.GetFirstChildByName(_T("UNZ")) : interchangeParticle.GetFirstChildByName(_T("UIZ"));
	const CEDIParticle* group = interchangeParticle.GetFirstChildByName(_T("Group"));

	if (interchangeHeader != NULL  && interchangeTrailer != NULL)
	{
		CTextNode* header = interchange.GetChildren()->GetFirstNodeByName(interchangeHeader->GetName());
		CTextNode* trailer = interchange.GetChildren()->GetLastNodeByName(interchangeTrailer->GetName());
		if (header == NULL && trailer == NULL)
		{
			if (group != NULL)
				MakeSureExists(interchange, group->GetName());
		}
		else
		{
			header = MakeSureExists(interchange, interchangeHeader->GetName());
			if (group != NULL)
				MakeSureExists(interchange, group->GetName());
			trailer = MakeSureExists(interchange, interchangeTrailer->GetName());
		}

		if (group != NULL)
		{
			CTextNodeContainer groups;
			interchange.GetChildren()->FilterByName(_T("Group"), groups);
			for (size_t i = 0; i < groups.GetCount(); ++i)
				CompleteGroup(*groups.GetAt(i), *group);
		}
		else
		{
			CompleteGroup(interchange, interchangeParticle);
		}

		if (header == NULL && trailer == NULL)
			return;

		CompleteInterchangeHeader(*header);
		CompleteInterchangeTrailer(*trailer);
	}
}

void CEDIFactDataCompletion::CompleteInterchangeHeader(CTextNode& header)
{
	if (header.GetName() == _T("UNB"))
	{
		CTextNode* s001 = MakeSureExists(header, _T("S001"));
		CTextNode* s002 = MakeSureExists(header, _T("S002"));
		CTextNode* s003 = MakeSureExists(header, _T("S003"));
		CTextNode* s004 = MakeSureExists(header, _T("S004"));
		CTextNode* f0020 = MakeSureExists(header, _T("F0020"));

		CompleteS001(*s001);
		CompleteS002(*s002);
		CompleteS003(*s003);
		CompleteS004(*s004);
	}
	else if (header.GetName() == _T("UIB"))
	{
		CTextNode* s001 = MakeSureExists(header, _T("S001"));
		CTextNode* s002 = MakeSureExists(header, _T("S002"));
		CTextNode* s003 = MakeSureExists(header, _T("S003"));

		CompleteS001(*s001);
		CompleteS002(*s002);
		CompleteS003(*s003);
	}
}

void CEDIFactDataCompletion::CompleteInterchangeTrailer(CTextNode& trailer)
{
	if (trailer.GetName() == _T("UNZ"))
	{
		CTextNode* f0036 = MakeSureExists(trailer, _T("F0036"));
		CTextNode* f0020 = MakeSureExists(trailer, _T("F0020"));

		ConservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(*trailer.GetParent(), false));
		CTextNode* unb = trailer.GetParent()->GetChildren()->GetFirstNodeByName(_T("UNB"));
		CTextNodeContainer unbChildren;
		unb->GetChildren()->FilterByName(_T("F0020"), unbChildren);
		ConservativeSetValue(f0020, unbChildren.GetAt(unbChildren.GetCount()-1));
	}
	else if (trailer.GetName() == _T("UIZ"))
	{
		CTextNode* f0036 = MakeSureExists(trailer, _T("F0036"));

		ConservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(*trailer.GetParent(), true));
		CTextNode* uib = trailer.GetParent()->GetChildren()->GetFirstNodeByName(_T("UIB"));
		CTextNodeContainer uibChildren;
		uib->GetChildren()->FilterByName(_T("S302"), uibChildren);
		if (uibChildren.GetCount() > 0)
		{
			CTextNode* uib_s302 = uibChildren.GetAt(0);
			CTextNode* s302 = MakeSureExists(trailer, _T("S302"));
			CompleteS302(*s302, *uib_s302);
		}
	}
}

void CEDIFactDataCompletion::CompleteGroup(CTextNode& group, const CEDIParticle& groupParticle)
{
	const CEDIParticle* groupHeader = groupParticle.GetFirstChildByName(_T("UNG"));
	const CEDIParticle* groupTrailer = groupParticle.GetFirstChildByName(_T("UNE"));

	CTextNode* header = NULL;
	CTextNode* trailer = NULL;
	if (groupHeader != NULL && groupTrailer != NULL)
	{
		header = group.GetChildren()->GetFirstNodeByName(groupHeader->GetName());
		trailer = group.GetChildren()->GetFirstNodeByName(groupTrailer->GetName());

		if (header != NULL)
		{
			trailer = MakeSureExists(group, groupTrailer->GetName());
		}
		else if (trailer != NULL)
		{
			header = MakeSureExists(group, groupHeader->GetName());
		}
	}

	for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
		 it != m_rDocument.GetMessages().end();
		 ++it)
	{
		CTextNodeContainer multiMessages;
		group.GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
		for(size_t i=0; i < multiMessages.GetCount(); ++i)
		{
 			const CEDIParticle& messageParticle = it->second.GetRootParticle();
			CompleteMandatory(*multiMessages.GetAt(i), messageParticle);
			CompleteMessage((*it).second.GetMessageType(), *multiMessages.GetAt(i), messageParticle);
		}
	}

	CTextNodeContainer messages;
	group.GetChildren()->FilterByName(_T("Message"), messages);
	for(size_t i=0; i< messages.GetCount(); ++i)
		CompleteMessage(m_Settings.GetMessageType(), *messages.GetAt(i), m_rDocument.GetFirstMessage().GetRootParticle());

	if (header != NULL && trailer != NULL)
	{
		CompleteGroupHeader(*header);
		CompleteGroupTrailer(*trailer);
	}
}

void CEDIFactDataCompletion::CompleteGroupHeader(CTextNode& ung)
{
	CTextNode* s006 = MakeSureExists(ung, _T("S006"));
	CTextNode* s007 = MakeSureExists(ung, _T("S007"));
	CTextNode* s004 = MakeSureExists(ung, _T("S004"));
	CTextNode* f0048 = MakeSureExists(ung, _T("F0048"));
	CTextNode* f0051 = MakeSureExists(ung, _T("F0051"));
	CTextNode* s008 = MakeSureExists(ung, _T("S008"));
	CTextNode* f0058 = MakeSureExists(ung, _T("F0058"));
	
	CompleteS004(*s004);
	
	CTextNode* une = ung.GetParent()->GetChildren()->GetFirstNodeByName(_T("UNE"));
	if (une)
		ConservativeSetValue(f0048, une->GetChildren()->GetFirstNodeByName(_T("F0048")));
		
	ConservativeSetValue(f0051, m_Settings.GetControllingAgency().substr(0,2));
}

void CEDIFactDataCompletion::CompleteGroupTrailer(CTextNode& une)
{
	CTextNode* f0060 = MakeSureExists(une, _T("F0060"));
	CTextNode* f0048 = MakeSureExists(une, _T("F0048"));

	CTextNodeContainer messages;
	une.GetParent()->GetChildren()->FilterByName(_T("Message"), messages);
	size_t nMsgCount = messages.GetCount();
	for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
		it != m_rDocument.GetMessages().end();
		++it)
	{
		CTextNodeContainer multiMessages;
		une.GetParent()->GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
		nMsgCount += multiMessages.GetCount();
	}
	ConservativeSetValue(f0060, nMsgCount);
	
	CTextNode* ung = une.GetParent()->GetChildren()->GetFirstNodeByName(_T("UNG"));
	if (ung)
		ConservativeSetValue(f0048, ung->GetChildren()->GetFirstNodeByName(_T("F0048")));
}

void CEDIFactDataCompletion::CompleteMessage(const tstring& sMessageType, CTextNode& message, const CEDIParticle& messageParticle)
{
	const CEDIParticle* messageHeader = messageParticle.GetFirstChildByName(_T("UNH")) ? messageParticle.GetFirstChildByName(_T("UNH")) : messageParticle.GetFirstChildByName(_T("UIH"));
	const CEDIParticle* messageTrailer = messageParticle.GetFirstChildByName(_T("UNT")) ? messageParticle.GetFirstChildByName(_T("UNT")) : messageParticle.GetFirstChildByName(_T("UIT"));

	CTextNode* header = MakeSureExists(message, messageHeader->GetName());
	CTextNode* trailer = MakeSureExists(message, messageTrailer->GetName());

	CompleteMessageHeader(sMessageType, *header, *messageHeader);
	CompleteMessageTrailer(*trailer, *messageTrailer);
}

void CEDIFactDataCompletion::CompleteMessageHeader(const tstring& sMessageType, CTextNode& header, const CEDIParticle& headerParticle) 
{
	if (headerParticle.GetName() == _T("UNH"))
	{
		CTextNode* f0062 = MakeSureExists(header, _T("F0062"));
		CTextNode* s009 = MakeSureExists(header, _T("S009"));

		tstring referenceNumber;
		CTextNode* unt = header.GetParent()->GetChildren()->GetFirstNodeByName(_T("UNT"));
		if (unt)
			referenceNumber = unt->GetValue();

		if (referenceNumber.length() == 0)
			referenceNumber = _T("0");

		ConservativeSetValue(f0062, referenceNumber);
		CompleteS009(sMessageType, *s009);
	}
	else if (headerParticle.GetName() == _T("UIH"))
	{
		CTextNode* f0340 = MakeSureExists(header, _T("F0340"));
		CTextNode* s306 = MakeSureExists(header, _T("S306"));

		tstring referenceNumber;
		CTextNode* unt = header.GetParent()->GetChildren()->GetFirstNodeByName(_T("UIT"));
		if (unt)
			referenceNumber = unt->GetValue();

		if (referenceNumber.length() == 0)
			referenceNumber = _T("0");

		ConservativeSetValue(f0340, referenceNumber);
		CompleteS306(sMessageType, *s306);


		CTextNodeContainer interchange_uib;
		header.GetParent()->GetParent()->GetChildren()->FilterByName(_T("UIB"), interchange_uib);
		if (interchange_uib.GetCount() > 0)
		{
			CTextNode* uib = interchange_uib.GetAt(0);
			CTextNodeContainer uibChildren;
			uib->GetChildren()->FilterByName(_T("S302"), uibChildren);
			if (uibChildren.GetCount() > 0)
			{
				CTextNode* uib_s302 = uibChildren.GetAt(0);
				CTextNode* s302 = MakeSureExists(header, _T("S302"));
				CompleteS302(*s302, *uib_s302);
			}
		}
	}
}

void CEDIFactDataCompletion::CompleteMessageTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle)
{
	if (trailerParticle.GetName() == _T("UNT"))
	{
		CTextNode* f0074 = MakeSureExists(trailer, _T("F0074"));
		CTextNode* f0062 = MakeSureExists(trailer, _T("F0062"));

		ConservativeSetValue(f0074, GetSegmentChildrenCount(*trailer.GetParent()));
		CTextNode* unh = trailer.GetParent()->GetChildren()->GetFirstNodeByName(_T("UNH"));
		if (unh)
			ConservativeSetValue(f0062, unh->GetChildren()->GetFirstNodeByName(_T("F0062")));
	}
	else if (trailerParticle.GetName() == _T("UIT"))
	{
		CTextNode* f0340 = MakeSureExists(trailer, _T("F0340"));
		CTextNode* f0074 = MakeSureExists(trailer, _T("F0074"));

		CTextNode* uih = trailer.GetParent()->GetChildren()->GetFirstNodeByName(_T("UIH"));
		if (uih)
			ConservativeSetValue(f0340, uih->GetChildren()->GetFirstNodeByName(_T("F0340")));
		ConservativeSetValue(f0074, GetSegmentChildrenCount(*trailer.GetParent()));
	}
}

void CEDIFactDataCompletion::CompleteS001(CTextNode& s001)
{
	CTextNode* f0001 = MakeSureExists(s001, _T("F0001"));
	CTextNode* f0002 = MakeSureExists(s001, _T("F0002"));

	ConservativeSetValue(f0001, m_Settings.GetControllingAgency() + m_Settings.GetSyntaxLevel());
	ConservativeSetValue(f0002, m_Settings.GetSyntaxVersionNumber());
}

void CEDIFactDataCompletion::CompleteS002(CTextNode& s002)
{
	CTextNode* f0004 = MakeSureExists(s002, _T("F0004"));
	ConservativeSetValue(f0004, _T("Sender"));
}

void CEDIFactDataCompletion::CompleteS003(CTextNode& s003)
{
	CTextNode* f0010 = MakeSureExists(s003, _T("F0010"));
	ConservativeSetValue(f0010, _T("Recipient"));
}

void CEDIFactDataCompletion::CompleteS004(CTextNode& s004)
{
	CTextNode* f0017 = MakeSureExists(s004, _T("F0017"));
	CTextNode* f0019 = MakeSureExists(s004, _T("F0019"));

	ConservativeSetValue(f0017, GetCurrentDateAsEDIString(m_Settings.GetSyntaxVersionNumber()));
	ConservativeSetValue(f0019, GetCurrentTimeAsEDIString());
}

void CEDIFactDataCompletion::CompleteS009(const tstring& sMessageType, CTextNode& s009)
{
	CTextNode* f0065 = MakeSureExists(s009, _T("F0065"));
	CTextNode* f0052 = MakeSureExists(s009, _T("F0052"));
	CTextNode* f0054 = MakeSureExists(s009, _T("F0054"));
	CTextNode* f0051 = MakeSureExists(s009, _T("F0051"));
	
	ConservativeSetValue(f0065, sMessageType);
	ConservativeSetValue(f0051, m_Settings.GetControllingAgency().substr(0, 2));
	ConservativeSetValue(f0052, m_Settings.GetVersion());
	ConservativeSetValue(f0054, m_Settings.GetRelease());
}

void CEDIFactDataCompletion::CompleteS302(CTextNode& s302, CTextNode& uib_s302)
{
	for(size_t i = 0; i < uib_s302.GetChildren()->GetCount(); i++)
	{
		CTextNode* node = MakeSureExists(s302, uib_s302.GetChildren()->GetAt(i)->GetName());
		ConservativeSetValue(node, uib_s302.GetChildren()->GetAt(i)->GetValue());
	}
}

void CEDIFactDataCompletion::CompleteS306(const tstring& sMessageType, CTextNode& s306)
{
	CompleteS009(sMessageType, s306);
}

size_t CEDIFactDataCompletion::GetNumberOfFunctionGroupsOrMessages(CTextNode& node, bool interactive)
{
	size_t nUNH =0;
	size_t nUNT =0;
	size_t nUNG =0;
	size_t nUNE =0;

	CTextNodeContainer groups;
	node.GetChildren()->FilterByName(_T("Group"), groups);
	if (interactive)
	{
		for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
			it != m_rDocument.GetMessages().end();
			++it)
		{
			CTextNodeContainer multiMessages;
			node.GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
			for (size_t k=0; k < multiMessages.GetCount(); ++k)
			{
				CTextNodeContainer uihs;
				multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UIH"), uihs);
				nUNH +=  uihs.GetCount();
				CTextNodeContainer uits;
				multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UIT"), uits);
				nUNT += uits.GetCount();
			}
		}
		CTextNodeContainer messages;
		node.GetChildren()->FilterByName(_T("Message"), messages);
		for (size_t j=0; j< messages.GetCount(); ++j)
		{
			CTextNodeContainer uihs;
			messages.GetAt(j)->GetChildren()->FilterByName(_T("UIH"), uihs);
			nUNH +=  uihs.GetCount();
			CTextNodeContainer uits;
			messages.GetAt(j)->GetChildren()->FilterByName(_T("UIT"), uits);
			nUNT += uits.GetCount();
		}
	}
	else
		for (size_t i = 0; i < groups.GetCount(); ++i)
		{
			CTextNodeContainer ungs;
			groups.GetAt(i)->GetChildren()->FilterByName(_T("UNG"), ungs);
			nUNG += ungs.GetCount();
			CTextNodeContainer unes;
			groups.GetAt(i)->GetChildren()->FilterByName(_T("UNE"), unes);
			nUNE += unes.GetCount();

			CTextNodeContainer messages;
			groups.GetAt(i)->GetChildren()->FilterByName(_T("Message"), messages);
			for (size_t j=0; j< messages.GetCount(); ++j)
			{
				CTextNodeContainer unhs;
				messages.GetAt(j)->GetChildren()->FilterByName(_T("UNH"), unhs);
				nUNH +=  unhs.GetCount();
				CTextNodeContainer unts;
				messages.GetAt(j)->GetChildren()->FilterByName(_T("UNT"), unts);
				nUNT += unts.GetCount();
			}

			for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
				it != m_rDocument.GetMessages().end();
				++it)
			{
				CTextNodeContainer multiMessages;
				groups.GetAt(i)->GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
				for (size_t k=0; k < multiMessages.GetCount(); ++k)
				{
					CTextNodeContainer unhs;
					multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UNH"), unhs);
					nUNH +=  unhs.GetCount();
					CTextNodeContainer unts;
					multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UNT"), unts);
					nUNT += unts.GetCount();
				}
			}
		}
	
	if (nUNH != nUNT)
		throw CTextException(CAltovaException::eError1, _T("Message header-trailer mismatch"));
	if (nUNG != nUNE)
		throw CAltovaException(CAltovaException::eError1, _T("Group header-trailer mismatch"));

	return nUNG == 0 ? nUNH : nUNG;
}

} // namespace edi
} // namespace text
} // namespace altova
