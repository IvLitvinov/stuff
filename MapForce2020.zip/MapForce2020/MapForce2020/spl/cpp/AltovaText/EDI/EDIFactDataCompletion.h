[call GenerateFileHeader("EDIFactDataCompletion.h")]
#ifndef __EDIFACTDATACOMPLETION_H
#define __EDIFACTDATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIFactSettings;

class CEDIFactDataCompletion : public CDataCompletion
{
public:
	CEDIFactDataCompletion(const CTextDocument& rDocument, const CEDIFactSettings&, const tstring&);
	void CompleteData(CTextNode* dataroot, const CEDIParticle&);

protected:
	void CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle);
	void CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle);
	void CompleteInterchangeHeader(CTextNode& unb);
	void CompleteInterchangeTrailer(CTextNode& unz);
	void CompleteGroup(CTextNode& group, const CEDIParticle& groupParticle);
	void CompleteGroupHeader(CTextNode& ung);
	void CompleteGroupTrailer(CTextNode& une);
	void CompleteMessage(const tstring& sMessageType, CTextNode& message, const CEDIParticle& messageParticle);
	void CompleteMessageHeader(const tstring& sMessageType, CTextNode& header, const CEDIParticle& headerParticle);
	void CompleteMessageTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle);
	void CompleteS001(CTextNode& s001);
	void CompleteS002(CTextNode& s002);
	void CompleteS003(CTextNode& s003);
	void CompleteS004(CTextNode& s004);
	void CompleteS009(const tstring& sMessageType, CTextNode& s009);
	void CompleteS302(CTextNode& s302, CTextNode& uib_s302);
	void CompleteS306(const tstring& sMessageType, CTextNode& s306);
	size_t GetNumberOfFunctionGroupsOrMessages(CTextNode& node, bool interactive);

private:
	const CEDIFactSettings& m_Settings;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif