[call GenerateFileHeader("EDIFactSettings.cpp")]
#include "StdAfx.h"
#include "EDIFactSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIFactSettings::CEDIFactSettings()
:	m_SyntaxVersionNumber(2)
,	m_SyntaxLevel(_T('A'))
,	m_WriteUNA(true)
{
	m_ControllingAgency = _T("UNO");
	m_EDIKind = EDIFact;
}
size_t CEDIFactSettings::GetSyntaxVersionNumber() const
{
	return m_SyntaxVersionNumber;
}
TCHAR CEDIFactSettings::GetSyntaxLevel() const
{
	return m_SyntaxLevel;
}
bool CEDIFactSettings::GetWriteUNA() const
{
	return m_WriteUNA;
}
void CEDIFactSettings::SetSyntaxVersionNumber(size_t rhs)
{
	m_SyntaxVersionNumber= rhs;
}
void CEDIFactSettings::SetSyntaxLevel(TCHAR rhs)
{
	m_SyntaxLevel= rhs;
}
void CEDIFactSettings::SetWriteUNA(bool rhs)
{
	m_WriteUNA= rhs;
}

} // namespace edi
} // namespace text
} // namespace altova
