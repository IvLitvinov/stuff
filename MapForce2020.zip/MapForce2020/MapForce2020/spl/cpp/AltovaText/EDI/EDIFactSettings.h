[call GenerateFileHeader("EDIFactSettings.h")]
#ifndef __EDIFACTSETTINGS_H
#define __EDIFACTSETTINGS_H

#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDIFactSettings : public CEDISettings
{
public:
	CEDIFactSettings();
	size_t GetSyntaxVersionNumber() const;
	TCHAR GetSyntaxLevel() const;
	bool GetWriteUNA() const;

	void SetSyntaxVersionNumber( size_t );
	void SetSyntaxLevel(TCHAR);
	void SetWriteUNA(bool);

private:
	size_t m_SyntaxVersionNumber;
	TCHAR m_SyntaxLevel;
	bool m_WriteUNA;

};
} // namespace edi
} // namespace text
} // namespace altova

#endif