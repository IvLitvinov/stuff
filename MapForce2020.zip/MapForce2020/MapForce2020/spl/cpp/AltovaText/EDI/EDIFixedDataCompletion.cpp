[call GenerateFileHeader("EDIFixedDataCompletion.cpp")]
#include "StdAfx.h"
#include "EDIFixedDataCompletion.h"
#include "TextNode.h"
#include "EDIFixedSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIFixedDataCompletion::CEDIFixedDataCompletion( const CTextDocument& rDocument,
												  const CEDIFixedSettings& settings,
											 	  const tstring& structurename)
:	CDataCompletion(rDocument, structurename)
,	m_Settings(settings)
{
}

void CEDIFixedDataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);
}

} // namespace edi
} // namespace text
} // namespace altova