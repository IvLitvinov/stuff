[call GenerateFileHeader("EDIFixedDataCompletion.h")]
#ifndef __EDIFIXEDDATACOMPLETION_H
#define __EDIFIXEDDATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIFixedSettings;

class ALTOVATEXT_DECLSPECIFIER CEDIFixedDataCompletion : public CDataCompletion
{
public:
	CEDIFixedDataCompletion(const CTextDocument& rDocument, const CEDIFixedSettings&, const tstring&);

public: // implementing CDataCompletion
	virtual void CompleteData(CTextNode*, const CEDIParticle&);

private:
	const CEDIFixedSettings& m_Settings;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif