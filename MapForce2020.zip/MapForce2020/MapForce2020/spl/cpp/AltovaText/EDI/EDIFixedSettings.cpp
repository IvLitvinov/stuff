[call GenerateFileHeader("EDIFixedSettings.cpp")]
#include "StdAfx.h"
#include "AltovaTextAPI.h"
#include "EDIFixedSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIFixedSettings::CEDIFixedSettings()
{
	m_EDIKind = EDIFixed;
}

} // namespace edi
} // namespace text
} // namespace altova
