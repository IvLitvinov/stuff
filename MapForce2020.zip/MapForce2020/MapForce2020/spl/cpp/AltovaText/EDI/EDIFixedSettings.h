[call GenerateFileHeader("EDIFixedSettings.h")]
#ifndef __EDIFIXEDSETTINGS_H
#define __EDIFIXEDSETTINGS_H

#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDIFixedSettings : public CEDISettings
{
public:
	CEDIFixedSettings();

private:

};


} // namespace edi
} // namespace text
} // namespace altova

#endif