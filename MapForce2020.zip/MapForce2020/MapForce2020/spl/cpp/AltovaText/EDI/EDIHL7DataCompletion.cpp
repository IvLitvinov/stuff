[call GenerateFileHeader("EDIHL7DataCompletion.cpp")]
#include "StdAfx.h"
#include "EDIHL7DataCompletion.h"
#include "TextNode.h"
#include "EDIHL7Settings.h"
#include "TextDocument.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIHL7DataCompletion::CEDIHL7DataCompletion(const CTextDocument& rDocument,
											 const CEDIHL7Settings& settings,
											 const tstring& structurename)
:	CDataCompletion(rDocument, structurename)
,	m_Settings(settings)
{
}

void CEDIHL7DataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);

	if( rootParticle.GetNode()->GetName() == _T("GroupFHS") ) //batch format
	{
		CompleteGroupFHS( dataroot );
	}
	else
	{
		CompleteMSH(GetStructureName(), MakeSureExists( dataroot, _T("MSH")));
	}
}

void CEDIHL7DataCompletion::CompleteGroupFHS( CTextNode* pFHS)
{
	if( HasKid( pFHS, _T("FTS") ) )
	{
		MakeSureExists( pFHS, _T("FHS") );
	}
	if( HasKid( pFHS, _T("FHS") ) )
	{
		CompleteSegmentFHS( pFHS->GetChildren()->GetFirstNodeByName( _T("FHS") ) );
		MakeSureExists( pFHS, _T("FTS") );
	}

	CompleteGroupBHS( pFHS->GetChildren()->GetFirstNodeByName(_T("GroupBHS") ) );

	if( HasKid( pFHS, _T("FTS") ) )
	{
		CTextNode* rFTS = pFHS->GetChildren()->GetFirstNodeByName( _T("FTS") );
		CTextNodeContainer oBatchGroups;
		pFHS->GetChildren()->FilterByName( _T("GroupBHS"), oBatchGroups );
		CTextNode* rFTS1 = MakeSureExists( rFTS, _T("FTS-1") );
		ConservativeSetValue(rFTS1, oBatchGroups.GetCount() );
	}
}

void CEDIHL7DataCompletion::CompleteGroupBHS( CTextNode* pBHS)
{
	if( HasKid( pBHS, _T("BTS") ) )
	{
		MakeSureExists( pBHS, _T("BHS") );
	}
	if( HasKid( pBHS, _T("BHS") ) )
	{
		CompleteSegmentBHS( pBHS->GetChildren()->GetFirstNodeByName( _T("BHS") ) );
		MakeSureExists( pBHS, _T("BTS") );
	}

	size_t nMessages = 0;
	for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
		it != m_rDocument.GetMessages().end();
		++it)
	{
		CTextNodeContainer messages;
		pBHS->GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), messages);
		for(size_t i=0; i < messages.GetCount(); ++i)
		{
			CTextNode* pMessage = messages.GetAt(i);
			CompleteMandatory( *pMessage, (*it).second.GetRootParticle());
			MakeSureExists(*pMessage, _T("ST"));
			MakeSureExists(*pMessage, _T("SE"));
			CompleteMSH((*it).second.GetMessageType(), MakeSureExists( pMessage, _T("MSH")) );
		}
		nMessages += messages.GetCount();
	}

	if( HasKid( pBHS, _T("BTS") ) )
	{
		CTextNode* pBTS = pBHS->GetChildren()->GetFirstNodeByName( _T("BTS") );
		CTextNode* pBTS1 = MakeSureExists( pBTS, _T("BTS-1") );
		ConservativeSetValue( pBTS1, nMessages );
	}
}

void CEDIHL7DataCompletion::CompleteSegmentFHS( CTextNode* pFHS)
{
	//Data element separator
	CTextNode* rFHS1 = MakeSureExists( pFHS, _T("FHS-1"));
	//this value will be overwritten, it just needs to be set
	rFHS1->SetValue( _T("-"));

	//Encoding Characters
	CTextNode* rFHS2 = MakeSureExists( pFHS, _T("FHS-2"));
	//this value will be overwritten, it just needs to be set
	rFHS2->SetValue( _T("#@!"));

	//Date/Time of Message
	CTextNode* pFHS7 = MakeSureExists( pFHS, _T("FHS-7"));
	FillDateTime( pFHS7);
}

void CEDIHL7DataCompletion::CompleteSegmentBHS( CTextNode* pBHS)
{
	//Data element separator
	CTextNode* rBHS1 = MakeSureExists( pBHS, _T("BHS-1"));
	//this value will be overwritten, it just needs to be set
	rBHS1->SetValue( _T("-"));

	//Encoding Characters
	CTextNode* rBHS2 = MakeSureExists( pBHS, _T("BHS-2"));
	//this value will be overwritten, it just needs to be set
	rBHS2->SetValue( _T("#@!"));

	//Date/Time of Message
	CTextNode* pBHS7 = MakeSureExists( pBHS, _T("BHS-7"));
	FillDateTime( pBHS7);
}

void CEDIHL7DataCompletion::CompleteMSH( const tstring& sMessageType, CTextNode* pMSH)
{
	//MSH-1 Data element separator
	CTextNode* pMSH1 = MakeSureExists( pMSH, _T("MSH-1"));
	//this value will be overwritten, it just needs to be set
	ConservativeSetValue( pMSH1, _T("-"));

	//MSH-2 Encoding Characters
	CTextNode* pMSH2 = MakeSureExists( pMSH, _T("MSH-2"));
	//this value will be overwritten, it just needs to be set
	ConservativeSetValue( pMSH2, _T("#@!"));

	//MSH-7 Date/Time of Message
	CTextNode* pMSH7 = MakeSureExists( pMSH, _T("MSH-7"));
	FillDateTime( pMSH7);


	//MSH-9 Message Type
	CTextNode* pMSH9 = MakeSureExists( pMSH, _T("MSH-9"));
	CompleteMSG(sMessageType, pMSH9);

	//MSH-12 Version ID
	CTextNode* pMSH12 = MakeSureExists( pMSH, _T("MSH-12"));
	CTextNode* pVID1 = MakeSureExists( pMSH12, _T("VID-1"));
	ConservativeSetValue( pVID1, m_Settings.GetRelease());
}

void CEDIHL7DataCompletion::CompleteMSG( const tstring& sMessageType, CTextNode* pMSG)
{
	//the example MSG Type is: QBP_Z73
	size_t pos = sMessageType.find(_T('_'));
	tstring messageCode(_T(""));
	tstring messageEvent(_T(""));
	if( pos != string::npos)
	{
		messageCode = sMessageType.substr( 0, pos);
		messageEvent = sMessageType.substr( pos + 1);
	}

	//Message Code: QBP
	CTextNode* pMSG1 = MakeSureExists( pMSG, _T("MSG-1"));
	ConservativeSetValue( pMSG1, messageCode);

	//Trigger Event: Z73
	CTextNode* pMSG2 = MakeSureExists( pMSG, _T("MSG-2"));
	ConservativeSetValue( pMSG2, messageEvent);

	//Message Structure: QBP_Z73
	CTextNode* pMSG3 = MakeSureExists( pMSG, _T("MSG-3"));
	ConservativeSetValue( pMSG3, sMessageType);
}

void CEDIHL7DataCompletion::FillDateTime( CTextNode* pDateField)
{
	if( m_Settings.GetRelease() == _T("2.6"))
        ConservativeSetValue( pDateField, GetCurrentDateAsEDIString(4) + GetCurrentTimeAsEDIString());
    else
    {
        CTextNode* pTS1 = MakeSureExists( pDateField, _T("TS-1"));
        ConservativeSetValue( pTS1, GetCurrentDateAsEDIString(4) + GetCurrentTimeAsEDIString());
    }
}

} // namespace edi
} // namespace text
} // namespace altova
