[call GenerateFileHeader("EDIHL7DataCompletion.h")]
#ifndef __EDIHL7DATACOMPLETION_H
#define __EDIHL7DATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIHL7Settings;

class ALTOVATEXT_DECLSPECIFIER CEDIHL7DataCompletion : public CDataCompletion
{
public:
	CEDIHL7DataCompletion(const CTextDocument& rDocument, const CEDIHL7Settings&, const tstring&);

public: // implementing CDataCompletion
	virtual void CompleteData(CTextNode*, const CEDIParticle&);

private:
	void CompleteGroupFHS(  CTextNode* pFHS);
	void CompleteGroupBHS(  CTextNode* pBHS);
	void CompleteSegmentFHS( CTextNode* pFHS);
	void CompleteSegmentBHS( CTextNode* pBHS);
	void CompleteMSH( const tstring& sMessageType, CTextNode* pMSH);
	void CompleteMSG( const tstring& sMessageType, CTextNode* pMSG);
	void FillDateTime( CTextNode* pDateField);

private:
	const CEDIHL7Settings& m_Settings;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif
