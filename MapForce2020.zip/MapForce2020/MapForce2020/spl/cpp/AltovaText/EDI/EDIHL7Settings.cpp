[call GenerateFileHeader("EDIHL7Settings.cpp")]
#include "StdAfx.h"
#include "AltovaTextAPI.h"
#include "EDIHL7Settings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIHL7Settings::CEDIHL7Settings()
{
	m_EDIKind = EDIHL7;
}

const TCHAR CEDIHL7Settings::cEscStartHighlight =		_T('H'); //H
const TCHAR CEDIHL7Settings::cEscNormalText =			_T('N'); //N
const TCHAR CEDIHL7Settings::cEscFieldSeparator =		_T('F'); //F
const TCHAR CEDIHL7Settings::cEscComponentSeparator =	_T('S');  //S
const TCHAR CEDIHL7Settings::cEscSubComponentSeparator = _T('T'); //T
const TCHAR CEDIHL7Settings::cEscRepetitionSeparator =	_T('R'); //R
const TCHAR CEDIHL7Settings::cEscEscapeSeparator =		_T('E'); //E
const TCHAR CEDIHL7Settings::cEscHexadecimalData =		_T('X'); //X
const TCHAR CEDIHL7Settings::cEscLocalEscapeSeq =		_T('Z'); //Z

} // namespace edi
} // namespace text
} // namespace altova
