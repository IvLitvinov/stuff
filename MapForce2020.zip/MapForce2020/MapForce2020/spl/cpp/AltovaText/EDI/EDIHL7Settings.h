[call GenerateFileHeader("EDIHL7Settings.h")]
#ifndef __EDIHL7SETTINGS_H
#define __EDIHL7SETTINGS_H

#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDIHL7Settings : public CEDISettings
{
public:
	CEDIHL7Settings();

	//escape sequences, V26_CH02_Control.pdf 2.7.1 Formatting codes
	static const TCHAR cEscStartHighlight; //H
	static const TCHAR cEscNormalText; //N
	static const TCHAR cEscFieldSeparator; //F
	static const TCHAR cEscComponentSeparator;  //S
	static const TCHAR cEscSubComponentSeparator; //T
	static const TCHAR cEscRepetitionSeparator; //R
	static const TCHAR cEscEscapeSeparator; //E
	static const TCHAR cEscHexadecimalData; //X
	static const TCHAR cEscLocalEscapeSeq; //Z

private:

};


} // namespace edi
} // namespace text
} // namespace altova

#endif