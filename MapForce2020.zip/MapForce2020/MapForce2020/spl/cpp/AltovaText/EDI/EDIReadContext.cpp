[call GenerateFileHeader("EDIReadContext.cpp")]
#include "StdAfx.h"

#include "EDIReadContext.h"
#include "Scanner.h"
#include "Generator.h"
#include "TextException.h"
#include "EDIX12Settings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIReadContext::CEDIReadContext( const CEDIReadContext& rParent, const CEDIParticle& rParticle, CEDISemanticValidator& rValidator ) :
	m_rScanner (rParent.m_rScanner), m_rParser (rParent.m_rParser), m_rParticle (rParticle),
	m_rGenerator (rParent.m_rGenerator), m_pGeneratorForErrors(NULL), m_pParent (&rParent),
	m_rValidator( rValidator), m_Occurence( 0)
{
	if( rParticle.GetNameOverride().find(_T("Message")) == 0 )
	{
		m_pGeneratorForErrors = new CGenerator();
		m_pGeneratorForErrors->EnterElement( _T("ParserErrors_Message"), ErrorList );
	}	
	else
	if( rParticle.GetNameOverride() == _T("Group") )
	{
		m_pGeneratorForErrors = new CGenerator();
		m_pGeneratorForErrors->EnterElement( _T("ParserErrors_Group"), ErrorList );
	}
}

CEDIReadContext::~CEDIReadContext()
{
	delete m_pGeneratorForErrors;
}

void CEDIReadContext::CreateGeneratorForErrors( const tstring& sName)
{
	delete m_pGeneratorForErrors;
	m_pGeneratorForErrors = new CGenerator();
	m_pGeneratorForErrors->EnterElement( sName, ErrorList );
}

void CEDIReadContext::HandleError (const CEDIParser::Errors error, const CEDIErrorPosition& errorPos, const tstring message, const tstring originalData) const
{
	CGenerator* pGen = FindGenerator();
	tstring location = m_rParticle.GetNode()->GetName();
	const CEDIReadContext* parent = m_pParent;
	while (parent != 0)
	{
		if(parent->m_rParticle.GetNode()->GetNodeClass() != Select)
			location = parent->m_rParticle.GetNode()->GetName() + _T(" / ") + location;
		parent = parent->m_pParent;
	}
	location += _T(": ") + message;
	
	tstringstream streamLocation;
	streamLocation << _T("Line ") << errorPos.GetLine() << _T(" column ") << errorPos.GetColumn() << _T(" (offset 0x");
	streamLocation.flags( std::ios::hex );
	streamLocation << errorPos.GetPosition() << _T("): ");
	location = streamLocation.str() + location;

	switch ( m_rParser.GetErrorAction( error) )
	{
		case CEDIParser::ActionStop:
		{
			throw CTextException (CAltovaException::eError1, location);
		}
		case CEDIParser::ActionReportReject:
		{
			m_rParser.SetF717( _T('R') );
			m_rParser.SetF715( _T('R') );
			tcerr << location.c_str() << endl;
		}
		break;
		case CEDIParser::ActionReportAccept:
		{
			if( m_rParser.GetF717() == _T('A') )
			{
				m_rParser.SetF717( _T('E') );
				m_rParser.SetF715( _T('E') );
			}
			tcerr << location.c_str() << endl;
		}
		break;
		case CEDIParser::ActionIgnore: pGen = NULL; break;
	}

	if( pGen )
	{
		if( m_rParser.GetSettings().GetStandard() == EDIX12)
		{
			ENodeClass nodeClass = m_rParticle.GetNode()->GetNodeClass(); 
			tstring currentSegment = GetCurrentSegmentName();
			tstringstream segmentPositionInTransactionSet;
			segmentPositionInTransactionSet << m_rParser.GetCurrentSegmentPosition();

			if( error == CEDIParser::MissingGroup ||
				error == CEDIParser::ExtraRepeat ||
				nodeClass == Segment ||
				nodeClass == Composite ||
				nodeClass == DataElement )
			{
				pGen->EnterElement( _T("LoopMF_AK3"), Group );
				pGen->EnterElement( _T("MF_AK3"), Group );

				tstring segmentSyntaxErrorCode = _T("");
				switch( error )
				{
				case CEDIParser::ExtraRepeat:
				{
					if( nodeClass == Group)
						segmentSyntaxErrorCode = _T("4");
					else
						segmentSyntaxErrorCode = _T("5");
				}
				break;
				case CEDIParser::MissingGroup:
				case CEDIParser::MissingSegment: segmentSyntaxErrorCode = _T("3"); break;
				case CEDIParser::SegmentUnexpected:
				{
					segmentSyntaxErrorCode = _T("2");
					currentSegment = originalData;
				}
				break;
				case CEDIParser::SegmentUnrecognized:
				{
					segmentSyntaxErrorCode = _T("1");
					currentSegment = originalData;
				}
				break;
				default:
					if( nodeClass == Composite ||
						nodeClass == DataElement )
						segmentSyntaxErrorCode = _T("8");
					else
						segmentSyntaxErrorCode = _T("2");
				}

				pGen->InsertElement( _T("F721"), currentSegment, DataElement );
				pGen->InsertElement( _T("F719"), segmentPositionInTransactionSet.str(), DataElement );
				if( m_rParser.GetF447().size() > 0)
					pGen->InsertElement( _T("F447"), m_rParser.GetF447(), DataElement );

				pGen->InsertElement( _T("F720"), segmentSyntaxErrorCode, DataElement );
				pGen->InsertElement( _T("ErrorMessage"), message, DataElement );
				pGen->LeaveElement( _T("MF_AK3") );
			}

			if( nodeClass == Composite ||
				nodeClass == DataElement )
			{
				// error in data element
				pGen->EnterElement( _T("MF_AK4"), Group );

				tstringstream sDataElementPos;
				sDataElementPos << m_rParser.GetDataElementPosition();

				//special X12 3040 handling
				const CEDIX12Settings& x12Settings = static_cast<const CEDIX12Settings&>(m_rParser.GetSettings());
				if( x12Settings.GetRelease() == _T("3040") )
				{
					pGen->InsertElement( _T("F722"), sDataElementPos.str(), DataElement );
				}
				else
				{
					pGen->EnterElement( _T("C030"), Composite );
					pGen->InsertElement( _T("F722"), sDataElementPos.str(), DataElement );

					// is optional F1528
					if( m_rParser.GetComponentDataElementPosition() > 0 )
					{
						tstringstream sComponentDataElementPos;
						sComponentDataElementPos << m_rParser.GetComponentDataElementPosition();
						pGen->InsertElement( _T("F1528"), sComponentDataElementPos.str(), DataElement );
					}

					// is optional F1686
					if( m_Occurence > 0)
					{
						tstringstream sOccurence;
						sOccurence << m_Occurence;
						pGen->InsertElement( _T("F1686"), sOccurence.str(), DataElement );
					}

					pGen->LeaveElement( _T("C030") );
				}

				tstring dataElementReferenceNumber = m_rParticle.GetNode()->GetName().substr( 1 );	// F1234 -> 1234
				pGen->InsertElement( _T("F725"), dataElementReferenceNumber, DataElement );

				tstring sDataElementSyntaxErrorCode = GetX12DataElementErrorCode( error );
				pGen->InsertElement( _T("F723"), sDataElementSyntaxErrorCode, DataElement );
				pGen->InsertElement( _T("F724"), originalData, DataElement );
				pGen->InsertElement( _T("ErrorMessage"), message, DataElement );
				pGen->LeaveElement( _T("MF_AK4") );
			}

			if( error == CEDIParser::MissingGroup ||
				error == CEDIParser::ExtraRepeat ||
				nodeClass == Segment ||
				nodeClass == Composite ||
				nodeClass == DataElement )
			{
				pGen->LeaveElement( _T("LoopMF_AK3") );
			}
		}
	}
}

void CEDIReadContext::HandleWarning (const CEDIErrorPosition& errorPos, const tstring message, const tstring originalData) const
{
	tstring location = m_rParticle.GetNode()->GetName();
	const CEDIReadContext* parent = m_pParent;
	while (parent != 0)
	{
		if(parent->m_rParticle.GetNode()->GetNodeClass() != Select)
			location = parent->m_rParticle.GetNode()->GetName() + _T(" / ") + location;
		parent = parent->m_pParent;
	}
	location += _T(": Warning: ") + message;
	
	tstringstream streamLocation;
	streamLocation << _T("Line ") << errorPos.GetLine() << _T(" column ") << errorPos.GetColumn() << _T(" (offset 0x");
	streamLocation.flags( std::ios::hex );
	streamLocation << errorPos.GetPosition() << _T("): ");
	location = streamLocation.str() + location;
	tcerr << location.c_str() << endl;
}

CGenerator* CEDIReadContext::FindGenerator() const
{
	if( m_pGeneratorForErrors != NULL )
		return m_pGeneratorForErrors;
	if( m_pParent != NULL )
		return m_pParent->FindGenerator();
	return NULL;
}

tstring CEDIReadContext::GetCurrentSegmentName() const
{
	if( m_rParticle.GetNode()->GetNodeClass() == Group &&
		m_rParticle.GetNode()->GetChildCount() > 0)
		return m_rParticle.GetNode()->GetChildren()\[0\].GetNode()->GetName();
	if( m_rParticle.GetNode()->GetNodeClass() == Segment )
		return m_rParticle.GetNode()->GetName();
	if( m_pParent != NULL )
		return m_pParent->GetCurrentSegmentName();
	return _T("");
}

tstring CEDIReadContext::GetX12DataElementErrorCode( const int error ) const
{
	switch( error )
	{
		case CEDIParser::MissingFieldOrComposite : 	return tstring(_T("1"));
		case CEDIParser::ExtraData : 				return tstring(_T("3"));
		case CEDIParser::ExtraRepeat : 				return tstring(_T("3"));
		case CEDIParser::DataElementTooShort : 		return tstring(_T("4"));
		case CEDIParser::DataElementTooLong : 		return tstring(_T("5"));
		case CEDIParser::FieldValueInvalid : 		return tstring(_T("6"));
		case CEDIParser::CodeListValueWrong : 		return tstring(_T("7"));
		case CEDIParser::InvalidDate : 				return tstring(_T("8"));
		case CEDIParser::InvalidTime : 				return tstring(_T("9"));
		case CEDIParser::SemanticWrong : 			return tstring(_T("10"));
		case CEDIParser::NotUsedPresent : 			return tstring(_T("I10"));
		default : return tstring(_T("1"));
	}
}

}
}
}