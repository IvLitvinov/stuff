[call GenerateFileHeader("EDIReadContext.h")]
#ifndef __ALTOVATEXT_EDIREADCONTEXT_H
#define __ALTOVATEXT_EDIREADCONTEXT_H

#include "Parser.h"
#include "Scanner.h"

namespace altova
{
namespace text
{
class CGenerator;
namespace edi
{
class ALTOVATEXT_DECLSPECIFIER CEDIParticle;

class ALTOVATEXT_DECLSPECIFIER CEDIErrorPosition
{
public:
	CEDIErrorPosition(const CEDIScannerState& scannerState)
	: m_nLine( scannerState.GetLine() ), m_nColumn( scannerState.GetColumn() ), m_nPosition( scannerState.GetPosition() )
	{
	}

	size_t GetLine() const { return m_nLine; }
	size_t GetColumn() const { return m_nColumn; }
	size_t GetPosition() const { return m_nPosition; }

private:
	const size_t m_nLine;
	const size_t m_nColumn;
	const size_t m_nPosition;
};

class ALTOVATEXT_DECLSPECIFIER CEDIReadContext
{
public:
	CEDIReadContext (CEDIScanner& rScanner, CEDIParser& rParser, const CEDIParticle& rRootParticle, CGenerator& rGenerator, CEDISemanticValidator& rValidator)
	:	m_rScanner (rScanner), m_rParser (rParser), m_rParticle (rRootParticle), 
		m_rGenerator (rGenerator), m_pGeneratorForErrors(NULL), m_pParent(0), 
		m_rValidator( rValidator), m_Occurence( 0)

	{ }

	CEDIReadContext (const CEDIReadContext& rParent, const CEDIParticle& rParticle, CEDISemanticValidator& rValidator);
	~CEDIReadContext();

	const CEDIReadContext* GetParent () const { return m_pParent; }
	CEDIScanner& GetScanner () const { return m_rScanner; }
	CEDIParser& GetParser () const { return m_rParser; }
	const CEDIParticle& GetParticle () const { return m_rParticle; }
	CGenerator& GetGenerator () const { return m_rGenerator; }
	CGenerator* GetGeneratorForErrors () const { return m_pGeneratorForErrors; }
	void CreateGeneratorForErrors( const tstring& sName);
	CEDISemanticValidator& GetSemanticValidator () const { return m_rValidator; }
	void SetOccurence( const size_t nOccurence) { m_Occurence = nOccurence; }
	tstring GetCurrentSegmentName() const;

	// called to process an error.
	void HandleError (const CEDIParser::Errors error, const CEDIErrorPosition& errorPos, const tstring message, const tstring originalData = _T("") ) const;
	void HandleWarning (const CEDIErrorPosition& errorPos, const tstring message, const tstring originalData = _T("") ) const;

private:
	CGenerator* FindGenerator() const;
	tstring GetX12DataElementErrorCode( const int error ) const;

private:
	const CEDIReadContext* m_pParent;
	CEDIScanner& m_rScanner;
	CEDIParser& m_rParser;
	const CEDIParticle& m_rParticle;
	CGenerator& m_rGenerator;
	CGenerator* m_pGeneratorForErrors;
	CEDISemanticValidator& m_rValidator;

	size_t m_Occurence;

};

}
}
}

#endif