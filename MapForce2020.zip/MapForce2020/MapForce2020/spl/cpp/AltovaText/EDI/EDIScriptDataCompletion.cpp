[call GenerateFileHeader("EDIScriptDataCompletion.cpp")]
#include "StdAfx.h"
#include "EDIScriptDataCompletion.h"
#include "EDIScriptSettings.h"
#include "TextNode.h"
#include "TextException.h"
#include "TextDocument.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIScriptDataCompletion::CEDIScriptDataCompletion( const CTextDocument& rDocument,
												const CEDIScriptSettings& settings,
												const tstring &structurename)
:	CDataCompletion(rDocument, structurename), m_Settings(settings)
{
}
	
void CEDIScriptDataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);
	CompleteEnvelope(*dataroot, rootParticle);
}
	
void CEDIScriptDataCompletion::CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle)
{
	if (envelope.GetName() != rootParticle.GetName())
		throw CTextException(CAltovaException::eError1, _T("CompleteEnvelope: root node is not an envelope"));

	const CEDIParticle& interchangeParticle = rootParticle.GetNode()->GetChildren()\[0\];
	MakeSureExists(envelope, interchangeParticle.GetName());

	CTextNodeContainer interchanges; 
	envelope.GetChildren()->FilterByName(interchangeParticle.GetName(), interchanges);
	for (size_t i=0; i< interchanges.GetCount(); ++i)
			CompleteInterchange(*interchanges.GetAt(i), interchangeParticle);
}

void CEDIScriptDataCompletion::CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle)
{
	const CEDIParticle* interchangeHeader = interchangeParticle.GetFirstChildByName(_T("UIB"));
	const CEDIParticle* interchangeTrailer = interchangeParticle.GetFirstChildByName(_T("UIZ"));

	if (interchangeHeader != NULL  && interchangeTrailer != NULL)
	{
		CTextNode* header = interchange.GetChildren()->GetFirstNodeByName(interchangeHeader->GetName());
		CTextNode* trailer = interchange.GetChildren()->GetLastNodeByName(interchangeTrailer->GetName());
		if (header != NULL && trailer != NULL)
		{
			header = MakeSureExists(interchange, interchangeHeader->GetName());
			trailer = MakeSureExists(interchange, interchangeTrailer->GetName());
		}

		for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
			it != m_rDocument.GetMessages().end();
			++it)
		{
			const tstring& sMessageType = it->first;

			CTextNodeContainer messages;
			interchange.GetChildren()->FilterByName(_T("Message_") + sMessageType, messages);
			for (size_t i = 0; i < messages.GetCount(); ++i)
			{
				CTextNode* node = messages.GetAt(i);
				const CEDIParticle& messageParticle = m_rDocument.GetMessage(sMessageType).GetRootParticle();
				CompleteMandatory(*node, messageParticle);
				CompleteMessage(sMessageType, *node, messageParticle);
			}
		}

		if (header == NULL && trailer == NULL)
			return;

		CompleteInterchangeHeader(*header, *interchangeHeader);
		CompleteInterchangeTrailer(*trailer, *interchangeTrailer);
	}
}

void CEDIScriptDataCompletion::CompleteInterchangeHeader(CTextNode& header, const CEDIParticle& headerParticle)
{
	CTextNode* s001 = MakeSureExists(header, _T("S001"));
	CTextNode* s002 = MakeSureExists(header, _T("S002"));
	CTextNode* s003 = MakeSureExists(header, _T("S003"));
	CTextNode* s300 = MakeSureExists(header, _T("S300"));

	CompleteS001(*s001);
	CompleteS002(*s002);
	CompleteS003(*s003);
	CompleteS300(*s300, *headerParticle.GetFirstChildByName(_T("S300")));
	
	if (headerParticle.GetFirstChildByName(_T("S045")))
	{
		CTextNode* s045 = MakeSureExists(header, _T("S045"));
		CompleteS045(*s045);
	}
}

void CEDIScriptDataCompletion::CompleteInterchangeTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle)
{
	CTextNode* f0036 = MakeSureExists(trailer, _T("F0036"));

	ConservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(*trailer.GetParent()));
}

void CEDIScriptDataCompletion::CompleteMessage(const tstring& sMessageType, CTextNode& message, const CEDIParticle& messageParticle)
{
	const CEDIParticle* messageHeader = messageParticle.GetFirstChildByName(_T("UIH"));
	const CEDIParticle* messageTrailer = messageParticle.GetFirstChildByName(_T("UIT"));

	CTextNode* header = MakeSureExists(message, messageHeader->GetName());
	CTextNode* trailer = MakeSureExists(message, messageTrailer->GetName());

	CompleteMessageHeader(sMessageType, *header, *messageHeader);
	CompleteMessageTrailer(*trailer, *messageTrailer);
}

void CEDIScriptDataCompletion::CompleteMessageHeader(const tstring& sMessageType, CTextNode& header, const CEDIParticle& headerParticle) 
{
	CTextNode* f0062 = MakeSureExists(header, _T("F0062"));
	CTextNode* s306 = MakeSureExists(header, _T("S306"));
	CTextNode* s300 = MakeSureExists(header, _T("S300"));

	tstring referenceNumber;
	CTextNode* uit = header.GetParent()->GetChildren()->GetFirstNodeByName(_T("UIT"));
	if (uit)
		referenceNumber = uit->GetValue();

	if (referenceNumber.length() == 0)
		referenceNumber = _T("0");

	ConservativeSetValue(f0062, referenceNumber);
	CompleteS306(sMessageType, *s306);
	CompleteS300(*s300, *headerParticle.GetFirstChildByName(_T("S300")));
}

void CEDIScriptDataCompletion::CompleteMessageTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle)
{
	CTextNode* f0062 = MakeSureExists(trailer, _T("F0062"));
	CTextNode* f0074 = MakeSureExists(trailer, _T("F0074"));

	CTextNode* uih = trailer.GetParent()->GetChildren()->GetFirstNodeByName(_T("UIH"));
	if (uih)
		ConservativeSetValue(f0062, uih->GetChildren()->GetFirstNodeByName(_T("F0062")));
	ConservativeSetValue(f0074, GetSegmentChildrenCount(*trailer.GetParent()));
}

void CEDIScriptDataCompletion::CompleteS001(CTextNode& s001)
{
	CTextNode* f0001 = MakeSureExists(s001, _T("F0001"));
	CTextNode* f0002 = MakeSureExists(s001, _T("F0002"));

	ConservativeSetValue(f0001, m_Settings.GetControllingAgency() + m_Settings.GetSyntaxLevel());
	ConservativeSetValue(f0002, m_Settings.GetSyntaxVersionNumber());
}

void CEDIScriptDataCompletion::CompleteS002(CTextNode& s002)
{
	CTextNode* f0004 = MakeSureExists(s002, _T("F0004"));
	ConservativeSetValue(f0004, _T("Sender"));
}

void CEDIScriptDataCompletion::CompleteS003(CTextNode& s003)
{
	CTextNode* f0010 = MakeSureExists(s003, _T("F0010"));
	ConservativeSetValue(f0010, _T("Recipient"));
}

void CEDIScriptDataCompletion::CompleteS045(CTextNode& s045)
{
	CTextNode* f8006 = MakeSureExists(s045, _T("F8006"));
	CTextNode* f8007 = MakeSureExists(s045, _T("F8007"));
	CTextNode* f8008 = MakeSureExists(s045, _T("F8008"));
	ConservativeSetValue(f8006, _T("Altova GmbH"));
	ConservativeSetValue(f8007, _T("[=$HostShort]"));
	ConservativeSetValue(f8008, _T("[=$HostVersionName]"));
}

namespace
{
	tstring GetCurrentDateAsString()
	{
		SYSTEMTIME now;
		GetLocalTime(&now);
		TCHAR buffer\[10\];
		GetDateFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, _T("yyyyMMdd"), buffer, 10);
		return buffer;
	}

	tstring GetCurrentTimeAsString()
	{
		SYSTEMTIME now;
		GetLocalTime(&now);
		TCHAR buffer\[10\];
		GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, _T("HHmmss"), buffer, 10);
		return buffer;
	}
}

void CEDIScriptDataCompletion::CompleteS300(CTextNode& s300, const CEDIParticle& particle)
{
	const CEDIParticle* timeField = particle.GetFirstChildByName(_T("F0114"));
	if(!timeField) timeField = particle.GetFirstChildByName(_T("F0314"));
	CTextNode* date = MakeSureExists(s300, _T("F0017"));
	CTextNode* time = MakeSureExists(s300, timeField->GetName());

	ConservativeSetValue(date, GetCurrentDateAsString());
	ConservativeSetValue(time, GetCurrentTimeAsString());
}

void CEDIScriptDataCompletion::CompleteS306(const tstring& sMessageType, CTextNode& s306)
{
	CTextNode* f0329 = MakeSureExists(s306, _T("F0329"));
	CTextNode* f0316 = MakeSureExists(s306, _T("F0316"));
	CTextNode* f0318 = MakeSureExists(s306, _T("F0318"));
	CTextNode* f0326 = MakeSureExists(s306, _T("F0326"));
	
	ConservativeSetValue(f0329, _T("SCRIPT"));
	ConservativeSetValue(f0316, m_Settings.GetVersion());
	ConservativeSetValue(f0318, m_Settings.GetRelease());
	ConservativeSetValue(f0326, sMessageType);
}

size_t CEDIScriptDataCompletion::GetNumberOfFunctionGroupsOrMessages(CTextNode& node)
{
	size_t nUIH =0;
	size_t nUIT =0;

	for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
		it != m_rDocument.GetMessages().end();
		++it)
	{
		CTextNodeContainer multiMessages;
		node.GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
		for (size_t k=0; k < multiMessages.GetCount(); ++k)
		{
			CTextNodeContainer uihs;
			multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UIH"), uihs);
			nUIH +=  uihs.GetCount();
			CTextNodeContainer uits;
			multiMessages.GetAt(k)->GetChildren()->FilterByName(_T("UIT"), uits);
			nUIT += uits.GetCount();
		}
	}
	CTextNodeContainer messages;
	node.GetChildren()->FilterByName(_T("Message"), messages);
	for (size_t j=0; j< messages.GetCount(); ++j)
	{
		CTextNodeContainer uihs;
		messages.GetAt(j)->GetChildren()->FilterByName(_T("UIH"), uihs);
		nUIH +=  uihs.GetCount();
		CTextNodeContainer uits;
		messages.GetAt(j)->GetChildren()->FilterByName(_T("UIT"), uits);
		nUIT += uits.GetCount();
	}
	
	if (nUIH != nUIT)
		throw CTextException(CAltovaException::eError1, _T("Message header-trailer mismatch"));

	return nUIH;
}

} // namespace edi
} // namespace text
} // namespace altova
