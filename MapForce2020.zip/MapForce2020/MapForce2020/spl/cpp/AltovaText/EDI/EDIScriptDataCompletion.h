[call GenerateFileHeader("EDIScriptDataCompletion.h")]
#ifndef __EDISCRIPTDATACOMPLETION_H
#define __EDISCRIPTDATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIScriptSettings;

class CEDIScriptDataCompletion : public CDataCompletion
{
public:
	CEDIScriptDataCompletion(const CTextDocument& rDocument, const CEDIScriptSettings&, const tstring&);
	void CompleteData(CTextNode* dataroot, const CEDIParticle&);

protected:
	void CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle);
	void CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle);
	void CompleteInterchangeHeader(CTextNode& header, const CEDIParticle& headerParticle);
	void CompleteInterchangeTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle);
	void CompleteMessage(const tstring& sMessageType, CTextNode& message, const CEDIParticle& messageParticle);
	void CompleteMessageHeader(const tstring& sMessageType, CTextNode& header, const CEDIParticle& headerParticle);
	void CompleteMessageTrailer(CTextNode& trailer, const CEDIParticle& trailerParticle);
	void CompleteS001(CTextNode& s001);
	void CompleteS002(CTextNode& s002);
	void CompleteS003(CTextNode& s003);
	void CompleteS045(CTextNode& s045);
	void CompleteS300(CTextNode& s302, const CEDIParticle& particle);
	void CompleteS306(const tstring& sMessageType, CTextNode& s306);
	size_t GetNumberOfFunctionGroupsOrMessages(CTextNode& node);

private:
	const CEDIScriptSettings& m_Settings;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif