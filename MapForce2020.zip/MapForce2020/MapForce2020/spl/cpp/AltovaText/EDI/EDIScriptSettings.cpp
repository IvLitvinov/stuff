[call GenerateFileHeader("EDIScriptSettings.cpp")]
#include "StdAfx.h"
#include "EDIScriptSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIScriptSettings::CEDIScriptSettings()
:	CEDIFactSettings()
{
	m_EDIKind = EDISCRIPT;
	SetControllingAgency(_T("UNO"));
	SetSyntaxVersionNumber( 0 );
}

} // namespace edi
} // namespace text
} // namespace altova
