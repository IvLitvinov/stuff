[call GenerateFileHeader("EDIScriptSettings.h")]
#ifndef __EDISCRIPTSETTINGS_H
#define __EDISCRIPTSETTINGS_H

#include "EDIFactSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDIScriptSettings : public CEDIFactSettings
{
public:
	CEDIScriptSettings();
};
} // namespace edi
} // namespace text
} // namespace altova

#endif