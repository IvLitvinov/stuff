[call GenerateFileHeader("EDISemanticValidator.cpp")]
#include "StdAfx.h"
#include "EDISemanticValidator.h"
#include "EDIDateTimeHelpers.h"
#include "EDIScriptSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

void CEDISemanticValidator::Segment( const tstring& sSegment )
{
	switch (m_rSettings.GetStandard())
	{
	case EDIFact:
	case EDISCRIPT:
		if (sSegment == _T("UNB"))
		{
			m_nGroupCount = 0;
		}
		else if (sSegment == _T("UIB"))
		{
			m_nMessageCount = 0;
		}
		else if (sSegment == _T("UNG"))
		{
			m_nGroupCount++;
			m_nMessageCount = 0;
		}
		else if (sSegment == _T("UNH") || sSegment == _T("UIH"))
		{
			m_nMessageCount++;
			m_nSegmentCount = 1;
		}
		else
		{
			m_nSegmentCount++;
		}
		break;
	case EDIX12:
		if (sSegment == _T("ISA"))
		{
			m_nGroupCount = 0;
		}
		else if (sSegment == _T("GS"))
		{
			m_nGroupCount++;
			m_nMessageCount = 0;
		}
		else if ( sSegment == _T("ST"))
		{
			m_nMessageCount++;
			m_nSegmentCount = 1;
		}
		else
		{
			m_nSegmentCount++;
		}
		break;
	case EDITRADACOMS:
		if (sSegment == _T("STX"))
		{
			m_nMessageCount = 0;
		}
		else if (sSegment == _T("BAT"))
		{
			m_nGroupCount = 0; // count messages in batch
		}
		else if ( sSegment == _T("MHD"))
		{
			m_nMessageCount++;
			m_nGroupCount++;
			m_nSegmentCount = 1;
		}
		else
		{
			m_nSegmentCount++;
		}
		break;
	}

	m_sCurrentSegment = sSegment;
}

tstring CEDISemanticValidator::ValidateX12( const tstring& sParent, const tstring& sField, const tstring& sValue )
{
	tstringstream sError;
	tstring sExpectedValue;

	if ( sField == _T("F96") ) // Segment count in group
	{
		long nValue = altova::CoreTypes::CastToInt( sValue);
		if ( nValue != m_nSegmentCount )
		{
			sError << _T("Field does not contain the correct number of segments (field value = ");
			sError << sValue << _T(", counted ") << m_nSegmentCount << _T( " ).");
		}
	}

	else if ( sField == _T("F97") ) // Message count in group
	{
		if ( m_sCurrentSegment == _T("GE") )
		{
			long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nMessageCount )
			{
				sError << _T("Field does not contain the correct number of messages (field value = ");
				sError << sValue << _T(", counted ") << m_nMessageCount << _T( " ).");
			}
		}
	}

	else if ( sField == _T("F28") )
	{
		if ( m_sCurrentSegment == _T("GS") || m_sCurrentSegment == _T("GE") )
		{
			sExpectedValue = ValidateEquality( sField, sValue );
			if ( sExpectedValue != _T("") )
				sError << _T("Field does not contain the same value as Interchange/Group/GS/F28 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F329") )
	{
		if ( m_sCurrentSegment == _T("ST") || m_sCurrentSegment == _T("SE") )
		{
			sExpectedValue = ValidateEquality( sField, sValue );
			if ( sExpectedValue != _T("") )
				sError << _T("Field does not contain the same value as Interchange/Group/Message/ST/F329 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F143") ) // message type
	{
		if ( m_sCurrentSegment == _T("ST") )
			if ( m_sCurrentMessageType != _T("") && m_sCurrentMessageType.substr(0, 3) != sValue )
			{
				sError << _T("'") << sValue << _T("' is not a correct message type specifier.");
			}
	}


	else if ( sField == _T("FI16") ) // Group count in interchange
	{
        long nValue = altova::CoreTypes::CastToInt( sValue );
		if ( nValue != m_nGroupCount )
		{
			sError << _T("Field does not contain the correct number of function groups (field value = ");
			sError << sValue << _T(", counted ") << m_nGroupCount << _T( " ).");
		}
	}

	else if ( sField == _T("FI12") && ( m_sCurrentSegment == _T("ISA") || m_sCurrentSegment == _T("IEA") ) )
	{
		sExpectedValue = ValidateEquality( sField, sValue );
		if ( sExpectedValue != _T("") )
			sError << _T("Field does not contain the same value as Interchange/Group/Message/ISA/FI12 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
	}

	return sError.str();
}

tstring  CEDISemanticValidator::ValidateEDIFACT( const tstring& sParent, const tstring& sField, const tstring& sValue )
{
	tstringstream sError;
	tstring sExpectedValue;

	if ( sParent == _T("S302") )
	{
		if ( m_sCurrentSegment == _T("UIB") )
		{
			if ( sField == _T("F0300") )
			{
				m_mapEquality\[sField\] = sValue;
				m_mapEquality\[_T("F0303")\] = _T("");
				m_mapEquality\[_T("F0051")\] = _T("");
				m_mapEquality\[_T("F0304")\] = _T("");
			}
			else if ( sField == _T("F0303") )
			{
				m_mapEquality\[sField\] = sValue;
			}
			else if ( sField == _T("F0051") )
			{
				m_mapEquality\[sField\] = sValue;
			}
			else if ( sField == _T("F0304") )
			{
				m_mapEquality\[sField\] = sValue;
			}
		}
		else if ( m_sCurrentSegment == _T("UIH") || m_sCurrentSegment == _T("UIZ") )
		{
			if ( m_mapEquality.find( _T("F0300") ) != m_mapEquality.end() )
			{
				if ( sField == _T("F0300") )
				{
					if ( m_mapEquality\[sField\] != sValue )
					{
						sError << _T("Field does not contain the same value as Interchange/UIB/S302/F0300 ('") << sValue << _T("' instead of '") << m_mapEquality\[sField\] << _T("').");
					}
				}

				else if ( sField == _T("F0303") )
				{
					if ( m_mapEquality\[sField\] != sValue )
					{
						sError << _T( "Field does not contain the same value as Interchange/UIB/S302/F0303 ('") << sValue << _T("' instead of '") << m_mapEquality\[sField\] << _T("').");
					}
				}

				else if ( sField == _T("F0051") )
				{
					if ( m_mapEquality\[sField\] != sValue )
					{
						sError << _T("Field does not contain the same value as Interchange/UIB/S302/F0051 ('") << sValue << _T("' instead of '") << m_mapEquality\[sField\] << _T("').");
					}
				}

				else if ( sField == _T("F0304") )
				{
					if ( m_mapEquality\[sField\] != sValue )
					{
						sError << _T("Field does not contain the same value as Interchange/UIB/S302/F0304 ('") << sValue << _T("' instead of '") << m_mapEquality\[sField\] << _T("').");
					}
				}
			}
		}
	}

	else if ( sField == _T("F0074") && ( m_sCurrentSegment == _T("UNT") || m_sCurrentSegment == _T("UIT") ) ) // segment count in message
	{
        long nValue = altova::CoreTypes::CastToInt( sValue );
		if ( nValue != m_nSegmentCount )
		{
			sError << _T("Field does not contain the correct number of segments (field value = ");
			sError << sValue << _T(", counted ") << m_nSegmentCount << _T( " ).");
		}
	}

	if ( sField == _T("F0060") && m_sCurrentSegment == _T("UNE") ) // message count in group
	{
        long nValue = altova::CoreTypes::CastToInt( sValue );
		if ( nValue != m_nMessageCount )
		{
			sError << _T("Field does not contain the correct number of messages (field value = ");
			sError << sValue << _T(", counted ") << m_nMessageCount << _T( " ).");
		}
	}

	if ( sField == _T("F0036") && m_sCurrentSegment == _T("UNZ") ) // message or group count in interchange
	{
		// if we have at least one group, we count groups, otherwise messages
		if ( m_nGroupCount ) // count groups
		{
            long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nGroupCount )
			{
				sError << _T("Field does not contain the correct number of function group (field value = ");
				sError << sValue << _T(", counted ") << m_nGroupCount << _T( " ).");
			}
		}
		else // count messages
		{
            long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nMessageCount )
			{
				sError << _T("Field does not contain the correct number of messages (field value = ");
				sError << sValue << _T(", counted ") << m_nMessageCount << _T( " ).");
			}
		}
	}



	else if ( sField == _T("F0062") && ( m_sCurrentSegment == _T("UNH") || m_sCurrentSegment == _T("UNT") ) ) // message reference number
	{
		sExpectedValue = ValidateEquality( sField, sValue );
		if ( sExpectedValue != _T("") )
		{
			sError << _T("Field does not contain the same value as Interchange/Group/Message/UNH/F0062 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F0340") && ( m_sCurrentSegment == _T("UIH") || m_sCurrentSegment == _T("UIT") ) ) // message reference number
	{
		sExpectedValue = ValidateEquality( sField, sValue );
		if ( sExpectedValue != _T("") )
		{
			sError << _T("Field does not contain the same value as Interchange/Message/UIH/F0340 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F0020") && ( m_sCurrentSegment == _T("UNZ") || m_sCurrentSegment == _T("UNB") ) ) // interchange reference number
	{
		sExpectedValue = ValidateEquality( sField, sValue );
		if ( sExpectedValue != _T("") )
		{
				sError << _T("Field does not contain the same value as Interchange/UNB/F0020 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F0048") ) // group reference number
	{
		sExpectedValue = ValidateEquality( sField, sValue );
		if ( sExpectedValue != _T("") )
		{
			sError << _T("Field does not contain the same value as Interchange/Group/UNG/F0048 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
		}
	}

	else if ( sField == _T("F0052") ) // version
	{
		if (sValue != m_rSettings.GetVersion() )
		{
			sError << _T( "Field value '") << sValue << _T( "' does not match expected message version number ('") << m_rSettings.GetVersion() << _T("')");
		}
	}

	else if ( sField == _T("F0054") ) // release
	{
		if (sValue != m_rSettings.GetRelease() )
		{
			sError << _T( "Field value '") << sValue << _T( "' does not match expected release number ('") << m_rSettings.GetRelease() << _T("')");
		}
	}
/*
	else if ( sField == _T("F0051") ) // agency
	{
		if (sValue != m_rSettings.GetControllingAgency() )
		{
			sError << _T( "Field value '") << sValue << _T( "' does not match expected control agency code ('") << m_rSettings.GetControllingAgency() << _T("')");
		}
	}
*/
	else if ( sField == _T("F0065") && ( m_sCurrentSegment == _T("UNH") || m_sCurrentSegment == _T("UIH") ) ) // message type
	{
		if ( m_sCurrentMessageType != _T("") && m_sCurrentMessageType != sValue )
			sError << _T("'") << sValue << _T("' is not a correct message type specifier.");
	}

	else if ( sField == _T("F0017") ) // date
	{
		if ( !EDIDateTimeHelpers::IsDateCorrect( sValue ) )
		{
			sError << _T("'") << sValue << _T("' is not an EDI formatted date value.");
		}
	}

	else if ( sField == _T("F0019") ) // message type
	{
		if ( !EDIDateTimeHelpers::IsTimeCorrect( sValue ) )
		{
			sError << _T("'") << sValue << _T("' is not an EDI formatted time value.");
		}
	}

	return sError.str();
}


tstring  CEDISemanticValidator::ValidateEDISCRIPT( const tstring& sParent, const tstring& sField, const tstring& sValue )
{
	tstringstream sError;
	tstring sExpectedValue;

	CEDIScriptSettings& rScriptSettings = (CEDIScriptSettings&)(m_rSettings);

	if ( sParent == _T("S300") )
	{
		if ( sField == _T("F0017") ) // date
		{
			if ( !EDIDateTimeHelpers::IsDateCorrect( sValue ) )
			{
				sError << _T("'") << sValue << _T("' is not an EDI formatted date value.");
			}
		}

		else if ( sField == _T("F0114") || sField == _T("F0314") ) // time
		{
			if ( !EDIDateTimeHelpers::IsTimeCorrect( sValue ) )
			{
				sError << _T("'") << sValue << _T("' is not an EDI formatted time value.");
			}
		}
	}
	else if ( m_sCurrentSegment == _T("UIB") )
	{
		if ( sField == _T("F0001") )
		{
			if (sValue != m_rSettings.GetControllingAgency() + rScriptSettings.GetSyntaxLevel() )
			{
				sError << _T("Field value '") << sValue << _T("' does not match expected syntax identifier ('") << m_rSettings.GetControllingAgency() + rScriptSettings.GetSyntaxLevel() << _T("')");
			}
		}
		else if ( sField == _T("F0002") )
		{
			if (CoreTypes::CastToInt(sValue) != rScriptSettings.GetSyntaxVersionNumber() )
			{
				sError << _T("Field value '") << sValue << _T("' does not match expected syntax version number ('") << rScriptSettings.GetSyntaxVersionNumber() << _T("')");
			}
		}
	}
	else if ( m_sCurrentSegment == _T("UIH") )
	{
		if ( sField == _T("F0062") )
		{
			m_mapEquality\[sField\] = sValue;
		}
		else if ( sParent == _T("S306") )
		{
			if ( sField == _T("F0329") )
			{
				if ( sValue != _T("SCRIPT") )
				{
					sError << _T("Field value '") << sValue << _T("' does not match expected message type specifier ('SCRIPT')");
				}
			}
			else if ( sField == _T("F0316") )
			{
				if (sValue != m_rSettings.GetVersion() )
				{
					sError << _T("Field value '") << sValue << _T("' does not match expected version number ('") << m_rSettings.GetVersion() << _T("')");
				}
			}
			else if ( sField == _T("F0318") )
			{
				if (sValue != m_rSettings.GetRelease() )
				{
					sError << _T("Field value '") << sValue << _T("' does not match expected release number ('") << m_rSettings.GetRelease() << _T("')");
				}
			}
			else if ( sField == _T("F0326") )
			{
				if ( !m_sCurrentMessageType.empty() && m_sCurrentMessageType != sValue )
				{
					sError << _T("'") << sValue << _T("' is not a correct message function specifier.");
				}
			}
		}
	}
	else if ( m_sCurrentSegment == _T("UIT") )
	{
		if ( sField == _T("F0062") )
		{
			sExpectedValue = ValidateEquality(sField, sValue);
			if ( sExpectedValue != _T("") )
			{
				sError << _T("Field does not contain the same value as Interchange/Message/UIH/F0062 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
			}
		}
		if ( sField == _T("F0074") ) // segment count in message
		{
			long nValue = CoreTypes::CastToInt( sValue );
			if ( nValue != m_nSegmentCount )
			{
				sError << _T("Field does not contain the correct number of segments (field value = ") << sValue << _T(", counted ") << m_nSegmentCount << _T(" ).");
			}
		}
	}
	else if ( m_sCurrentSegment == _T("UIZ") )
	{
		if ( sField == _T("F0036") ) // message or group count in interchange
		{
			long nValue = CoreTypes::CastToInt( sValue );
			if ( nValue != m_nMessageCount )
			{
				sError << _T("Field does not contain the correct number of messages (field value = ") << sValue << _T(", counted ") << m_nMessageCount << _T(" ).");
			}
		}
	}
	
	return sError.str();
}

tstring  CEDISemanticValidator::ValidateTRADACOMS( const tstring& sParent, const tstring& sField, const tstring& sValue )
{
	tstringstream sError;
	tstring sExpectedValue;

	if (m_sCurrentSegment == _T("STX"))
	{
		if (sField == _T("SNRF"))
			m_mapEquality\[sField\] = sValue;
		else if (sField == _T("UNTO-1"))
			m_mapEquality\[sField\] = sValue;
	}
	else if (m_sCurrentSegment == _T("MHD"))
	{
		if (sField == _T("MSRF"))
		{
			long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nMessageCount )
			{
				sError << _T("Field does not contain the correct message refence number (field value = ");
				sError << sValue << _T(", expected ") << m_nMessageCount << _T( " ).");
			}
		}
	}
	else if (m_sCurrentSegment == _T("MTR"))
	{
		if (sField == _T("NOSG"))
		{
			long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nSegmentCount )
			{
				sError << _T("Field does not contain the correct number of segments (field value = ");
				sError << sValue << _T(", counted ") << m_nSegmentCount << _T( " ).");
			}

		}
	}
	else if (m_sCurrentSegment == _T("EOB"))
	{
		if (sField == _T("NOLI"))
		{
			long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nGroupCount )
			{
				sError << _T("Field does not contain the correct number of messages (field value = ");
				sError << sValue << _T(", counted ") << m_nGroupCount << _T( " ).");
			}

		}
	}
	else if (m_sCurrentSegment == _T("RSG"))
	{
		if (sField == _T("RSGA"))
		{
			sExpectedValue = ValidateEquality( _T("SNRF"), sValue );
			if ( sExpectedValue != _T("") )
			{
				sError << _T("Field does not contain the same value as STX/SNRF ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
			}
		}
		else if (sField == _T("RSGB"))
		{
			sExpectedValue = ValidateEquality( _T("UNTO-1"), sValue );
			if ( sExpectedValue != _T("") )
			{
				sError << _T("Field does not contain the same value as STX/UNTO/UNTO-1 ('") << sValue << _T("' instead of '") << sExpectedValue << _T("').");
			}
		}
	}
	else if (m_sCurrentSegment == _T("END"))
	{
		if (sField == _T("NMST"))
		{
			long nValue = altova::CoreTypes::CastToInt( sValue );
			if ( nValue != m_nMessageCount )
			{
				sError << _T("Field does not contain the correct number of messages (field value = ");
				sError << sValue << _T(", counted ") << m_nMessageCount << _T( " ).");
			}

		}
	}
	return sError.str();
}

tstring CEDISemanticValidator::ValidateHL7( const tstring& sParent, const tstring& sField, const tstring& sValue )
{
	tstring sError;
	tstring sExpectedValue;

	return sError;
}

tstring CEDISemanticValidator::ValidateEquality( const tstring& sField, const tstring& sValue )
{
    // if has no field, add it; if map has field compare it and remove it
	if ( m_mapEquality.find( sField ) == m_mapEquality.end() ) // map has no field?
	{
		m_mapEquality\[sField\] = sValue;
		return tstring();
	}

	// obviously map has the field
	tstring ret;
	if (m_mapEquality\[sField\] != sValue)
		ret = m_mapEquality\[sField\];
	m_mapEquality.erase( sField );
	return ret;
}

}
}
}
