[call GenerateFileHeader("EDISemanticValidator.h")]
#ifndef __ALTOVATEXT_EDISEMANTICVALIDATOR_H
#define __ALTOVATEXT_EDISEMANTICVALIDATOR_H

#include "Parser.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDISemanticValidator
{
public:
	CEDISemanticValidator(const CEDISettings& settings )
		: m_nSegmentCount( 0 ),m_nGroupCount( 0 ), m_nMessageCount( 0 ), m_rSettings( settings) {}

	void Segment( const tstring& sSegmentName );
	inline tstring Validate ( const tstring& sParent, const tstring& sField, const tstring& sValue )
	{
		if( m_rSettings.GetStandard() == EDIFact )
			return ValidateEDIFACT( sParent, sField, sValue );
		if( m_rSettings.GetStandard() == EDISCRIPT )
			return ValidateEDISCRIPT( sParent, sField, sValue );
		if( m_rSettings.GetStandard()  == EDIX12 )
			return ValidateX12( sParent, sField, sValue );
        if( m_rSettings.GetStandard() == EDIHL7 )
            return ValidateHL7( sParent, sField, sValue );
		if( m_rSettings.GetStandard() == EDITRADACOMS )
			return ValidateTRADACOMS( sParent, sField, sValue );

		return tstring();
	}

	void SetCurrentMessageType(const tstring& sMessageType) { m_sCurrentMessageType = sMessageType; }

protected:
	tstring ValidateEDIFACT ( const tstring& sParent, const tstring& sField, const tstring& sValue );
	tstring ValidateEDISCRIPT ( const tstring& sParent, const tstring& sField, const tstring& sValue );
	tstring ValidateX12 ( const tstring& sParent, const tstring& sField, const tstring& sValue );
	tstring ValidateHL7 ( const tstring& sParent, const tstring& sField, const tstring& sValue );
	tstring ValidateTRADACOMS ( const tstring& sParent, const tstring& sField, const tstring& sValue );
	tstring ValidateEquality( const tstring& sField, const tstring& sValue );

private:
	long m_nSegmentCount;
	long m_nGroupCount;
	long m_nMessageCount;
	const CEDISettings& m_rSettings;
	std::map<tstring, tstring> m_mapEquality;
	tstring m_sCurrentSegment;
	tstring m_sCurrentMessageType;
};

}
}
}

#endif //__ALTOVATEXT_EDISEMANTICVALIDATOR_H
