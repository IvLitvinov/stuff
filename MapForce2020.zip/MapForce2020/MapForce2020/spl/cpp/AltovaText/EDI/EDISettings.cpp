[call GenerateFileHeader("EDISettings.cpp")]
#include "StdAfx.h"
#include "AltovaTextAPI.h"
#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDISettings::CEDISettings()
:	m_TerminateSegmentsWithLinefeed(false)
,	m_AutoCompleteData(true)
,	m_LineEnd(0)
{
	m_EDIKind = Unknown;
}

const CEDIServiceChars& CEDISettings::GetServiceChars() const
{
	return m_ServiceChars;
}
CEDIServiceChars& CEDISettings::GetServiceChars()
{
	return m_ServiceChars;
}
bool CEDISettings::GetTerminateSegmentsWithLinefeed() const
{
	return m_TerminateSegmentsWithLinefeed;
}
bool CEDISettings::GetAutoCompleteData() const
{
	return m_AutoCompleteData;
}
int CEDISettings::GetLineEnd() const
{
	return m_LineEnd;
}
void CEDISettings::SetTerminateSegmentsWithLinefeed(bool rhs)
{
	m_TerminateSegmentsWithLinefeed= rhs;
}
void CEDISettings::SetAutoCompleteData(bool rhs)
{
	m_AutoCompleteData= rhs;
}
void CEDISettings::SetLineEnd(int lineend)
{
	m_LineEnd = lineend;
}


} // namespace edi
} // namespace text
} // namespace altova
