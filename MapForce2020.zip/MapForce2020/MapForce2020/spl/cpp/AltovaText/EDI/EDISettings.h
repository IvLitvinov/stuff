[call GenerateFileHeader("EDISettings.h")]
#ifndef __EDISETTINGS_H
#define __EDISETTINGS_H

#include "AltovaTextAPI.h"

namespace altova
{
namespace text
{
namespace edi
{
enum EDIStandard
{
	EDIFact,
	EDIX12,
	EDIHL7,
	EDIFixed,
	EDITRADACOMS,
	EDISCRIPT,
	Unknown
};

enum EDISERVICECHAR_TYPE
{
	EDISERVICECHAR_COMPONENTSEPARATOR = 0,
	EDISERVICECHAR_DATAELEMENTSEPARATOR = 1,
	EDISERVICECHAR_DECIMALMARK = 2,
	EDISERVICECHAR_RELEASECHARACTER = 3,
	EDISERVICECHAR_REPETITIONSEPARATOR = 4,
	EDISERVICECHAR_SEGMENTTERMINATOR = 5,
	EDISERVICECHAR_SUBCOMPONENTSEPARATOR = 6,
	EDISERVICECHAR_SEGMENTSEPARATOR = 7,
	EDISERVICECHAR_COUNT = 8,
};

class ALTOVATEXT_DECLSPECIFIER CEDIServiceChars
{
	TCHAR m_acServiceChars \[EDISERVICECHAR_COUNT\];
public:
	TCHAR GetServiceChar (EDISERVICECHAR_TYPE serviceChar) const
	{
		return m_acServiceChars \[serviceChar\];
	}

	void SetServiceChar (EDISERVICECHAR_TYPE serviceChar, TCHAR cValue)
	{
		m_acServiceChars \[serviceChar\] = cValue;
	}

	TCHAR GetDataElementSeparator () const { return GetServiceChar (EDISERVICECHAR_DATAELEMENTSEPARATOR); }
	TCHAR GetSegmentSeparator () const { return GetServiceChar (EDISERVICECHAR_SEGMENTSEPARATOR); }
	TCHAR GetSegmentTerminator () const { return GetServiceChar (EDISERVICECHAR_SEGMENTTERMINATOR); }
	TCHAR GetReleaseIndicator () const { return GetServiceChar (EDISERVICECHAR_RELEASECHARACTER); }
	TCHAR GetComponentDataElementSeparator () const { return GetServiceChar (EDISERVICECHAR_COMPONENTSEPARATOR); }
	TCHAR GetDecimalNotation () const { return GetServiceChar (EDISERVICECHAR_DECIMALMARK); }
	TCHAR GetRepetitionSeparator () const { return GetServiceChar (EDISERVICECHAR_REPETITIONSEPARATOR); }
	TCHAR GetSubComponentSeparator () const { return GetServiceChar (EDISERVICECHAR_SUBCOMPONENTSEPARATOR); }
};


class ALTOVATEXT_DECLSPECIFIER CEDISettings
{
public:
	CEDISettings();
	virtual ~CEDISettings() {};

	const CEDIServiceChars& GetServiceChars() const;
	CEDIServiceChars& GetServiceChars();
	bool GetTerminateSegmentsWithLinefeed() const;
	bool GetAutoCompleteData() const;
	int GetLineEnd() const;
	void SetTerminateSegmentsWithLinefeed(bool);
	void SetAutoCompleteData(bool);
	void SetLineEnd(int);
	void SetVersion(const tstring& ver) {m_Version = ver;}
	tstring GetVersion() const {return m_Version;}
	void SetRelease(const tstring& rel) {m_Release = rel;}
	tstring GetRelease() const {return m_Release;}
	void SetControllingAgency(const tstring& agency) {m_ControllingAgency = agency;}
	tstring GetControllingAgency() const {return m_ControllingAgency;}
	void SetMessageType(const tstring& msg) {m_MessageType = msg;}
	tstring GetMessageType() const {return m_MessageType;}
	EDIStandard GetStandard() const {return m_EDIKind;}

protected:
	tstring m_ControllingAgency;
	tstring m_Version;
	tstring m_Release;
	tstring m_MessageType;
	EDIStandard m_EDIKind;

private:
	CEDIServiceChars m_ServiceChars;
	bool m_TerminateSegmentsWithLinefeed;
	bool m_AutoCompleteData;
	int m_LineEnd;
};

} // namespace edi
} // namespace text
} // namespace altova

#endif