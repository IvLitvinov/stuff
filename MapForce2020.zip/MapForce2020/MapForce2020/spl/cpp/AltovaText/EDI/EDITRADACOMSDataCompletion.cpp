[call GenerateFileHeader("EDIFactDataCompletion.cpp")]
#include "StdAfx.h"
#include "EDITRADACOMSDataCompletion.h"
#include "EDITRADACOMSSettings.h"
#include "TextNode.h"
#include "TextException.h"
#include "TextDocument.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDITradacomsDataCompletion::CEDITradacomsDataCompletion( const CTextDocument& rDocument,
												const CEDITradacomsSettings& settings,
												const tstring &structurename)
:	CDataCompletion(rDocument, structurename, true), m_Settings(settings)
{
}
	
void CEDITradacomsDataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);
	CompleteEnvelope(*dataroot, rootParticle);
}
	
void CEDITradacomsDataCompletion::CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle)
{
	if (envelope.GetName() != _T("Envelope"))
		throw CTextException(CAltovaException::eError1, _T("CompleteEnvelope: root node is not an envelope"));

	MakeSureExists(envelope, _T("Interchange"), Group);

	CTextNodeContainer interchanges; 
	envelope.GetChildren()->FilterByName(_T("Interchange"), interchanges);
	const CEDIParticle* interchangeParticle = rootParticle.GetNode()->GetChildren();
	for (size_t i=0; i< interchanges.GetCount(); ++i)
			CompleteInterchange(*interchanges.GetAt(i), *interchangeParticle);
}

void CEDITradacomsDataCompletion::CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle)
{
	CTextNode* stx = MakeSureExists(interchange, _T("STX"), Segment);
	MakeSureExists(interchange, _T("Batch"), Group);
	CTextNode* end = MakeSureExists(interchange, _T("END"), Segment);
	
	m_bWriteReconciliation = false;
	m_nMessageCounter = 0;

	CompleteInterchangeHeader(*stx);
	
	CTextNodeContainer groups;
	interchange.GetChildren()->FilterByName(_T("Batch"), groups);
	for (size_t i=0; i< groups.GetCount(); ++i)
		CompleteBatch(*groups.GetAt(i));

	if(m_bWriteReconciliation)
	{
		CTextNode* rsgrsg = MakeSureExists(interchange, _T("RSGRSG"), Group);
		CompleteReconciliationMessage(*rsgrsg, *GetParticleByPath(interchangeParticle, rsgrsg->GetName()));
	}
	
	CompleteInterchangeTrailer(*end);
}

namespace
{
	tstring GetCurrentDateAsString()
	{
		SYSTEMTIME now;
		GetLocalTime(&now);
		TCHAR buffer\[10\];
		GetDateFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, _T("yyMMdd"), buffer, 10);
		return buffer;
	}

	tstring GetCurrentTimeAsString()
	{
		SYSTEMTIME now;
		GetLocalTime(&now);
		TCHAR buffer\[10\];
		GetTimeFormat(LOCALE_SYSTEM_DEFAULT, 0, &now, _T("HHmmss"), buffer, 10);
		return buffer;
	}
}

void CEDITradacomsDataCompletion::CompleteInterchangeHeader(CTextNode& stx)
{
	CTextNode* stds  = MakeSureExists(stx, _T("STDS"), Composite);
	CTextNode* stds1  = MakeSureExists(stds, _T("STDS-1"), DataElement);
	CTextNode* stds2  = MakeSureExists(stds, _T("STDS-2"), DataElement);
	CTextNode* trdt  = MakeSureExists(stx, _T("TRDT"), Composite);
	CTextNode* trdt1  = MakeSureExists(trdt, _T("TRDT-1"), DataElement);
	CTextNode* trdt2  = MakeSureExists(trdt, _T("TRDT-2"), DataElement);

	CTextNode* snrf = stx.GetChildren()->GetFirstNodeByName(_T("SNRF"));
	CTextNode* unto = stx.GetChildren()->GetFirstNodeByName(_T("UNTO"));
	CTextNode* unto1 = NULL;
	if(unto)
		unto1 = unto->GetChildren()->GetFirstNodeByName(_T("UNTO-1"));

	ConservativeSetValue(stds1, _T("ANA"));
	ConservativeSetValue(stds2, _T("1"));
	ConservativeSetValue(trdt1, GetCurrentDateAsString());
	ConservativeSetValue(trdt2, GetCurrentTimeAsString());
	
	if((m_bWriteReconciliation = stds1->GetValue() == _T("ANAA")) == true)
	{
		m_sSenderReference = snrf ? snrf->GetValue() : _T("");
		m_sRecieverCode = unto1 ? unto1->GetValue() : _T("");
	}
}

void CEDITradacomsDataCompletion::CompleteReconciliationMessage(CTextNode& rsgrsg, const CEDIParticle& particle)
{
	CompleteMandatory(rsgrsg, particle);
	CompleteMessage(rsgrsg);
	
	CTextNode* rsg  = MakeSureExists(rsgrsg, _T("RSG"), Segment);
	CTextNode* rsga  = MakeSureExists(rsg, _T("RSGA"), DataElement);
	CTextNode* rsgb  = MakeSureExists(rsg, _T("RSGB"), DataElement);

	ConservativeSetValue(rsga, m_sSenderReference);
	ConservativeSetValue(rsgb, m_sRecieverCode);
	CompleteConditionsAndValues(&rsgrsg, particle);
}

void CEDITradacomsDataCompletion::CompleteInterchangeTrailer(CTextNode& end)
{
	CTextNode* nmst = MakeSureExists(end, _T("NMST"), DataElement);

	ConservativeSetValue(nmst, m_nMessageCounter);
}

void CEDITradacomsDataCompletion::CompleteBatch(CTextNode& group)
{
	if (HasKid(group, _T("BAT")))
	{
		MakeSureExists(group, _T("EOB"), Segment);
	}
	else if (HasKid(group, _T("EOB")))
	{
		MakeSureExists(group, _T("BAT"), Segment);
	}

	size_t nMsgCount = 0;
	
	CTextNodeContainer* multiMessages = group.GetChildren();
	for(size_t i=0; i < multiMessages->GetCount(); ++i)
	{
		CTextNode* pMessageNode = multiMessages->GetAt(i);
		if(pMessageNode->GetName().substr(0, sizeof("Message_")-1) == _T("Message_"))
		{
			const CMessage& message = m_rDocument.GetMessage(pMessageNode->GetName().substr(sizeof("Message_")-1));
			CompleteMandatory(*pMessageNode, message.GetRootParticle());
			CompleteFile(*pMessageNode);
			CompleteConditionsAndValues(pMessageNode, message.GetRootParticle());
			nMsgCount += pMessageNode->GetChildren()->GetCount();
		}
	}

	CTextNode* eob = GetKid(group, _T("EOB"));
	if (eob)
		CompleteBatchTrailer(*eob, nMsgCount);
}

void CEDITradacomsDataCompletion::CompleteBatchTrailer(CTextNode& eob, size_t nMsgCount)
{
	CTextNode* noli = MakeSureExists(eob, _T("NOLI"), DataElement);
	ConservativeSetValue(noli, nMsgCount);
}

void CEDITradacomsDataCompletion::CompleteFile(CTextNode& file)
{
	CTextNodeContainer* pMessages = file.GetChildren();
	for(size_t i=0; i < pMessages->GetCount(); ++i)
	{
		CTextNode* pMessageNode = pMessages->GetAt(i);
		CompleteMessage(*pMessageNode);
	}
	
}

void CEDITradacomsDataCompletion::CompleteMessage(CTextNode& message)
{
	CTextNode* mhd = MakeSureExists(message, _T("MHD"), Segment);
	CTextNode* mtr = MakeSureExists(message, _T("MTR"), Segment);

	CompleteMessageHeader(*mhd);
	CompleteMessageTrailer(*mtr);
}

void CEDITradacomsDataCompletion::CompleteMessageHeader(CTextNode& mhd) 
{
	CTextNode* msrf = MakeSureExists(mhd, _T("MSRF"), DataElement);
	ConservativeSetValue(msrf, ++m_nMessageCounter);
}

void CEDITradacomsDataCompletion::CompleteMessageTrailer(CTextNode& mtr) 
{
	CTextNode* nosg = MakeSureExists(mtr, _T("NOSG"), DataElement);
	ConservativeSetValue(nosg, GetSegmentChildrenCount(*mtr.GetParent()));
}

} // namespace edi
} // namespace text
} // namespace altova
