[call GenerateFileHeader("EDIFactDataCompletion.h")]
#ifndef __EDITRADADATACOMPLETION_H
#define __EDITRADADATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDITradacomsSettings;

class CEDITradacomsDataCompletion : public CDataCompletion
{
public:
	CEDITradacomsDataCompletion(const CTextDocument& rDocument, const CEDITradacomsSettings&, const tstring&);
	void CompleteData(CTextNode* dataroot, const CEDIParticle&);

protected:
	void CompleteEnvelope (CTextNode& envelope, const CEDIParticle& rootParticle);
	void CompleteInterchange(CTextNode& interchange, const CEDIParticle& interchangeParticle);
	void CompleteInterchangeHeader(CTextNode& stx);
	void CompleteInterchangeTrailer(CTextNode& end);
	void CompleteBatch(CTextNode& group);
	void CompleteBatchTrailer(CTextNode& eob, size_t nMsgCount);
	void CompleteReconciliationMessage(CTextNode& rsgrsg, const CEDIParticle& particle);
	void CompleteFile(CTextNode& file);
	void CompleteMessage(CTextNode& message);
	void CompleteMessageHeader(CTextNode& mhd);
	void CompleteMessageTrailer(CTextNode& mtr);

private:
	const CEDITradacomsSettings& m_Settings;
	bool m_bWriteReconciliation;
	size_t m_nMessageCounter;
	tstring m_sSenderReference;
	tstring m_sRecieverCode;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif