[call GenerateFileHeader("EDITRADACOMSSettings.cpp")]
#include "StdAfx.h"
#include "EDITRADACOMSSettings.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDITradacomsSettings::CEDITradacomsSettings()
{
	m_ControllingAgency = _T("BIC");
	m_EDIKind = EDITRADACOMS;
}

} // namespace edi
} // namespace text
} // namespace altova
