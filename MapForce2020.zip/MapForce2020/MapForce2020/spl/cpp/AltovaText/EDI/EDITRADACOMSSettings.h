[call GenerateFileHeader("EDITRADACOMSSettings.h")]
#ifndef __EDITRADASETTINGS_H
#define __EDITRADASETTINGS_H

#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDITradacomsSettings : public CEDISettings
{
public:
	CEDITradacomsSettings();

private:

};
} // namespace edi
} // namespace text
} // namespace altova

#endif