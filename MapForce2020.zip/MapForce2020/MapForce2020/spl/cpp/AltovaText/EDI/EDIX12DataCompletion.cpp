[call GenerateFileHeader("EDIX12DataCompletion.cpp")]
#include "StdAfx.h"
#include "EDIX12DataCompletion.h"
#include "TextNode.h"
#include "EDIX12Settings.h"
#include "TextException.h"
#include "TextDocument.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIX12DataCompletion::CEDIX12DataCompletion(const CTextDocument& rDocument,
											 const CEDIX12Settings& settings,
											 const tstring& structurename)
:	CDataCompletion(rDocument, structurename)
,	m_Settings(settings)
,	m_pGroupRoot(0)
,	m_nHLSegmentCounter(0)
{
}

void CEDIX12DataCompletion::CompleteData(CTextNode* dataroot, const CEDIParticle& rootParticle)
{
	CompleteMandatory(*dataroot, rootParticle);
	CompleteEnvelope(*dataroot);
}

void CEDIX12DataCompletion::CompleteEnvelope(CTextNode& envelope)
{
	if (envelope.GetName() != _T("Envelope"))
		throw CTextException(CAltovaException::eError1, _T("CompleteEnvelope: root node is not an envelope"));

	MakeSureExists(envelope, _T("Interchange"));

	CTextNodeContainer interchanges; 
	envelope.GetChildren()->FilterByName(_T("Interchange"), interchanges);
	for (size_t i=0; i< interchanges.GetCount(); ++i)
			CompleteInterchange(*interchanges.GetAt(i));
}

void CEDIX12DataCompletion::CompleteInterchange(CTextNode& interchange)
{
	CTextNode* isa = MakeSureExists(interchange, _T("ISA"));
    m_pGroupRoot = MakeSureExists(interchange, _T("Group"));
    CTextNode* iea = MakeSureExists(interchange, _T("IEA"));

    
    CTextNode* FI01 = MakeSureExists(*isa, _T("FI01"));
    ConservativeSetValue(FI01, _T("00"));
    CTextNode* FI02 = MakeSureExists(*isa, _T("FI02"));
    ConservativeSetValue(FI02, _T("          "));
    CTextNode* FI03 = MakeSureExists(*isa, _T("FI03"));
    ConservativeSetValue(FI03, _T("00"));
    CTextNode* FI04 = MakeSureExists(*isa, _T("FI04"));
    ConservativeSetValue(FI04, _T("          "));
    CTextNode* FI05_1 = MakeSureExists(*isa, _T("FI05_1"));
    ConservativeSetValue(FI05_1, _T("ZZ"));
    CTextNode* FI05_2 = MakeSureExists(*isa, _T("FI05_2"));
    ConservativeSetValue(FI05_2, _T("ZZ"));
    CTextNode* FI08 = MakeSureExists(*isa, _T("FI08"));
    ConservativeSetValue(FI08, GetCurrentDateAsEDIString());
    CTextNode* FI09 = MakeSureExists(*isa, _T("FI09"));
    ConservativeSetValue(FI09, GetCurrentTimeAsEDIString());
	
	if( IsOldISAVersion() )
	{
		MakeSureExists(*isa, _T("FI10"));
	}
	else
	{
		CTextNode* FI65 = MakeSureExists(*isa, _T("FI65"));
		ConservativeSetValue(FI65, m_Settings.GetServiceChars().GetRepetitionSeparator());
	}
    CTextNode* FI11 = MakeSureExists(*isa, _T("FI11"));
    ConservativeSetValue(FI11, m_Settings.GetInterchangeControlVersionNumber());
    CTextNode* FI12 = MakeSureExists(*isa, _T("FI12"));
	ConservativeSetValue(FI12, _T("000000000"));
    CTextNode* FI13 = MakeSureExists(*isa, _T("FI13"));
    ConservativeSetValue(FI13, m_Settings.GetRequestAcknowledgement() ? _T("1") : _T("0"));
    CTextNode* FI14 = MakeSureExists(*isa, _T("FI14"));
    ConservativeSetValue(FI14, _T("P"));
    CTextNode* FI15 = MakeSureExists(*isa, _T("FI15"));
	ConservativeSetValue(FI15, m_Settings.GetServiceChars().GetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR));

	CTextNodeContainer groups;
	interchange.GetChildren()->FilterByName(_T("Group"), groups);
	for (size_t i= 0; i<groups.GetCount(); ++i)
	{
		m_pGroupRoot= groups.GetAt(i);
		MakeSureExists(*m_pGroupRoot, _T("GS"));
       	MakeSureExists(*m_pGroupRoot, _T("GE"));
		CompleteGroup();
	}


    CTextNode* IEAFI16 = MakeSureExists(*iea, _T("FI16"));
    ConservativeSetValue(IEAFI16, GetNamedChildrenCount(interchange, _T("Group")));
    CTextNode* IEAFI12 = MakeSureExists(*iea, _T("FI12"));
    ConservativeSetValue(IEAFI12, FI12);
}

void CEDIX12DataCompletion::CompleteGroup()
{
	size_t nMessageCount = 0;

	CTextNodeContainer messages;
	m_pGroupRoot->GetChildren()->FilterByName(_T("Message"), messages);
	for (size_t i= 0; i<messages.GetCount(); ++i)
	{
		CTextNode* pMessage = messages.GetAt(i);
		MakeSureExists(*pMessage, _T("ST"));
		MakeSureExists(*pMessage, _T("SE"));
		CompleteMessage(m_rDocument.GetMessage(m_Settings.GetMessageType()), pMessage);
	}
	nMessageCount += messages.GetCount();

	for( std::map<tstring,CMessage>::const_iterator it = m_rDocument.GetMessages().begin();
		it != m_rDocument.GetMessages().end();
		++it)
	{
		CTextNodeContainer multiMessages;
		m_pGroupRoot->GetChildren()->FilterByName(_T("Message_") + (*it).second.GetMessageType(), multiMessages);
		for(size_t i=0; i < multiMessages.GetCount(); ++i)
		{
			CTextNode* pMessage = multiMessages.GetAt(i);
			CompleteMandatory( *pMessage, (*it).second.GetRootParticle());
			MakeSureExists(*pMessage, _T("ST"));
			MakeSureExists(*pMessage, _T("SE"));
			CompleteMessage((*it).second, pMessage);
		}
		nMessageCount += multiMessages.GetCount();
	}

	CTextNode* GS = GetKid(*m_pGroupRoot, _T("GS"));
	if (GS)
	{
		CTextNode* GE = GetKid(*m_pGroupRoot, _T("GE"));
		CTextNode* GSF373 = MakeSureExists(*GS, _T("F373"));
		ConservativeSetValue(GSF373, GetCurrentDateAsEDIString());
		CTextNode* GSF337 = MakeSureExists(*GS, _T("F337"));
		ConservativeSetValue(GSF337, GetCurrentTimeAsEDIString());
		CTextNode* GSF28 = GetKid(*GS, _T("F28"));
		CTextNode* GEF97 = MakeSureExists(*GE, _T("F97"));
		ConservativeSetValue(GEF97, nMessageCount);
		CTextNode* GEF28 = MakeSureExists(*GE, _T("F28"));
		ConservativeSetValue(GEF28, GSF28);
	}
}

void CEDIX12DataCompletion::CompleteMessage(const CMessage& message, CTextNode* pMessageNode)
{
	const tstring& sMessageType = message.GetMessageType();

    CTextNode* ST = GetKid(*pMessageNode, _T("ST"));
    CTextNode* SE = GetKid(*pMessageNode, _T("SE"));
    CTextNode* STF143 = MakeSureExists(*ST, _T("F143"));
    ConservativeSetValue(STF143, sMessageType.substr(0, 3));
    CTextNode* SEF96 = MakeSureExists(*SE, _T("F96"));
	size_t segmentcount = GetSegmentChildrenCount(*ST->GetParent());
    ConservativeSetValue(SEF96, segmentcount);
    CTextNode* STF329 = MakeSureExists(*ST, _T("F329"));
    CTextNode* SEF329 = MakeSureExists(*SE, _T("F329"));
    ConservativeSetValue(SEF329, STF329);

	m_nHLSegmentCounter = 0;
	if (message.ShouldCompleteHLSegments())
		CompleteHLSegments(pMessageNode, 0, message.GetRootParticle());

	if (message.ShouldCompleteSingleConditions() || message.ShouldCompleteSingleValues())
	{
		m_bCompleteSingleValues = message.ShouldCompleteSingleValues();
		CompleteConditionsAndValues(pMessageNode, message.GetRootParticle());
	}
}

bool CEDIX12DataCompletion::CompleteHLSegments(CTextNode* pGroup, int parent, const CEDIParticle& particle)
{
	bool hasChildren = false;

	CTextNode* hl = pGroup->GetChildren()->GetFirstNodeByName(_T("HL"));
	const CEDIParticle* hlParticle = GetParticleByPath(particle, _T("HL"));

	if (hl != NULL)
	{
		// set parent and ID
		CTextNode* hlID = MakeSureExists(hl, _T("F628"));
		hlID->SetValue( ((const tstringstream&) (tstringstream() << (++m_nHLSegmentCounter))).str() );
		if (parent != 0)
		{
			CTextNode* hlParentID = MakeSureExists(hl, _T("F734"));
			hlParentID->SetValue( ((const tstringstream&) (tstringstream() << parent)).str() );
		}
	}

	parent = m_nHLSegmentCounter;

	CTextNodeContainer* pChildren = pGroup->GetChildren();
	for( size_t i = 0 ; i < pChildren->GetCount() ; ++i )
	{
		CTextNode* pNode = pChildren->GetAt(i);
		if (pNode->GetClass() == Group)
		{
			const CEDIParticle* p = GetParticleByPath(particle, pNode->GetName());
			hasChildren = CompleteHLSegments(pNode, parent, *p);
		}
	}

	if (hl != NULL)
	{
		const CEDIParticle* p_F736 = GetParticleByPath(*hlParticle, _T("F736"));

		if (p_F736->GetMinOccurs() > 0)
		{
			// Set has children flag
			CTextNode* hlChildCode = MakeSureExists(hl, _T("F736"));
			hlChildCode->SetValue( hasChildren ? _T("1") : _T("0") );
		}
		return true;
	}

	return hasChildren;
}

bool
CEDIX12DataCompletion::IsOldISAVersion() const
{
	return m_Settings.GetRelease() == _T("3040") ||
		m_Settings.GetRelease() == _T("3050") ||
		m_Settings.GetRelease() == _T("3060") ||
		m_Settings.GetRelease() == _T("3070") ||
		m_Settings.GetRelease() == _T("4010");
}

} // namespace edi
} // namespace text
} // namespace altova