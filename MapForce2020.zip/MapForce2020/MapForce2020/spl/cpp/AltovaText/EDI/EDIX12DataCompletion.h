[call GenerateFileHeader("EDIX12DataCompletion.h")]
#ifndef __EDIX12DATACOMPLETION_H
#define __EDIX12DATACOMPLETION_H

#include "DataCompletion.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIX12Settings;

class ALTOVATEXT_DECLSPECIFIER CEDIX12DataCompletion : public CDataCompletion
{
public:
	CEDIX12DataCompletion(const CTextDocument& rDocument, const CEDIX12Settings&, const tstring&);

public: // implementing CDataCompletion
	virtual void CompleteData(CTextNode*, const CEDIParticle&);

private:
	void CompleteEnvelope(CTextNode& envelope);
	void CompleteInterchange(CTextNode& interchange);
	void CompleteGroup();
	void CompleteMessage(const CMessage& message, CTextNode* pMessageNode);
	bool CompleteHLSegments(CTextNode* pGroup, int parent, const CEDIParticle& particle);
	
	// checks if the ISA version is within 3040-4010, otherwise false.
	bool IsOldISAVersion() const;

private:
	const CEDIX12Settings& m_Settings;
	CTextNode* m_pGroupRoot;

	int m_nHLSegmentCounter;
};

} // namespace edi
} // namespace text
} // namespace altova


#endif