[call GenerateFileHeader("Message.cpp")]

#include "StdAfx.h"
#include "Message.h"

namespace altova
{
namespace text
{
namespace edi
{

bool CMessage::HasSegment( const tstring& sSegment ) const
{
	return m_setSegments.find( sSegment ) != m_setSegments.end();
}

} // namespace edi
} // namespace text
} // namespace altova
