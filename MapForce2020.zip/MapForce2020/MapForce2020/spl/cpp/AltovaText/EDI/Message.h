[call GenerateFileHeader("Message.h")]
#ifndef __ALTOVATEXT_MESSAGE_H
#define __ALTOVATEXT_MESSAGE_H

#include "AltovaTextAPI.h"

namespace altova
{
namespace text
{
namespace edi
{

class CEDIParticle;

class ALTOVATEXT_DECLSPECIFIER CMessage
{
public:
	CMessage ( const tstring& sMessageType, const CEDIParticle& pParticle, const tstring arSegments\[\], unsigned long nSegmentSize, int completeHL, int completeSingleValues, int completeSingleConditions )
		: m_sMessageType(sMessageType), m_pRootParticle( pParticle), m_setSegments( arSegments, arSegments+nSegmentSize), mShouldCompleteHLSegments( completeHL == 1 ), mShouldCompleteSingleConditions( completeSingleConditions == 1 ), mShouldCompleteSingleValues( completeSingleValues == 1 )
	{}

	bool HasSegment( const tstring& sSegment ) const;

	const tstring& GetMessageType() const { return m_sMessageType; }
	const CEDIParticle& GetRootParticle() const { return m_pRootParticle; }

    bool ShouldCompleteSingleConditions() const { return mShouldCompleteSingleConditions; }
    bool ShouldCompleteSingleValues() const { return mShouldCompleteSingleValues; }
    bool ShouldCompleteHLSegments() const { return mShouldCompleteHLSegments; }

protected:
	const CEDIParticle& m_pRootParticle;
	const tstring m_sMessageType;
	const std::set<tstring> m_setSegments;
    const bool mShouldCompleteSingleConditions;
    const bool mShouldCompleteSingleValues;
    const bool mShouldCompleteHLSegments;
};

} // namespace edi
} // namespace text
} // namespace altova

#endif
