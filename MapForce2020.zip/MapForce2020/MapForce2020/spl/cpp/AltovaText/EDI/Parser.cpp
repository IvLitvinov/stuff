[call GenerateFileHeader("Parser.cpp")]
#include "StdAfx.h"

#include "Parser.h"

#include "TextException.h"
#include "EDISemanticValidator.h"
#include "Scanner.h"
#include "Generator.h"
#include "EDIReadContext.h"
#include "EDIFactSettings.h"
#include "EDIHL7Settings.h"
#include "Writer.h"

#include <iostream>

namespace altova
{
namespace text
{
namespace edi
{
/////////////////////////////////////////////////////////////////////////////
// EDI parser

CEDIParser::CEDIParser ()
: StandardSegments(NULL)
{
	//some defaults which should be overwritten from the textdocument
	m_ErrorSettings\[Undefined\] = ActionStop;
	m_ErrorSettings\[MissingSegment\] = ActionStop;
	m_ErrorSettings\[MissingGroup\] = ActionStop;
	m_ErrorSettings\[MissingFieldOrComposite\] = ActionStop;
	m_ErrorSettings\[ExtraData\] = ActionReportReject;
	m_ErrorSettings\[FieldValueInvalid\] = ActionReportReject;
	m_ErrorSettings\[InvalidDate\] = ActionReportReject;
	m_ErrorSettings\[InvalidTime\] = ActionReportReject;
	m_ErrorSettings\[ExtraRepeat\] = ActionReportReject;
	m_ErrorSettings\[NumericOverflow\] = ActionReportReject;
	m_ErrorSettings\[DataElementTooShort\] = ActionReportReject;
	m_ErrorSettings\[DataElementTooLong\] = ActionReportReject;
	m_ErrorSettings\[UnexpectedEndOfFile\] = ActionStop;
	m_ErrorSettings\[CodeListValueWrong\] = ActionReportReject;
	m_ErrorSettings\[SemanticWrong\] = ActionReportReject;
	m_ErrorSettings\[SegmentUnexpected\] = ActionStop;
	m_ErrorSettings\[SegmentUnrecognized\] = ActionStop;
	m_ErrorSettings\[NotUsedPresent\] = ActionStop;
}

CEDIParser::~CEDIParser ()
{
	delete StandardSegments;
}

// Parse EDI text into generator tree
bool CEDIParser::Parse (const CEDIParticle& rRootParticle, const TCHAR* szBuffer, CGenerator& rGenerator,
								CEDISettings& rSettings)
{
	size_t nLength = _tcslen(szBuffer);
	m_ServiceChars = rSettings.GetServiceChars();
	m_pSettings = &rSettings;

	CEDIScanner scanner(szBuffer, nLength, m_ServiceChars, rSettings.GetStandard());

	m_bContinueOnError = true;

	CEDISemanticValidator semanticValidator( rSettings);
	CEDIReadContext rootContext (scanner, *this, rRootParticle, rGenerator, semanticValidator);
	
	//init transaction counter for X12
	m_ParseInfo.m_F715 = _T( 'A');
	// the first ST segment for X12 will set this to 'A' (Accepted)
	// if there is no 'ST' segment there must be something wrong
	m_ParseInfo.m_F717 = _T('R');
	ResetTransactionSetCount();
	ResetTransactionSetAccepted();
	
	bool bOk = rRootParticle.GetNode()->Read(rootContext);
	scanner.SkipWhitespace();
	if( !bOk || !scanner.IsAtEnd() )
	{
		CEDIScannerState beforeReadState = scanner;
		tstring sExtra = scanner.ConsumeString(EDISERVICECHAR_SEGMENTTERMINATOR, true);
		rootContext.HandleError(
			NotAllDataParsed,
			CEDIErrorPosition( beforeReadState),
			CEDIErrorMessages::GetTextNotParsedMessage( sExtra)
		);
	}
	return bOk;
}

namespace details
{
	bool StartsWith(const tstring& str, const tstring& substr)
	{
		if (substr.size() > str.size())
			return false;
		return std::equal(substr.begin(), substr.end(), str.begin());
	}
}

void CEDIParser::FilterMessages(std::vector<CMessage*>& filteredMessages, const tstring& sNameStartsWith)
{
	filteredMessages.clear();
	for( std::map<tstring,CMessage>::iterator it = m_mapMessages.begin() ; it != m_mapMessages.end() ; ++it )
	{
		if( details::StartsWith( it->first, sNameStartsWith ) )
			filteredMessages.push_back( &it->second );
	}
}

bool CEDIStructureItem::IsRepeatingSequenceStarting(size_t it) const
{
	if (it == m_nChildCount)
		return false;

	if (it + 1 == m_nChildCount)
		return false;

	return ParticlesEquivalent(it, it+1);
}

bool CEDIStructureItem::ParticlesEquivalent(size_t i_a, size_t i_b) const
{
	const CEDIParticle& a = m_pChildren\[i_a\];
	const CEDIParticle& b = m_pChildren\[i_b\];
	
	if (a.GetNode()->GetNodeClass() != b.GetNode()->GetNodeClass())
		return false;

	if (a.GetNode()->GetNodeClass() == Segment)
		return a.GetNode()->GetName() == b.GetNode()->GetName();

	if (a.GetNode()->GetNodeClass() == Group)
	{
		tstring s_a = a.GetNode()->GetName();
		tstring s_b = b.GetNode()->GetName();

		tstring n_a;
		for (size_t i=0; i<s_a.length(); i++)
		{
			if ( _T('0') <= s_a\[i\] && s_a\[i\] <= _T('9') )
				n_a += s_a\[i\];
		}

		tstring n_b;
		for (size_t i2=0; i2<s_b.length(); i2++)
		{
			if ( _T('0') <= s_b\[i2\] && s_b\[i2\] <= _T('9') )
				n_b += s_b\[i2\];
		}


		size_t l = n_a.length();
		if (l < 2)
			return false;

		if ( !n_a.empty() && !( n_a\[l-1\] == _T('0') && n_a\[l-2\] == _T('0') )  && n_a == n_b )
			return true;
	}
	
	return false;
}

void CEDIStructureItem::HandleMissingSegmentOrGroup(CEDIReadContext& context, const CEDIParticle* currentParticle) const
{
	if (context.GetScanner().IsAtEnd())
	{
		context.HandleError (
			CEDIParser::UnexpectedEndOfFile,
			CEDIErrorPosition( context.GetScanner() ),
			CEDIErrorMessages::GetUnexpectedEndOfFileMessage()
			);
	}
	if (currentParticle->GetNode()->GetNodeClass() == Segment)
	{
		context.HandleError (
			CEDIParser::MissingSegment,
			CEDIErrorPosition( context.GetScanner() ),
			CEDIErrorMessages::GetMissingSegmentMessage(currentParticle->GetNode()->GetName())
			);
	}
	else if (currentParticle->GetNode()->GetNodeClass() == Group)
	{
		context.HandleError (
			CEDIParser::MissingGroup,
			CEDIErrorPosition( context.GetScanner() ),
			CEDIErrorMessages::GetMissingGroupMessage(currentParticle->GetNode()->GetName())
			);
	}
	else if (currentParticle->GetNode()->GetNodeClass() == Select)
	{
		context.HandleError (
			CEDIParser::MissingGroup,
			CEDIErrorPosition( context.GetScanner() ),
			CEDIErrorMessages::GetMissingGroupMessage(_T("Message"))
			);
	}
}

bool CEDIStructureItem::ReadChildren (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const
{
	if (GetNodeClass() == Group)
		return ReadChildrenOfGroup(context, cSeparator);
	else
		return ReadChildrenOfSegment(context, cSeparator);
}

bool CEDIStructureItem::ReadChildrenOfGroup (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const
{

	CEDIScanner& scanner = context.GetScanner();
	map<const CEDIParticle*, size_t> readMap;
	
	size_t it = 0;
	size_t repeatingStart = m_nChildCount;

	while (it != m_nChildCount)
	{
		if (repeatingStart != m_nChildCount)
		{
			if (ParticlesEquivalent(it, repeatingStart))
			{
				;
			}
			else
			{
				for ( map<const CEDIParticle*, size_t>::iterator it1 = readMap.begin(); it1 != readMap.end(); ++it1 )
				{
					CEDIReadContext ctx( context, *it1->first, context.GetSemanticValidator() );
					
					// report missing stuff
					if ( it1->second < it1->first->GetMinOccurs() )
					{
						HandleMissingSegmentOrGroup( ctx, it1->first );
					}
				}

				repeatingStart  = m_nChildCount;
				readMap.clear();
			}
		}

		if(repeatingStart == m_nChildCount && IsRepeatingSequenceStarting(it))
		{
			repeatingStart = it;
		}

		bool inRepeatingSequence = repeatingStart != m_nChildCount;

		const CEDIParticle* currentParticle = &(m_pChildren\[it\]);
		if (context.GetParser().GetSettings().GetStandard() == EDIX12 && currentParticle->GetNode()->GetNodeClass() == Group)
		{
			if( it > 0 )
			{
				const CEDIParticle* precedingParticle = &(m_pChildren\[it-1\]);

				if( precedingParticle->GetNode()->GetNodeClass() == Segment && precedingParticle->GetNode()->GetName() == _T("LS") )
					currentParticle->mBoundedGroup = true;
			}
		}
		
		if ( inRepeatingSequence && !(readMap.find(currentParticle) != readMap.end()) )
			readMap\[currentParticle\] = 0;

		size_t toRead = currentParticle->GetMergedEntries();
		EDISERVICECHAR_TYPE repSeparator = cSeparator;
		if (toRead == 1) // no merged entry
		{
			toRead = currentParticle->GetRespectMaxOccurs() ?
				currentParticle->GetMaxOccurs() : // read only max occurs
				INT_MAX; // try to read as much as possible -> errors are reported anyways

			if (currentParticle->GetMaxOccurs() <= 1)
			{
				toRead = 1;
			}
		}

		CEDIReadContext childContext (context, *currentParticle, context.GetSemanticValidator());
		bool advance = true;
		bool readSuccess = true;
		for (size_t count = 0; count < toRead; ++count)
		{
			childContext.SetOccurence( count + 1 );

			CEDIScannerState preservedState = scanner;

			bool readSuccess = !scanner.IsAtEnd() && currentParticle->GetNode()->Read(childContext);

			if ( !readSuccess )
			{
				if ( count >= currentParticle->GetMinOccurs())
				{
					break; // read enough
				}
				if ( context.GetParser().GetSettings().GetStandard() == EDITRADACOMS && currentParticle->GetNode()->GetNodeClass() == Select)
				{
					return false; // select failed because it was not read, report upwards
				}

				if ( !inRepeatingSequence )
				{
					if ( count < currentParticle->GetMinOccurs())
					{
						tstring sSeg = ReadSegmentTag( childContext );

						childContext.HandleError (
							CEDIParser::SegmentUnexpected,
							CEDIErrorPosition( context.GetScanner() ),
							CEDIErrorMessages::GetUnexpectedSegmentIDMessage( sSeg )
							);
					}
				}
			}

			size_t readSoFar = inRepeatingSequence ? readMap\[currentParticle\] : count;
			if (readSuccess && currentParticle->GetMergedEntries() == 1 && readSoFar >= currentParticle->GetMaxOccurs())
			{
				childContext.HandleError (
					CEDIParser::ExtraRepeat,
					CEDIErrorPosition( preservedState),
					CEDIErrorMessages::GetExtraRepeatMessage( currentParticle->GetNode()->GetName() )
					);
			}

			if (readSuccess)
			{
				advance = false;
				if (inRepeatingSequence)
					readMap\[currentParticle\] = readMap\[currentParticle\] + 1;
			}
		}

		if ( inRepeatingSequence && !advance ) // we are in repeating sequence
		{
			it = repeatingStart;
		}
		else 
			++it;
	}

	return true;
}

bool CEDIStructureItem::ReadChildrenOfSegment (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const
{
	CEDIScanner& scanner = context.GetScanner();

	// basically the same as for WriteChildren applies.
	for (size_t nChildIndex = 0; nChildIndex != m_nChildCount; ++nChildIndex)
	{
    	const CEDIParticle& currentParticle = (m_pChildren\[nChildIndex\]);

        // consume a separator if it is valid to do so.
        if (nChildIndex != 0 && cSeparator != EDISERVICECHAR_COUNT && scanner.IsAtSeparator(cSeparator))
            scanner.RawConsumeChar();

        size_t nToRead = currentParticle.GetMergedEntries();
        EDISERVICECHAR_TYPE repSeparator = cSeparator;
        if (nToRead == 1) // no merged entry
        {
            nToRead = currentParticle.GetRespectMaxOccurs() ?
					currentParticle.GetMaxOccurs()
				: 	INT_MAX; // try to read as much as possible -> errors are reported anyways
            if (m_NodeClass == Segment)
            {
                repSeparator = EDISERVICECHAR_REPETITIONSEPARATOR;
                if (scanner.separators.GetRepetitionSeparator() == 0)
                {
                    nToRead = 1;
                    repSeparator = EDISERVICECHAR_COUNT;
                }
                else if (context.GetParser().GetSettings().GetStandard() == EDIHL7
					&& IsHL7SpecialField(currentParticle.GetNameOverride(), _T("-1")) )
                {
                    nToRead = 1;
                    repSeparator = EDISERVICECHAR_COUNT;
                }
                else
                {
                	nToRead = INT_MAX;
                }
            }
            else if (currentParticle.GetMaxOccurs() <= 1)
            {
                nToRead = 1;
                repSeparator = EDISERVICECHAR_COUNT;
            }
        }

		switch( context.GetParticle().GetNode()->GetNodeClass() )
		{
			case Segment: context.GetParser().IncrementDataElementPosition(); break;
			case Composite: context.GetParser().IncrementComponentDataElementPosition(); break;
		}
		
        CEDIReadContext childContext (context, currentParticle, context.GetSemanticValidator());
        for (size_t nCount = 0; nCount < nToRead && !scanner.IsAtEnd(); ++nCount)
        {
			childContext.SetOccurence( nCount + 1 );
            // consume the proper separator. otherwise the children won't find anything to read and fail anyways.
            if (nCount != 0 && repSeparator != EDISERVICECHAR_COUNT)
            {
            	if (scanner.IsAtSeparator(repSeparator))
                	scanner.RawConsumeChar ();
                else
                	break;
            }

            CEDIScannerState preservedState = scanner;

            bool readSuccess = currentParticle.GetNode()->Read(childContext);

            if (!readSuccess && (repSeparator == EDISERVICECHAR_COUNT || currentParticle.GetMinOccurs() > 0))
            {
                //scanner.Reset(preservedState);

                if (nCount >= currentParticle.GetMinOccurs())
                {
                    if (nCount >= currentParticle.GetMergedEntries())
                        break; // had enough
                }
                else
                {
                    // error: missing fields OR missing segment
                    if (currentParticle.GetNode()->GetNodeClass() == Segment)
                    {
                        childContext.HandleError (
							CEDIParser::MissingSegment,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetMissingSegmentMessage(currentParticle.GetNode()->GetName())
						);
                    }
                    else
                    if (currentParticle.GetNode()->GetNodeClass() == Group)
                    {
                        childContext.HandleError (
							CEDIParser::MissingGroup,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetMissingGroupMessage(currentParticle.GetNode()->GetName())
						);
                    }
					else
                    if (currentParticle.GetNode()->GetNodeClass() == Select)
                    {
                        childContext.HandleError (
							CEDIParser::MissingGroup,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetMissingGroupMessage(_T("Message"))
						);
                    }
                    else
                        childContext.HandleError (
							CEDIParser::MissingFieldOrComposite,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetMissingFieldOrCompositeMessage(currentParticle.GetNode()->GetName())
						);
                }
            }

            if (currentParticle.GetMergedEntries() == 1 && nCount >= currentParticle.GetMaxOccurs())
            {
            	if (currentParticle.GetMaxOccurs() != 0 || readSuccess)
            	{
            		if (currentParticle.GetMaxOccurs() == 0 && nCount == 0)
	            	{
	            		childContext.HandleError (
							CEDIParser::NotUsedPresent,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetNotUsedPresentMessage( currentParticle.GetNode()->GetName() )
						);
	            	}
	            	else
	            	{
		                childContext.HandleError (
							CEDIParser::ExtraRepeat,
							CEDIErrorPosition( preservedState),
							CEDIErrorMessages::GetExtraRepeatMessage( currentParticle.GetNode()->GetName() )
						);
					}
				}
			}

            if (repSeparator != EDISERVICECHAR_COUNT)
            {
				tstring sExtra = scanner.ConsumeString(repSeparator, true);
                if (sExtra.size() > 0)
					childContext.HandleError(
						CEDIParser::ExtraData,
						CEDIErrorPosition( preservedState),
						CEDIErrorMessages::GetExtraDataMessage( currentParticle.GetNode()->GetName(), sExtra)
					);
            }
        }

		// the inner loop has now consumed everything excluding the next terminator
		// if the repetition separator is different and nToRead is not INT_MAX and
		// there are still data fields left over, then the parser won't recover.
	}

	return true;
}


bool CEDIStructureItem::IsAtGroup (const CEDIReadContext& context) const
{
	if (!m_sConditionPath.empty() && !CheckConditionValue(context, m_sConditionPath, m_sConditionValue))
	{
		return false;
	}
	
	if (context.GetParticle().mBoundedGroup)
	{	
		string_type loopID = GetName();
		if( loopID.find(_T("Loop")) == 0)
			loopID = loopID.substr(4);
		
		loopID = loopID.substr(0,4);
		
		if (loopID.empty() || loopID != context.GetParser().GetF447())
			return false;
	}
	
	const CEDIStructureItem* pNode = this;
	const CEDIParticle* pParticle = &pNode->m_pChildren\[0\];
	while (pParticle->GetNode()->m_NodeClass == Group)
	{
		pNode = pParticle->GetNode();
		// first child of group is mandatory group header
		pParticle = &pNode->m_pChildren\[0\];
	}

	// for the special Interchange and Envelope groups different behavior is needed.
	for (size_t nIndex = 0; nIndex < pNode->m_nChildCount; ++nIndex)
	{
		pParticle = &pNode->m_pChildren\[nIndex\];
		
		const CEDIStructureItem* pChild = pParticle->GetNode();

		if (pChild->m_NodeClass == Segment)
		{
			// try to find out whether this segment appears here.
			CEDIScannerState preservedState = context.GetScanner();
			bool bResult = pChild->IsSegmentStarting (context);
			context.GetScanner().Reset(preservedState);
			if (bResult)
				return true;
		}
		else // shouldn't be anything else.
		{
			if (pChild->IsAtGroup (context))
				return true;
		}

		// the segment is mandatory -> the group cannot occur here.
		if (pParticle->GetMinOccurs() > 0)
			return false;
	}
	// this could happen in cases where groups have no indicator segment.
	return false;
}

tstring CEDIStructureItem::ReadSegmentTag (const CEDIReadContext& context) const
{
	tstring sRet;
	CEDIScanner& scanner = context.GetScanner();
	scanner.SkipWhitespace(); // skip whitespace before/between segments

	if (m_sName == _T("UNA") || m_sName == _T("ISA") || IsHL7SpecialSegment(m_sName) ||
		context.GetParser().GetSettings().GetStandard() == altova::text::edi::EDIFixed)
	{
		// check segment tag - character by character because separators are not known yet
		for (tstring::size_type i = 0; i < m_sName.length(); ++i)
		{
			TCHAR c = scanner.RawConsumeChar();
			if( c != 0 )
				sRet.append( 1, c );
		}
	}
	else
		sRet = scanner.ConsumeString(EDISERVICECHAR_COMPONENTSEPARATOR, true);

	return sRet;
}

bool CEDIStructureItem::IsSegmentStarting (const CEDIReadContext& context) const
{
	return ReadSegmentTag( context ) == m_sName && CheckSegmentCondition(context);
}

bool CEDIStructureItem::CheckSegmentCondition(const CEDIReadContext& context) const
{
	if (m_sConditionPath.empty())
		return true;
	return CheckConditionValue(context, m_sConditionPath, m_sConditionValue);
}

bool CEDIStructureItem::CheckConditionValue(const CEDIReadContext& ctx, const tstring& conditionPath, const tstring& conditionValue) const
{
	CEDIScannerState preservedState = ctx.GetScanner();
	for( size_t k = 0 ; k < m_nChildCount ; ++k )
	{
		const CEDIParticle& particle = m_pChildren\[k\];
		if (ctx.GetScanner().IsAtEnd() || ctx.GetScanner().IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR))
		{
			ctx.GetScanner().Reset(preservedState);
			return false;
		}

		if (ctx.GetScanner().IsAtAnySeparator())
			ctx.GetScanner().RawConsumeChar();

		if( particle.GetNode()->GetNodeClass() == DataElement )
		{
			if (ctx.GetScanner().IsAtEnd() || ctx.GetScanner().IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR))
			{
				ctx.GetScanner().Reset(preservedState);
				return false;
			}

			EDISERVICECHAR_TYPE separator;
			switch (m_NodeClass)
			{
				case Segment:
					separator = EDISERVICECHAR_DATAELEMENTSEPARATOR;
					break;

				case Composite:
					separator = EDISERVICECHAR_COMPONENTSEPARATOR;
					break;

				case SubComposite:
					separator = EDISERVICECHAR_SUBCOMPONENTSEPARATOR;
					break;

				default:
					ctx.GetScanner().Reset(preservedState);
					return false;
			}

			tstring value = ctx.GetScanner().ConsumeString(separator, true);

			if (particle.GetTargetName() == conditionPath)
			{
				ctx.GetScanner().Reset(preservedState);
				if (!conditionValue.empty() && value == conditionValue)
					return true;

				for( std::vector<tstring>::const_iterator it = particle.GetCodeValues().begin() ; it != particle.GetCodeValues().end() ; ++it )
					if( *it == value )
					  return true;            	

				return false;
			}
		}
		else if (particle.GetNode()->GetNodeClass() == Composite)
		{
			int i = (int) conditionPath.find('/');
			if (i > 0)
			{
				tstring path = conditionPath.substr(i+1);
				if (particle.GetTargetName() == conditionPath.substr(0, i))
				{
					bool result = particle.GetNode()->CheckConditionValue(ctx, path, conditionValue);
					ctx.GetScanner().Reset(preservedState);
					return result;
				}
			}

			// skip composite
			for (; ; )
			{
				ctx.GetScanner().RawConsumeChar();

				if (ctx.GetScanner().IsAtEnd() || ctx.GetScanner().IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR))
				{
					ctx.GetScanner().Reset(preservedState);
					return false;
				}
				if (ctx.GetScanner().IsAtSeparator(EDISERVICECHAR_DATAELEMENTSEPARATOR))
					break;
			}
		}
		else if (particle.GetNode()->GetNodeClass() == Segment)
		{
			int i = (int) conditionPath.find('/');
			if (i > 0)
			{
				tstring path = conditionPath.substr(i+1);
				if (particle.GetTargetName() == conditionPath.substr(0, i) && particle.GetTargetName() == particle.GetNode()->ReadSegmentTag(ctx))
				{
					bool result = particle.GetNode()->CheckConditionValue(ctx, path, conditionValue);

					ctx.GetScanner().Reset(preservedState);
					return result;
				}
			}

			// skip segment
			for (;;)
			{
				ctx.GetScanner().RawConsumeChar();

				if (ctx.GetScanner().IsAtEnd())
				{
					ctx.GetScanner().Reset(preservedState);
					return false;
				}
				if (ctx.GetScanner().IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR))
				{
					ctx.GetScanner().RawConsumeChar();
					break;
				}
			}
		}
	}

	ctx.GetScanner().Reset(preservedState);
	return false;
}

bool CEDIStructureItem::IsHL7SpecialSegment( const tstring& sSegmentName ) const
{
	return sSegmentName == _T("MSH") || sSegmentName == _T("FHS") || sSegmentName == _T("BHS");
}

bool CEDIStructureItem::IsHL7SpecialField( const tstring& sFieldName, const tstring& sFieldIndex) const
{
	if( sFieldName.find(_T('-') != tstring::npos) )
		return IsHL7SpecialSegment( sFieldName.substr(0, sFieldName.find( _T('-') ) ) )
			&& sFieldName.compare( sFieldName.length() - sFieldIndex.length(), sFieldIndex.length(), sFieldIndex ) == 0;
	else
		return false;
}

void CEDIStructureItem::WriteChildren (
CEDIWriter& writer, CTextNode* pNode, EDISERVICECHAR_TYPE separator) const
{
	for (size_t nChildPos = 0; nChildPos < m_nChildCount; ++nChildPos)
	{
		const CEDIParticle& currentParticle = (m_pChildren\[nChildPos\]);

		size_t nToWrite = currentParticle.GetMergedEntries();
		EDISERVICECHAR_TYPE repSeparator = separator;
		if (currentParticle.GetMaxOccurs() > 1 || m_NodeClass == Group)
		{
			nToWrite = INT_MAX;
			if (m_NodeClass == Segment)
			{
				repSeparator = EDISERVICECHAR_REPETITIONSEPARATOR;
				if (writer.GetServiceChars().GetRepetitionSeparator() == 0)
					nToWrite = 1;
				if (writer.GetStandard() == altova::text::edi::EDIFixed)
					nToWrite = 1;
			}
		}

		CTextNodeContainer oChildren;
		if (pNode)
			pNode->GetChildren()->FilterByName(currentParticle.GetNameOverride(), oChildren);

		if( oChildren.GetCount() > max( currentParticle.GetMaxOccurs(), currentParticle.GetMergedEntries() ) )
		{
			writer.HandleError( pNode, CEDIParser::ExtraRepeat, CEDIErrorMessages::GetExtraRepeatMessage( currentParticle.GetNameOverride() ) );
		}
		
		for (size_t nCount = 0; nCount < nToWrite; ++nCount)
		{
			if (nCount < oChildren.GetCount())
				currentParticle.GetNode()->Write(writer, oChildren.GetAt(nCount), currentParticle);
			else
			{
				if (writer.GetStandard() == altova::text::edi::EDIFixed && m_NodeClass == Segment)
					currentParticle.GetNode()->Write(writer, pNode, currentParticle);

				// selects name doesn't match the generator tree. so always try to write them.
				if (currentParticle.GetNode()->GetNodeClass() == Select)
				{
					currentParticle.GetNode()->Write(writer, pNode, currentParticle);
					break;
				}

				if (nCount < currentParticle.GetMinOccurs())
				{
					if ( m_NodeClass == Group && currentParticle.GetNameOverride() == _T("Message") )
					{
						//report error/warning
						writer.HandleError(
							pNode,
							CEDIParser::MissingGroup,
							CEDIErrorMessages::GetMissingGroupMessage( currentParticle.GetNameOverride() )
							);
					}
					else
					{
						//report error/warning
						writer.HandleError(
							pNode,
							CEDIParser::MissingFieldOrComposite,
							CEDIErrorMessages::GetMissingFieldOrCompositeMessage( currentParticle.GetNameOverride() )
							);
					}

					if (m_NodeClass == Group && currentParticle.GetNameOverride() != _T("Message"))
						currentParticle.GetNode()->Write(writer, pNode, currentParticle);
				}
				if (nCount >= currentParticle.GetMergedEntries())
					break;
			}
			if( !(writer.GetStandard() == EDIHL7
				&& IsHL7SpecialField(currentParticle.GetNameOverride(), _T("-1"))) )
				writer.AddSeparator(repSeparator);
		}

		if (repSeparator != separator)
		{
			writer.ClearPendingSeparators(repSeparator);
			writer.AddSeparator(separator);
		}
	}

	writer.ClearPendingSeparators(separator);
}


bool CEDIDataElement::Read (const CEDIReadContext& context) const
{
	tstring s;
	CEDIScanner& scanner = context.GetScanner();
	CEDIScannerState beforeRead = scanner;
	if( context.GetParser().GetSettings().GetStandard() == EDIFixed)
	{
		while( s.length() < m_Validator->GetMaxLength() && !scanner.IsAtEnd() &&
				scanner.GetCurrentChar() != scanner.separators.GetSegmentTerminator() )
		{
			TCHAR c = scanner.RawConsumeChar();
			if (scanner.GetCurrentChar() == '\\n')
			{
				if (c != '\\r')
					s.append( 1, c);
			}
			else
				s.append( 1, c);
		}

		m_Validator->MakeValidOnRead( s, context, CEDIErrorPosition(beforeRead));

		if (s.length() == 0)
			return false;

		context.GetGenerator().InsertElement(context.GetParticle().GetTargetName(), s, m_NodeClass);
		return true;
	}

    if( context.GetParser().GetSettings().GetStandard() == EDIHL7
		&& IsHL7SpecialField(context.GetParticle().GetNameOverride(), _T("-2"))
    )
    {
            TCHAR c = scanner.RawConsumeChar();
			scanner.separators.SetServiceChar( EDISERVICECHAR_COMPONENTSEPARATOR, c);
			s += c;
			s += c = scanner.RawConsumeChar();
            scanner.separators.SetServiceChar( EDISERVICECHAR_REPETITIONSEPARATOR, c);
			if( scanner.GetCurrentChar() != scanner.separators.GetDataElementSeparator())
			{
				s += c = scanner.RawConsumeChar();
				scanner.separators.SetServiceChar( EDISERVICECHAR_RELEASECHARACTER, c);
			}
			if( scanner.GetCurrentChar() != scanner.separators.GetDataElementSeparator())
			{
				s += c = scanner.RawConsumeChar();
				scanner.separators.SetServiceChar( EDISERVICECHAR_SUBCOMPONENTSEPARATOR, c);
			}
			while( scanner.GetCurrentChar() != scanner.separators.GetDataElementSeparator())
			{
				s += c = scanner.RawConsumeChar();
			}
    }
    else
    {
    	s = scanner.ConsumeString(EDISERVICECHAR_COMPONENTSEPARATOR, true);
    	if ( s.empty() )
    		return false;  // data element is absent

    	// validator does error reporting itself.
    	m_Validator->MakeValidOnRead (s, context, CEDIErrorPosition(beforeRead));

		// codelist validation
		if( !m_Validator->HasValue( s))
		{
			if( !m_Validator->IsIncomplete() )
				context.HandleError( 
					CEDIParser::CodeListValueWrong,
					CEDIErrorPosition(beforeRead),
					CEDIErrorMessages::GetInvalidCodeListValueMessage( s, m_Validator->GetCodeListValues()),
					s
					);
			else
				context.HandleWarning( 
				CEDIErrorPosition(beforeRead),
				CEDIErrorMessages::GetIncompleteCodeListValueMessage( s, m_Validator->GetCodeListValues()),
				s
				);
		}

		// embedded codelist validate
		if( !EmbeddedCodeListValidate(s, context.GetParticle()) )
			context.HandleError(
				CEDIParser::CodeListValueWrong,
				CEDIErrorPosition(beforeRead),
				CEDIErrorMessages::GetInvalidCodeListValueMessage( s, EmbeddedCodeListValueList(context.GetParticle()) ),
				s
			);

		//edi validation
		tstring sError(context.GetSemanticValidator().Validate( context.GetParent()->GetParticle().GetNameOverride(), context.GetParticle().GetNameOverride(), s));
		if( sError.size() > 0)
			context.HandleError( CEDIParser::SemanticWrong, CEDIErrorPosition(beforeRead), sError, s);
    }
	
	if( context.GetParser().GetSettings().GetStandard() == EDIX12 )
	{
		if( context.GetParticle().GetNameOverride() == _T("F447") && context.GetCurrentSegmentName() == _T("LS") )
			context.GetParser().SetF447( s );
	}

	CGenerator& generator = context.GetGenerator();
	generator.InsertElement (context.GetParticle().GetTargetName(), s, m_NodeClass);
	return true;
}

void CEDIDataElement::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	tstring value;
	tstring name;
	
	if (pNode)
	{
		value = pNode->GetValue();
		name = pNode->GetName();
	}

	m_Validator->MakeValidOnWrite (value, pNode, writer);

	// codelist validation
	if( !m_Validator->HasValue( value))
	{
		if( !m_Validator->IsIncomplete() )
			writer.HandleError( 
				pNode,
				CEDIParser::CodeListValueWrong,
				CEDIErrorMessages::GetInvalidCodeListValueMessage( value, m_Validator->GetCodeListValues() )
			);
		else
			writer.HandleWarning( 
				pNode,
				CEDIErrorMessages::GetIncompleteCodeListValueMessage( value, m_Validator->GetCodeListValues() )
			);
	}

	// embedded codelist validate
	if( !EmbeddedCodeListValidate(value, particle) )
		writer.HandleError(
			pNode,
			CEDIParser::CodeListValueWrong,
			CEDIErrorMessages::GetInvalidCodeListValueMessage( value, EmbeddedCodeListValueList(particle) )
		);

	// edi validate
	tstring sError(writer.GetSemanticValidator().Validate( pNode->GetParent()->GetName(), name, value));
	if( sError.size() > 0)
		writer.HandleError( pNode, CEDIParser::SemanticWrong, sError);

	if (value.length() == 0)
		return; // do not write empty values.

	TCHAR releaseCharacter = writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER);
	tstring result;
    if( writer.GetStandard() == EDIHL7 )
    {
		if( IsHL7SpecialField(name, _T("-2")) )
		{
			result = writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR);
			result += writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR);
			if( releaseCharacter != 0 )
			{
				result += releaseCharacter;
				if( writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR) != 0 )
					result += writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR);
			}
		}
		else
		{
			bool skipEscape = false;

			for(size_t i=0; i < value.length(); ++i)
			{
				TCHAR ch = value\[i\];
				if (IsSpecialChar(writer.GetServiceChars(), ch) && !skipEscape)
				{
					if (writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER) != 0)
					{
						TCHAR chNext = i + 1 < value.length() ? value\[i + 1\] : 0;
						if( ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER)
							&& (chNext == CEDIHL7Settings::cEscNormalText
							|| chNext == CEDIHL7Settings::cEscStartHighlight
							|| chNext == CEDIHL7Settings::cEscHexadecimalData
							|| chNext == CEDIHL7Settings::cEscLocalEscapeSeq))
						{
							skipEscape = true;
							result += ch;
						}
						else
						{
							result += writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER);

							if (ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR)) result += CEDIHL7Settings::cEscFieldSeparator;
							else if (ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR)) result += CEDIHL7Settings::cEscSubComponentSeparator;
							else if (ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR)) result += CEDIHL7Settings::cEscComponentSeparator;
							else if (ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER)) result += CEDIHL7Settings::cEscEscapeSeparator;
							else if (ch == writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR)) result += CEDIHL7Settings::cEscRepetitionSeparator;

							result += writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER);
						}
					}
					else
						result += _T(' ');
				}
				else
				{
					skipEscape = skipEscape && ch != writer.GetServiceChars().GetServiceChar(EDISERVICECHAR_RELEASECHARACTER);
					result += ch;
				}
			}
		}
    }
	else
	{
		for (size_t i = 0; i < value.length(); ++i)
		{
			if (IsSpecialChar (writer.GetServiceChars(), value\[i\]))
			{
				if( releaseCharacter != 0 )
				{
    				result.append (1, releaseCharacter);
					result.append (1, value\[i\]);
				}
				else
				{
					result.append ((tstring::size_type)1, _T(' '));
				}
			}
			else
			{
				result.append ((tstring::size_type)1, value\[i\]);
			}
		}
	}
	writer.Write (result);
}

bool CEDIDataElement::IsSpecialChar (const CEDIServiceChars& serviceChars, TCHAR ch)
{
	EDISERVICECHAR_TYPE separators \[\] = {
		EDISERVICECHAR_COMPONENTSEPARATOR,
		EDISERVICECHAR_DATAELEMENTSEPARATOR,
		EDISERVICECHAR_RELEASECHARACTER,
		EDISERVICECHAR_REPETITIONSEPARATOR,
		EDISERVICECHAR_SEGMENTTERMINATOR,
        EDISERVICECHAR_SUBCOMPONENTSEPARATOR,
		EDISERVICECHAR_SEGMENTSEPARATOR,
		EDISERVICECHAR_COUNT
	};

	for (EDISERVICECHAR_TYPE* p = separators; *p != EDISERVICECHAR_COUNT; ++p)
	{
		TCHAR sc = serviceChars.GetServiceChar(*p);
		if (sc != 0 && sc != _T(' ') && sc == ch)
			return true;
	}

	return false;
}

bool CEDIDataElement::EmbeddedCodeListValidate(const tstring& value, const CEDIParticle& particle) const
{
	if (particle.GetCodeValues().empty())
		return true;

	for( std::vector<tstring>::const_iterator it = particle.GetCodeValues().begin() ; it != particle.GetCodeValues().end() ; ++it )
		if( *it == value )
			return true;

	return false;
}

tstring CEDIDataElement::EmbeddedCodeListValueList(const CEDIParticle& particle) const
{
	tstring message;
	for( std::vector<tstring>::const_iterator it = particle.GetCodeValues().begin() ; it != particle.GetCodeValues().end() ; ++it )
		message += _T(", '") + *it + _T("'");

	return message.substr(2);
}

bool CEDISingleCharElement::Read (const CEDIReadContext& context) const
{
	CEDIScanner& scanner = context.GetScanner();
	if (scanner.IsAtEnd())
		return false; // not read
	TCHAR c = scanner.RawConsumeChar();

    if (context.GetParser().GetSettings().GetStandard() == EDIHL7
		&& IsHL7SpecialField(context.GetParticle().GetNameOverride(), _T("-1")) )
    {
        scanner.separators.SetServiceChar( EDISERVICECHAR_DATAELEMENTSEPARATOR, c);
        scanner.separators.SetServiceChar( EDISERVICECHAR_SEGMENTSEPARATOR, c);
        scanner.separators.SetServiceChar( EDISERVICECHAR_REPETITIONSEPARATOR, '\\0');
    }

	CGenerator& generator = context.GetGenerator();
	generator.InsertElement (context.GetParticle().GetTargetName(), tstring(1, c), m_NodeClass);
	return true;
}

void CEDISingleCharElement::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	tstring value = pNode->GetValue();
	if (value.empty())
		value = _T(" ");
		
	if( writer.GetStandard() == EDIHL7 && IsHL7SpecialField(pNode->GetName(), _T("-1")) )
		writer.Write (tstring(1, writer.GetServiceChars().GetDataElementSeparator()));
	else
		writer.Write (tstring(1, value\[0\]));
}



bool CEDIComposite::Read (const CEDIReadContext& context) const
{
	CEDIScanner& scanner = context.GetScanner();
	if (scanner.IsAtAnySeparator() &&
		!scanner.IsAtSeparator(EDISERVICECHAR_COMPONENTSEPARATOR))
		return false; // empty

	context.GetParser().ResetComponentDataElementPosition(); // reset composite data element pos to 0
		
	CGenerator& generator = context.GetGenerator();
	generator.EnterElement (context.GetParticle().GetTargetName(), m_NodeClass);
	if (!ReadChildren (context, EDISERVICECHAR_COMPONENTSEPARATOR))
	{
		generator.LeaveElement (context.GetParticle().GetTargetName());
		return false;
	}

	generator.LeaveElement (context.GetParticle().GetTargetName());
	return true;
}


void CEDIComposite::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	WriteChildren (writer, pNode, EDISERVICECHAR_COMPONENTSEPARATOR);
}

bool CEDISubComposite::Read (const CEDIReadContext& context) const
{
	CEDIScanner& scanner = context.GetScanner();
	if (scanner.IsAtAnySeparator() &&
		!scanner.IsAtSeparator(EDISERVICECHAR_SUBCOMPONENTSEPARATOR))
		return false; // empty

	CGenerator& generator = context.GetGenerator();
	generator.EnterElement (context.GetParticle().GetTargetName(), m_NodeClass);
	if (!ReadChildren (context, EDISERVICECHAR_SUBCOMPONENTSEPARATOR))
	{
		generator.LeaveElement (context.GetParticle().GetTargetName());
		return false;
	}

	generator.LeaveElement (context.GetParticle().GetTargetName());
	return true;
}


void CEDISubComposite::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	WriteChildren (writer, pNode, EDISERVICECHAR_SUBCOMPONENTSEPARATOR);
}

bool CEDISegment::Read (const CEDIReadContext& context) const
{
	CEDIScanner& scanner = context.GetScanner();

	CEDIScannerState preserved = scanner;
	
	// check if current segment starts here.
	if (!IsSegmentStarting (context))
	{
		scanner.Reset(preserved);

		if( context.GetParticle().GetMinOccurs() > 0)
		{
			tstring sSeg = ReadSegmentTag( context );
			std::set<tstring>* pStdSegments = context.GetParser().StandardSegments;
			tstring sCurrentMessageType = context.GetParser().GetCurrentMessageType();
			if ( sSeg.size() > 0)
			{
				if ( pStdSegments->find(sSeg) == pStdSegments->end())
				{
					context.HandleError(
						CEDIParser::SegmentUnrecognized,
						CEDIErrorPosition(preserved),
						CEDIErrorMessages::GetUnrecognizedSegmentMessage(sSeg),
						sSeg
						);
					return false;
				}
				else if ( sCurrentMessageType != _T("") &&
					!context.GetParser().GetMessage(sCurrentMessageType).HasSegment(sSeg) )
				{
					context.HandleError(
						CEDIParser::SegmentUnexpected,
						CEDIErrorPosition(preserved),
						CEDIErrorMessages::GetUnexpectedSegmentIDMessage(sSeg),
						sSeg
						);
					return false;
				}
			}
			scanner.Reset(preserved);
		}
		return false;
	}
	
	context.GetParser().ResetDataElementPosition();
	context.GetParser().ResetComponentDataElementPosition();

	switch( context.GetParser().GetSettings().GetStandard() )
	{
		case EDIFact:
		case EDISCRIPT:
		{
			if ( m_sName == _T("UNA") )  // read EDIFACT service string advice
				return scanner.ReadUNA ();
		}
		break;
		case EDIX12:
		{
			if ( m_sName == _T("ISA") )  // X12 ISA segment defines the data element separator here
			{
				if (!scanner.ReadISASegmentStart())
					return false;
			}
			
			if( m_sName == _T("ST") )
			{
				//reset current segment position
				context.GetParser().ResetCurrentSegmentPosition();
				
				//increment transaction count
				context.GetParser().IncrementTransactionSetCount();
				
				//default that everything will be ok.
				context.GetParser().SetF717( _T('A') );
			}
			else if( m_sName == _T("GS") )
			{
				context.GetParser().SetF715( _T('A') );
			}
			else
			{
				//increment segment counter
				context.GetParser().IncrementCurrentSegmentPosition();
			}
			
			//reset current loop identifier code, if segment is LE
			if( m_sName == _T("LE") )
				context.GetParser().SetF447( _T("") );
		}
	}

	// skip data element separator eventually following and do sanity checks
	if (scanner.IsAtSeparator (EDISERVICECHAR_SEGMENTSEPARATOR) ||
		context.GetParser().GetSettings().GetStandard() == EDIFixed)
    {
		if(context.GetParser().GetSettings().GetStandard() != EDIFixed)
		{
			if ( !(context.GetParser().GetSettings().GetStandard() == EDIHL7 && IsHL7SpecialSegment(m_sName)) )
				scanner.RawConsumeChar();
		}
    }
	else if (!scanner.IsAtSeparator (EDISERVICECHAR_SEGMENTTERMINATOR))
	{
		return false;		// invalid input character.
	}

	CGenerator& generator = context.GetGenerator();
	generator.EnterElement (context.GetParticle().GetTargetName(), m_NodeClass);	// begin node construction

	context.GetSemanticValidator().Segment( m_sName);

	if (!ReadChildren (context, EDISERVICECHAR_DATAELEMENTSEPARATOR))
	{
		generator.LeaveElement (context.GetParticle().GetTargetName());
		return true; // return true, since we nonetheless read the segment.
	}

	if ( context.GetParser().GetSettings().GetStandard() == EDIX12 )
	{
		if( m_sName == _T("SE") && ( context.GetParser().GetF717() == _T('A') || context.GetParser().GetF717() == _T('E') ) )
				context.GetParser().IncrementTransactionSetAccepted();
				
		if (m_sName == _T("ISA"))  // X12 ISA segment defines the segment terminator here
		{
			if (!scanner.ReadISASegmentEnd())
			{
				generator.LeaveElement (context.GetParticle().GetTargetName());
				return false;	// this is useless
			}

			CTextNode* isa = generator.GetCurrentNode();

			// Get component separator from FI15 child.
			CTextNode* fi15 = isa->GetChildren()->GetFirstNodeByName (_T("FI15"));
			if (fi15 && fi15->GetValue().length() != 0)
				scanner.separators.SetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR, fi15->GetValue()\[0\]);

			// Get repetition separator from FI65 child.
			CTextNode* fi65 = isa->GetChildren()->GetFirstNodeByName (_T("FI65"));
			if (fi65 && fi65->GetValue().length() != 0)
			{
				scanner.separators.SetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR, fi65->GetValue()\[0\]);
				// alphanumeric means something different
				if (_istalnum(scanner.separators.GetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR)))
					scanner.separators.SetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR, 0);
			}
		}
	}

	// expect segment terminator
	if (!scanner.IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR))
	{
		CEDIScannerState beforeRead = scanner;
		tstring sExtraContent = scanner.ForwardToSegmentTerminator ();
		if ( sExtraContent.length() > 0 )
			context.HandleError (
				CEDIParser::ExtraData,
				CEDIErrorPosition( beforeRead ),
				CEDIErrorMessages::GetExtraDataMessage( m_sName, sExtraContent ) 
			);

		if ( scanner.IsAtEnd() )
			context.HandleError (
				CEDIParser::UnexpectedEndOfFile,
				CEDIErrorPosition( beforeRead ),
				CEDIErrorMessages::GetUnexpectedEndOfFileMessage()
			);
	}

	scanner.RawConsumeChar();
	generator.LeaveElement (context.GetParticle().GetTargetName());
	return true;
}

void CEDISegment::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	// write out name and separator
	writer.Write (m_sName);
	writer.GetSemanticValidator().Segment( m_sName);

	// even this could be omitted according to spec:
	if (pNode)
		if( !(writer.GetStandard() == EDIHL7 && IsHL7SpecialSegment(pNode->GetName())))
			writer.AddSeparator (EDISERVICECHAR_SEGMENTSEPARATOR);

	WriteChildren (writer, pNode, EDISERVICECHAR_DATAELEMENTSEPARATOR);
	// now no superfluous separators are left, therefore write the segment terminator.
	writer.ClearPendingSeparators();
    writer.AddSeparator (EDISERVICECHAR_SEGMENTTERMINATOR);

	if (writer.IsNewlineAfterSegments())
		writer.Write (writer.GetLineEnd());
	else
		writer.Write (_T("")); // flushes out the segment terminator, so it won't be lost.
}

bool CEDIGroup::Read (const CEDIReadContext& context) const
{
	if (!IsAtGroup (context))
		return false;

	CGenerator& generator = context.GetGenerator();
	generator.EnterElement (context.GetParticle().GetTargetName(), m_NodeClass);

	if( m_sName == _T("Group") )
	{
		context.GetParser().ResetTransactionSetCount();
		context.GetParser().ResetTransactionSetAccepted();
	}

	if( m_sName == _T("Message") )
	{
		context.GetParser().SetCurrentMessageType( context.GetParser().GetFirstMessage().GetMessageType() );
	}

	if (!ReadChildren (context, EDISERVICECHAR_COUNT))
	{
		CTextNode* node = generator.GetCurrentNode();
		if( m_sName == _T("Message") )
		{
			context.GetParser().SetCurrentMessageType( _T("") );
		}
		generator.LeaveElement (context.GetParticle().GetTargetName());
		if( m_sName == _T("Batch") && node->GetChildren()->GetCount() == 0 )
		{
			generator.GetCurrentNode()->GetChildren()->RemoveAt(generator.GetCurrentNode()->GetChildren()->GetCount() - 1);
		}
		return false;
	}

	if( m_sName == _T("Message") )
	{
		context.GetParser().SetCurrentMessageType( _T("") );
	}
	generator.LeaveElement (context.GetParticle().GetTargetName());
	return true;
}

void CEDIGroup::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	WriteChildren (writer, pNode, EDISERVICECHAR_COUNT);
}

bool CEDIErrorList::Read (const CEDIReadContext& context) const
{
	CGenerator* pGen = context.GetParent()->GetGeneratorForErrors();
	if( m_sName == _T("ParserErrors_Group") )
	{
		pGen->EnterElement( _T("MF_AK9"), Group );
		
		if ( context.GetParser().GetF715() == _T('R') && context.GetParser().GetTransactionSetAccepted() > 0)
			pGen->InsertElement( _T("F715"), tstring() + _T('P'), DataElement );
		else
			pGen->InsertElement( _T("F715"), tstring() + context.GetParser().GetF715(), DataElement );

		//F97: Number of Transaction Sets Included
		tstringstream sTransactionCount;
		sTransactionCount << context.GetParser().GetTransactionSetCount();
		pGen->InsertElement( _T("F97"), sTransactionCount.str(), DataElement );
		//F123: Number of Received Transaction Sets
		pGen->InsertElement( _T("F123"), sTransactionCount.str(), DataElement );
		//F2: Number of Accepted Transaction Sets
		tstringstream sTransactionAccepted;
		sTransactionAccepted << context.GetParser().GetTransactionSetAccepted();
		pGen->InsertElement( _T("F2"), sTransactionAccepted.str(), DataElement );
		
		pGen->LeaveElement( _T("MF_AK9") );
	}
	else if( m_sName == _T("ParserErrors_Message") )
	{
		pGen->EnterElement( _T("MF_AK5"), Group );
		
		pGen->InsertElement( _T("F717"), tstring() + context.GetParser().GetF717(), DataElement );
		
		pGen->LeaveElement( _T("MF_AK5") );
	}

	CTextNode* errorNode = pGen->DetachRootNode();
	if( errorNode->GetChildren()->GetCount() > 0 )
	{
		context.GetGenerator().GetCurrentNode()->GetChildren()->Add( errorNode );
		const_cast<CEDIReadContext*>(context.GetParent())->CreateGeneratorForErrors( m_sName );
	}
	return true;
}

void CEDIErrorList::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
}

bool CEDISelect::Read (const CEDIReadContext& context) const
{
	CEDIScanner tmpScanner(
		context.GetScanner().GetStart(),
		context.GetScanner().GetLength(),
		context.GetScanner().separators,
		context.GetParser().GetSettings().GetStandard()
	);
	tmpScanner.Reset( context.GetScanner() );
	const CEDIParticle& selectChild = context.GetParticle().GetNode()->GetChildren()\[0\];
	CGenerator tmpGenerator;
	CEDISettings tmpSettings;
	CEDISemanticValidator tmpValidator(tmpSettings); // no validation

	CEDIReadContext preScanCtx( tmpScanner, context.GetParser(), selectChild, tmpGenerator, tmpValidator);
	
	//backup parseinfo
	CEDIParser::ParseInfo backupParseinfo = context.GetParser().GetParseInfo();
	if( selectChild.GetNode()->Read(preScanCtx) )
	{
		tstring sMessage;

		if( m_sField == _T("@HL7_old") )
		{
			sMessage = preScanCtx.GetGenerator().GetNodeValueByPath( _T("MSH/MSH-9/CM_MSG-1") );
			sMessage += _T("_") + preScanCtx.GetGenerator().GetNodeValueByPath( _T("MSH/MSH-9/CM_MSG-2") );
		}
		else if( m_sField == _T("@HL7") )
		{
			sMessage = preScanCtx.GetGenerator().GetNodeValueByPath( _T("MSH/MSH-9/MSG-1") );
			sMessage += _T("_") + preScanCtx.GetGenerator().GetNodeValueByPath( _T("MSH/MSH-9/MSG-2") );
		}
		else if( m_sField.find( _T('+') ) >= 0 )
		{
			for( tstring::size_type prev = 0, next = m_sField.find( _T('+') ); ; prev = next + 1, next = m_sField.find( _T('+'), prev ) )
			{
				if( !sMessage.empty() ) sMessage += _T("_");
				sMessage += preScanCtx.GetGenerator().GetNodeValueByPath( m_sField.substr( prev, next ) );
				if( next == string::npos )
					break;
			}
		}
		else
		{
			sMessage = preScanCtx.GetGenerator().GetNodeValueByPath(m_sField);
		}
		
		//restore parseinfo
    	context.GetParser().SetParseInfo( backupParseinfo );
    	if( !sMessage.empty() )
    	{
			std::vector<CMessage*> filtered;
			context.GetParser().FilterMessages( filtered, sMessage );
			for( std::vector<CMessage*>::const_iterator it = filtered.begin() ; it != filtered.end() ; ++it )
				if( (*it)->GetRootParticle().GetNode()->Read( CEDIReadContext( context, (*it)->GetRootParticle(), context.GetSemanticValidator() ) ) )
					return true;
		}

		if( context.GetParser().GetSettings().GetStandard() == EDITRADACOMS && sMessage == _T("RSGRSG") )
		{
			context.GetParser().SetParseInfo( backupParseinfo );
			return false; // this message is handled at interchange level
		}

			tstring sError = _T("Message type '");
  		sError += sMessage + _T("' unknown.");
  		throw CTextException (CAltovaException::eError1, sError);
	}

   	//restore parseinfo
   	context.GetParser().SetParseInfo( backupParseinfo );

	return false;
}

void CEDISelect::Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const
{
	bool anyMessageWritten = false;
	if ( pNode )
	{
		for(std::map<tstring,CMessage>::const_iterator it = writer.GetMessages().begin();
			it != writer.GetMessages().end();
			it++)
		{
			CTextNodeContainer children;
			const CMessage& msg = (*it).second;
			pNode->GetChildren()->FilterByName(m_sPrefix + msg.GetMessageType(), children);
			for( size_t i = 0; i < children.GetCount(); ++i)
			{
				writer.GetSemanticValidator().SetCurrentMessageType( msg.GetMessageType() );
				const CEDIParticle& p = msg.GetRootParticle();
				p.GetNode()->Write(writer, children.GetAt(i), p);
				anyMessageWritten = true;
			}
		}
	}
	if( !anyMessageWritten )
	{
		//report error/warning
		writer.HandleError(
			pNode,
			CEDIParser::MissingGroup,
			CEDIErrorMessages::GetMissingGroupMessage( _T("Message") )
		);
	}
}

tstring CEDIErrorMessages::GetMissingSegmentMessage(const tstring& sSegment)
{
	tstringstream msg;
	msg << _T("Missing segment '") << sSegment << _T("'.");
	return msg.str();
}

tstring CEDIErrorMessages::GetMissingGroupMessage(const tstring& sGroup)
{
	tstringstream msg;
	msg << _T("Missing group '") << sGroup << _T("'.");
	return msg.str();
}

tstring CEDIErrorMessages::GetMissingFieldOrCompositeMessage(const tstring& sField)
{
	tstringstream msg;
	msg << _T("Missing field or composite '") << sField << _T("'.");
	return msg.str();
}

tstring CEDIErrorMessages::GetExtraDataMessage(const tstring& sNodeName, const tstring& sExtra)
{
	tstringstream msg;
	msg << _T("Extra content detected in '") << sNodeName << _T("': '") << sExtra << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetInvalidFieldValueMessage(const tstring& sNodeName, const tstring& sValue, const tstring& sType)
{
	tstringstream msg;
	msg << _T("Type mismatch in field '") << sNodeName << _T("'. The value '") << sValue << _T("' is not of type '") << sType << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetInvalidDateMessage( const tstring& sNodeName, const tstring& sValue, const tstring& sType)
{
	return GetInvalidFieldValueMessage( sNodeName, sValue, sType);
}

tstring CEDIErrorMessages::GetInvalidTimeMessage( const tstring& sNodeName, const tstring& sValue, const tstring& sType)
{
	return GetInvalidFieldValueMessage( sNodeName, sValue, sType);
}

tstring CEDIErrorMessages::GetExtraRepeatMessage( const tstring& sNodeName)
{
	tstringstream msg;
	msg << _T("Extra repetition of '") << sNodeName << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetNumericOverflowMessage( const tstring& sNodeName, const tstring& sValue)
{
	tstringstream msg;
	msg << _T("Numeric overflow in field '") << sNodeName << _T("' with value: '") << sValue << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetDataElementTooShortMessage( const tstring& sNodeName, const size_t nMinLength, const tstring& sValue)
{
	tstringstream msg;
	msg << _T("The content of '") << sNodeName 
		<< _T("' is shorter than the minimum length of ") 
		<< nMinLength << _T(" characters: '") << sValue << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetDataElementTooLongMessage( const tstring& sNodeName, const size_t nMaxLength, const tstring& sValue)
{
	tstringstream msg;
	msg << _T("The content of '") << sNodeName 
		<< _T("' is longer than the maximum length of ") 
		<< nMaxLength << _T(" characters: '") << sValue << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetUnexpectedEndOfFileMessage( )
{
	return _T("Unexpected end of file");
}

tstring CEDIErrorMessages::GetInvalidCodeListValueMessage( const tstring& sValue, const tstring& sItemList)
{
	tstringstream msg;
	msg << _T("'") << sValue << _T("' is not a legal value. Legal values are: ") << sItemList << _T(".");
	return msg.str();
}

tstring CEDIErrorMessages::GetIncompleteCodeListValueMessage( const tstring& sValue, const tstring& sItemList)
{
	tstringstream msg;
	msg << _T("'") << sValue << _T("' is not in code list but code list is incomplete. Legal values are: ") << sItemList << _T(".");
	return msg.str();
}

tstring CEDIErrorMessages::GetUnexpectedSegmentIDMessage( const tstring& sSegment)
{
	tstringstream msg;
	msg << _T("Segment '") + sSegment + _T("' is unexpected.");
	return msg.str();
}

tstring CEDIErrorMessages::GetUnrecognizedSegmentMessage( const tstring& sSegment)
{
	tstringstream msg;
	msg << _T("Segment '") + sSegment + _T("' is unrecognized.");
	return msg.str();
}

tstring CEDIErrorMessages::GetTextNotParsedMessage( const tstring& sText)
{
	tstringstream msg;
	msg << _T("The following text was not parsed: '") << sText << _T("'");
	return msg.str();
}

tstring CEDIErrorMessages::GetNotUsedPresentMessage( const tstring& sText)
{
	tstringstream msg;
	msg << _T("Implementation \\"Not Used\\" data element present: '") << sText << _T("'");
	return msg.str();
}

const altova::text::edi::CEDIParticle* CEDIParticle::GetFirstChildByName( const tstring& name ) const
{
	for ( size_t i = 0; i < m_pTargetItem.GetChildCount(); i++ )
	{
		const CEDIParticle& childParticle = m_pTargetItem.GetChildren()\[i\];
		if ( childParticle.GetName() == name )
			return &childParticle;
	}
	return NULL;
}

} // namespace edi
} // namespace text
} // namespace altova
