[call GenerateFileHeader("Parser.h")]
#ifndef __ALTOVATEXT_PARSER_H
#define __ALTOVATEXT_PARSER_H

#include "EDISettings.h"
#include "DataTypeValidator.h"
#include "TextNode.h"
#include "Message.h"

namespace altova
{
namespace text
{
class CGenerator;
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CEDIParticle;
class CEDISemanticValidator;
class CEDIDataTypeValidator;
class CEDIReadContext;
class CEDIWriter;

class ALTOVATEXT_DECLSPECIFIER CEDIParser
{
public:
	CEDIParser();
	virtual ~CEDIParser();
	bool Parse (const CEDIParticle& rootParticle, const TCHAR* szBuffer, CGenerator& generator, CEDISettings& rSettings);

	bool m_bContinueOnError;

	CEDISettings& GetSettings() { return *m_pSettings; };
	
	class ParseInfo {
	public:
		//EDI error counters
		TCHAR m_F717;
		TCHAR m_F715;
		tstring m_sF447;
		unsigned long m_TransactionSetCount;
		unsigned long m_TransactionSetAccepted;
		unsigned long m_CurrentSegmentPos;
		unsigned long m_ComponentDataElementPos;
		unsigned long m_DataElementPos;
	};

	enum Actions
	{
		ActionUndefined = 0,
		ActionIgnore = 1,
		ActionReportAccept = 2,
		ActionReportReject = 3,
		ActionStop = 4
	};
	
	enum Errors
	{
		// react on no error
		Undefined = 0,

		// a mandatory segment is missing
		MissingSegment = 1,

		// a mandatory segment is missing
		MissingGroup = 2,

		// a mandatory field or composite is missing
		MissingFieldOrComposite = 3,

		// extra data is present on segment or composite
		ExtraData = 4,

		// a field value is invalid (like decimal/datetime format error)
		FieldValueInvalid = 5,
		
		// an invalid date value
		InvalidDate = 6,
		
		// an invalid time value
		InvalidTime = 7,

		// too many repetitions
		ExtraRepeat = 8,

		// number is too large for field
		NumericOverflow = 9,

		// a data elemnt is too short
		DataElementTooShort = 10,

		// a date element is too long
		DataElementTooLong = 11,
		
		// due to a missing final segment terminator
		UnexpectedEndOfFile = 12,

		// Field value doesn't match CodeList value
		CodeListValueWrong = 13,

		// Field value didn't pass semantic validation
		SemanticWrong = 14,
		
		// Segment is not exptected in this message.
		SegmentUnexpected = 15,
		
		// Segment not recognized in this EDI standard.
		SegmentUnrecognized = 16,

		// Implementation Not Used data element present
		NotUsedPresent = 17,
		
		// Not all data in the file was parsed
		NotAllDataParsed = 18,

		// react on all errors
		Count = 19,
	};
	
	void SetErrorSettings( const CEDIParser::Actions actions\[\]) 
	{
		for( int i = 0; i < CEDIParser::Count; ++i) m_ErrorSettings\[i\] = actions\[i\]; 
	}
	void SetErrorSetting( const CEDIParser::Errors error, const CEDIParser::Actions action)
	{
		m_ErrorSettings\[error\] = action;
	}
	
	TCHAR GetF717() { return m_ParseInfo.m_F717; }
	void SetF717(const TCHAR f717) { m_ParseInfo.m_F717 = f717; }
	
	TCHAR GetF715() { return m_ParseInfo.m_F715; }
	void SetF715(const TCHAR f715) { m_ParseInfo.m_F715 = f715; }
	
	tstring GetF447() { return m_ParseInfo.m_sF447; }
	void SetF447(const tstring f447) { m_ParseInfo.m_sF447 = f447; }
	
	unsigned long GetTransactionSetCount() { return m_ParseInfo.m_TransactionSetCount; }
	void IncrementTransactionSetCount() { m_ParseInfo.m_TransactionSetCount++; }
	void ResetTransactionSetCount() { m_ParseInfo.m_TransactionSetCount = 0; }
	
	unsigned long GetTransactionSetAccepted() { return m_ParseInfo.m_TransactionSetAccepted; }
	void IncrementTransactionSetAccepted() { m_ParseInfo.m_TransactionSetAccepted++; }
	void ResetTransactionSetAccepted() { m_ParseInfo.m_TransactionSetAccepted = 0; }
	
	unsigned long GetCurrentSegmentPosition() { return m_ParseInfo.m_CurrentSegmentPos; }
	void IncrementCurrentSegmentPosition() { m_ParseInfo.m_CurrentSegmentPos++; }
	void ResetCurrentSegmentPosition() { m_ParseInfo.m_CurrentSegmentPos = 1; }
	
	unsigned long GetComponentDataElementPosition() { return m_ParseInfo.m_ComponentDataElementPos; }
	void IncrementComponentDataElementPosition() { m_ParseInfo.m_ComponentDataElementPos++; }
	void ResetComponentDataElementPosition() { m_ParseInfo.m_ComponentDataElementPos = 0; }
	
	unsigned long GetDataElementPosition() { return m_ParseInfo.m_DataElementPos; }
	void IncrementDataElementPosition() { m_ParseInfo.m_DataElementPos++; }
	void ResetDataElementPosition() { m_ParseInfo.m_DataElementPos = 0; }

	const ParseInfo& GetParseInfo() const { return m_ParseInfo; }
	void SetParseInfo(const ParseInfo& parseInfo) { m_ParseInfo = parseInfo; }
	
	Actions GetErrorAction( Errors error) { return m_ErrorSettings\[error\]; }

	const tstring& GetCurrentMessageType() const { return m_sCurrentMessageType; }
	void SetCurrentMessageType( const tstring& sCurrentMessageType) { m_sCurrentMessageType = sCurrentMessageType; }
	
	//Message map accessors
	bool HasMessage(const tstring& sMessage) const { return m_mapMessages.find(sMessage) != m_mapMessages.end(); }
	const CMessage& GetMessage(const tstring& sMessage) const { return m_mapMessages.find(sMessage)->second; }
	const std::map<tstring,CMessage>& GetMessages() const { return m_mapMessages; }
	const CMessage GetFirstMessage() const { return m_mapMessages.begin()->second; }
	void FilterMessages(std::vector<CMessage*>& filteredMessages, const tstring& sNameStartsWith);

public:
	// used pointers because std::set doesn't have an assign method
	// and can only initialized by constructor
	std::set<tstring> * StandardSegments;
	
protected:
	CEDISettings* m_pSettings;
	Actions m_ErrorSettings\[Count\];
	std::map<tstring,CMessage> m_mapMessages;
	tstring m_sCurrentMessageType;
	ParseInfo m_ParseInfo;

private:
	CEDIServiceChars m_ServiceChars;
};

class ALTOVATEXT_DECLSPECIFIER CEDIStructureItem
{
public:
	virtual bool Read (const CEDIReadContext& context) const = 0;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const = 0;

	const tstring& GetName () const { return m_sName; }
	const CEDIParticle* GetChildren () const { return m_pChildren; }
	size_t GetChildCount () const { return m_nChildCount; }

	ENodeClass GetNodeClass() const { return m_NodeClass; }

	const tstring& GetConditionPath() const { return m_sConditionPath; }
	const tstring& GetConditionValue() const { return m_sConditionValue; }

protected:
	CEDIStructureItem (const TCHAR* sName, ENodeClass nodeClass)
		: m_sName (sName), m_pChildren (0), m_nChildCount (0), m_NodeClass (nodeClass)
	{ }

	CEDIStructureItem (const TCHAR* sName, ENodeClass nodeClass, const CEDIParticle* pChildren, size_t nChildCount)
		: m_sName (sName), m_pChildren (pChildren), m_nChildCount (nChildCount), m_NodeClass (nodeClass)
	{ }

	CEDIStructureItem (const TCHAR* sName, ENodeClass nodeClass, const tstring& sConditionPath, const tstring& sConditionValue, const CEDIParticle* pChildren, size_t nChildCount) :
		m_sName (sName), m_pChildren (pChildren), m_nChildCount (nChildCount), m_NodeClass (nodeClass),
		m_sConditionPath( sConditionPath ), m_sConditionValue( sConditionValue )
	{ }

	tstring m_sName;
	ENodeClass m_NodeClass;
	const CEDIParticle* m_pChildren;
	size_t m_nChildCount;
	tstring m_sConditionPath;
	tstring m_sConditionValue;

	bool IsRepeatingSequenceStarting(size_t a) const;
	bool ParticlesEquivalent(size_t a, size_t b) const;
	void HandleMissingSegmentOrGroup(CEDIReadContext& context, const CEDIParticle* currentParticle) const;
	bool ReadChildren (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const;
	bool ReadChildrenOfGroup (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const;
	bool ReadChildrenOfSegment (const CEDIReadContext& context, EDISERVICECHAR_TYPE  cSeparator) const;
	
	bool IsAtGroup (const CEDIReadContext& context) const;
	tstring ReadSegmentTag (const CEDIReadContext& context) const;
	bool IsSegmentStarting (const CEDIReadContext& context) const;
	bool CheckSegmentCondition(const CEDIReadContext& context) const;
	bool CheckConditionValue(const CEDIReadContext& ctx, const tstring& conditionPath, const tstring& conditionValue) const;
	bool IsHL7SpecialSegment( const tstring& sSegmentName ) const;
	bool IsHL7SpecialField( const tstring& sFieldName, const tstring& sFieldIndex) const;

	void WriteChildren (CEDIWriter& writer, CTextNode* pNode, EDISERVICECHAR_TYPE separator) const;

};

class ALTOVATEXT_DECLSPECIFIER CEDIDataElementBase : public CEDIStructureItem
{
public:
	CEDIDataElementBase (const TCHAR* sName)
		: CEDIStructureItem (sName, DataElement)
	{ }

};

class ALTOVATEXT_DECLSPECIFIER CEDIDataElement : public CEDIDataElementBase
{
public:
	CEDIDataElement (const TCHAR* sName, const CEDIDataTypeValidator* validator)
		: CEDIDataElementBase (sName), m_Validator(validator)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;

private:
	const CEDIDataTypeValidator* m_Validator;
	static bool IsSpecialChar (const CEDIServiceChars& serviceChars, TCHAR ch);
	bool EmbeddedCodeListValidate(const tstring& value, const CEDIParticle& particle) const;
	tstring EmbeddedCodeListValueList(const CEDIParticle& particle) const;
};


class ALTOVATEXT_DECLSPECIFIER CEDISingleCharElement : public CEDIDataElementBase
{
public:
	CEDISingleCharElement (const TCHAR* sName)
		: CEDIDataElementBase (sName)
	{ }
	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;
};


class ALTOVATEXT_DECLSPECIFIER CEDIComposite : public CEDIStructureItem
{
public:
	CEDIComposite (const TCHAR* sName, const CEDIParticle* pChildren, size_t nChildCount)
		: CEDIStructureItem (sName, Composite, pChildren, nChildCount)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;
};

class ALTOVATEXT_DECLSPECIFIER CEDISubComposite : public CEDIStructureItem
{
public:
	CEDISubComposite (const TCHAR* sName, const CEDIParticle* pChildren, size_t nChildCount)
		: CEDIStructureItem (sName, Composite, pChildren, nChildCount)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;
};

class ALTOVATEXT_DECLSPECIFIER CEDISegment : public CEDIStructureItem
{
public:
	CEDISegment (const TCHAR* sName, const tstring& sConditionPath, const tstring& sConditionValue, const CEDIParticle* pChildren, size_t nChildCount)
		: CEDIStructureItem (sName, Segment, sConditionPath, sConditionValue, pChildren, nChildCount)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;
};

class ALTOVATEXT_DECLSPECIFIER CEDIGroup : public CEDIStructureItem
{
public:
	CEDIGroup (const TCHAR* sName, const tstring& sConditionPath, const tstring& sConditionValue, const CEDIParticle* pChildren, size_t nChildCount)
		: CEDIStructureItem (sName, Group, sConditionPath, sConditionValue, pChildren, nChildCount)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;

};

class ALTOVATEXT_DECLSPECIFIER CEDIErrorList : public CEDIStructureItem
{
public:
	CEDIErrorList (const TCHAR* sName, const CEDIParticle* pChildren, size_t nChildCount)
		: CEDIStructureItem (sName, ErrorList, pChildren, nChildCount)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;

};

class ALTOVATEXT_DECLSPECIFIER CEDISelect : public CEDIStructureItem
{
public:
	CEDISelect (
		const TCHAR* sName,
		const tstring& sPrefix,
		const tstring& sField,
		const tstring& sType,
		const CEDIParticle* pChildren,
		size_t nChildCount)
		: CEDIStructureItem (sName, Select, pChildren, nChildCount)
		, m_sField(sField)
		, m_sPrefix(sPrefix)
		, m_sType(sType)
	{ }

	virtual bool Read (const CEDIReadContext& context) const;
	virtual void Write (CEDIWriter& writer, CTextNode* pNode, const CEDIParticle& particle) const;

protected:
	const tstring m_sField;
	const tstring m_sPrefix;
	const tstring m_sType;
};


class ALTOVATEXT_DECLSPECIFIER CEDIParticle
{
public:
	CEDIParticle (const TCHAR* sNameOverride, const CEDIStructureItem& pTargetItem, size_t nMinOccurs, size_t nMaxOccurs, size_t nMergedEntries, bool respectMaxOccurs) :
		m_pTargetItem (pTargetItem), m_nMinOccurs (nMinOccurs), m_nMaxOccurs (nMaxOccurs), m_nMergedEntries (nMergedEntries),
		m_sNameOverride(sNameOverride != NULL ? sNameOverride : _T("")), m_bRespectMaxOccurs(respectMaxOccurs), mBoundedGroup(false)
	{
	}

	CEDIParticle (const TCHAR* sNameOverride, const CEDIStructureItem& pTargetItem, size_t nMinOccurs, size_t nMaxOccurs, size_t nMergedEntries, bool respectMaxOccurs, const std::vector<tstring>& codeValues) :
		m_pTargetItem (pTargetItem), m_nMinOccurs (nMinOccurs), m_nMaxOccurs (nMaxOccurs), m_nMergedEntries (nMergedEntries),
		m_sNameOverride(sNameOverride != NULL ? sNameOverride : _T("")), m_bRespectMaxOccurs(respectMaxOccurs),
		m_CodeValues(codeValues), mBoundedGroup(false)
	{
	}

	size_t GetMinOccurs () const { return m_nMinOccurs; }
	size_t GetMaxOccurs () const { return m_nMaxOccurs; }
	size_t GetMergedEntries () const { return m_nMergedEntries; }
	bool GetRespectMaxOccurs() const { return m_bRespectMaxOccurs; }
	const CEDIStructureItem* GetNode () const { return &m_pTargetItem; }
	const tstring& GetNameOverride () const { return m_sNameOverride; }
	const tstring& GetTargetName () const { return m_sNameOverride;	}
	const tstring& GetName () const { return !m_sNameOverride.empty() ? m_sNameOverride : m_pTargetItem.GetName(); }
	const std::vector<tstring>& GetCodeValues() const { return m_CodeValues; }
	const CEDIParticle* GetFirstChildByName( const tstring& name ) const;

private:
	tstring m_sNameOverride;
	const CEDIStructureItem& m_pTargetItem;
	size_t m_nMinOccurs;
	size_t m_nMaxOccurs;
	size_t m_nMergedEntries;
	bool   m_bRespectMaxOccurs;
	std::vector<tstring>	m_CodeValues;

public:
	mutable bool mBoundedGroup;
};

class ALTOVATEXT_DECLSPECIFIER CEDIErrorMessages
{
public:
	static tstring GetMissingSegmentMessage(const tstring& sSegment);
	static tstring GetMissingGroupMessage(const tstring& sGroup);
	static tstring GetMissingFieldOrCompositeMessage(const tstring& sField);
	static tstring GetExtraDataMessage(const tstring& sNodeName, const tstring& sExtra);
	static tstring GetInvalidFieldValueMessage(const tstring& sNodeName, const tstring& sValue, const tstring& sType);
	static tstring GetInvalidDateMessage( const tstring& sNodeName, const tstring& sValue, const tstring& sType);
	static tstring GetInvalidTimeMessage( const tstring& sNodeName, const tstring& sValue, const tstring& sType);
	static tstring GetExtraRepeatMessage( const tstring& sNodeName);
	static tstring GetNumericOverflowMessage( const tstring& sNodeName, const tstring& sValue);
	static tstring GetDataElementTooShortMessage( const tstring& sNodeName, const size_t nMinLength, const tstring& sValue);
	static tstring GetDataElementTooLongMessage( const tstring& sNodeName, const size_t nMaxLength, const tstring& sValue);
	static tstring GetUnexpectedEndOfFileMessage( );
	static tstring GetInvalidCodeListValueMessage( const tstring& sValue, const tstring& sItemList);
	static tstring GetIncompleteCodeListValueMessage( const tstring& sValue, const tstring& sItemList);
	static tstring GetUnexpectedSegmentIDMessage( const tstring& sSegment);
	static tstring GetUnrecognizedSegmentMessage( const tstring& sSegment);
	static tstring CEDIErrorMessages::GetTextNotParsedMessage( const tstring& sText);
	static tstring GetNotUsedPresentMessage( const tstring& sText);
};

}
}
}


#endif
