[call GenerateFileHeader("Scanner.cpp")]
#include "StdAfx.h"
#include "Scanner.h"
#include "EDIHL7Settings.h"


namespace altova
{
namespace text
{
namespace edi
{

bool CEDIScanner::MoveNextSignificantChar()
{
	while ( !IsAtEnd() )
	{
		if ( !IsIgnorableWhitespace() )
			return true;
		RawConsumeChar();
	}
	return false;
}

void CEDIScanner::SkipWhitespace()
{
	while (!IsAtEnd() && _istspace(GetCurrentChar()) && !IsAtAnySeparator())
		RawConsumeChar();
}

EDISERVICECHAR_TYPE CEDIScanner::GetSeparatorType() const
{
	EDISERVICECHAR_TYPE separatorType = EDISERVICECHAR_COUNT;
	for (int i = 0; i < EDISERVICECHAR_COUNT; ++i) 
	{
		if (IsAtSeparator((EDISERVICECHAR_TYPE)i))
			separatorType = (EDISERVICECHAR_TYPE)i;
	}
	return separatorType;
}

tstring CEDIScanner::ConsumeString(EDISERVICECHAR_TYPE stopAtSeparator, bool wantResult)
{
	tstring sResult;
	static int separatorPrecedence\[\] = 
	{
		0,	// EDISERVICECHAR_COMPONENTSEPARATOR = 0,
		2,	// EDISERVICECHAR_DATAELEMENTSEPARATOR = 1,
		-1,	// EDISERVICECHAR_DECIMALMARK = 2,
		-1,	// EDISERVICECHAR_RELEASECHARACTER = 3,
		1,	// EDISERVICECHAR_REPETITIONSEPARATOR = 4,
		4,	// EDISERVICECHAR_SEGMENTTERMINATOR = 5,
        3,  // EDISERVICECHAR_SUBCOMPONENTSEPARATOR = 6,
		2,  // EDISERVICECHAR_SEGMENTSEPARATOR = 7,
		-1,	// EDISERVICECHAR_COUNT, not valid
	};

	int stopSeparatorPrecedence = separatorPrecedence\[stopAtSeparator\];

	while (MoveNextSignificantChar())
	{
		bool bCharProcessed = false;
		EDISERVICECHAR_TYPE separatorType = GetSeparatorType();

		if (separatorType == EDISERVICECHAR_RELEASECHARACTER)
		{
			if( m_EDIStandard == EDIHL7 )
			{
				if( GetHL7SeparatorByEscapeIdentifier(GetNextChar()) != 0 )
				{
					RawConsumeChar(); //consume escape character
					if (wantResult)
						sResult.append ((tstring::size_type)1, GetHL7SeparatorByEscapeIdentifier(RawConsumeChar()));
					else
						RawConsumeChar();
					if( GetSeparatorType() == EDISERVICECHAR_RELEASECHARACTER )
					{
						RawConsumeChar();
						bCharProcessed = true;
					}
					//else
					//error invalid escape sequence
				}
				else if( GetNextChar() == CEDIHL7Settings::cEscStartHighlight
					|| GetNextChar() == CEDIHL7Settings::cEscNormalText
					|| GetNextChar() == CEDIHL7Settings::cEscHexadecimalData
					|| GetNextChar() == CEDIHL7Settings::cEscLocalEscapeSeq)
				{
					//leave at it is
				}
				else
				{
					//error unsupported escape sequence
				}
			}
			else
			{
				RawConsumeChar();
			}
			if (!MoveNextSignificantChar())
				break;
		}
		else
		{
			int foundPrecedence = separatorPrecedence\[separatorType\];
			if (foundPrecedence >= stopSeparatorPrecedence)
				break;
		}

		if( !bCharProcessed )
		{
			if (wantResult)
				sResult.append ((tstring::size_type)1, RawConsumeChar());
			else
				RawConsumeChar();
		}
	}
	return sResult;
}

bool CEDIScanner::ReadUNA()
{
	separators.SetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR, RawConsumeChar());
	separators.SetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR, RawConsumeChar());
	separators.SetServiceChar(EDISERVICECHAR_SEGMENTSEPARATOR, separators.GetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR));
	separators.SetServiceChar(EDISERVICECHAR_DECIMALMARK, RawConsumeChar());
	separators.SetServiceChar(EDISERVICECHAR_RELEASECHARACTER, RawConsumeChar());
	separators.SetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR, RawConsumeChar());
	separators.SetServiceChar(EDISERVICECHAR_SEGMENTTERMINATOR, RawConsumeChar());

	// space means no release character at all
	if (separators.GetServiceChar(EDISERVICECHAR_RELEASECHARACTER) == _T(' '))
		separators.SetServiceChar(EDISERVICECHAR_RELEASECHARACTER, 0);

	// space means an old syntax without repeating elements is in use
	if (separators.GetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR) == _T(' '))
		separators.SetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR, 0);

	separators.SetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR, 0);
	return true;
}

bool CEDIScanner::ReadISASegmentStart()
{
	separators.SetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR, GetCurrentChar());
	separators.SetServiceChar(EDISERVICECHAR_SEGMENTSEPARATOR, separators.GetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR));
	separators.SetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR, 0);
	separators.SetServiceChar(EDISERVICECHAR_DECIMALMARK, _T('.'));
	separators.SetServiceChar(EDISERVICECHAR_RELEASECHARACTER, 0);
	separators.SetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR, 0);
	separators.SetServiceChar(EDISERVICECHAR_SEGMENTTERMINATOR, 0);
	separators.SetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR, 0);
	return true;
}

bool CEDIScanner::ReadISASegmentEnd()
{
	separators.SetServiceChar(EDISERVICECHAR_SEGMENTTERMINATOR, GetCurrentChar());
	return true;
}

tstring CEDIScanner::ForwardToSegmentTerminator ()
{
	return ConsumeString(EDISERVICECHAR_SEGMENTTERMINATOR, true);
}

TCHAR CEDIScanner::GetHL7SeparatorByEscapeIdentifier(const TCHAR ident) const
{
	if( CEDIHL7Settings::cEscFieldSeparator == ident )
		return separators.GetServiceChar(EDISERVICECHAR_DATAELEMENTSEPARATOR);
	else if( CEDIHL7Settings::cEscComponentSeparator == ident )
		return separators.GetServiceChar(EDISERVICECHAR_COMPONENTSEPARATOR);
	else if( CEDIHL7Settings::cEscSubComponentSeparator == ident )
		return separators.GetServiceChar(EDISERVICECHAR_SUBCOMPONENTSEPARATOR);
	else if( CEDIHL7Settings::cEscRepetitionSeparator == ident )
		return separators.GetServiceChar(EDISERVICECHAR_REPETITIONSEPARATOR);
	else if( CEDIHL7Settings::cEscEscapeSeparator == ident )
		return separators.GetServiceChar(EDISERVICECHAR_RELEASECHARACTER);
	else
		return 0;
}

} // namespace edi
} // namespace text
} // namespace altova
