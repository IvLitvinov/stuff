[call GenerateFileHeader("Scanner.h")]
#ifndef __ALTOVATEXT_SCANNER_H
#define __ALTOVATEXT_SCANNER_H

#include "AltovaTextAPI.h"
#include "EDISettings.h"

namespace altova
{
namespace text
{
namespace edi
{
class ALTOVATEXT_DECLSPECIFIER CEDIScannerState
{
public:
	CEDIScannerState () 
		: m_pCurrent(0), m_pLineStart(0), m_nLine(0), m_pStart(0)
	{}

	// uses default copy constructor and assignment operator

	bool operator==(const CEDIScannerState& other) const { return m_pCurrent == other.m_pCurrent; }
	bool operator!=(const CEDIScannerState& other) const { return m_pCurrent != other.m_pCurrent; }
	
	size_t GetPosition() const { return m_pCurrent - m_pStart; }
	size_t GetLine() const { return m_nLine + 1; }
	size_t GetColumn() const { return m_pCurrent - m_pLineStart + 1; }

	const TCHAR* GetStart() const { return m_pStart; }
protected:
	const TCHAR* m_pStart;
	const TCHAR* m_pCurrent;
	const TCHAR* m_pLineStart;
	size_t m_nLine;

	CEDIScannerState (const TCHAR* pStart) : m_pCurrent(pStart), m_pLineStart(pStart), m_pStart(pStart), m_nLine(0) { }
};



class ALTOVATEXT_DECLSPECIFIER CEDIScanner : public CEDIScannerState
{
	CEDIScanner (const CEDIScanner &other) : separators(other.separators), m_nLength( other.m_nLength ), m_EDIStandard(other.m_EDIStandard) {}
public:
	CEDIScanner (const TCHAR* pStart, size_t nLength, CEDIServiceChars& separators, EDIStandard ediStandard)
		: CEDIScannerState(pStart), separators(separators), 
		m_pEnd(pStart + nLength), m_nLength( nLength ), m_EDIStandard(ediStandard)
	{}

	void Reset (const CEDIScannerState& savedState) 
	{
		CEDIScannerState::operator= (savedState);
	}

	TCHAR GetCurrentChar() const { return *m_pCurrent; }
	TCHAR GetNextChar() const
	{
		if( (m_pCurrent+1) < m_pEnd && *(m_pCurrent+1) != 0)
			return *(m_pCurrent+1);
		else
			return 0;
	}
	bool IsAtEnd() const { return m_pCurrent >= m_pEnd || *m_pCurrent == 0; }
	bool IsAtSeparator(EDISERVICECHAR_TYPE sep) const { return GetCurrentChar() == separators.GetServiceChar(sep); }
	bool IsAtAnySeparator() const {
		return
			IsAtSeparator(EDISERVICECHAR_COMPONENTSEPARATOR) ||
			IsAtSeparator(EDISERVICECHAR_DATAELEMENTSEPARATOR) ||
			IsAtSeparator(EDISERVICECHAR_REPETITIONSEPARATOR) ||
			IsAtSeparator(EDISERVICECHAR_SEGMENTSEPARATOR) ||
			IsAtSeparator(EDISERVICECHAR_SEGMENTTERMINATOR) ||
            IsAtSeparator(EDISERVICECHAR_SUBCOMPONENTSEPARATOR);
	}

	TCHAR RawConsumeChar() 
	{ // this is the only function that should increment m_pCurrent
		if (IsAtEnd()) return 0;
		if (GetCurrentChar() == '\\n' || ( GetCurrentChar() == '\\r' && GetNextChar() != '\\n' ) )
		{
			++m_nLine;
			m_pLineStart = m_pCurrent + 1;
		}
		return *m_pCurrent++;
	}

	bool IsIgnorableWhitespace() const
	{
		TCHAR c = GetCurrentChar();
		return (c == '\\t' || c == '\\r' || c == '\\n' ) && !IsAtAnySeparator();
	}

	bool MoveNextSignificantChar();
	void SkipWhitespace();
	EDISERVICECHAR_TYPE GetSeparatorType() const;

	tstring ConsumeString(EDISERVICECHAR_TYPE stopAtSeparator, bool wantResult);

	bool ReadUNA();
	bool ReadISASegmentStart();
	bool ReadISASegmentEnd();

	tstring ForwardToSegmentTerminator ();
	TCHAR GetHL7SeparatorByEscapeIdentifier(const TCHAR ident) const;

	const size_t GetLength() const { return m_nLength; }

	CEDIServiceChars& separators;
private:
	const TCHAR* m_pEnd;
	const size_t m_nLength;
	const EDIStandard m_EDIStandard;
};

} // namespace edi
} // namespace text
} // namespace altova

#endif
