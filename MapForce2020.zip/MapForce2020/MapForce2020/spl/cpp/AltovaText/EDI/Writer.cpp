[call GenerateFileHeader("Writer.cpp")]
#include "StdAfx.h"

#include "Writer.h"
#include "EDISemanticValidator.h"
#include "EDIFactSettings.h"
#include "EDIScriptSettings.h"
#include "TextException.h"

namespace altova
{
namespace text
{
namespace edi
{

CEDIWriter::CEDIWriter (
						tostream& out,
						const std::map<tstring,CMessage>& mapMessages,
						const CEDISettings& settings,
						CEDISemanticValidator& validator,
						const CEDIParser::Actions errorSettings\[\],
						int lineend)
						:	m_Out(out)
						,	m_Settings(settings)
						,	m_rValidator( validator)
						,	m_nLine(0)
						,	m_nLineStart(0)
						,	m_nLineEnd(lineend)
						,	m_mapMessages(mapMessages)
{
	m_rValidator.SetCurrentMessageType( (*m_mapMessages.begin()).second.GetMessageType() );
	for( int i = 0; i < CEDIParser::Count; ++i) m_ErrorSettings\[i\] = errorSettings\[i\];

	if (EDIFact==GetStandard())
	{
		if (((const CEDIFactSettings&) settings).GetWriteUNA())
		{
			CEDIServiceChars serviceChars = settings.GetServiceChars();
			out << _T("UNA");
			tstring sUNAServiceChars;
			sUNAServiceChars += serviceChars.GetComponentDataElementSeparator();
			sUNAServiceChars += serviceChars.GetDataElementSeparator();
			sUNAServiceChars += serviceChars.GetDecimalNotation();
			if( serviceChars.GetReleaseIndicator() != _T('\\0') )
				sUNAServiceChars += serviceChars.GetReleaseIndicator();
			else
				sUNAServiceChars += _T(' ');

			if( serviceChars.GetRepetitionSeparator() != _T('\\0') )
				sUNAServiceChars += serviceChars.GetRepetitionSeparator();
			else
				sUNAServiceChars += _T(' ');

			sUNAServiceChars += serviceChars.GetSegmentTerminator();
			out << sUNAServiceChars;
			if (settings.GetTerminateSegmentsWithLinefeed())
				Write( GetLineEnd() );
		}
	}
	else if (EDISCRIPT==GetStandard())
	{
		if (((const CEDIScriptSettings&) settings).GetWriteUNA())
		{
			CEDIServiceChars serviceChars = settings.GetServiceChars();
			out << _T("UNA");
			tstring sUNAServiceChars;
			sUNAServiceChars += serviceChars.GetComponentDataElementSeparator();
			sUNAServiceChars += serviceChars.GetDataElementSeparator();
			sUNAServiceChars += serviceChars.GetDecimalNotation();
			if( serviceChars.GetReleaseIndicator() != _T('\\0') )
				sUNAServiceChars += serviceChars.GetReleaseIndicator();
			else
				sUNAServiceChars += _T(' ');

			if( serviceChars.GetRepetitionSeparator() != _T('\\0') )
				sUNAServiceChars += serviceChars.GetRepetitionSeparator();
			else
				sUNAServiceChars += _T(' ');

			sUNAServiceChars += serviceChars.GetSegmentTerminator();
			out << sUNAServiceChars;
			if (settings.GetTerminateSegmentsWithLinefeed())
				Write( GetLineEnd() );
		}
	}
}

void CEDIWriter::HandleError (const CTextNode* pNode, const CEDIParser::Errors error, const tstring message) const
{
	tstring location = pNode ? pNode->GetName() : _T("");
	CTextNode* parent = pNode ? pNode->GetParent() : 0;
	while (parent && parent->GetParent())
	{
		location = parent->GetName() + _T(" / ") + location;
		parent = parent->GetParent();
	}
	location += _T(": ") + message;

	tstringstream streamLocation;
	streamLocation << _T("Line ") << GetLine() << _T(" column ") << GetColumn() << _T(" (offset 0x");
	streamLocation.flags( std::ios::hex );
	streamLocation << GetPosition() << _T("): ");
	location = streamLocation.str() + location;

	switch ( m_ErrorSettings\[error\] )
	{
	case CEDIParser::ActionStop:
		{
			throw CTextException (CAltovaException::eError1, location);
		}
	case CEDIParser::ActionReportReject:
	case CEDIParser::ActionReportAccept:
		{
			tcerr << location.c_str() << endl;
		}
		break;
	}
}

void CEDIWriter::HandleWarning (const CTextNode* pNode, const tstring message) const
{
	tstring location = pNode ? pNode->GetName() : _T("");
	CTextNode* parent = pNode ? pNode->GetParent() : 0;
	while (parent && parent->GetParent())
	{
		location = parent->GetName() + _T(" / ") + location;
		parent = parent->GetParent();
	}
	location += _T(": Warning: ") + message;

	tstringstream streamLocation;
	streamLocation << _T("Line ") << GetLine() << _T(" column ") << GetColumn() << _T(" (offset 0x");
	streamLocation.flags( std::ios::hex );
	streamLocation << GetPosition() << _T("): ");
	location = streamLocation.str() + location;

	tcerr << location.c_str() << endl;
}

tstring CEDIWriter::GetLineEnd() const
{
	switch(m_nLineEnd)
	{
		case 0:
#ifdef _WIN32
			return _T("\\r\\n");
#elif defined macintosh
			return _T("\\r");
#else
			return _T("\\n");
#endif
		case 1: return _T("\\r\\n");
		case 2: return _T("\\n");
		case 3: return _T("\\r");
		default: return _T("\\r\\n");
	}
	return _T("\\r\\n");
}

} // namespace edi
} // namespace text
} // namespace altova
