[call GenerateFileHeader("Writer.h")]
#ifndef __ALTOVATEXT_WRITER_H
#define __ALTOVATEXT_WRITER_H

#include "Parser.h"

namespace altova
{
namespace text
{
namespace edi
{

class ALTOVATEXT_DECLSPECIFIER CMessage;
class CEDISettings;
class CEDISemanticValidator;

class CEDIWriter
{
public:
	CEDIWriter (
		tostream& out,
		const std::map<tstring,CMessage>& mapMessages,
		const CEDISettings& settings,
		CEDISemanticValidator& validator,
		const CEDIParser::Actions errorSettings\[\],
		int lineend);

	void Write (const tstring& text)
	{
		m_Out << m_sPendingSeparators << text;
		ChecknewLines( m_sPendingSeparators + text);
		m_sPendingSeparators.erase();
	}

	void AddSeparator (EDISERVICECHAR_TYPE separator)
	{
		if (separator != EDISERVICECHAR_COUNT && m_Settings.GetServiceChars().GetServiceChar(separator) != 0)
			m_sPendingSeparators.append (1, m_Settings.GetServiceChars().GetServiceChar(separator));
	}

	void ClearPendingSeparators (EDISERVICECHAR_TYPE separator)
	{
		if (separator == EDISERVICECHAR_COUNT)
			return;

		tstring::size_type valid = m_sPendingSeparators.find_last_not_of (m_Settings.GetServiceChars().GetServiceChar(separator));
		if (valid == tstring::npos)
			m_sPendingSeparators.erase ();
		else
			m_sPendingSeparators.erase (valid + 1);
	}

	void ClearPendingSeparators ()
	{
		m_sPendingSeparators.clear();
	}

	EDIStandard GetStandard() { return m_Settings.GetStandard(); };

	bool IsNewlineAfterSegments () const { return m_bNewlineAfterSegments; }
	void SetNewlineAfterSegments (bool bValue) { m_bNewlineAfterSegments = bValue; }

	const CEDIServiceChars& GetServiceChars() const { return m_Settings.GetServiceChars(); }
	CEDISemanticValidator& GetSemanticValidator () const { return m_rValidator; }

	void HandleError (const CTextNode* pNode, const CEDIParser::Errors error, const tstring message) const;
	void HandleWarning (const CTextNode* pNode, const tstring message) const;

	size_t GetLine() const { return m_nLine + 1; }
	size_t GetColumn() const { return static_cast<size_t>(m_Out.tellp()) + m_sPendingSeparators.length() - m_nLineStart + 1; }
	size_t GetPosition() const { return static_cast<size_t>(m_Out.tellp()) + m_sPendingSeparators.length(); }
	tstring GetLineEnd() const;

	const std::map<tstring,CMessage>& GetMessages() const { return m_mapMessages; }

private:
	void ChecknewLines( const tstring& s)
	{
		for( size_t i = 0; i < s.length(); ++i)
		{
			TCHAR chNext = i + 1 < s.length() ? s\[i+1\] : 0;
			if( s\[i\] == '\\n' || (s\[i\] == '\\r' && chNext != '\\n'))
			{
				m_nLine++;
				m_nLineStart = static_cast<size_t>(m_Out.tellp());
			}
		}
	}

private:
	tostream& m_Out;
	const CEDISettings& m_Settings;
	tstring m_sPendingSeparators;
	bool m_bNewlineAfterSegments;
	CEDISemanticValidator& m_rValidator;
	CEDIParser::Actions m_ErrorSettings\[CEDIParser::Count\];
	const std::map<tstring,CMessage>& m_mapMessages;

	size_t m_nLine;
	size_t m_nLineStart;
	int m_nLineEnd;
};

}
}
}

#endif
