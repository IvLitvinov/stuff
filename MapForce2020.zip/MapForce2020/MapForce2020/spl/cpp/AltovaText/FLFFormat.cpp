[call GenerateFileHeader("FLFFormat.cpp")]
#include "stdafx.h"
#include "FLFFormat.h"

namespace altova
{
namespace text
{
namespace tablelike
{
namespace flf
{

CFormat::CFormat()
:	m_AssumeRecordDelimiters(false)
,	m_FillCharacter(_T(' '))
,	m_RemoveEmpty(true)
{
	m_LineEnd\[0\] = _T('\\r');
	m_LineEnd\[1\] = _T('\\n');
	m_LineEnd\[2\] = 0; 
	m_RecordDelimiters\[0\]= _T('\\r');
	m_RecordDelimiters\[1\]= _T('\\n'); 
}

bool CFormat::GetAssumeRecordDelimiters() const
{
	return m_AssumeRecordDelimiters;
}

void CFormat::SetAssumeRecordDelimiters(bool rhs)
{
	m_AssumeRecordDelimiters= rhs;
}

bool CFormat::GetRemoveEmpty() const
{
	return m_RemoveEmpty;
}

void CFormat::SetRemoveEmpty(bool rhs)
{
	m_RemoveEmpty = rhs;
}


TCHAR CFormat::GetFillCharacter() const
{
	return m_FillCharacter;
}

void CFormat::SetFillCharacter(TCHAR rhs)
{
	m_FillCharacter= rhs;
}

const TCHAR* CFormat::GetLineEnd() const
{
	return m_LineEnd;
}

void CFormat::SetLineEnd(int lineend)
{
	switch(lineend)
	{
		case 0:
#ifdef _WIN32
			m_LineEnd\[0\] = _T('\\r'); m_LineEnd\[1\] = _T('\\n'); m_LineEnd\[2\] = 0; break;
#elif defined macintosh
			m_LineEnd\[0\] = _T('\\r'); m_LineEnd\[1\] = 0; break;
#else
			m_LineEnd\[0\] = _T('\\n'); m_LineEnd\[1\] = 0; break;
#endif
		case 1: m_LineEnd\[0\] = _T('\\r'); m_LineEnd\[1\] = _T('\\n'); m_LineEnd\[2\] = 0; break;
		case 2: m_LineEnd\[0\] = _T('\\n'); m_LineEnd\[1\] = 0; break;
		case 3: m_LineEnd\[0\] = _T('\\r'); m_LineEnd\[1\] = 0; break;
		default: m_LineEnd\[0\] = _T('\\r'); m_LineEnd\[1\] = _T('\\n'); m_LineEnd\[2\] = 0; break;
	}
}

bool CFormat::IsRecordDelimiter(TCHAR rhs) const
{
	for (size_t i= 0; i<2; ++i)
	{
		if (rhs == m_RecordDelimiters\[i\])
			return true;
	}
	return false;
}

} // namespace flf
} // namespace tablelike
} // namespace text
} // namespace altova

