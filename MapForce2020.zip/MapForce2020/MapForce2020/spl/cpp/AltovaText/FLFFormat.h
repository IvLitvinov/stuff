[call GenerateFileHeader("FLFFormat.h")]
#ifndef __ALTOVATEXT_FLFFORMAT_H
#define __ALTOVATEXT_FLFFORMAT_H

#include "AltovaTextAPI.h"

namespace altova
{
namespace text
{
namespace tablelike
{
namespace flf
{

class ALTOVATEXT_DECLSPECIFIER CFormat
{
public:
	CFormat();

	bool GetAssumeRecordDelimiters() const;
	void SetAssumeRecordDelimiters(bool rhs);

	bool GetRemoveEmpty() const;
	void SetRemoveEmpty(bool rhs);

	TCHAR GetFillCharacter() const;
	void SetFillCharacter(TCHAR rhs);

	const TCHAR* GetLineEnd() const;
	void SetLineEnd(int lineend);

	bool IsRecordDelimiter(TCHAR rhs) const;
	
private:
	bool m_AssumeRecordDelimiters;
	TCHAR m_FillCharacter;
	TCHAR m_RecordDelimiters\[2\];
	TCHAR m_LineEnd\[3\];
	bool m_RemoveEmpty;
};

} // namespace flf
} // namespace tablelike
} // namespace text
} // namespace altova

#endif 
