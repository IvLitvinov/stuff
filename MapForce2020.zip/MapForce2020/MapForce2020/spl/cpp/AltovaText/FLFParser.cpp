[call GenerateFileHeader("FLFParser.cpp")]
#include "stdafx.h"
#include "FLFParser.h"
#include "Helpers.h"

namespace altova
{
namespace text
{
namespace tablelike
{
namespace flf
{

// CParserException:
CParserException::CParserException(tstring message, size_t offset)
:	m_Offset(offset)
{
#ifdef _UNICODE
	std::wstringstream ss;
#else
	std::stringstream ss;
#endif
	ss << message << _T(" at offset #") << offset;
	CMappingException::SetMessage(ss.str());
}
size_t CParserException::GetOffset() const
{
	return m_Offset;
}

// ---------------------------------------------------------------------------------------

CParser::CParser(const flf::CFormat& format, const CHeader& header)
:	m_Format(format)
,	m_Header(header)
,	m_Offset(0)
,	m_Buffer(_T(""))
{
}

int CParser::Parse(const tstring& buffer)
{
	int result = 0;
	m_Buffer = buffer;
	m_Offset = 0;
	
	do
	{
		ParseRecord();
		++result;
	}
	while (m_Offset<m_Buffer.length());
	return result;
}

int CParser::GetRecordLength()
{
	size_t result = 0;
	const TColumnSpecificationArray& cols = m_Header.GetColumns();
	TColumnSpecificationArray::const_iterator it, itEnd = cols.end();
	for (it = cols.begin(); it != itEnd; ++it)
		result += (*it)->GetLength();
	return (int) result;
}

size_t CParser::ExtractFieldValueFromBuffer(int bufferstartoffset, TStringList& fields, size_t fieldindex)
{
	size_t len = m_Header.GetColumns()\[fieldindex\]->GetLength();
	tstring value = m_Buffer.substr(bufferstartoffset, len);
	Trim(value);
	fields.push_back(new tstring(value));
	return len;
}

void CParser::ParseFields(TStringList& fields, size_t fieldcount)
{
	if (m_Format.GetAssumeRecordDelimiters())
	{
		size_t i=0;
		while (i < fieldcount)
		{
			size_t count = m_Header.GetColumns()\[i\]->GetLength();
			if (m_Offset + count > m_Buffer.length())
				count = m_Buffer.length() - m_Offset;
			tstring value = m_Buffer.substr(m_Offset, count);
			size_t recSepPos = value.find(_T('\\r'), 0);
			if (recSepPos != tstring::npos)
			{
				value.resize(recSepPos);
				Trim(value);
				fields.push_back(new tstring(value));
				m_Offset += recSepPos;
				i++;
				break;
			}
			else
			{
				Trim(value);
				fields.push_back(new tstring(value));
				m_Offset += count;
				i++;
			}
		}
		if (i<fieldcount)
			for (size_t j = i; j < fieldcount; ++j)
				fields.push_back(new tstring(_T("")));
	}
	else
	{
		for (size_t i = 0; i < fieldcount; ++i)
		{
			size_t len = m_Header.GetColumns()\[i\]->GetLength();
			size_t bufLen = m_Buffer.size();

			tstring value;

			if (bufLen < m_Offset)
				value = _T("");
			else if (bufLen < m_Offset + len)
				value = m_Buffer.substr(m_Offset);
			else
				value = m_Buffer.substr(m_Offset, len);
				
			Trim(value);
			fields.push_back(new tstring(value));

			m_Offset += len;
		}
	}
}

void CParser::ParseRecord()
{
	TStringList fields;
	const TColumnSpecificationArray& cols= m_Header.GetColumns();
	if (m_Format.GetAssumeRecordDelimiters())
	{
		size_t maxfieldindex = cols.size() - 1;
		ParseFields(fields, maxfieldindex);
		size_t start = m_Offset;
		MoveToNextRecordDelimiter();
		size_t len = min(m_Offset-start, cols\[maxfieldindex\]->GetLength());
		tstring value = m_Buffer.substr(start, len);
		Trim(value);
		fields.push_back(new tstring(value));

		SwallowTillNextRecord();
	}
	else 
	{
		ParseFields(fields, cols.size());
	}

	if (m_Format.GetRemoveEmpty())
	{
		for (size_t i = 0; i < fields.size(); ++i)
		{
			tstring* field = fields\[i\];
			if (fields\[i\] != 0 && field->empty()) 
			{
				delete field;
				fields\[i\] = 0;
			}
		}		
	}

	CRecordBasedParser::NotifyObserverAboutRecordFound(fields);
	DeleteContainedPointers(fields);
}

void CParser::MoveToNextNonRecordDelimiter()
{
	while ((m_Offset<m_Buffer.size()) && (m_Format.IsRecordDelimiter(m_Buffer\[m_Offset\])))
		++m_Offset;
}

void CParser::MoveToNextRecordDelimiter()
{
	while ((m_Offset<m_Buffer.size()) && (!m_Format.IsRecordDelimiter(m_Buffer\[m_Offset\])))
		++m_Offset;
}

void CParser::SwallowTillNextRecord()
{
	MoveToNextRecordDelimiter();
	MoveToNextNonRecordDelimiter();
}

void CParser::Trim(tstring& rhs)
{
	if(rhs.empty()) return;
	TCHAR fillcharacter = m_Format.GetFillCharacter();
	size_t size = rhs.size();
	long end = (long) size - 1;
	while ((end>-1) && (fillcharacter==rhs\[end\]))
		--end;
	rhs = rhs.substr(0, end+1);
}

// ---------------------------------------------------------------------------------------

} // namespace flf
} // namespace tablelike
} // namespace text
} // namespace altova
