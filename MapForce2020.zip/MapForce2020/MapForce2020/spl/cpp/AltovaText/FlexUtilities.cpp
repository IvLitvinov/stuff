[call GenerateFileHeader("FlexUtilities.cpp")]
#include "StdAfx.h"
#include "Generator.h"
#include "FlexUtilities.h"

namespace altova
{
namespace text
{
namespace flex
{

static const TCHAR CR = _T('\\r');
static const TCHAR LF = _T('\\n');
static const TCHAR TAB = _T('\\t');


//////////////////////////////////////////////////////////////////////////

CTextRange CSplitAtPosition::Split(CTextRange& range) const
{
	if (m_nPosition < 0)
	{
		// count from right
		size_t nChars = min((size_t)-m_nPosition, range.length());
		CTextRange result(range.m_pStart, range.m_pEnd - nChars);
		range.m_pStart = result.m_pEnd;
		return result;
	}
	else
	{
		// count from left
		CTextRange result(range.m_pStart, min((size_t)m_nPosition, range.length()));
		range.m_pStart = result.m_pEnd;
		return result;
	}
}

void CSplitAtPosition::PrepareUpper(tstring& buffer, int lineend) const
{
	if (m_nPosition > 0)
	{
		buffer.resize(m_nPosition, ' ');
	} 
}

void CSplitAtPosition::PrepareLower(tstring& buffer, int lineend) const
{
	if (m_nPosition < 0)
	{
		reverse(buffer.begin(), buffer.end());
		buffer.resize(-m_nPosition, ' ');
		reverse(buffer.begin(), buffer.end());
	}
}


//////////////////////////////////////////////////////////////////////////

CTextRange CSplitLines::Split(CTextRange& range) const
{
	CTextRange result(range.m_pStart, range.m_pStart);
	if (m_nLines >= 0)
	{
		// count from top
		const TCHAR*& p = result.m_pEnd;

		for (int nLines = m_nLines; nLines > 0 && p != range.m_pEnd; ++p)
		{
			if (*p == CR || *p == LF)
			{
				if (*p == CR && p != range.m_pEnd-1 && *(p+1) == LF)
					++p;

				nLines--;
			}
		}
	}
	else
	{
		// count from bottom
		result.m_pEnd = range.m_pEnd;
		const TCHAR*& p = result.m_pEnd;
		int nLines = -m_nLines;
		if (result && (*(p-1) == CR || *(p-1) == LF))
			nLines++;

		for (; p > range.m_pStart; --p)
		{
			if (*(p-1) == CR || *(p-1) == LF)
			{
				if (!--nLines)
					break;
				if (nLines && *(p-1) == LF && p > range.m_pStart+1 && *(p-2) == CR)
					--p;
			}
		}
	}
	range.m_pStart = result.m_pEnd;
	if (m_RemoveDelimiter)
	{
		if (result.EndsWith(LF))
			result.m_pEnd--;
		if (result.EndsWith(CR))
			result.m_pEnd--;
	}
	return result;
}

void CSplitLines::AppendDelimiter(CTextAppender& output) const
{
	if (m_RemoveDelimiter)
		output.AppendLineEnd();
}

void CSplitLines::PrepareUpper(tstring& buffer, int lineend) const
{
	if (m_nLines >= 0)
		makeBufferNLines(buffer, m_nLines, lineend);
}

void CSplitLines::PrepareLower(tstring& buffer, int lineend) const
{
	if (m_nLines < 0)
		makeBufferNLines(buffer, -m_nLines, lineend);
}

void CSplitLines::makeBufferNLines(tstring& buffer, int nLines, int lineend)
{
	// count from top
	tstring::iterator p = buffer.begin();

	for (int nLinesLeft = nLines; nLinesLeft > 0;)
	{
		if (p != buffer.end())
		{
			if (*p == CR || *p == LF)
			{
				if (*p == CR && p+1 != buffer.end() && *(p+1) == LF)
					++p;
				--nLinesLeft;
				if (nLinesLeft == 0) 
				{
					buffer.erase(p+1, buffer.end());
					break;
				}
			}
			++p;			
		}
		else
		{
			switch(lineend)
			{
				case 0:
#ifdef _WIN32
					buffer.append(1, CR); buffer.append(1, LF); break;
#elif defined macintosh
					buffer.append(1, CR); break;
#else
					buffer.append(1, LF); break;
#endif
				
				case 1: buffer.append(1, CR); buffer.append(1, LF); break;
				case 2: buffer.append(1, LF); break;
				case 3: buffer.append(1, CR); break;
				default: buffer.append(1, CR); buffer.append(1, LF); break;
			}
			--nLinesLeft;
			p = buffer.end();
		}
	}
}

//////////////////////////////////////////////////////////////////////////

CTextRange CSplitAtDelimiter::Split(CTextRange& range) const
{
	if (m_sDelimiter.empty())
	{
		CTextRange result(range);
		range.m_pStart = range.m_pEnd;
		return result;
	}

	if (m_Reverse)
	{
		CTextRange result(range.m_pStart, range.m_pStart);
		for (const TCHAR* p = range.m_pEnd - m_sDelimiter.length(); p >= range.m_pStart; --p)
		{
			if (*p == m_sDelimiter\[0\])
				if (!memcmp(p, &(m_sDelimiter\[0\]), m_sDelimiter.length() * sizeof(TCHAR)))
				{
					result.m_pEnd = p;
					range.m_pStart = p + m_sDelimiter.length();
					return result;
				}
		}
		return result;
	}
	else
	{
		CTextRange result(range.m_pStart, range.m_pStart);
		result.m_pEnd = search(range.m_pStart, range.m_pEnd, m_sDelimiter.begin(), m_sDelimiter.end());
		range.m_pStart = result.m_pEnd + (result.m_pEnd == range.m_pEnd ? 0 : m_sDelimiter.length() );
		return result;
	}
}

//////////////////////////////////////////////////////////////////////////

#ifdef ALTOVA_TR1_SUPPORT

// splits input range to result containing the head section and range the tail section
// if no match occured, the head section contains all and the tail is empty (result.m_pEnd == range.m_pEnd)
CTextRange CSplitAtDelimiterRegex::Split( CTextRange& range ) const
{
	if ( m_sPattern.empty() )
	{
		CTextRange result( range );
		range.m_pStart = range.m_pEnd;
		return result;
	}

	CTextRange result( range.m_pStart, range.m_pStart );

	std::regex_constants::match_flag_type searchFlags = std::regex_constants::match_default;
	std::regex_constants::syntax_option_type flags = std::regex_constants::ECMAScript;
	if ( !m_MatchCase )
		flags |= std::regex_constants::icase;

	try
	{
		std::basic_regex<TCHAR> re( m_sPattern, flags );
		std::match_results<const TCHAR*> matchResult;
		
		if ( std::regex_search( tstring(_T("")), re, searchFlags ) )
			throw CAltovaException( 0, _T("Regular expression matches empty string") );
		
		if ( std::regex_search( range.m_pStart, range.m_pEnd, matchResult, re, searchFlags ) )
		{
			if ( matchResult\[0\].first == matchResult\[0\].second )
				throw CAltovaException( 0, _T("Regular expression matches empty string") );

			result.m_pEnd = matchResult\[0\].first;
			range.m_pStart = matchResult\[0\].second;
		}
		else
		{
			// full range in the head section
			result.m_pEnd = range.m_pEnd;
			range.m_pStart = range.m_pEnd;
		}

		return result;
	}
	catch ( std::regex_error& )
	{
		throw CAltovaException( 0, _T("Regular expression is invalid") );
	}
}

#endif

//////////////////////////////////////////////////////////////////////////

CTextRange CSplitAtDelimiterLineBased::Split(CTextRange& range) const
{
	if (m_sDelimiter.empty())
	{
		CTextRange result(range);
		range.m_pStart = range.m_pEnd;
		return result;
	}

	CTextRange result = CSplitAtDelimiter::Split(range);

	while (result && *(result.m_pEnd-1) != CR && *(result.m_pEnd-1) != LF)
		result.m_pEnd--;
	range.m_pStart = result.m_pEnd;
	return result;
}

//////////////////////////////////////////////////////////////////////////

#ifdef ALTOVA_TR1_SUPPORT

CTextRange CSplitAtDelimiterLineBasedRegex::Split( CTextRange& range ) const
{
	if ( m_sPattern.empty() )
	{
		CTextRange result(range);
		range.m_pStart = range.m_pEnd;
		return result;
	}

	CTextRange result = CSplitAtDelimiterRegex::Split( range );

	while ( result && *(result.m_pEnd-1) != CR && *(result.m_pEnd-1) != LF )
		result.m_pEnd--;
	range.m_pStart = result.m_pEnd;
	return result;
}

#endif

//////////////////////////////////////////////////////////////////////////

CTextRange CSplitAtDelimiterLineBasedMultiple::Split(CTextRange& range) const
{
	static const CSplitLines splitAtFirstLine(1);
	bool firstLine = true;
	CTextRange result (range);

	while (true) 
	{
		CTextRange line = splitAtFirstLine.Split(range);
		if (!line)
		{
			result.m_pEnd = line.m_pStart;
			break;
		}
		if (search(line.m_pStart, line.m_pEnd, m_sDelimiter.begin(), m_sDelimiter.end()) != line.m_pEnd)
		{
			if (!firstLine) 
			{
				result.m_pEnd = line.m_pStart;
				break;
			}
		}
		firstLine = false;
	}
	range.m_pStart = result.m_pEnd;
	return result;
}

//////////////////////////////////////////////////////////////////////////

#ifdef ALTOVA_TR1_SUPPORT

CTextRange CSplitAtDelimiterLineBasedMultipleRegex::Split( CTextRange& range ) const
{
	static const CSplitLines splitAtFirstLine(1);
	bool firstLine = true;
	CTextRange result( range );
	CSplitAtDelimiterRegex splitter( m_sPattern, m_MatchCase, tstring() );

	while ( true ) 
	{
		CTextRange line = splitAtFirstLine.Split( range );
		if ( !line )
		{
			result.m_pEnd = line.m_pStart;
			break;
		}
		CTextRange head = splitter.Split( line );
		if ( head.m_pEnd != line.m_pEnd )
		{
			if (!firstLine) 
			{
				result.m_pEnd = head.m_pStart;
				break;
			}
		}
		firstLine = false;
	}
	range.m_pStart = result.m_pEnd;
	return result;
}

#endif

//////////////////////////////////////////////////////////////////////////

CTextRange CSplitAtDelimiterLineStartsWith::Split(CTextRange& range) const
{
	if (!m_Reverse)
	{
		CTextRange result(range);

		if (m_sDelimiter.empty())
		{
			range.m_pStart = range.m_pEnd;
			return result;
		}

		static const CSplitLines splitAtFirstLine(1);
		bool firstLine = m_bConsumeFirstLine;
		while (true) 
		{
			CTextRange line = splitAtFirstLine.Split(range);
			if (!line)
			{
				result.m_pEnd = line.m_pStart;
				break;
			}
			if (line.StartsWith(m_sDelimiter))
			{
				if (!firstLine) 
				{
					result.m_pEnd = line.m_pStart;
					break;
				}
			}
			firstLine = false;
		}
		range.m_pStart = result.m_pEnd;
		return result;
	}
	else
	{
		CTextRange result (range);

		if (m_sDelimiter.empty())
		{
			result.m_pEnd = result.m_pStart;
			return result;
		}

		static const CSplitLines splitAtLastLine(-1);
		CTextRange pre(range);
		while (true) 
		{
			CTextRange line = splitAtLastLine.Split(pre);
			if (!line)
			{
				result.m_pEnd = line.m_pStart;
				break;
			}
			if (pre.StartsWith(m_sDelimiter))
			{
				result.m_pEnd = pre.m_pStart;
				break;
			}
			pre = line;
		}
		range.m_pStart = result.m_pEnd;
		return result;
	}
}

//////////////////////////////////////////////////////////////////////////

#ifdef ALTOVA_TR1_SUPPORT

CTextRange CSplitAtDelimiterLineStartsWithRegex::Split( CTextRange& range ) const
{
	CTextRange result( range );

	if ( m_sPattern.empty() )
	{
		range.m_pStart = range.m_pEnd;
		return result;
	}

	static const CSplitLines splitAtFirstLine(1);
	bool firstLine = m_bConsumeFirstLine;
	while ( true )
	{
		CTextRange line = splitAtFirstLine.Split( range );
		if ( !line )
		{
			result.m_pEnd = line.m_pStart;
			break;
		}
		CTextRange head = CSplitAtDelimiterRegex::Split( line );
		if ( head.m_pEnd != line.m_pEnd && head.m_pStart == head.m_pEnd )
		{
			if (!firstLine) 
			{
				result.m_pEnd = head.m_pStart;
				break;
			}
		}
		firstLine = false;
	}
	range.m_pStart = result.m_pEnd;
	return result;
}

#endif


} // namespace flex
} // namespace text
} // namespace altova
