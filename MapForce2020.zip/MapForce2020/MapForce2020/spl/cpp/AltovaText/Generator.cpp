[call GenerateFileHeader("Generator.cpp")]
#include "StdAfx.h"
#include "Generator.h"
#include "TextNode.h"
#include "Helpers.h"
#include "TextException.h"

namespace {
	void Tokenize(const tstring& str,
		vector<tstring>& tokens,
		const tstring& delimiters = _T(" ") )
	{
		// Skip delimiters at beginning.
		tstring::size_type lastPos = str.find_first_not_of(delimiters, 0);
		// Find first "non-delimiter".
		tstring::size_type pos     = str.find_first_of(delimiters, lastPos);

		while (tstring::npos != pos || tstring::npos != lastPos)
		{
			// Found a token, add it to the vector.
			tokens.push_back(str.substr(lastPos, pos - lastPos));
			// Skip delimiters.  Note the "not_of"
			lastPos = str.find_first_not_of(delimiters, pos);
			// Find next "non-delimiter"
			pos = str.find_first_of(delimiters, lastPos);
		}
	}
}

namespace altova
{
namespace text
{

const static tstring k_sEmpty(_T(""));

CGenerator::CGenerator() : CTextNode()
{
	this->Init();
}

CGenerator::~CGenerator()
{
	this->Exit();
}

void CGenerator::Init()
{
	m_pCurrent= 0;
}

void CGenerator::Done()
{
	m_pCurrent = m_pCurrent ? m_pCurrent->GetRoot() : 0;
}

void CGenerator::Exit()
{
	this->Done();
	CTextNodeFactory::GetInstance().Delete(m_pCurrent);
}

void CGenerator::EnterElement(const tstring& name, ENodeClass eClass)
{
	CTextNode* node= (!m_pCurrent)
					 ? CTextNodeFactory::GetInstance().CreateRootNode()
					 : CTextNodeFactory::GetInstance().Create(m_pCurrent, name);
	node->SetName(name);
	node->SetClass(eClass);
	if (!m_pCurrent)
		GetChildren()->Add(node);
	m_pCurrent= node;
}

void CGenerator::LeaveElement(const tstring& name)
{
	CTextNode* tobeleft = (name.empty()) ? m_pCurrent : this->FindElementUpwardsByName(name);
	if (tobeleft)
	{
		CTextNode* parent = tobeleft->GetParent();
		m_pCurrent= (!parent) ? tobeleft : parent;
	}
}

void CGenerator::InsertElement (const tstring& name, const tstring& value, ENodeClass eClass)
{
	CTextNode* node= CTextNodeFactory::GetInstance().Create(m_pCurrent, name);
	node->SetValue(value);
	node->SetClass(eClass);
}


void CGenerator::SetRootNode(CTextNode* rhs)
{
	m_pCurrent= CTextNodeFactory::GetInstance().CreateRootNode(rhs);
	GetChildren()->Add(m_pCurrent);
}

CTextNode* CGenerator::FindElementUpwardsByName(const tstring& name) const
{
	CTextNode* result= m_pCurrent;
	while (result)
	{
		if (name == result->GetName()) return result;
		result = result->GetParent();
	}
	return result;
}

tstring CGenerator::GetNodeValueByPath( const tstring& sPath ) const
{
	CTextNode* node = m_pCurrent;

	std::vector<tstring> tokens;
	Tokenize( sPath, tokens, _T("/") );
	std::vector<tstring>::const_iterator it = tokens.begin();

	if( node->GetName() != *it )
		return _T("");

	for( it++; it != tokens.end(); it++ )
	{
		node = node->GetChildren()->GetFirstNodeByName(*it);
		if( node == NULL )
			return _T("");
	}

	return node->GetValue();
}

CTextNode* CGenerator::DetachRootNode()
{
	CTextNode* root = m_pCurrent->GetRoot();
	GetChildren()->RemoveAll();
	m_pCurrent = 0;
	return root;
}

} // namespace text
} // namespace altova

