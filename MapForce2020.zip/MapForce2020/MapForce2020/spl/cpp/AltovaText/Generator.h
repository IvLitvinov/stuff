[call GenerateFileHeader("Generator.h")]
#ifndef __ALTOVATEXT_GENERATOR_H
#define __ALTOVATEXT_GENERATOR_H

#include "AltovaTextAPI.h"
#include "TextNode.h"

namespace altova
{
namespace text
{

class CTextNode;


class ALTOVATEXT_DECLSPECIFIER CGenerator : public CTextNode
{
public:
	CGenerator();
	virtual ~CGenerator();
	
	void Init();
	void Done();
	void Exit();
		
	void EnterElement(const tstring& name, ENodeClass eClass);
	void LeaveElement(const tstring& name);
	void InsertElement(const tstring& name, const tstring& value, ENodeClass eClass);

	bool DoesCurrentsNameEqual(const tstring& name) const;
	bool DoesHaveChildByName(const tstring& name) const;
	
	CTextNode* DetachRootNode();
	
	tstring	GetRootName() { return GetRootNode()->GetName(); }
	CTextNode* GetRootNode() { return GetChildren()->GetAt(0); }
	CTextNodeContainer* GetRootNodes() { return GetChildren(); }
	void SetRootNode(CTextNode*);
	CTextNode* GetCurrentNode() { return m_pCurrent; }
	
	tstring GetNodeValueByPath( const tstring& sPath ) const;
private:					
	CTextNode* FindElementUpwardsByName(const tstring& name) const;
private:					
	CTextNode* m_pCurrent;
};

} // namespace text
} // namespace altova

#endif
