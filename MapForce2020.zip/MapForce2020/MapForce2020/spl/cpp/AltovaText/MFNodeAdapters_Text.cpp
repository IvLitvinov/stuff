[call GenerateFileHeader("MFNodeAdapters_Text.cpp")]

#include "stdafx.h"
#include "MFNodeAdapters_Text.h"

using namespace altova::mapforce;

Enumerable* TextNodeAsMFNodeAdapter::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
	case k_AllChildren:
		if (node.GetChildren()->GetCount() > 0)
			return new TextChildrenAsMFNodeSequenceAdapter(node);
		else
			return new MFSingletonSequence(new MFSimpleNode<string_type>(node.GetValue()));

	case k_AllAttributes:
		return MFEmptySequence::Instance();

	case k_AttributeByQName:
		return MFEmptySequence::Instance();
	
	case k_ChildrenByQName:
		return new MFNodeByKindAndQNameFilter(new TextChildrenAsMFNodeSequenceAdapter(node), k_Children, query);

	case k_SelfByQName:
		if (node.GetName() == query.localName)
			return new MFSingletonSequence(this);
		else
			return MFEmptySequence::Instance();

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

Enumerable* TableAsMFNodeAdapter::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
		case k_AllAttributes:
		case k_AttributeByQName:
		case k_SelfByQName:
			return MFEmptySequence::Instance();

		case k_All:
		case k_AllChildren:
		case k_ChildrenByQName:
			return new RecordsAdapter(table);

		default:
			throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

Enumerable* TableAsMFNodeAdapter::RecordAdapter::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
	case k_AllChildren:
		return new FieldsAdapter(table, record, header);
	case k_ChildrenByQName:
		return new MFNodeByKindAndQNameFilter(Select(k_AllChildren), k_Element, query);
			
	case k_AttributeByQName:
		return new MFNodeByKindAndQNameFilter(Select(k_AllAttributes), k_Attribute, query);

	case k_SelfByQName:
		if (query.localName == _T("Rows"))
			return new MFSingletonSequence(this);
		else
			return MFEmptySequence::Instance();

	case k_AllAttributes:
		return MFEmptySequence::Instance();

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

Enumerable* TableAsMFNodeAdapter::FieldAdapter::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
	case k_AllChildren:
		return new MFSingletonSequence(new  MFSimpleNode<string_type>(value));
	case k_AllAttributes:
	case k_AttributeByQName:
	case k_ChildrenByQName:
		return MFEmptySequence::Instance();

	case k_SelfByQName:
		if (query.localName == colspec->GetName())
			return new MFSingletonSequence(this);
		else
			return MFEmptySequence::Instance();

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}
