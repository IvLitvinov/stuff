[call GenerateFileHeader("MFNodeAdapters_Text.h")]


#ifndef MFNODE_ADAPTERS_H
#define MFNODE_ADAPTERS_H

#include "../Altova/AltovaMapforce.h"
#include "TextNode.h"
#include "Table.h"
#include "Header.h"
#include "Record.h"
#include "ColumnSpecification.h"
#include <map>

namespace altova
{
	namespace mapforce
	{
		class ALTOVATEXT_DECLSPECIFIER TableAsMFNodeAdapter : public MFNode, public MFDocumentNode
		{
			class Table : public RefCounted
			{
			public: 
				Table(altova::text::tablelike::CTable* t) : RefCounted(), table(t) {}
				~Table() {delete table;}
				operator altova::text::tablelike::CTable*() {return table;}
				altova::text::tablelike::CTable* GetTable() {return table;}
				
			private:
				altova::text::tablelike::CTable* table;
			};
			
			class FieldAdapter : public MFNode
			{
			public:
				FieldAdapter(const string_type& v, const altova::text::tablelike::CColumnSpecification* s) : MFNode(QName(s->GetName())), value(v), colspec(s) {}
				~FieldAdapter() {}

				Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
				MFNodeKind GetNodeKind() const { return k_Element; }
				string_type GetValue() const {return value;}

			private:
				string_type value;
				const altova::text::tablelike::CColumnSpecification* colspec;
			};

			class FieldsAdapter : public Enumerable
			{
				class Enum : public Enumerator
				{
				public:
					Enum(Table* t, const altova::text::tablelike::CRecord& r, altova::text::tablelike::CHeader& h, Enumerable* cls) : Enumerator(cls), table(t), record(r), header(h), index(-1) {}
					~Enum() {}
					
					IMFNode GetCurrent()
					{
						if (index < 0 || (size_t) index >= header.GetColumns().size())
							throw altova::CAltovaException(0, _T("Out of bounds."));
						return new FieldAdapter(record.GetFieldAt(index), header.GetColumns()\[index\]);
					}

					bool MoveNext()
					{
						while(true)
						{
							if (++index >= (int) header.GetColumns().size())
							{
								index = (int) header.GetColumns().size();
								return false;
							}
							if (record.HasFieldAt(index))
							{
								pos++;
								return true;
							}
						}
					}
				private:
					Table* table;
					const altova::text::tablelike::CRecord& record;
					altova::text::tablelike::CHeader& header;
					int index;
				};
			public:
				FieldsAdapter(Table* t, const altova::text::tablelike::CRecord& r, altova::text::tablelike::CHeader& h) : Enumerable(), table(t), record(r), header(h) {table->AddRef();}
				~FieldsAdapter() {table->RemoveRef();}
				
				Enumerator* GetEnumerator() {return new Enum(table, record, header, this);}

			private:
				Table* table;
				const altova::text::tablelike::CRecord& record;
				altova::text::tablelike::CHeader& header;
			};

			class RecordAdapter : public MFNode
			{
			public:
				RecordAdapter(Table* t, int index) : MFNode(QName(_T("Rows"))), table(t), record(table->GetTable()->GetRecordAt(index)), header(table->GetTable()->GetHeader()) {table->AddRef();}
				~RecordAdapter() {table->RemoveRef();}

				Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
				MFNodeKind GetNodeKind() const {return k_Element;}
				string_type GetValue() const {return _T("");}

			private:
				Table* table;
				const altova::text::tablelike::CRecord& record;
				altova::text::tablelike::CHeader& header;
			};

			class RecordsAdapter : public Enumerable
			{
				class Enum : public Enumerator
				{
				public:
					Enum(Table* t, Enumerable* cls) : Enumerator(cls), table(t), index(-1) {}
					~Enum() {}

					bool MoveNext()
					{
						if (++index >= (int) table->GetTable()->GetRecordCount())
						{
							index = (int) table->GetTable()->GetRecordCount();
							return false;
						}
						pos++;
						return true;
					}

					IMFNode GetCurrent()
					{
						if (index <0 || (size_t) index >= table->GetTable()->GetRecordCount())
							throw altova::CAltovaException(0, _T("Out of bounds."));
						return new RecordAdapter(table, index);
					}


				private:
					Table* table;
					int index;
				};
			public:
				RecordsAdapter(Table* t) : Enumerable(), table(t) {table->AddRef();}
				~RecordsAdapter() {table->RemoveRef();}
				Enumerator* GetEnumerator() {return new Enum(table, this);}
			private:
				Table* table;
			};

		public:
			TableAsMFNodeAdapter(altova::text::tablelike::CTable* t, const string_type& f) : MFNode(QName()), MFDocumentNode(f), table(new Table(t)) {table->AddRef();}
			~TableAsMFNodeAdapter() {table->RemoveRef();}

			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			MFNodeKind GetNodeKind() const { return k_Element; }
			string_type GetValue() const {return _T("");}
		private:
			Table* table;
		};

		class ALTOVATEXT_DECLSPECIFIER TextNodeAsMFNodeAdapter : public MFNode
		{
		public:
			TextNodeAsMFNodeAdapter(altova::text::CTextNode& n)  : MFNode(QName(n.GetName())), node(n) {}
			TextNodeAsMFNodeAdapter(altova::text::CTextNode* n)  : MFNode(QName(n->GetName())), node(*n) {}
			~TextNodeAsMFNodeAdapter() {}

			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			MFNodeKind GetNodeKind() const { return k_Element; }
			string_type GetValue() const { return node.GetValue(); }

		
		private:
			altova::text::CTextNode& node;
		};

		class ALTOVATEXT_DECLSPECIFIER TextDocumentNodeAsMFNodeAdapter : public TextNodeAsMFNodeAdapter, public MFDocumentNode
		{
		public:
			TextDocumentNodeAsMFNodeAdapter(altova::text::CTextNode& n, const string_type& f) : TextNodeAsMFNodeAdapter(n), MFDocumentNode(f) {}
			TextDocumentNodeAsMFNodeAdapter(altova::text::CTextNode* n, const string_type& f) : TextNodeAsMFNodeAdapter(n), MFDocumentNode(f) {}
		};

		class ALTOVATEXT_DECLSPECIFIER TextChildrenAsMFNodeSequenceAdapter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(altova::text::CTextNode& node, Enumerable* cls) : Enumerator(cls), i(-1), children(node.GetChildren()) {}
				~Enum() {}

				IMFNode GetCurrent() 
				{
					if (i==-1) 
						throw altova::CAltovaException(0, _T("No current."));
					return new TextNodeAsMFNodeAdapter(children->GetAt(i));
				}

				bool MoveNext()
				{
					++i;
					if (i < (int) children->GetCount())
					{
						pos++;
						return true;
					}
					return false;
				}

			private:
				int i;
				altova::text::CTextNodeContainer* children;
			};

		public:
			TextChildrenAsMFNodeSequenceAdapter(altova::text::CTextNode& t) : Enumerable(), from(t) {}
			~TextChildrenAsMFNodeSequenceAdapter() {}

			Enumerator* GetEnumerator() {return new Enum(from, this);}

		private:
			altova::text::CTextNode& from;
		};

		static void MFTextWrite(Enumerable* what, altova::text::CTextNode* where)
		{
			for (IEnumerator en = what; en.MoveNext();)
			{
				IMFNode el = en.GetCurrent();
				if (el->GetNodeKind() == k_Simple)
					where->SetValue(el->GetValue());
				else
				{
					if ((el->GetNodeKind() & (k_Element|k_Attribute)) != 0)
					{
						altova::text::CTextNode* child = altova::text::CTextNodeFactory::GetInstance().Create(where, el->GetLocalName());
						MFTextWrite(el->Select(k_All), child);
					}
					else
						MFTextWrite(el->Select(k_AllChildren), where);
				}
			}
		}

		static void MFTextWrite(Enumerable* what, altova::text::tablelike::CTable* where)
		{
			std::map<string_type, int> hash;
			int i = 0;
			for (unsigned nMember = where->GetTableType()->MemberBegin; nMember != where->GetTableType()->MemberEnd; ++nMember)
			{
				const altova::MemberInfo* pMember = where->GetTableType()->Binder->Members + nMember;
				hash\[pMember->LocalName\] = i++;
			}
			
			for (IEnumerator en = what; en.MoveNext();)
			{
				IMFNode el = en.GetCurrent();
				altova::text::tablelike::CRecord record(where->GetHeader().GetColumns().size());
				
				for(IEnumerator chi_en = el->Select(k_All); chi_en.MoveNext();)
				{
					if (hash.find(chi_en.GetCurrent()->GetLocalName()) != hash.end())
						record.SetFieldAt(hash\[chi_en.GetCurrent()->GetLocalName()\], chi_en.GetCurrent()->GetValue());
				}
				
				where->AddRecord(record);
			}
		}
	}
}

#endif