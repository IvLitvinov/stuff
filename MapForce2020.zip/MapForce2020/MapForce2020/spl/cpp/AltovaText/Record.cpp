[call GenerateFileHeader("Record.cpp")]
#include "stdafx.h"
#include "Record.h"

namespace altova
{
namespace text
{
namespace tablelike
{


CRecord::CRecord(size_t fieldcount)
:	m_FieldCount(fieldcount)
{
	m_Fields= new tstring\[m_FieldCount\];
	m_FieldsValid = new bool\[m_FieldCount\];
	memset( m_FieldsValid, 0, m_FieldCount * sizeof(bool) );
}

CRecord::CRecord(const CRecord& rhs)
{
	m_FieldCount = rhs.m_FieldCount;
	m_Fields = new tstring\[m_FieldCount\];
	m_FieldsValid = new bool\[m_FieldCount\];
	for (size_t i = 0; i < m_FieldCount; ++i)
	{
		m_Fields\[i\] = rhs.m_Fields\[i\];
		m_FieldsValid\[i\] = rhs.m_FieldsValid\[i\];
	}
}

CRecord::~CRecord()
{
	delete \[\] m_Fields;
	delete \[\] m_FieldsValid;
}

void CRecord::Assign(const CRecord& rhs)
{
	delete \[\] m_Fields;
	delete \[\] m_FieldsValid;
	m_FieldCount = rhs.m_FieldCount;
	m_Fields = new tstring\[m_FieldCount\];
	m_FieldsValid = new bool\[m_FieldCount\];
	for (size_t i = 0; i < m_FieldCount; ++i)
	{
		m_Fields\[i\] = rhs.m_Fields\[i\];
		m_FieldsValid\[i\] = rhs.m_FieldsValid\[i\];
	}
}

bool CRecord::HasFieldAt(size_t index) const
{
	return (index < m_FieldCount) && m_FieldsValid\[ index \];
}

const tstring& CRecord::GetFieldAt(size_t index) const
{
	static const tstring empty = _T("");
	if (0 <= index && index < m_FieldCount)
		return m_Fields\[index\];
	else
		return empty;
}

void CRecord::SetFieldAt(size_t index, const tstring& rhs)
{
	if (0 <= index && index < m_FieldCount)
	{
		m_Fields\[index\] = rhs;
		m_FieldsValid\[index\] = true;
	}
}

} // namespace tablelike
} // namespace text
} // namespace altova
