[call GenerateFileHeader("StdAfx.cpp")]
#include "StdAfx.h"

