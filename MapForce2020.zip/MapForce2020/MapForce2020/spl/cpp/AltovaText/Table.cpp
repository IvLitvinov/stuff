[call GenerateFileHeader("Table.cpp")]
#include "stdafx.h"
#include "Table.h"
#include "Helpers.h"
#include "Serializer.h"
#include "Record.h"
#include "Header.h"
#include "RecordBasedParser.h"
#include "../Altova/AltovaException.h"
#include "CSVSerializer.h"
#include "FLFSerializer.h"
#include "../Altova/xs-types.h"

namespace altova
{
namespace text
{
namespace tablelike
{

CTable::CTable()
:	m_pSerializer(NULL)
{
}

CTable::CTable(const altova::TypeInfo* pTableType)
:	m_pSerializer(NULL),m_pType(pTableType)
{
}

CTable::~CTable()
{
	delete m_pSerializer;
	m_pSerializer = NULL;

	Clear();
}

void CTable::init()
{
	InitHeader(m_Header);

	m_pSerializer = CreateSerializer();
	m_pSerializer->SetEncoding(m_nCodePage, m_bBigEndian, m_bBOM);
}

void CTable::Parse(const tstring& filename)
{
	try
	{
		m_pSerializer->Deserialize(filename);
	}
	catch (CMappingException& x)
	{
		throw altova::CAltovaException(0, filename + _T(":") + x.GetMessage());
	}
}

void CTable::Save(const tstring& filename)
{
	tstringstream stream;
	
	m_pSerializer->SetStream(stream);
	m_pSerializer->Serialize();
	
	SaveFileFromBuffer(filename, stream.str(), m_nCodePage, m_bBigEndian, m_bBOM);
}

size_t CTable::GetRecordCount() const
{
	return m_Records.size();
}

const CRecord& CTable::GetRecordAt(size_t index) const
{
	return *m_Records\[index\];
}

void CTable::AddRecord(const CRecord& rhs)
{
	m_Records.push_back(new CRecord(rhs));
}

void CTable::Clear()
{
	DeleteContainedPointers( m_Records );
	m_Records.clear();
}

CHeader& CTable::GetHeader()
{
	return m_Header;
}

void CTable::SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM)
{
	m_nCodePage = codepage;
	m_bBigEndian = bBigEndian;
	m_bBOM = bBOM;

	if( m_pSerializer )
		m_pSerializer->SetEncoding(m_nCodePage, m_bBigEndian, m_bBOM);
}

static size_t ReadLengthFacet(const altova::MemberInfo* pMember)
{
	const altova::TypeInfo* pType = pMember->Binder->Types + pMember->DataType;
	if (pType->Facets == ~0)
		return ~0;
	

	for (const altova::FacetInfo* pFacet = pMember->Binder->Facets + pType->Facets; pFacet->FacetName != 0; ++pFacet)
	{
		if (pFacet->FacetName == string_type(_T("length")) || pFacet->FacetName == string_type(_T("maxLength")))
			return pFacet->IntValue;
	}
	return ~0;
}

ISerializer* CCsvTable::CreateSerializer()
{
	CCSVSerializer* serializer = new CCSVSerializer(*this);
	serializer->SetFormat( &Format);
	return serializer;
}

void CCsvTable::InitHeader(CHeader& header)
{
	for (unsigned nMember = m_pType->MemberBegin; nMember != m_pType->MemberEnd; ++nMember)
	{
		const altova::MemberInfo* pMember = m_pType->Binder->Members + nMember;
		CColumnSpecification spec;
		spec.SetName(pMember->LocalName);
        spec.SetLength(ReadLengthFacet(pMember));
		header.GetColumns().push_back(new CColumnSpecification(spec));
	}		
}

CCsvTable::CCsvTable()
{
}

CCsvTable::CCsvTable(const altova::TypeInfo* pType)
: CTable( pType)
{
	init();
}


ISerializer* CFlfTable::CreateSerializer()
{
	CFLFSerializer* serializer = new CFLFSerializer(*this);
	serializer->SetFormat( &Format);
	return serializer;
}

void CFlfTable::InitHeader(CHeader& header)
{
	for (unsigned nMember = m_pType->MemberBegin; nMember != m_pType->MemberEnd; ++nMember)
	{
		const altova::MemberInfo* pMember = m_pType->Binder->Members + nMember;
		CColumnSpecification spec;
		spec.SetName(pMember->LocalName);
        const altova::TypeInfo* pType = pMember->Binder->Types + pMember->DataType;
        spec.SetLength(ReadLengthFacet(pType->Binder->Members + pType->MemberBegin));
		header.GetColumns().push_back(new CColumnSpecification(spec));
	}		
}

CFlfTable::CFlfTable(const altova::TypeInfo* pType)
: CTable( pType)
{
	init();
}


} // namespace tablelike
} // namespace text
} // namespace altova


bool TextTableOperations::IsValid(const std::pair<string_type,bool>& pNode)
{
	return pNode.second;
}

TextTableOperations::MemberIterator TextTableOperations::GetElements(altova::text::tablelike::CTable* pNode, const altova::MemberInfo* pMemberInfo)
{
	return TextTableOperations::MemberIterator(pNode);
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, const string_type& sValue)
{
	size_t memberIndex = (pMemberInfo - pMemberInfo->Binder->Members) - (pMemberInfo->Binder->Types + pMemberInfo->ContainingType)->MemberBegin;
	pNode->SetFieldAt(memberIndex, sValue);
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, bool b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, int b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, unsigned b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, __int64 b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, unsigned __int64 b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, double b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, altova::DateTime b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(altova::DateTime(b.NormalizedValue())));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, altova::Duration b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

void TextTableOperations::SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, const std::vector<unsigned char>& b)
{
	SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
}

altova::text::tablelike::CRecord* TextTableOperations::AddElement(altova::text::tablelike::CTable* pNode, const altova::MemberInfo* pMemberInfo)
{
	const altova::TypeInfo* pDataType = pMemberInfo->Binder->Types + pMemberInfo->DataType;
	altova::text::tablelike::CRecord record(pDataType->MemberEnd - pDataType->MemberBegin);
	pNode->AddRecord(record);
	return const_cast<altova::text::tablelike::CRecord*>(&pNode->GetRecordAt(pNode->GetRecordCount() - 1));
}

double TextTableOperations::CastToDouble(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToDouble(pNode.first);
}

string_type TextTableOperations::CastToString(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return pNode.first;
}

__int64 TextTableOperations::CastToInt64(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToInt64(pNode.first);
}

unsigned __int64 TextTableOperations::CastToUInt64(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToUInt64(pNode.first);
}

unsigned TextTableOperations::CastToUInt(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToUInt(pNode.first);
}

int TextTableOperations::CastToInt(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToInt(pNode.first);
}

bool TextTableOperations::CastToBool(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToBool(pNode.first);
}

altova::DateTime TextTableOperations::CastToDateTime(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToDateTime(pNode.first);
}

altova::Duration TextTableOperations::CastToDuration(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return altova::CoreTypes::CastToDuration(pNode.first);
}

std::vector<unsigned char> TextTableOperations::CastToBinary(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo)
{
	return GetFormatter(pMemberInfo)->ParseBinary(pNode.first);
}

std::pair<string_type,bool> TextTableOperations::FindAttribute(const altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo)
{
	size_t memberIndex = (pMemberInfo - pMemberInfo->Binder->Members) - (pMemberInfo->Binder->Types + pMemberInfo->ContainingType)->MemberBegin;
	if (pNode->HasFieldAt(memberIndex))
		return std::pair<string_type,bool>(pNode->GetFieldAt(memberIndex), true);
	else
		return std::pair<string_type,bool>(string_type(), false);
}

altova::XmlFormatter* TextTableOperations::GetFormatter(const altova::MemberInfo* pMember)
{
	if (((pMember->Binder->Types + pMember->DataType)->Formatter))
		return static_cast<altova::XmlFormatter*>(*((pMember->Binder->Types + pMember->DataType)->Formatter));
	else
		return static_cast<altova::XmlFormatter*>(altova::AnySimpleTypeFormatter);
}
