[call GenerateFileHeader("Table.h")]
#ifndef __ALTOVATEXT_TABLE_H
#define __ALTOVATEXT_TABLE_H

#include "Header.h"
#include <utility>
#include "CSVFormat.h"
#include "FLFFormat.h"

namespace altova
{
	class XmlFormatter;

namespace text
{
namespace tablelike
{

struct ISerializer;
class CRecord;

class ALTOVATEXT_DECLSPECIFIER CTable
{
public:
	void Parse(const tstring& filename);
	void Save(const tstring& filename);
	void Clear();
	
	CHeader& GetHeader();
	
	void AddRecord(const CRecord& rhs);
	size_t GetRecordCount() const;
	const CRecord& GetRecordAt(size_t index) const;
    const altova::TypeInfo* GetTableType() { return m_pType; };

	void SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM);
	virtual ~CTable();

	CTable();
    CTable(const altova::TypeInfo* pTableType);

protected:
	virtual ISerializer* CreateSerializer()= 0;
	virtual void InitHeader(CHeader& header) {};

	virtual void init();
    
    const altova::TypeInfo* m_pType;
	
private:
	typedef std::vector <CRecord*> TRecordArray;

private:
	ISerializer* m_pSerializer;
	TRecordArray m_Records;
	CHeader		 m_Header;
	unsigned m_nCodePage;
	bool m_bBigEndian;
	bool m_bBOM;
};


class ALTOVATEXT_DECLSPECIFIER CCsvTable : public CTable
{
protected:
	virtual ISerializer* CreateSerializer();
	virtual void InitHeader(CHeader& header);

public:
    CCsvTable();
	CCsvTable(const altova::TypeInfo* pType);

	csv::CFormat Format;
};

class ALTOVATEXT_DECLSPECIFIER CFlfTable : public CTable
{
protected:
	virtual ISerializer* CreateSerializer();
	virtual void InitHeader(CHeader& header);

public:
	CFlfTable(const altova::TypeInfo* pType);

	flf::CFormat Format;
};

} // namespace tablelike
} // namespace text
} // namespace altova

class ALTOVATEXT_DECLSPECIFIER TextTableOperations
{
public:
	class MemberIterator 
	{
		altova::text::tablelike::CTable& m_Table;
		size_t m_Index;

	public:
		operator bool() const { return m_Index != m_Table.GetRecordCount(); }

		bool operator++() 
		{ 
			if (m_Index == m_Table.GetRecordCount())
				return false;
			++m_Index;
			return m_Index != m_Table.GetRecordCount();
		}

		altova::text::tablelike::CRecord* operator*() const { return const_cast<altova::text::tablelike::CRecord*>(&m_Table.GetRecordAt(m_Index)); }		

		MemberIterator(altova::text::tablelike::CTable* pTable)
			: m_Table(*pTable), m_Index(0)
		{
		}
	};

	//static bool IsEqualString(const char_type* a, const char_type* b);
	//static bool IsMember(const MSXML2::IXMLDOMNodePtr& pNode, const altova::MemberInfo* pMember);
	static bool IsValid(const std::pair<string_type,bool>& pNode);
	static MemberIterator GetElements(altova::text::tablelike::CTable* pNode, const altova::MemberInfo* pMemberInfo);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, const string_type& sValue);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, bool b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, int b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, unsigned b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, __int64 b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, unsigned __int64 b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, double b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, altova::DateTime b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, altova::Duration b);
	static void SetValue(altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* pMemberInfo, const std::vector<unsigned char>& b);
	static altova::text::tablelike::CRecord* AddElement(altova::text::tablelike::CTable* pNode, const altova::MemberInfo* pMemberInfo);
	static double CastToDouble(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static string_type CastToString(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static __int64 CastToInt64(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static unsigned __int64 CastToUInt64(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static unsigned CastToUInt(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static int CastToInt(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static bool CastToBool(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static altova::DateTime CastToDateTime(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static altova::Duration CastToDuration(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);
	static std::vector<unsigned char> CastToBinary(const std::pair<string_type,bool>& pNode, const altova::MemberInfo* pMemberInfo);


	static std::pair<string_type,bool> FindAttribute(const altova::text::tablelike::CRecord* pNode, const altova::MemberInfo* member);

private:
	static altova::XmlFormatter* GetFormatter(const altova::MemberInfo* pMember);
};



#endif 
