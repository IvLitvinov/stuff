[call GenerateFileHeader("TextDocument.cpp")]
#include "StdAfx.h"
#include "TextDocument.h"
#include "TextException.h"
#include "Generator.h"
#include "Helpers.h"
#include "TextNode.h"
#include "EDIFactDataCompletion.h"
#include "EDIX12DataCompletion.h"
#include "EDIHL7DataCompletion.h"
#include "EDIFixedDataCompletion.h"
#include "EDITRADACOMSDataCompletion.h"
#include "EDIScriptDataCompletion.h"
#include "EDIFactSettings.h"
#include "EDIX12Settings.h"
#include "EDIHL7Settings.h"
#include "EDIFixedSettings.h"
#include "EDITRADACOMSSettings.h"
#include "EDIScriptSettings.h"
#include "EDISemanticValidator.h"
#include "FlexCommand.h"
#include "Writer.h"

namespace altova
{
namespace text
{


namespace flex
{

CTextDocument::CTextDocument(int lineend)
: m_pFlexProject(NULL), m_nCodePage(CP_ACP), m_bBigEndian(false), m_bBOM(false), m_LineEnd(lineend)
{
}

void CTextDocument::SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM)
{
	m_nCodePage = codepage;
	m_bBigEndian = bBigEndian;
	m_bBOM = bBOM;
}

CTextNode* CTextDocument::ParseFile(const tstring& filename)
{
	
	tstring buffer;
	if (LoadFileIntoBuffer(filename, buffer, m_nCodePage, m_bBigEndian))
	{
		return ParseString(buffer);
	}
	return 0;
}

CTextNode* CTextDocument::ParseString(const tstring& str)
{
	if (!m_pFlexProject)
		throw CTextException(CAltovaException::eError1, _T("Parse error: No syntax definition."));
	CTextDocumentReader doc(str, &GetGenerator());
	m_pFlexProject->ReadText(doc);
	return GetGenerator().GetRootNode();
}

void CTextDocument::SaveFile(const tstring& filename)
{
	tstring str;
	SaveString(str);
	SaveFileFromBuffer(filename, str, m_nCodePage, m_bBigEndian, m_bBOM);
}

void CTextDocument::SaveString(tstring& str)
{
	if (!m_pFlexProject)
		throw CTextException(CAltovaException::eError1, _T("Save error: No syntax definition."));

	if(GetRoot() != NULL)
	{
		CTextDocumentWriter doc(GetRoot(), str, m_LineEnd);
		m_pFlexProject->WriteText(doc);
	}
}

CGenerator&	CTextDocument::GetGenerator()
{
	return m_Generator;
}

CTextNode* CTextDocument::GetRoot()
{
	return m_Generator.GetRootNode();
}

} // namespace flex


////////////////////////////////////////////////////////////////////////

namespace edi
{

CTextDocument::CTextDocument (CEDISettings& settings, const CEDIParticle& rootParticle)
: m_Settings(settings), m_RootParticle(rootParticle), m_nCodePage(CP_ACP), m_bBigEndian(false), m_bBOM(false)
{
}

void CTextDocument::SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM)
{
	m_nCodePage = codepage;
	m_bBigEndian = bBigEndian;
	m_bBOM = bBOM;
}

CTextNode* CTextDocument::ParseFile(const tstring& filename)
{
	tstring buffer;
	if (LoadFileIntoBuffer(filename, buffer, m_nCodePage, m_bBigEndian))
	{
		TrimStart(buffer);
		CEDIParser::Parse(m_RootParticle, buffer.c_str(), m_Generator, m_Settings);
		m_Generator.Done();
		m_Generator.GetRootNode()->SetName(m_RootParticle.GetNode()->GetName());
		return m_Generator.GetRootNode();
	}
	return 0;
}

CGenerator&	CTextDocument::GetGenerator()
{
	return m_Generator;
}

CTextNode* CTextDocument::GetRoot()
{
	return m_Generator.GetRootNode();
}

CDataCompletion* CTextDocument::CreateDataCompletion() const
{
	switch (GetStandard())
	{
	case EDIFact:
		return new CEDIFactDataCompletion(*this, (const CEDIFactSettings&) GetSettings(), GetStructureName());
	case EDIX12:
		return new CEDIX12DataCompletion(*this, (const CEDIX12Settings&) GetSettings(), GetStructureName());
	case EDIHL7:
		return new CEDIHL7DataCompletion(*this, (const CEDIHL7Settings&) GetSettings(), GetStructureName());
	case EDIFixed:
		return new CEDIFixedDataCompletion(*this, (const CEDIFixedSettings&) GetSettings(), GetStructureName());
	case EDITRADACOMS:
		return new CEDITradacomsDataCompletion(*this, (const CEDITradacomsSettings&) GetSettings(), GetStructureName());
	case EDISCRIPT:
		return new CEDIScriptDataCompletion(*this, (const CEDIScriptSettings&) GetSettings(), GetStructureName());
	}
	return NULL;
}
void CTextDocument::Save(const tstring& filename)
{
	CTextNodeContainer* rootnodes = m_Generator.GetRootNodes();

	if (GetSettings().GetAutoCompleteData())
	{
#if __cplusplus < 201103L
		std::auto_ptr<CDataCompletion> datacompletion(CreateDataCompletion());
#else
		std::unique_ptr<CDataCompletion> datacompletion(CreateDataCompletion());
#endif
		for(size_t i = 0; i < rootnodes->GetCount(); ++i)
		{
			datacompletion->CompleteData(rootnodes->GetAt(i), m_RootParticle);
		}
	}

	tstringstream str;

	CEDISemanticValidator validator( GetSettings());
	CEDIWriter writer (str, m_mapMessages, GetSettings(), validator, m_ErrorSettings, GetSettings().GetLineEnd());
	writer.SetNewlineAfterSegments (GetSettings().GetTerminateSegmentsWithLinefeed());
	for(size_t i = 0; i < rootnodes->GetCount(); ++i)
	{
		m_RootParticle.GetNode()->Write (writer, rootnodes->GetAt(i), m_RootParticle);
	}

	SaveFileFromBuffer(filename, str.str(), m_nCodePage, m_bBigEndian, m_bBOM);
}

} // namespace edi
} // namespace text
} // namespace altova
