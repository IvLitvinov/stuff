[call GenerateFileHeader("TextDocument.h")]
#ifndef __ALTOVATEXT_TEXTDOCUMENT_H
#define __ALTOVATEXT_TEXTDOCUMENT_H

#include "Parser.h"
#include "Generator.h"

#include <memory>

namespace altova
{
namespace text
{

class CTextNode;


namespace flex
{

class CFlexCommandProject;

class ALTOVATEXT_DECLSPECIFIER CTextDocument
{
public:
	CTextDocument(int lineend=0);

	CGenerator&	GetGenerator();
	CTextNode* GetRoot();

	void SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM);
		
protected:
	CTextNode* ParseFile(const tstring& filename);
	CTextNode* ParseString(const tstring& str);

	void SaveFile(const tstring& filename);
	virtual void SaveString(tstring &str);

	CFlexCommandProject* m_pFlexProject;
	int m_LineEnd;

private:
	CGenerator m_Generator;
	unsigned m_nCodePage;
	bool m_bBigEndian;
	bool m_bBOM;
};

} // namespace flex


////////////////////////////////////////////////////////////////////////

namespace edi
{

class CEDISettings;
class CDataCompletion;

class ALTOVATEXT_DECLSPECIFIER CTextDocument : public CEDIParser
{
public:
	CGenerator&	GetGenerator();
	CTextNode* GetRoot();
	void Save(const tstring&);

	void SetEncoding(unsigned codepage, bool bBigEndian, bool bBOM);
    virtual EDIStandard GetStandard() const = 0;
    
protected:
	CTextNode* ParseFile(const tstring& filename);

protected:

	CTextDocument (CEDISettings& m_Settings, const CEDIParticle& rootParticle);

protected:
	virtual tstring GetStructureName() const = 0;
	virtual const CEDISettings& GetSettings() const = 0;

private:
	CDataCompletion* CreateDataCompletion() const;

private:
	CEDISettings& m_Settings;
	CGenerator m_Generator;
	unsigned m_nCodePage;
	bool m_bBigEndian;
	bool m_bBOM;
	const CEDIParticle& m_RootParticle;
};

} // namespace edi
} // namespace text
} // namespace altova

#endif
