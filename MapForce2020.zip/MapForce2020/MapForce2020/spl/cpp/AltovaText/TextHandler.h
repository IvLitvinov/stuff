[call GenerateFileHeader("Table.h")]
#ifndef __ALTOVATEXT_TEXTHANDLER_H
#define __ALTOVATEXT_TEXTHANDLER_H

#include "AltovaTextAPI.h"
#include "Table.h"
#include "TextNode.h"
#include "TextDocument.h"
#include "../Altova/xs-types.h"

class TextTreeOperations
{
public:
	class AllIterator
	{
		altova::text::CTextNode* m_Parent;
		size_t m_Position;

	public:
		operator bool() const { 
			return m_Parent->GetChildren()->GetCount() > m_Position; 
		}
		bool operator++() { ++m_Position; return *this; }
		bool operator--() { --m_Position; return *this; }
		altova::text::CTextNode* operator*() const { return m_Parent->GetChildren()->GetAt(m_Position); }

		AllIterator( altova::text::CTextNode* parent ) : m_Parent( parent ), m_Position( 0 ) {}
	};

	class MemberIterator 
	{
		AllIterator m_AllIterator;
		const altova::MemberInfo* m_MemberInfo;

	public:
		operator bool() const { return m_AllIterator; }

		bool operator++() 
		{ 
			while (++m_AllIterator)
			{
				if (IsMember(*m_AllIterator, m_MemberInfo))
					return true;
			}			
			return false;
		}

		bool operator--() 
		{ 
			while (--m_AllIterator)
			{
				if (IsMember(*m_AllIterator, m_MemberInfo))
					return true;
			}			
			return false;
		}

		altova::text::CTextNode* operator*() const { return *m_AllIterator; }		

		MemberIterator(altova::text::CTextNode* pParent, const altova::MemberInfo* pMemberInfo)
			: m_AllIterator( pParent ), m_MemberInfo( pMemberInfo )
		{
			while (m_AllIterator && !IsMember(*m_AllIterator, m_MemberInfo))
				++m_AllIterator;
		}
	};

	static bool IsEqualString(const char_type* a, const char_type* b)
	{
		return _tcscmp(a,b) == 0;
	}

	static bool IsMember(altova::text::CTextNode* pNode, const altova::MemberInfo* pMember)
	{
		return IsEqualString(pNode->GetName().c_str(), pMember->LocalName);
	}

	static bool IsValid(altova::text::CTextNode* pNode)
	{
		return pNode != 0;
	}

	static AllIterator GetElements(altova::text::CTextNode* pNode)
	{
		return AllIterator(pNode);
	}

	static MemberIterator GetElements(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return MemberIterator(pNode, pMemberInfo);
	}

	static void SetTextValue(altova::text::CTextNode* pNode, const string_type& sText)
	{
		pNode->SetValue(sText);
	}

	static string_type GetTextValue(altova::text::CTextNode* pNode)
	{
		return pNode->GetValue();
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, const string_type& sValue)
	{
		if (pMemberInfo->LocalName == 0 || pMemberInfo->LocalName\[0\] == 0)
		{
			pNode->SetValue(sValue);
		}
		else 
		{
			altova::text::CTextNode* pAttNode = pNode->GetChildren()->GetFirstNodeByName(pMemberInfo->LocalName);
			if (pAttNode == 0)
			{
				pAttNode = altova::text::CTextNodeFactory::GetInstance().Create(pNode, pMemberInfo->LocalName);
			}
			pAttNode->SetValue(sValue);
		}
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, bool b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, int b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format((__int64)b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, unsigned b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format((unsigned __int64)b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, __int64 b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, unsigned __int64 b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, double b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, altova::DateTime b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(altova::DateTime(b.Value())));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, altova::Duration b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static void SetValue(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo, const std::vector<unsigned char>& b)
	{
		SetValue(pNode, pMemberInfo, GetFormatter(pMemberInfo)->Format(b));
	}

	static altova::text::CTextNode* AddElement(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		altova::text::CTextNode* pNewChild = altova::text::CTextNodeFactory::GetInstance().Create(pNode, pMemberInfo->LocalName);
		return pNewChild;
	}

	static double CastToDouble(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToDouble(pNode->GetValue());
	}

	static string_type CastToString(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToString(pNode->GetValue());
	}

	static __int64 CastToInt64(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToInt64(pNode->GetValue());
	}

	static unsigned __int64 CastToUInt64(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToUInt64(pNode->GetValue());
	}

	static unsigned CastToUInt(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToUInt(pNode->GetValue());
	}

	static int CastToInt(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToInt(pNode->GetValue());
	}

	static bool CastToBool(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToBool(pNode->GetValue());
	}

	static altova::DateTime CastToDateTime(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToDateTime(pNode->GetValue());
	}

	static altova::Duration CastToDuration(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return altova::CoreTypes::CastToDuration(pNode->GetValue());
	}

	static std::vector<unsigned char> CastToBinary(altova::text::CTextNode* pNode, const altova::MemberInfo* pMemberInfo)
	{
		return GetFormatter(pMemberInfo)->ParseBinary(pNode->GetValue());
	}

	static altova::text::CTextNode* FindAttribute(altova::text::CTextNode* pNode, const altova::MemberInfo* member)
	{
		return pNode->GetChildren()->GetFirstNodeByName(member->LocalName);
	}
	
private:
	static inline altova::XmlFormatter* GetFormatter(const altova::MemberInfo* pMember)
	{
		if (((pMember->Binder->Types + pMember->DataType)->Formatter))
			return static_cast<altova::XmlFormatter*>(*((pMember->Binder->Types + pMember->DataType)->Formatter));
		else
			return static_cast<altova::XmlFormatter*>(altova::AnySimpleTypeFormatter);
	}
};


#endif 
