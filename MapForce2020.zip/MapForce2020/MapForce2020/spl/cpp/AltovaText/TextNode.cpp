[call GenerateFileHeader("TextNode.cpp")]
#include "StdAfx.h"
#include "TextNode.h"
#include "TextException.h"
#include "Helpers.h"

#include <algorithm>

namespace altova
{
	namespace text
	{
		CTextNodeFactory& CTextNodeFactory::GetInstance()
		{
			static CTextNodeFactory instance;
			return instance;
		}

		CTextNodeFactory::CTextNodeFactory()
		{}

		CTextNodeFactory::~CTextNodeFactory()
		{	
			while (m_RegisteredNodes.size())
			{
				delete *m_RegisteredNodes.begin();
				m_RegisteredNodes.erase(m_RegisteredNodes.begin());
			}
		}

		CTextNode* CTextNodeFactory::Create(CTextNode* parent, const tstring& name)
		{
			CTextNode* result= new CTextNode(name, parent);
			m_RegisteredNodes.insert(result);
			return result;
		}

		CRootTextNode* CTextNodeFactory::CreateRootNode(CTextNode* inner)
		{
			CRootTextNode* root = inner ? new CRootTextNode(inner->m_Name, inner->m_Value, inner->m_Children) : new CRootTextNode();
			m_RegisteredNodes.insert(root);
			return root;
		}

		void CTextNodeFactory::Delete(CTextNode* node)
		{
			if (m_RegisteredNodes.end() == m_RegisteredNodes.find(node))
				return;

			if (!node)
				return;

			delete node;
			m_RegisteredNodes.erase(node);
			node = 0;
		}

		// -----------------------------------------------------------------------------------------------
		
		
		CTextNodeContainer* CTextNode::GetChildren()
		{
			if (m_Children == 0)
				m_Children = new COwnedTextNodeContainer(this);
			return m_Children;
		}

		void CTextNode::SetParent(CTextNode* rhs, bool alsoInsert)
		{
			m_Parent = rhs;
			if (!m_Parent) return;

			if (alsoInsert) 
			{
				if (rhs->m_Children == 0)
					rhs->m_Children = new COwnedTextNodeContainer(rhs);
				rhs->m_Children->AddWithoutSettingParent(this);
			}
		}
		
		namespace Internal
		{
			class SearchingFunctor
			{
			public:
				SearchingFunctor(const CTextNode* pattern)
				:	m_Pattern(pattern)
				,	m_Found( FALSE )
				{}

				bool operator() (CTextNode* node)
				{
					m_Found= node->IsContainedInTree(m_Pattern);
					return !m_Found;
				}

				bool HasFound() const
				{
					return m_Found;
				}

			private:
				const CTextNode* m_Pattern;
				bool m_Found;
			};
		}

		bool CTextNode::IsContainedInTree(const CTextNode* rhs) const
		{
			if (!rhs) return false;
			if (this == rhs) return true; 					// TODO I am my own child...
			if (0 == m_Children->GetCount()) return false; 	// ... regardless if I have children or not
			Internal::SearchingFunctor functor(rhs);
			m_Children->ConditionalApplyToAll(functor);
			return functor.HasFound();
		}

		// -----------------------------------------------------------------------------------------------

		
		CTextNodeContainer::CTextNodeContainer ()
		: m_Map (0)
		{
		}

		CTextNodeContainer::~CTextNodeContainer ()
		{
			if (m_Map != 0)
				delete m_Map;
		}

		void CTextNodeContainer::BuildMap() const
		{
			if (m_Map != 0)
				return;

			m_Map = new CName2TextNodePtrVectorMap();

			for (CTextNodePtrVector::const_iterator it = m_List.begin(); it != m_List.end(); ++it)
				AddToMap(*it);
		}

		size_t CTextNodeContainer::GetCount() const
		{
			return m_List.size();
		}

		CTextNode* CTextNodeContainer::GetAt(size_t index) const
		{
			if ((0>index) || (index>=m_List.size()))
				return 0;
			CTextNodePtrVector::const_iterator i= m_List.begin();
			std::advance(i, index);
			return *i;
		}

		bool CTextNodeContainer::Add(CTextNode* rhs)
		{
			m_List.push_back(rhs);
			if (m_Map != 0)
				AddToMap(rhs);
			return true;
		}

		void CTextNodeContainer::Insert(CTextNode* rhs, size_t index)
		{
			CTextNodePtrVector::iterator i= m_List.begin();
			std::advance(i, index);
			m_List.insert(i, rhs);
			if (m_Map != 0)
				AddToMap(rhs);
		}

		void CTextNodeContainer::FilterByName(const tstring& name, CTextNodeContainer& target) const
		{
			BuildMap();
			CName2TextNodePtrVectorMap::const_iterator hit= m_Map->find(name);
			if (((const CName2TextNodePtrVectorMap*)m_Map)->end()!=hit)
			{
				target.m_List= hit->second;
			}
		}
		
		bool CTextNodeContainer::HasNodeByName(const tstring& name) const
		{
			BuildMap();
			CTextNodeContainer matchingchildren;
			FilterByName(name, matchingchildren);
			return (0<matchingchildren.GetCount());
		}

		CTextNode* CTextNodeContainer::GetFirstNodeByName(const tstring& name) const
		{
			BuildMap();
			CTextNodeContainer matchingchildren;
			FilterByName(name, matchingchildren);
			if (0==matchingchildren.GetCount())
				return 0;
			return matchingchildren.GetAt(0);
		}

		CTextNode* CTextNodeContainer::GetLastNodeByName(const tstring& name) const
		{
			BuildMap();
			CTextNodeContainer matchingchildren;
			FilterByName(name, matchingchildren);
			if (0==matchingchildren.GetCount())
				return 0;
			return matchingchildren.GetAt(matchingchildren.GetCount()-1);
		}

		bool CTextNodeContainer::Contains(CTextNode* rhs) const
		{
			CTextNodePtrVector::const_iterator b= m_List.begin(), e= m_List.end();
			CTextNodePtrVector::const_iterator i= std::find(b, e, rhs);
			return (e!=i);
		}

		CTextNodePtrVector& CTextNodeContainer::GetInternalList()
		{
			return m_List;
		}
		
		void CTextNodeContainer::RemoveAt(size_t index)
		{
			CTextNodePtrVector::iterator i= m_List.begin();
			std::advance(i, index);
			if (m_Map != 0)
				RemoveFromMap(*i);
			m_List.erase(i);
		}
		
		void CTextNodeContainer::RemoveAll()
		{
			for( size_t i = 0; i < GetCount(); ++i)
				RemoveAt( i);
		}
		
		void CTextNodeContainer::AddToMap(CTextNode* rhs) const
		{
			tstring key= rhs->GetName();
			
			std::pair<CName2TextNodePtrVectorMap::iterator, bool> tmp = 
				m_Map->insert(CName2TextNodePtrVectorMap::value_type(key, CTextNodePtrVector()));
				
			CName2TextNodePtrVectorMap::iterator& i= tmp.first;
			i->second.push_back(rhs);
		}
		
		void CTextNodeContainer::RemoveFromMap(CTextNode* rhs)
		{
			tstring key= rhs->GetName();
			CName2TextNodePtrVectorMap::iterator& mi= m_Map->find(key);
			CTextNodePtrVector& v = mi->second;
			CTextNodePtrVector::iterator vi = v.begin();
			do
			{
				if (*vi == rhs)
				{
					v.erase(vi);
					break;
				}
				else
				{
					vi++;
				}
			}
			while (vi!= v.end());
		}

		void CTextNodeContainer::MoveNode(CTextNode* rhs, size_t targetIndex)
		{	
			CTextNodePtrVector::iterator i = std::find(m_List.begin(), m_List.end(), rhs);

			if (i - m_List.begin() != targetIndex)
			{
				size_t insertIndex = m_List.begin() + targetIndex > i ? targetIndex - 1 : targetIndex;
				m_List.erase(i);
				m_List.insert(m_List.begin() + insertIndex, rhs);
			}
		}

		// -----------------------------------------------------------------------------------------------
		
		
		COwnedTextNodeContainer::COwnedTextNodeContainer(CTextNode* owner)
		:	m_Owner(owner)
		{}

		COwnedTextNodeContainer::~COwnedTextNodeContainer()
		{
			CTextNodePtrVector& internallist= GetInternalList();
			CTextNodePtrVector::iterator i= internallist.begin(), e= internallist.end();
			for (; i!=e; ++i)
				CTextNodeFactory::GetInstance().Delete(*i);
		}

		void COwnedTextNodeContainer::AddWithoutSettingParent(CTextNode* rhs)
		{
			CTextNodeContainer::Add(rhs);
		}

		bool COwnedTextNodeContainer::Add(CTextNode* rhs)
		{
			rhs->SetParent(m_Owner);
			return true;
		}

		void COwnedTextNodeContainer::Insert(CTextNode* rhs, size_t index)
		{
			ASSERT(!rhs->GetParent());
			CTextNodeContainer::Insert(rhs, index);
			rhs->SetParent(m_Owner, false);
		}
	} // namespace text
} // namespace altova
