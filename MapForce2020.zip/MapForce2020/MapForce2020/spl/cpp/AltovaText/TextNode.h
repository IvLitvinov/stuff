[call GenerateFileHeader("TextNode.h")]
#ifndef __ALTOVATEXT_TEXTNODE_H
#define __ALTOVATEXT_TEXTNODE_H

#include "AltovaTextAPI.h"

#include <list>

namespace altova
{
	namespace text
	{

		class CTextNode;
		typedef std::list<CTextNode*>		CTextNodePtrList;
		typedef std::vector<CTextNode*>		CTextNodePtrVector;

		class ALTOVATEXT_DECLSPECIFIER CTextNodeContainer
		{
		public:
			size_t GetCount() const;
			CTextNode* GetAt(size_t index) const;
			virtual bool Add(CTextNode* rhs);
			virtual void Insert(CTextNode* rhs, size_t index);
			void FilterByName(const tstring& name, CTextNodeContainer& target) const;
			bool HasNodeByName(const tstring& name) const;
			CTextNode* GetFirstNodeByName(const tstring& name) const;
			CTextNode* GetLastNodeByName(const tstring& name) const;
			bool Contains(CTextNode* rhs) const;
			void RemoveAt(size_t index);
			void RemoveAll();
			void MoveNode(CTextNode* rhs, size_t targetIndex);

			template <class VoidFunctor>
			inline void ApplyToAll(VoidFunctor& functor) const
			{
				CTextNodePtrVector::const_iterator i= m_List.begin(), e = m_List.end();
				for(; i!=e; ++i) functor(*i);
			}

			template <class BoolFunctor>
			inline bool ConditionalApplyToAll(BoolFunctor& functor) const
			{
				bool docontinue = TRUE;
				CTextNodePtrVector::const_iterator i= m_List.begin(), e= m_List.end();
				for(; i!=e && docontinue; ++i) docontinue= functor(*i);
				return docontinue;
			}

			virtual ~CTextNodeContainer();
			CTextNodeContainer();
		protected:
			CTextNodePtrVector& GetInternalList();

		private:
			void AddToMap(CTextNode*) const;
			void RemoveFromMap(CTextNode*);
			void BuildMap() const;

		private:
			typedef std::map<tstring, CTextNodePtrVector> CName2TextNodePtrVectorMap;
			mutable CName2TextNodePtrVectorMap* m_Map;
			CTextNodePtrVector m_List;
		};

		//////////////////////////////////////////////////////////////////////////


		class ALTOVATEXT_DECLSPECIFIER COwnedTextNodeContainer : public CTextNodeContainer
		{
		public:
			COwnedTextNodeContainer(CTextNode* owner);
			~COwnedTextNodeContainer();

			void AddWithoutSettingParent(CTextNode* rhs);

		public: // overriding CTextNodeContainer
			virtual bool Add(CTextNode* rhs);
			virtual void Insert(CTextNode* rhs, size_t index);

		private:
			CTextNode* m_Owner;
		};

		//////////////////////////////////////////////////////////////////////////

		enum ENodeClass
		{
			Undefined,
			DataElement,
			Composite,
			Segment,
			Group,
			SubComposite,
			ErrorList,
			Select
		};

		//////////////////////////////////////////////////////////////////////////

		class CRootTextNode;

		class ALTOVATEXT_DECLSPECIFIER CTextNodeFactory
		{
		public:
			static CTextNodeFactory& GetInstance();
			~CTextNodeFactory();
			CTextNode* Create(CTextNode*, const tstring&);
			CRootTextNode* CreateRootNode(CTextNode* = 0);
			void Delete(CTextNode*);

		private:
			CTextNodeFactory();

		private:
			typedef std::set<CTextNode*> CTextNodePtrSet;
			CTextNodePtrSet m_RegisteredNodes;
		};

		//////////////////////////////////////////////////////////////////////////

		class ALTOVATEXT_DECLSPECIFIER CTextNode
		{
		friend CTextNodeFactory;

		public:
			virtual CTextNode* GetRoot() { return (!m_Parent) ? this : m_Parent->GetRoot(); }
			virtual CTextNode* GetParent() const { return m_Parent; }
			virtual void SetParent(CTextNode*, bool insert = true);

			virtual CTextNodeContainer* GetChildren();
			
			virtual tstring GetName() const { return m_Name; }
			virtual tstring GetValue() const { return m_Value; }
			virtual ENodeClass GetClass() const { return m_Class; }
			
			virtual void SetName(const tstring& name) { m_Name =  name; }
			virtual void SetValue(const tstring& value) { m_Value = value; }
			virtual void SetClass(ENodeClass nodeClass) { m_Class = nodeClass; }
			
			virtual bool IsContainedInTree(const CTextNode*) const;

		protected:
			CTextNode() : m_Children(0), m_Parent(0), m_Name(_T("")), m_Value(_T("")), m_Class(Undefined) {}
			CTextNode(const tstring& name, CTextNode* parent) : m_Children(0), m_Name(name), m_Value(_T("")), m_Class(Undefined) 
			{
				SetParent(parent);
			}
			CTextNode(ENodeClass c) : m_Children(0), m_Parent(0), m_Name(_T("")), m_Value(_T("")), m_Class(c) {}
			CTextNode(const tstring& name, const tstring value, COwnedTextNodeContainer* children, ENodeClass c) 
				: m_Children(children), m_Parent(0), m_Name(name), m_Value(value), m_Class(c) {}
			
			virtual ~CTextNode() { if (m_Children)	delete m_Children; }

		private:
			COwnedTextNodeContainer* m_Children;
			CTextNode* m_Parent;
			tstring m_Name;
			tstring m_Value;
			ENodeClass m_Class;
		};


		//////////////////////////////////////////////////////////////////////////

		class ALTOVATEXT_DECLSPECIFIER CRootTextNode : public CTextNode
		{
		friend CTextNodeFactory;

		private:
			CRootTextNode() : CTextNode(Group) {}
			CRootTextNode(const tstring& name, const tstring& value, COwnedTextNodeContainer* children) 
				: CTextNode(name, value, children, Group) {}
			virtual ~CRootTextNode() {}
			
		public: // overriding CTextNode
			virtual CTextNode* GetRoot() { return this; }
			virtual CTextNode* GetParent() const { return 0; }
			virtual void SetClass(ENodeClass) {}
		};
	} // namespace text
} // namespace altova

#endif
