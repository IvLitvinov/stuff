[call GenerateFileHeader("MFNodeAdapters_DOM.cpp")]



#include "stdafx.h"
#include "MFNodeAdapters_DOM.h"
#include "Node.h"


using namespace altova::mapforce;


MFNodeKind DOMNodeAsMFNodeAdapter::GetNodeKind() const
{	
	MSXML2::DOMNodeType t = node->nodeType;
	
	switch (t)
	{
	case MSXML2::NODE_ATTRIBUTE:
		return k_Attribute; // also field?
	case MSXML2::NODE_CDATA_SECTION:
		return (MFNodeKind) (k_Text | k_CData);
	case MSXML2::NODE_COMMENT:
		return k_Comment;
	case MSXML2::NODE_DOCUMENT:
		return k_Document;
	case MSXML2::NODE_ELEMENT:
		return k_Element;
	case MSXML2::NODE_TEXT:
		return k_Text;
	case MSXML2::NODE_PROCESSING_INSTRUCTION:
		return k_ProcessingInstruction;
	default:
		return k_Unknown;
	}
}

Enumerable* DOMNodeAsMFNodeAdapter::Select(MFQueryKind kind, const QName& query) const
{
	MSXML2::DOMNodeType t = node->nodeType;
	
	switch (kind)
	{
	case k_All:
		switch (t)
		{
			case MSXML2::NODE_ELEMENT:
				return new SequenceJoin(new DOMAttributesAsMFNodeSequenceAdapter(node), new DOMChildrenAsMFNodeSequenceAdapter(node));
				
			case MSXML2::NODE_DOCUMENT:
				return new DOMChildrenAsMFNodeSequenceAdapter(node);

			case MSXML2::NODE_ATTRIBUTE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));

			case MSXML2::NODE_TEXT:
			case MSXML2::NODE_CDATA_SECTION:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
				
			case MSXML2::NODE_PROCESSING_INSTRUCTION:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
				
			case MSXML2::NODE_COMMENT:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
				
			default:
				return MFEmptySequence::Instance();
		}
	
	case k_AllChildren:
		switch (t)
		{
			case MSXML2::NODE_ELEMENT:
			case MSXML2::NODE_DOCUMENT:
				return new DOMChildrenAsMFNodeSequenceAdapter(node);

			case MSXML2::NODE_ATTRIBUTE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));

			case MSXML2::NODE_TEXT:
			case MSXML2::NODE_CDATA_SECTION:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
			
			case MSXML2::NODE_PROCESSING_INSTRUCTION:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
				
			case MSXML2::NODE_COMMENT:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(node->text)));
			
			default:
				return MFEmptySequence::Instance();
		}

	case k_AllAttributes:
		switch (t)
		{
		case MSXML2::NODE_ELEMENT:
		case MSXML2::NODE_DOCUMENT:
			return new DOMAttributesAsMFNodeSequenceAdapter(node);

		default:
			return MFEmptySequence::Instance();
		}

	case k_ChildrenByQName:
		switch (t)
		{
		case MSXML2::NODE_ELEMENT:
		case MSXML2::NODE_DOCUMENT:
			return new MFNodeByKindAndQNameFilter(new DOMChildrenAsMFNodeSequenceAdapter(node), k_Element, query);

		default:
			return MFEmptySequence::Instance();
		}

	case k_SelfByQName:
		switch (t)
		{
		case MSXML2::NODE_ELEMENT:
		case MSXML2::NODE_ATTRIBUTE:
			if (QName_from_node(node) == query)
				return new MFSingletonSequence((MFNode*) this);
			else
				return MFEmptySequence::Instance();

		default:
			return MFEmptySequence::Instance();
		}

	case k_AttributeByQName:
		switch (t)
		{
			case MSXML2::NODE_ELEMENT:
			{
				string_type l = query.localName;
				string_type u = query.namespaceUri;

				MSXML2::IXMLDOMNodePtr att = node->attributes->getQualifiedItem(_bstr_t(l.c_str()), _bstr_t(u.c_str()));

				if (att)
					return new MFSingletonSequence(new DOMNodeAsMFNodeAdapter(att, node));
				else
					return MFEmptySequence::Instance();
			}

			default:
				return MFEmptySequence::Instance();
		}

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

altova::QName DOMNodeAsMFNodeAdapter::GetQNameValue()
{
	string_type value(node->text);
	size_t i =  value.find(_T(':'));
	if (i == string_type::npos)
		return altova::QName(string_type(FindNamespaceUriForPrefix(refNode, _bstr_t(_T("")))), value);

	string_type prefix = value.substr(0, i);
	string_type local = value.substr(i+1);

	string_type uri = FindNamespaceUriForPrefix(refNode, _bstr_t(prefix.c_str()));

	return altova::QName(uri, prefix, local);
}

_bstr_t DOMNodeAsMFNodeAdapter::FindNamespaceUriForPrefix(const MSXML2::IXMLDOMNodePtr& pNode, const _bstr_t& prefix)
{
	if ( prefix == _bstr_t(_T("xml")) )
		return _bstr_t(_T("http://www.w3.org/XML/1998/namespace"));

	if (pNode->nodeType == MSXML2::NODE_ELEMENT)
	{
		_bstr_t ns = _bstr_t(_T("xmlns"));
		if (prefix.length())
			ns = _bstr_t(_T("xmlns:")) + prefix;

		MSXML2::IXMLDOMNodePtr item = pNode->attributes->getNamedItem(ns);
		if (item)
			return item->text;
	}

	if (pNode->parentNode != 0 && pNode->parentNode->nodeType != MSXML2::NODE_DOCUMENT)
		return FindNamespaceUriForPrefix(pNode->parentNode, prefix);

	return _bstr_t(_T(""));
}
