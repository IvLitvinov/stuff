[call GenerateFileHeader("MFNodeAdapters_DOM.h")]

#ifndef MF_NODE_ADAPTERS_DOM_H
#define MF_NODE_ADAPTERS_DOM_H

#include "AltovaXMLAPI.h"
#include "../Altova/AltovaMapforce.h"
#include "Node.h"
#import "[=$msxml_dll]" no_implementation no_auto_exclude

namespace altova
{
	namespace mapforce
	{
		static QName QName_from_node(const MSXML2::IXMLDOMNodePtr& n)
		{
            if( n->nodeType == MSXML2::NODE_ATTRIBUTE)
			{
				MSXML2::IXMLDOMAttributePtr e = n;
				string_type sL = e->baseName.length() == 0 ? _T( "" ) : e->baseName;
				string_type sU = e->namespaceURI.length() == 0 ? _T("") : e->namespaceURI;
				string_type sP = e->prefix.length() == 0 ? _T( "" ) : e->prefix;
				return QName( sL, sU, sP);
			}
            
			if (n->nodeType == MSXML2::NODE_PROCESSING_INSTRUCTION)
				return QName(string_type(n->nodeName));
				
			if (n->nodeType == MSXML2::NODE_ELEMENT)
			{
				MSXML2::IXMLDOMElementPtr e = n;
				string_type sL = e->baseName.length() == 0 ? _T("") : e->baseName;
				string_type sU = e->namespaceURI.length() == 0 ? _T("") : e->namespaceURI;
				string_type sP = e->prefix.length() == 0 ? _T("") : e->prefix;
				return QName(sL, sU, sP);
			}
			return QName();
		}

		class ALTOVAXML_DECLSPECIFIER DOMNodeAsMFNodeAdapter : public MFNode
		{
		public:
			DOMNodeAsMFNodeAdapter(const MSXML2::IXMLDOMNodePtr& n, const MSXML2::IXMLDOMNodePtr& rn = 0) 
				: MFNode(QName_from_node(n)), node(n), refNode(rn == 0?n:rn) 
				{
					if (rn == 0 && n->nodeType == MSXML2::NODE_ATTRIBUTE)
						throw altova::CAltovaException(0, _T("Attribute node without owner node; QName values cannot be resolved."));
				}
			~DOMNodeAsMFNodeAdapter() {}

			MFNodeKind GetNodeKind() const;
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const 
			{
				string_type s = (const char_type*) node->text;
				return s;
			}
			altova::QName GetQNameValue();

		private:
			MSXML2::IXMLDOMNodePtr node;
			MSXML2::IXMLDOMNodePtr refNode;
			_bstr_t FindNamespaceUriForPrefix(const MSXML2::IXMLDOMNodePtr& pNode, const _bstr_t& prefix);
		};

		class ALTOVAXML_DECLSPECIFIER DOMDocumentNodeAsMFNodeAdapter : public DOMNodeAsMFNodeAdapter, public MFDocumentNode
		{
		public:
			DOMDocumentNodeAsMFNodeAdapter(const MSXML2::IXMLDOMNodePtr& n, const string_type& f) : DOMNodeAsMFNodeAdapter(n), MFDocumentNode(f) {}
		};

		class ALTOVAXML_DECLSPECIFIER DOMChildrenAsMFNodeSequenceAdapter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(const MSXML2::IXMLDOMNodePtr& n, Enumerable* cls) : Enumerator(cls), from(n), current(0) {} 
				~Enum() {}
				IMFNode GetCurrent() 
				{
					if (current) 
						return new DOMNodeAsMFNodeAdapter(current); 
					throw altova::CAltovaException(0, _T("No current."));
				}
				bool MoveNext()
				{
					if ( pos && current == 0)
						return false;
						
					current = (pos == 0) ? from->firstChild : current->nextSibling; 
					if (current != 0)
					{
						pos++;
						return true;
					}
					return false;
				}
			private:
				MSXML2::IXMLDOMNodePtr from;
				MSXML2::IXMLDOMNodePtr current;
			};

		public:
			DOMChildrenAsMFNodeSequenceAdapter(const MSXML2::IXMLDOMNodePtr& n) : Enumerable(), from(n) {}
			~DOMChildrenAsMFNodeSequenceAdapter() {}; 

			Enumerator* GetEnumerator() {return new Enum(from, this);}
		private:
			MSXML2::IXMLDOMNodePtr from;
		};

		
		class ALTOVAXML_DECLSPECIFIER DOMAttributesAsMFNodeSequenceAdapter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(const MSXML2::IXMLDOMNodePtr& n, Enumerable* cls) : Enumerator(cls), from(n), current(-1) {} 
				~Enum() {}
				
				IMFNode GetCurrent() 
				{
					MSXML2::IXMLDOMElementPtr from_el = from;
					if (current > -1)
						return new DOMNodeAsMFNodeAdapter(from_el->attributes->item\[current\], from_el);
					throw altova::CAltovaException(0, _T("No current."));
				}
				bool MoveNext() 
				{
					MSXML2::IXMLDOMElementPtr from_el = from;
					++current; 
					if (current < from_el->attributes->length)
					{
						pos++;
						return true;
					}
					return false;
				}
			private:
				MSXML2::IXMLDOMNodePtr from;
				int current;
			};

		public:
			DOMAttributesAsMFNodeSequenceAdapter(const MSXML2::IXMLDOMNodePtr& n) : Enumerable(), from(n) {}
			~DOMAttributesAsMFNodeSequenceAdapter() {}; 

			Enumerator* GetEnumerator() {return new Enum(from, this);}
		private:
			MSXML2::IXMLDOMNodePtr from;
		};
		
		static string_type GetValue(IMFNode& node, MSXML2::IXMLDOMNodePtr ctx)
		{
			MFNode* mfnode = node;
			if (dynamic_cast<MFSimpleNode<altova::QName>*> (mfnode))
			{
				altova::QName q = node;

				if (q.Uri.empty())
					return q.LocalName;

				string_type prefix = FindPrefixForNamespace(ctx, _bstr_t(q.Uri.c_str()));
				if (prefix.empty())
				{
					prefix = GetUnusedPrefix(ctx, q.Uri, q.Prefix);
					MSXML2::IXMLDOMElementPtr el = ctx;
					el->setAttribute(_bstr_t(_T("xmlns:")) + _bstr_t(prefix.c_str()), _bstr_t(q.Uri.c_str()));
				}
				
				size_t i = q.LocalName.find(_T(':'));
				if (i == string_type::npos)
					return prefix + string_type(_T(":")) + q.LocalName;
				return prefix + q.LocalName.substr(i);
			}

			if (mfnode->GetNodeKind() == k_AttributeOrField)
			{
				// value is the value of child
				altova::mapforce::IEnumerator r(mfnode->Select((k_AllChildren))); 
				if (r.MoveNext())
				{
					IMFNode n = r.GetCurrent();
					if (dynamic_cast<MFSimpleNode<altova::QName>*> ((MFNode*) n))
						return GetValue(n, ctx);
				}
			}

			return node->GetValue();
		}
				
		static void MFDomWrite(Enumerable* what, MSXML2::IXMLDOMNodePtr& where)
		{
			MSXML2::IXMLDOMDocument2Ptr owner = (where->nodeType == MSXML2::NODE_DOCUMENT) ? where : where->ownerDocument;

			for (IEnumerator en = what; en.MoveNext();)
			{
				IMFNode el = en.GetCurrent();
				if ((el->GetNodeKind() & k_Element) != 0)
				{
					MSXML2::IXMLDOMElementPtr xel;
					
					if (el->GetPrefix().IsNull())
					{
						_bstr_t prefix = FindPrefixForNamespace(where, _bstr_t(el->GetNamespaceURI().c_str()));
						if (prefix.length() == 0)
							xel = owner->createNode(_variant_t((short)MSXML2::NODE_ELEMENT), _bstr_t(el->GetLocalName().c_str()), _bstr_t(el->GetNamespaceURI().c_str()));
						else
							xel = owner->createNode(_variant_t((short)MSXML2::NODE_ELEMENT), prefix + _bstr_t(_T(":")) + _bstr_t(el->GetLocalName().c_str()), _bstr_t(el->GetNamespaceURI().c_str()));
					}
					else if (el->GetPrefix().IsEmpty())
						xel = owner->createNode(_variant_t((short)MSXML2::NODE_ELEMENT), _bstr_t(el->GetLocalName().c_str()), _bstr_t(el->GetNamespaceURI().c_str()));
					else
						xel = owner->createNode(_variant_t((short)MSXML2::NODE_ELEMENT), _bstr_t(el->GetPrefix().GetPrefix().c_str()) + _bstr_t(_T(":")) + _bstr_t(el->GetLocalName().c_str()), _bstr_t(el->GetNamespaceURI().c_str()));

					where->appendChild(xel);
					MSXML2::IXMLDOMNodePtr xel_but_node = xel;
					MFDomWrite(el->Select(k_All), xel_but_node);
				}
				else if ((el->GetNodeKind() & k_Attribute) != 0)
				{
					if (el->GetPrefix().IsNull())
					{
						_bstr_t prefix = FindPrefixForNamespace(where, _bstr_t(el->GetNamespaceURI().c_str()));
						if (prefix.length() == 0 || el->GetLocalName() == _T("xmlns"))
							MsxmlTreeOperations::SetAttribute(where, el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, where));
						else
							MsxmlTreeOperations::SetAttribute(where, string_type(prefix) + _T(":") + el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, where));
					}
					else if (el->GetPrefix().IsEmpty())
						MsxmlTreeOperations::SetAttribute(where, el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, where));
					else
						MsxmlTreeOperations::SetAttribute(where, el->GetPrefix().GetPrefix() + _T(":") + el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, where));
				}
				else if ((el->GetNodeKind() & k_Comment) != 0)
				{
					where->appendChild(owner->createComment(_bstr_t(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_ProcessingInstruction) != 0)
				{
					where->appendChild(owner->createProcessingInstruction(_bstr_t(el->GetLocalName().c_str()), _bstr_t(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_CData) != 0)
				{
					where->appendChild(owner->createCDATASection(_bstr_t(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_TextOrSimple) != 0)
				{
					string_type s = GetValue(el, where);
					if (!s.empty())
						where->appendChild(owner->createTextNode(_bstr_t(s.c_str())));
				}
			}
		}
		
		static void MFDomWrite(Enumerable* what, MsxmlTreeOperations::DocumentType& where)
		{
			MFDomWrite(what, (MSXML2::IXMLDOMNodePtr&) where);
		}

	} // namespace mapforce
} // namespace altova

#endif