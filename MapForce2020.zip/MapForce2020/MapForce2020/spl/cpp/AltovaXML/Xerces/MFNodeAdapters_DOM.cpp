[call GenerateFileHeader("MFNodeAdapters_DOM.cpp")]




#include "stdafx.h"
#include "MFNodeAdapters_DOM.h"
#include "Node.h"

using namespace altova::mapforce;


MFNodeKind DOMNodeAsMFNodeAdapter::GetNodeKind() const
{	
	switch (node->getNodeType())
	{
	case xercesc::DOMNode::ATTRIBUTE_NODE:
		return k_Attribute; // also field?
	case xercesc::DOMNode::CDATA_SECTION_NODE:
		return (MFNodeKind) (k_Text | k_CData);
	case xercesc::DOMNode::COMMENT_NODE:
		return k_Comment;
	case xercesc::DOMNode::DOCUMENT_NODE:
		return k_Document;
	case xercesc::DOMNode::ELEMENT_NODE:
		return k_Element;
	case xercesc::DOMNode::TEXT_NODE:
		return k_Text;
	case xercesc::DOMNode::PROCESSING_INSTRUCTION_NODE:
		return k_ProcessingInstruction;
	default:
		return k_Unknown;
	}
}

Enumerable* DOMNodeAsMFNodeAdapter::Select(MFQueryKind kind, const QName& query) const
{
	switch (kind)
	{
	case k_All:
		switch (node->getNodeType())
		{
			case xercesc::DOMNode::ELEMENT_NODE:
				return new SequenceJoin(new DOMAttributesAsMFNodeSequenceAdapter(node), new DOMChildrenAsMFNodeSequenceAdapter(node));
				
			case xercesc::DOMNode::DOCUMENT_NODE:
				return new DOMChildrenAsMFNodeSequenceAdapter(node);

			case xercesc::DOMNode::ATTRIBUTE_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));

			case xercesc::DOMNode::TEXT_NODE:
			case xercesc::DOMNode::CDATA_SECTION_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			case xercesc::DOMNode::PROCESSING_INSTRUCTION_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			case xercesc::DOMNode::COMMENT_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			default:
				return MFEmptySequence::Instance();
		}
	
	case k_AllChildren:
		switch (node->getNodeType())
		{
			case xercesc::DOMNode::ELEMENT_NODE:
			case xercesc::DOMNode::DOCUMENT_NODE:
				return new DOMChildrenAsMFNodeSequenceAdapter(node);

			case xercesc::DOMNode::ATTRIBUTE_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));

			case xercesc::DOMNode::TEXT_NODE:
			case xercesc::DOMNode::CDATA_SECTION_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			case xercesc::DOMNode::PROCESSING_INSTRUCTION_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			case xercesc::DOMNode::COMMENT_NODE:
				return new MFSingletonSequence(new MFSimpleNode<string_type>(string_type(XercesUnstringTemp(node->getNodeValue()))));
				
			default:
				return MFEmptySequence::Instance();
		}

	case k_AllAttributes:
		switch (node->getNodeType())
		{
		case xercesc::DOMNode::ELEMENT_NODE:
		case xercesc::DOMNode::DOCUMENT_NODE:
			return new DOMAttributesAsMFNodeSequenceAdapter(node);

		default:
			return MFEmptySequence::Instance();
		}

	case k_ChildrenByQName:
		switch (node->getNodeType())
		{
		case xercesc::DOMNode::ELEMENT_NODE:
		case xercesc::DOMNode::DOCUMENT_NODE:
			return new MFNodeByKindAndQNameFilter(new DOMChildrenAsMFNodeSequenceAdapter(node), k_Element, query);

		default:
			return MFEmptySequence::Instance();
		}

	case k_SelfByQName:
		switch (node->getNodeType())
		{
		case xercesc::DOMNode::ELEMENT_NODE:
		case xercesc::DOMNode::ATTRIBUTE_NODE:
			if (QName_from_node(node) == query)
				return new MFSingletonSequence((MFNode*) this);
			else
				return MFEmptySequence::Instance();

		default:
			return MFEmptySequence::Instance();
		}

	case k_AttributeByQName:
		switch (node->getNodeType())
		{
			case xercesc::DOMNode::ELEMENT_NODE:
			{
				const string_type& l = query.localName;
				const string_type& u = query.namespaceUri;

				xercesc::DOMNode* att = node->getAttributes()->getNamedItemNS(XercesStringTemp(u.c_str()), XercesStringTemp(l.c_str()));

				if (att)
					return new MFSingletonSequence(new DOMNodeAsMFNodeAdapter(att, node));
				else
					return MFEmptySequence::Instance();
			}

			default:
				return MFEmptySequence::Instance();
		}

	default:
		throw altova::CAltovaException(0, _T("Unsupported query type."));
	}
}

altova::QName DOMNodeAsMFNodeAdapter::GetQNameValue()
{
	string_type value(GetValue());
	size_t i =  value.find(_T(':'));
	if (i == string_type::npos)
		return altova::QName(FindNamespaceUriForPrefix(refNode, _T("")), value);

	string_type prefix = value.substr(0, i);
	string_type local = value.substr(i+1);

	string_type uri = FindNamespaceUriForPrefix(refNode, prefix.c_str());

	return altova::QName(uri, prefix, local);
}

string_type DOMNodeAsMFNodeAdapter::FindNamespaceUriForPrefix(const xercesc::DOMNode* node, const string_type& prefix)
{
	if ( prefix == string_type(_T("xml")) )
		return string_type(_T("http://www.w3.org/XML/1998/namespace"));

	if (node->getNodeType() == xercesc::DOMNode::ELEMENT_NODE)
	{
		string_type ns = prefix.empty() ?
			string_type(_T("xmlns")) :
			string_type(_T("xmlns:") + prefix);

		xercesc::DOMNode* item = node->getAttributes()->getNamedItem(XercesStringTemp(ns));
		if (item)
			return XercesTreeOperations::GetTextValue(item);
	}

	if (node->getParentNode() != 0 && node->getParentNode()->getNodeType() != xercesc::DOMNode::DOCUMENT_NODE)
		return FindNamespaceUriForPrefix(node->getParentNode(), prefix);

	return string_type();
}
