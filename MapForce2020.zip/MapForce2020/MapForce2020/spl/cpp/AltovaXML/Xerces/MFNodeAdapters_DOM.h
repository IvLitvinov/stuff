[call GenerateFileHeader("MFNodeAdapters_DOM.h")]





#ifndef MF_NODE_ADAPTERS_DOM_H
#define MF_NODE_ADAPTERS_DOM_H

#include "AltovaXMLAPI.h"
#include "../Altova/AltovaMapforce.h"
#include "Node.h"
#include "XercesString.h"
#include "memory"

namespace altova
{
	namespace mapforce
	{
		static QName QName_from_node(xercesc::DOMNode* n)
		{
			if (n->getNodeType() == xercesc::DOMNode::PROCESSING_INSTRUCTION_NODE)
				return QName(string_type(XercesUnstringTemp(n->getNodeName())));
			return QName(string_type(XercesUnstringTemp(n->getLocalName())), string_type(XercesUnstringTemp(n->getNamespaceURI())), string_type(XercesUnstringTemp(n->getPrefix())));
		}


		class ALTOVAXML_DECLSPECIFIER DOMNodeAsMFNodeAdapter : public MFNode
		{
		public:
			DOMNodeAsMFNodeAdapter(xercesc::DOMNode* n, xercesc::DOMNode* rn = 0)
				: MFNode(QName_from_node(n)), node(n), refNode(rn == 0?n:rn)
				{
					if (rn == 0 && n->getNodeType() == xercesc::DOMNode::ATTRIBUTE_NODE)
						throw altova::CAltovaException(0, _T("Attribute node without owner node; QName values cannot be resolved."));
				}
			~DOMNodeAsMFNodeAdapter() {}

			MFNodeKind GetNodeKind() const;
			Enumerable* Select(MFQueryKind kind, const QName& query = QName()) const;
			string_type GetValue() const 
			{
				return XercesTreeOperations::CastToString( node, 0 );
			}
			altova::QName GetQNameValue();

		private:
			xercesc::DOMNode* node;
			xercesc::DOMNode* refNode;
			string_type FindNamespaceUriForPrefix(const xercesc::DOMNode* node, const string_type& prefix);
		};

		class ALTOVAXML_DECLSPECIFIER DOMDocumentNodeAsMFNodeAdapter : public DOMNodeAsMFNodeAdapter, public MFDocumentNode
		{
		public:
			DOMDocumentNodeAsMFNodeAdapter(xercesc::DOMNode* n, const string_type& f) : DOMNodeAsMFNodeAdapter(n), MFDocumentNode(f) {}
		};

		class ALTOVAXML_DECLSPECIFIER DOMChildrenAsMFNodeSequenceAdapter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(xercesc::DOMNode* n, Enumerable* cls) : Enumerator(cls), from(n), current(0)  {} 
				~Enum() {}
				IMFNode GetCurrent() 
				{
					if (current)
						return IMFNode(new DOMNodeAsMFNodeAdapter(current));  

					throw altova::CAltovaException(0, _T("No current."));
				}

				bool MoveNext()
				{
					if ( pos && current == 0)
						return false;
						
					current = (pos == 0) ? from->getFirstChild() : current->getNextSibling(); 
					if (current != 0)
					{
						pos++;
						return true;
					}
					return false;
				}
			private:
				xercesc::DOMNode* from;
				xercesc::DOMNode* current;
			};

		public:
			DOMChildrenAsMFNodeSequenceAdapter(xercesc::DOMNode* n) : Enumerable(), from(n) {}
			~DOMChildrenAsMFNodeSequenceAdapter() {}; 

			Enumerator* GetEnumerator() {return new Enum(from, this);}
		private:
			xercesc::DOMNode* from;
		};

		
		class ALTOVAXML_DECLSPECIFIER DOMAttributesAsMFNodeSequenceAdapter : public Enumerable
		{
			class Enum : public Enumerator
			{
			public:
				Enum(xercesc::DOMNode* n, Enumerable* cls) : Enumerator(cls), from(n), current(-1) {} 
				~Enum() {}
				IMFNode GetCurrent() 
				{
					if (current > -1)
						return IMFNode(new DOMNodeAsMFNodeAdapter(from->getAttributes()->item(current), from));
					throw altova::CAltovaException(0, _T("No current."));
				}
				bool MoveNext() 
				{
					++current; 
					if (current < static_cast<int>(from->getAttributes()->getLength()))
					{
						pos++;
						return true;
					}
					return false;
				}
			private:
				xercesc::DOMNode* from;
				int current;
			};

		public:
			DOMAttributesAsMFNodeSequenceAdapter(xercesc::DOMNode* n) : Enumerable(), from(n) {}
			~DOMAttributesAsMFNodeSequenceAdapter() {}; 

			Enumerator* GetEnumerator() {return new Enum(from, this);}
		private:
			xercesc::DOMNode* from;
		};
		
		static string_type GetValue(IMFNode& node, xercesc::DOMNode* ctx)
		{
			MFNode* mfnode = node;
			if (dynamic_cast<MFSimpleNode<altova::QName>*> (mfnode))
			{
				altova::QName q = node;

				if (q.Uri.empty())
					return q.LocalName;

				string_type prefix = FindPrefixForNamespace(ctx, q.Uri);
				if (prefix.empty())
				{
					prefix = GetUnusedPrefix(ctx, q.Prefix);
					xercesc::DOMElement* el = static_cast<xercesc::DOMElement*>(ctx);
					string_type ns = _T("xmlns:");
					ns += prefix;
					el->setAttributeNS(XercesStringTemp(_T("http://www.w3.org/2000/xmlns/")), XercesStringTemp(ns), XercesStringTemp(q.Uri));
				}
				size_t i = q.LocalName.find(_T(':'));
				if (i == string_type::npos)
					return prefix + string_type(_T(":")) + q.LocalName;
				return prefix + q.LocalName.substr(i);
			}

			if (mfnode->GetNodeKind() == k_AttributeOrField)
			{
				// value is the value of child
				altova::mapforce::IEnumerator r(mfnode->Select((k_AllChildren))); 
				if (r.MoveNext())
				{
					IMFNode n = r.GetCurrent();
					if (dynamic_cast<MFSimpleNode<altova::QName>*> ((MFNode*) n))
						return GetValue(n, ctx);
				}
			}

			return node->GetValue();
		}
		
		static void MFDomWrite(Enumerable* what, xercesc::DOMNode* where)
		{
			xercesc::DOMDocument* owner = (where->getNodeType() == xercesc::DOMNode::DOCUMENT_NODE) ? (xercesc::DOMDocument*) where : where->getOwnerDocument();
		
			for (IEnumerator en = what; en.MoveNext();)
			{
				IMFNode el = en.GetCurrent();
				if ((el->GetNodeKind() & k_Element) != 0)
				{
					xercesc::DOMElement* xel;

					if (el->GetPrefix().IsNull())
					{
						string_type prefix = FindPrefixForNamespace(where, el->GetNamespaceURI());
						if (prefix.empty())
							xel = owner->createElementNS(XercesStringTemp(el->GetNamespaceURI().c_str()), XercesStringTemp(el->GetLocalName().c_str()));
						else
							xel = owner->createElementNS(XercesStringTemp(el->GetNamespaceURI().c_str()), XercesStringTemp(prefix + _T(":") + el->GetLocalName().c_str()));
					}
					else if (el->GetPrefix().IsEmpty())
						xel = owner->createElementNS(XercesStringTemp(el->GetNamespaceURI().c_str()), XercesStringTemp(el->GetLocalName().c_str()));
					else
						xel = owner->createElementNS(XercesStringTemp(el->GetNamespaceURI().c_str()), XercesStringTemp(el->GetPrefix().GetPrefix() + _T(":") + el->GetLocalName().c_str()));

					where->appendChild(xel);
					MFDomWrite(el->Select(k_All), xel);
				}
				else if ((el->GetNodeKind() & k_Attribute) != 0)
				{
					xercesc::DOMElement* xel = (xercesc::DOMElement*) where;

					if (el->GetPrefix().IsNull())
					{
						string_type prefix = FindPrefixForNamespace(where, el->GetNamespaceURI());
						if (prefix.empty())
							XercesTreeOperations::SetAttribute(xel, el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, xel));
						else
							XercesTreeOperations::SetAttribute(xel, prefix + _T(":") +el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, xel));
					}
					else if (el->GetPrefix().IsEmpty())
						XercesTreeOperations::SetAttribute(xel, el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, xel));
					else
						XercesTreeOperations::SetAttribute(xel, el->GetPrefix().GetPrefix() + _T(":") +el->GetLocalName(), el->GetNamespaceURI(), GetValue(el, xel));
				}
				else if ((el->GetNodeKind() & k_Comment) != 0)
				{
					where->appendChild(owner->createComment(XercesStringTemp(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_ProcessingInstruction) != 0)
				{
					where->appendChild(owner->createProcessingInstruction(XercesStringTemp(el->GetLocalName().c_str()), XercesStringTemp(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_CData) != 0)
				{
					where->appendChild(owner->createCDATASection(XercesStringTemp(el->GetValue().c_str())));
				}
				else if ((el->GetNodeKind() & k_TextOrSimple) != 0)
				{
					string_type s = GetValue(el, where);
					if (!s.empty())
						where->appendChild(owner->createTextNode(XercesStringTemp(s.c_str())));
				}
			}
		}

	} // namespace mapforce
} // namespace altova

#endif
