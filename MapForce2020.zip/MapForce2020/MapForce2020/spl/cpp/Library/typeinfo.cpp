[call GenerateFileHeader($TheLibrary.Name & "-typeinfo.cpp")]

#include "StdAfx.h"
#include "[=$TheLibrary.Name]-typeinfo.h"
#include "../Altova/xs-types.h"

namespace [=$TheLibrary.Name]
{

const altova::Binder binder = { namespaces, types, members, facets };

// Array of all namespaces with pointers to types:
const altova::NamespaceInfo namespaces\[\] = 
{
[	foreach $namespace in $TheLibrary.SchemaNamespaces
]	{ &binder, [=$namespace.NamespaceURI.LiteralCppT], [=$namespace.LocalName.LiteralCppT], [=CombineNames("_altova_tif", $namespace.CodeName)], [=CombineNames("_altova_til", $namespace.CodeName)] },
[	next
]	{ 0 },
};

// Array of all types with pointers to members:
const altova::TypeInfo types\[\] = 
{
[	$facetNumber = 0
	foreach $namespace in $TheLibrary.SchemaNamespaces
		foreach $class in $namespace.Types
]	{ &binder, [=BuildNamespaceInfoIndexName($class.Namespace)], [=$class.LocalName.LiteralCppT], [
		if $class.IsDerived ][=BuildTypeInfoIndexName($class.BaseType)][else](unsigned)~0[endif
			$basename = CombineNames(CombineNames($namespace.CodeName, "altova"), $class.CodeName)
		], [=CombineNames("_altova_mif", $basename)], [=CombineNames("_altova_mil", $basename)], [
			if $class.IsSimpleType and $class.Facets <> 0 
				][=$facetNumber][
				$facetNumber = $facetNumber + $class.Facets.List.Length + 1
			else
				](unsigned)~0[
			endif
			], [
			if $class.IsSimpleType
				switch $class.Whitespace
				case "preserve"
					write "altova::Whitespace_Preserve"
				case "replace"
					write "altova::Whitespace_Replace"
				case "collapse"
					write "altova::Whitespace_Collapse"
				default
					write "altova::Whitespace_Unknown"
				endswitch
				if $class.IsNativeBound
					write ", &" & $class.NativeBinding.ValueHandler
				endif
			else
				write "altova::Whitespace_Unknown"
				foreach $member in $class.Attributes 
					if $member.LocalName = ""
						if $member.DataType.IsNativeBound
							write ", &" & $member.DataType.NativeBinding.ValueHandler
						endif
					endif
				next
			endif

			] },
[		next
]
[	next
]{ 0 },
};

const altova::MemberInfo members\[\] = 
{
[
	foreach $namespace in $TheLibrary.SchemaNamespaces
		foreach $class in $namespace.Types
			$emitempty = false
			foreach $member in $class.Attributes
				$emitempty = true
]	{ &binder, [=$member.NamespaceURI.LiteralCppT], [=$member.LocalName.LiteralCppT], [=BuildTypeInfoIndexName($class)], [=BuildTypeInfoIndexName($member.DataType)], MemberFlags_IsAttribute, [=$member.MinOccurs], (unsigned)[=$member.MaxOccurs] },
[			next
			foreach $member in $class.Elements
				$emitempty = true
]	{ &binder, [=$member.NamespaceURI.LiteralCppT], [=$member.LocalName.LiteralCppT], [=BuildTypeInfoIndexName($class)], [=BuildTypeInfoIndexName($member.DataType)], MemberFlags_None, [=$member.MinOccurs], (unsigned)[=$member.MaxOccurs] },
[			next
			if $emitempty
]
[			endif
		next
	next
]{ 0 },
};

const altova::FacetInfo facets\[\] = 
{
[
' Facet checkers use local names because (a) for schema types these are valid identifiers
' and (b) otherwise we may run into trouble when names are decollided to something else for
' some reason.
	foreach $namespace in $TheLibrary.SchemaNamespaces
		foreach $class in $namespace.Types
			if $class.IsSimpleType and $class.Facets <> 0
]	// [=$class.LocalName]
[				foreach $facet in $class.Facets.List
					$checker = $facet.FacetCheckerName
					if $checker = "" 
						$checker = "0"
					endif
					switch $facet.FacetType
					case "valuespace-length"
]	{ [=$checker], [=$facet.LocalName.LiteralCppT], _T("[=$facet.FacetValue]"), [=$facet.FacetValue] }, 
[					case "valuespace-enum"
					case "lexicalspace"
					case "valuespace-range"
]	{ [=$checker], [=$facet.LocalName.LiteralCppT], [=$facet.FacetValue.LiteralCppT], 0 }, 
[					default
]	{ [=$checker], [=$facet.LocalName.LiteralCppT], [=$facet.FacetValue.LiteralCppT], 0 },
[					endswitch		
				next 
]	{ 0, 0, 0, 0 },
[
			endif
		next
	next
]{ 0 },
};

}  // namespace [=$TheLibrary.Name]
