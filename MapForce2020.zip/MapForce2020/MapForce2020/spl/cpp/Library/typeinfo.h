[call GenerateFileHeader($TheLibrary.Name & "-typeinfo.h")]

#ifndef _INCLUDED_[=$TheLibrary.Name]_typeinfo_H_
#define _INCLUDED_[=$TheLibrary.Name]_typeinfo_H_

#include "../Altova/StructInfo.h"

#undef [=$module]_DECLSPECIFIER
[if $libtype = 1
]#define [=$module]_DECLSPECIFIER
[else
]
#if !defined( __GNUC__ )
#ifdef [=$module]_EXPORTS
#define [=$module]_DECLSPECIFIER __declspec(dllexport)
#else
#define [=$module]_DECLSPECIFIER __declspec(dllimport)
#endif
#else
#define [=$module]_DECLSPECIFIER
#endif
[endif
]

namespace [=$TheLibrary.Name]
{

enum _altova_namespace_indices
{
[
foreach $namespace in $TheLibrary.SchemaNamespaces
]	[=BuildNamespaceInfoIndexName($namespace)],		
[
next
]
};

enum _altova_typeinfo_indices
{
[
$previous = ""
foreach $namespace in $TheLibrary.SchemaNamespaces
	$name = CombineNames("_altova_tif", $namespace.CodeName)
]	[=$name][if $previous <> ""] = [=$previous][endif],
[	
	$previous = $name
	foreach $type in $namespace.Types
]	[=BuildTypeInfoIndexName($type)][if $previous <> ""] = [=$previous][endif],
[		$previous = ""
	next
	$name = CombineNames("_altova_til", $namespace.CodeName)
]	[=$name][if $previous <> ""] = [=$previous][endif],

[	
	$previous = $name
next
]
};

[
$previous = ""
foreach $namespace in $TheLibrary.SchemaNamespaces
	foreach $type in $namespace.Types
]enum
{
[		$name = CombineNames(CombineNames(CombineNames("_altova_mif", $namespace.CodeName), "altova"), $type.CodeName)
]	[=$name][if $previous <> ""] = [=$previous][endif],
[		$previous = $name
		foreach $att in $type.Attributes
]	[=BuildMemberInfoIndexName($att)][if $previous <> ""] = [=$previous][endif],
[			$previous = ""
		next ' $att
		foreach $el in $type.Elements
]	[=BuildMemberInfoIndexName($el)][if $previous <> ""] = [=$previous][endif],
[			$previous = ""
		next ' $el
		$name = CombineNames(CombineNames(CombineNames("_altova_mil", $namespace.CodeName), "altova"), $type.CodeName)
]	[=$name][if $previous <> ""] = [=$previous][endif],
};
[		
		$previous = $name
	next ' $class
next ' $namespace
]


extern [=$module]_DECLSPECIFIER const altova::FacetInfo facets\[\];
extern [=$module]_DECLSPECIFIER const altova::NamespaceInfo namespaces\[\];
extern [=$module]_DECLSPECIFIER const altova::MemberInfo members\[\];
extern [=$module]_DECLSPECIFIER const altova::TypeInfo types\[\];

}  // namespace [=$TheLibrary.Name]

#endif // _INCLUDED_[=$TheLibrary.Name]_typeinfo_H_
