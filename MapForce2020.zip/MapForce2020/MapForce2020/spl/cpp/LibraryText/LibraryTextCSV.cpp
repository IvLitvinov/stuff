[
call GenerateCSVDocument()
' to isolate local variables
sub GenerateCSVDocument()

$format= $library.FormatCSV]
[=$module]Document::[=$module]Document(const altova::TypeInfo* pTableType)
{
    m_pType = pTableType;
	init();
}

altova::text::tablelike::ISerializer* [=$module]Document::CreateSerializer()
{
	altova::text::tablelike::CCSVSerializer* result= new altova::text::tablelike::CCSVSerializer(*this);
	this->Format.SetLineEnd([=$format.LineEnd]);
    result->SetFormat( &this->Format);
	result->GetFormat()->SetFieldDelimiter([=$format.FieldSeparator.LiteralCharCppT]);
	[if $format.QuoteCharacter <> ""]
	result->GetFormat()->SetQuoteCharacter([=$format.QuoteCharacter.LiteralCharCppT]);
	[endif]
	result->GetFormat()->SetAssumeFirstRowAsHeaders([=$format.UseFirstRowNames]);
	result->GetFormat()->SetRemoveEmpty([=$format.RemoveEmpty]);
	result->GetFormat()->SetAlwaysQuote([=$format.AlwaysQuote] == 1);
	return result;
}
void [=$module]Document::InitHeader(altova::text::tablelike::CHeader& header)
{
	altova::text::tablelike::TColumnSpecificationArray& columns= header.GetColumns();
	[foreach $field in $format.Fields]
	columns.push_back(new altova::text::tablelike::CColumnSpecification(_T("[=$field.Name]")));
	[next]
}
[endsub ' GenerateCSVDocument()
]
