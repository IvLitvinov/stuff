class [=$module]_DECLSPECIFIER [=$module]Document : public altova::text::tablelike::CCsvTable
{
public:
    [=$module]Document(const altova::TypeInfo* pTableType);

protected:
	virtual altova::text::tablelike::ISerializer* CreateSerializer();
	virtual void InitHeader(altova::text::tablelike::CHeader& header);
};