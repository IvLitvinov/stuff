[
sub emitParticles ($strucItem, $prefix)
]
	{ 
[
	foreach $particle in $strucItem.Children 
		$emitName = $particle.NodeName 
]			CEDIParticle(_T("[=$emitName]"), [=$prefix][=$particle.Item.Name], [=$particle.MinOccurs], [
		if $particle.MaxOccurs < 0]INT_MAX[else][=$particle.MaxOccurs][endif], [=$particle.MergedEntries], [
		if $particle.RespectMaxOccurs = 1]true[else]false[endif][$x = $particle.CodeValues : if $x.Length = 0])[if $particle.IsLast][else],[endif]
[			else],
				details::StringVectorBuilder([=$x.Length])[
			foreach $code in $particle.CodeValues
				].Add([=$code.LiteralCppT])[
			next]),
[			endif
	next ' $particle in $strucItem.Children 
]	};[		
endsub ' emitParticles

sub emitContainer ($strucItem, $type, $prefix, $childPrefix)
	if $strucItem.Children.Length > 0 
]
	const CEDIParticle [=$prefix][=$strucItem.Name]Contents \[\] = [	
		call emitParticles ($strucItem, $childPrefix)
]
	const [=$type] [=$prefix][=$strucItem.Name] (_T("[=$strucItem.OriginalName]"), [
		if $strucItem.NodeClass = "Segment" or $strucItem.NodeClass = "Group"
		][=$strucItem.ConditionPath.LiteralCppT], [=$strucItem.ConditionValue.LiteralCppT], [
		endif
		][=$prefix][=$strucItem.Name]Contents, [=$strucItem.Children.Length]);

[
	else ' $strucItem.Children.Length > 0 
]	const [=$type] [=$prefix][=$strucItem.Name] (_T("[=$strucItem.OriginalName]"), [
		if $strucItem.NodeClass = "Segment"
		][=$strucItem.ConditionPath.LiteralCppT], [=$strucItem.ConditionValue.LiteralCppT], [
		endif
		]0, 0);
[
	endif ' $strucItem.Children.Length > 0 
endsub ' emitContainer

]

////////////////////////////////////////////////////////////////////////
//	[=$module]Document
////////////////////////////////////////////////////////////////////////


	namespace details
	{
		class StringVectorBuilder
		{
			private :
				std::vector<tstring> m_vec;

			public :
				StringVectorBuilder( unsigned int nPrepareCount ) { m_vec.reserve( nPrepareCount ); }

				StringVectorBuilder& Add( tstring s ) { m_vec.push_back( s ); return *this; }

				operator const std::vector<tstring>& () const { return m_vec; }
		};
	}


[
sub CreateEDIConfig()
	' generate forwards
foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Group"
		$prefix = $module & "eds"
]	extern const CEDIGroup [=$prefix][=$item.Name];		
[
	endif
next ' $item in $library.EDIConfig.Items

foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "ErrorList"
		$prefix = $module & "eds"
]	extern const CEDIErrorList [=$prefix][=$item.Name];		
[
	endif
next ' $item in $library.EDIConfig.Items

foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Select"
		$prefix = $module & "eds"
]	extern const CEDISelect [=$prefix][=$item.Name];		
[
	endif
next ' $item in $library.EDIConfig.Items
 		
$childPrefix = ""
$prefix = $module & "edi"
foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Data"
		if $item.TypeName = "string" and $item.CodeListCount > 0
			if $item.CodeListGroupsCount > 0
				foreach $codegroup in $item.CodeListGroups
					foreach $field in $codegroup.CodeLists
						if $field.Items.Length > 0]
	static tstring [=$prefix][=$item.Name]CodeListGroup[=$codegroup.Index]Field[=$field.Index]\[\] = { [ 
						foreach $codeitem in $field.Items 
							if $codeitem.IsLast ]_T("[=$codeitem.Current]")[else]_T("[=$codeitem.Current]"),[endif
						next] };[
						endif
						if $field.PosOffset > 0]
	const CEDIDataValueSubCodeListValidator [=$prefix][=$item.Name]ValueValidator[if $item.CodeListGroupsCount > 1 or $codegroup.ListName.Length > 0]Group[=$codegroup.Index][endif][if $codegroup.CodeLists.Length > 1 or $codegroup.ListName.Length > 0]Field[=$field.Index][endif] ([if $field.Complete = 1]true[else]false[endif], [=$field.PosOffset], [=$field.PosLength][if $field.Items.Length > 0], [=$prefix][=$item.Name]CodeListGroup[=$codegroup.Index]Field[=$field.Index], [=$field.Items.Length][endif]);[
						else]
	const CEDIDataValueCodeListValidator [=$prefix][=$item.Name]ValueValidator[if $item.CodeListGroupsCount > 1 or $codegroup.ListName.Length > 0]Group[=$codegroup.Index][endif][if $codegroup.CodeLists.Length > 1 or $codegroup.ListName.Length > 0]Field[=$field.Index][endif] ([if $field.Complete = 1]true[else]false[endif][if $field.Items.Length > 0], [=$prefix][=$item.Name]CodeListGroup[=$codegroup.Index]Field[=$field.Index], [=$field.Items.Length][endif]);[
						endif
					next
					if $codegroup.CodeLists.Length > 1 or $codegroup.ListName.Length > 0]
	static const CEDIDataValueValidator* [=$prefix][=$item.Name]ValueValidatorGroup[=$codegroup.Index]List\[\] = { [
						foreach $field in $codegroup.CodeLists
							]&[=$prefix][=$item.Name]ValueValidatorGroup[=$codegroup.Index]Field[=$field.Index][if not $field.IsLast], [endif][
						next
			] };
	const CEDIDataValueGroupValidator [=$prefix][=$item.Name]ValueValidator[if $codegroup.CodeLists.Length > 1]Group[=$codegroup.Index][endif] (_T("[=$codegroup.ListName]"), [=$prefix][=$item.Name]ValueValidatorGroup[=$codegroup.Index]List, [=$codegroup.CodeLists.Length] );[
					endif
				next
				if $item.CodeListGroupsCount > 1
			]
	static const CEDIDataValueValidator* [=$prefix][=$item.Name]ValueValidatorGroupsList\[\] = { [
					foreach $codegroup in $item.CodeListGroups]&[=$prefix][=$item.Name]ValueValidatorGroup[=$codegroup.Index][if not $codegroup.IsLast], [endif][
					next
			] };
	const CEDIDataValueGroupsValidator [=$prefix][=$item.Name]ValueValidator ( [=$prefix][=$item.Name]ValueValidatorGroupsList, [=$item.CodeListGroups.Length] );[
				endif
			else
				if $item.CodeList.Items.Length > 0]
	static tstring [=$prefix][=$item.Name]CodeList\[\] = { [ 
				foreach $codeitem in $item.CodeList.Items
					if $codeitem.IsLast ]_T("[=$codeitem.Current]")[else]_T("[=$codeitem.Current]"),[endif
				next] };[
				endif
				if $item.CodeList.PosOffset > 0]
	const CEDIDataValueSubCodeListValidator [=$prefix][=$item.Name]ValueValidator ([if $item.CodeList.Complete = 1]true[else]false[endif], [=$item.CodeList.PosOffset], [=$item.CodeList.PosLength][if $item.CodeList.Items.Length > 0], [=$prefix][=$item.Name]CodeList, [=$item.CodeList.Items.Length][endif]);[
				else]
	const CEDIDataValueCodeListValidator [=$prefix][=$item.Name]ValueValidator ([if $item.CodeList.Complete = 1]true[else]false[endif][if $item.CodeList.Items.Length > 0], [=$prefix][=$item.Name]CodeList, [=$item.CodeList.Items.Length][endif]);[
				endif
			endif
		endif
		' X12 special field handling
		if ($library.EDIKind = 2 and ($item.OriginalName = "FI15" or $item.OriginalName = "FI65" or $item.OriginalName = "FI10") or ($library.EDIKind = 3 and ($item.OriginalName = "MSH-1" or $item.OriginalName = "BHS-1" or $item.OriginalName = "FHS-1")))
]
	const CEDISingleCharElement [=$prefix][=$item.Name] (_T("[=$item.OriginalName]"));[
		else ' normal field (EDIFACT or X12 non-special)

			switch $item.TypeName
				case "date":
]
	const CEDIDataTypeValidatorDate [=$prefix][=$item.Name]Validator ([=$item.MinLength], [=$item.MaxLength]);[
				case "time":
]
	const CEDIDataTypeValidatorTime [=$prefix][=$item.Name]Validator ([=$item.MinLength], [=$item.MaxLength]);[
				case "decimal": 
]
	const CEDIDataTypeValidatorDecimal [=$prefix][=$item.Name]Validator ([=$item.MinLength], [=$item.MaxLength], [=$item.ImplicitDecimals]);[
				default: 
]
	const CEDIDataTypeValidatorString [=$prefix][=$item.Name]Validator ([=$item.MinLength], [=$item.MaxLength] [if $item.CodeListCount > 0], &[=$prefix][=$item.Name]ValueValidator[endif]);[
			endswitch
]
	const CEDIDataElement [=$prefix][=$item.Name] (_T("[=$item.OriginalName]"), &[=$prefix][=$item.Name]Validator);
[
		endif ' special field handling
	endif
next ' $item in $library.EDIConfig.Items

$childPrefix = $module & "edi"
$prefix = $module & "edi"

foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "SubComposite"
		$type = "CEDISubComposite"
		call emitContainer ($item, $type, $prefix, $childPrefix)
	endif
next ' $item in $library.EDIConfig.Items

foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Composite"
		$type = "CEDIComposite"
		call emitContainer ($item, $type, $prefix, $childPrefix)
	endif
next ' $item in $library.EDIConfig.Items

$childPrefix = $module & "edi"
$prefix = $module & "eds"
foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Segment"
		$type = "CEDISegment"
		call emitContainer ($item, $type, $prefix, $childPrefix)
	endif
next ' $item in $library.EDIConfig.Items

$childPrefix = $module & "eds"
$prefix = $module & "eds"
foreach $item in $library.EDIConfig.Items
	if $item.NodeClass = "Group"
		$type = "CEDIGroup"
		call emitContainer ($item, $type, $prefix, $childPrefix)
	endif
next ' $item in $library.EDIConfig.Items

$childPrefix = $module & "eds"
$prefix = $module & "eds"
foreach $item in $library.EDIConfig.Items
	switch $item.NodeClass
	case "ErrorList":
		$type = "CEDIErrorList"
		call emitContainer ($item, $type, $prefix, $childPrefix)
	case "Select":
]
	const CEDIParticle [=$prefix][=$item.Name]Contents \[\] = [	
		call emitParticles ($item, $childPrefix)
]
	const CEDISelect [=$prefix][=$item.Name] (_T("[=$item.OriginalName]"), _T("[=$item.Prefix]"), _T("[=$item.Field]"), _T("[=$item.SearchType]"), [=$prefix][=$item.Name]Contents, [=$item.Children.Length]);

[
	endswitch
next ' $item in $library.EDIConfig.Items

]	const CEDIParticle [=$module]_RootParticle (0, [=$module]eds[=$library.EDIConfig.RootParticle.CodeName], 1, 1, 1, false);
[	foreach $msg in $library.EDIConfig.Messages
]	const CEDIParticle [=$module]_[=$msg.RootParticle.CodeName]_RootParticle( _T("[=$msg.RootParticle.Name]"), [=$module]eds[=$msg.RootParticle.CodeName], 1,1,1, false);
[	next

endsub ' CreateEDIConfig

call CreateEDIConfig()

]

void [=$module]Document::InitSegmentList()
{
	tstring arStandardSegments\[\] =  { [
	foreach $seg in $library.EDIConfig.StandardSegments if $seg.IsLast ]_T("[=$seg.Current]")[else]_T("[=$seg.Current]"),[endif next] }; 
	StandardSegments = new std::set<tstring> ( arStandardSegments, arStandardSegments+[=$library.EDIConfig.StandardSegments.Length]);
[	foreach $msg in $library.EDIConfig.Messages ]
	tstring ar[=$msg.CodeName]Segments\[\] =  { [
	foreach $seg in $msg.Segments if $seg.IsLast ]_T("[=$seg.Current]")[else]_T("[=$seg.Current]"),[endif next] }; 
	m_mapMessages.insert( std::pair<tstring,CMessage>(_T("[=$msg.MessageType]"), CMessage(_T("[=$msg.MessageType]"), [=$module]_[=$msg.RootParticle.CodeName]_RootParticle, ar[=$msg.CodeName]Segments, [=$msg.Segments.Length], [=$msg.CompleteHLSegments], [=$msg.CompleteSingleConditions], [=$msg.CompleteSingleValues]) ) );
[	next]
}

[=$module]Document::[=$module]Document()
:	altova::text::edi::CTextDocument(m_Settings, [=$module]_RootParticle)
{
	this->InitSettings();
	this->InitSegmentList();
}

[=$module]Document::~[=$module]Document()
{}

bool [=$module]Document::Parse(const tstring& filename)
{
	return (ParseFile(filename));
}

void [=$module]Document::InitSettings()
{[
	switch ($library.EDIKind)
	case 1:]
	// EDIFact specific settings:
	[if $library.EDIFactSettings.SyntaxLevel<>""]
	m_Settings.SetSyntaxLevel(_T('[=$library.EDIFactSettings.SyntaxLevel]'));
	[endif]
	m_Settings.SetSyntaxVersionNumber([=$library.EDIFactSettings.SyntaxVersionNumber]);
	[if $library.EDIFactSettings.ControllingAgency<>""]
	m_Settings.SetControllingAgency(_T("[=$library.EDIFactSettings.ControllingAgency]"));
	[endif]
	m_Settings.SetWriteUNA([=$library.EDIFactSettings.WriteUNA]);
	[case 2:]
	// X12 specific settings:
	m_Settings.SetInterchangeControlVersionNumber(_T("[=$library.EDIX12Settings.InterchangeControlVersionNumber]"));
	m_Settings.SetRequestAcknowledgement([=$library.EDIX12Settings.RequestAcknowledgement]);
	[case 3:]
	// HL7 specific settings:
	[case 4:]
	// Fixed config specific settings:
	[case 5:]
	// TRADACOMS specific settings:
	[case 6:]
	// NCPDP SCRIPT specific settings:
	[if $library.EDIFactSettings.SyntaxLevel<>""]
	m_Settings.SetSyntaxLevel(_T('[=$library.EDIFactSettings.SyntaxLevel]'));
	[endif]
	m_Settings.SetSyntaxVersionNumber([=$library.EDIFactSettings.SyntaxVersionNumber]);
	[if $library.EDIFactSettings.ControllingAgency<>""]
	m_Settings.SetControllingAgency(_T("[=$library.EDIFactSettings.ControllingAgency]"));
	[endif]
	m_Settings.SetWriteUNA([=$library.EDIFactSettings.WriteUNA]);
	[default:]
	// unknown EDI document type
	[endswitch]
	// general settings:
	m_Settings.SetTerminateSegmentsWithLinefeed([=$library.EDISettings.TerminateSegmentsWithLinefeed]);
	m_Settings.SetAutoCompleteData([=$library.EDISettings.AutoCompleteData]);
	m_Settings.SetLineEnd([=$library.EDISettings.LineEnd]);
	m_Settings.SetMessageType(_T("[=$library.StructureName]"));
	[if $library.EDIConfig.Version <> ""]
	m_Settings.SetVersion(_T("[=$library.EDIConfig.Version]"));
	[endif
	if $library.EDIConfig.Release <> ""]
	m_Settings.SetRelease(_T("[=$library.EDIConfig.Release]"));
	[endif]
	CEDIServiceChars& una= m_Settings.GetServiceChars();
	[
	$compsep = $library.EDISettings.ComponentDataElementSeparator.LiteralCharCppT
	$datasep = $library.EDISettings.DataElementSeparator.LiteralCharCppT
	$tagsep = $library.EDISettings.DataElementSeparator.LiteralCharCppT
	$decisep = $library.EDISettings.DecimalNotation.LiteralCharCppT
	$subcompsep = "_T('\\0')"
	$escpsep = "_T('\\0')"
	switch ($library.EDIKind)
	case 1:
	$escpsep = $library.EDISettings.ReleaseIndicator.LiteralCharCppT
	case 3:
	$escpsep = $library.EDISettings.ReleaseIndicator.LiteralCharCppT
	$subcompsep = $library.EDISettings.SubComponentSeparator.LiteralCharCppT
	case 4:
		$datasep = "_T('\\0')"
		$compsep = "_T('\\0')"
		$tagsep = "_T('\\0')"
	case 5:
	$escpsep = $library.EDISettings.ReleaseIndicator.LiteralCharCppT
	$tagsep = "_T('=')"
	default:
	endswitch
	$segmsep = $library.EDISettings.SegmentTerminator.LiteralCharCppT
	$repesep = $library.EDISettings.RepetitionSeparator.LiteralCharCppT
	if $escpsep = "_T(' ')" : $escpsep = "_T('\\0')" : endif
	if $repesep = "_T(' ')" : $repesep = "_T('\\0')" : endif
	if $subcompsep = "_T(' ')" : $subcompsep = "_T('\\0')" : endif
	]
	una.SetServiceChar (EDISERVICECHAR_COMPONENTSEPARATOR, [=$compsep]); 
	una.SetServiceChar (EDISERVICECHAR_DATAELEMENTSEPARATOR, [=$datasep]); 
	una.SetServiceChar (EDISERVICECHAR_DECIMALMARK, [=$decisep]);
	una.SetServiceChar (EDISERVICECHAR_RELEASECHARACTER, [=$escpsep]); 
	una.SetServiceChar (EDISERVICECHAR_SEGMENTSEPARATOR, [=$tagsep]); 
	una.SetServiceChar (EDISERVICECHAR_SEGMENTTERMINATOR, [=$segmsep]); 
	una.SetServiceChar (EDISERVICECHAR_REPETITIONSEPARATOR, [=$repesep]);
    una.SetServiceChar (EDISERVICECHAR_SUBCOMPONENTSEPARATOR, [=$subcompsep]);
	
	// Error handling settings
    altova::text::edi::CEDIParser::Actions arValidationSettings\[\] = {
[      foreach $setting in $library.EDISettings.ValidationSettings
]		(altova::text::edi::CEDIParser::Actions)[=$setting.Action],
[      next]
    };
	SetErrorSettings( arValidationSettings);
}

tstring [=$module]Document::GetStructureName() const
{
	return _T("[=$library.StructureName]");
}

const altova::text::edi::CEDISettings& [=$module]Document::GetSettings() const
{
	return m_Settings;
}

altova::text::edi::EDIStandard [=$module]Document::GetStandard() const
{
	[switch ($library.EDIKind)
	   case 1:   $EDIKindSpecifier= "altova::text::edi::EDIFact"
	   case 2:   $EDIKindSpecifier= "altova::text::edi::EDIX12"
       case 3:   $EDIKindSpecifier= "altova::text::edi::EDIHL7"
	   case 4:   $EDIKindSpecifier= "altova::text::edi::EDIFixed"
	   case 5:   $EDIKindSpecifier= "altova::text::edi::EDITRADACOMS"
	   case 6:   $EDIKindSpecifier= "altova::text::edi::EDISCRIPT"
	   default:  $EDIKindSpecifier= "altova::text::edi::Unknown"
	 endswitch]
	return [=$EDIKindSpecifier];
}

void [=$module]Document::Save(const tstring& filename)
{
	CTextDocument::Save(filename);
}


