//////////////////////////////////////////////////////////////////////////

class [=$module]_DECLSPECIFIER [=$module]Document : public altova::text::edi::CTextDocument
{
public:
	// construction and destruction
	[=$module]Document();
	virtual ~[=$module]Document();

	bool Parse(const tstring& filename);

public:
	void Save(const tstring& filename);

    virtual altova::text::edi::EDIStandard GetStandard() const;

protected:
	virtual tstring GetStructureName() const;
	virtual const altova::text::edi::CEDISettings& GetSettings() const;

private:
	void InitGeneral();
	void InitSettings();
	void InitSegmentList();

private:
	[switch ($library.EDIKind)
	   case 1:	$EDISettingsType= "CEDIFactSettings"
	   case 2:	$EDISettingsType= "CEDIX12Settings"
       case 3:	$EDISettingsType= "CEDIHL7Settings"
	   case 4:	$EDISettingsType= "CEDIFixedSettings"
	   case 5:	$EDISettingsType= "CEDITradacomsSettings"
	   case 6:	$EDISettingsType= "CEDIScriptSettings"
	   default:	$EDISettingsType= "UnknownSettings"
	 endswitch]
	altova::text::edi::[=$EDISettingsType] m_Settings;

private:
	[=$module]Document(const [=$module]Document&);
	[=$module]Document& operator= (const [=$module]Document&);
};
