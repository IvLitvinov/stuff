[
call GenerateFLFDocument()
' to isolate local variables
sub GenerateFLFDocument()

$format= $library.FormatFLF]

altova::text::tablelike::ISerializer* [=$module]Document::CreateSerializer()
{
	altova::text::tablelike::CFLFSerializer* result= new altova::text::tablelike::CFLFSerializer(*this);
	result->GetFormat()->SetLineEnd([=$format.LineEnd]);
	result->GetFormat()->SetAssumeRecordDelimiters([=$format.AssumeRecordDelimitersPresent]);
	result->GetFormat()->SetFillCharacter([=$format.FillCharacter.LiteralCharCppT]);
	result->GetFormat()->SetRemoveEmpty([=$format.RemoveEmpty]);
	return result;
}
void [=$module]Document::InitHeader(altova::text::tablelike::CHeader& header)
{
	altova::text::tablelike::TColumnSpecificationArray& columns= header.GetColumns();
	[foreach $field in $format.FieldDescriptions]
	columns.push_back(new altova::text::tablelike::CColumnSpecification(_T("[=$field.Name]"), [=$field.Length]));
	[next]
}
[
endsub ' GenerateFLFDocument()
]