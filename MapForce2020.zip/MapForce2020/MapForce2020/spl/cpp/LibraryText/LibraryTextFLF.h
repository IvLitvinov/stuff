class [=$module]_DECLSPECIFIER [=$module]Document : public altova::text::tablelike::CTable
{
protected:
	virtual altova::text::tablelike::ISerializer* CreateSerializer();
	virtual void InitHeader(altova::text::tablelike::CHeader& header);
};