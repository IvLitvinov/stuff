[
sub GenerateCommand(byref $command)
	$lParams = ""
]
// [=$command.Kind] [=$command.Name]
[
	if $command.Kind = "Project"
		$lParams = $lParams & ", " & $command.TabSize
	endif

	' ----------

	if $command.Kind = "SplitSingle" or $command.Kind = "SplitMultiple"
		$lParams = $lParams & ", &Splitter_" & $command.Name
		if $command.IsDelimited
			$classname = "CSplitAtDelimiter"
			if $command.IsLineBased
				$classname = $classname & "LineBased"
				if $command.Kind = "SplitMultiple"
					$classname = $classname & "Multiple"
				endif
			else 
				if $command.IsLineStartsWith
					$classname = "CSplitAtDelimiterLineStartsWith"
					if $command.Kind = "SplitMultiple"
						$classname = $classname & "Multiple"
					endif
				endif
			endif
			if $command.UseRegex
				$classname = $classname & "Regex"
			endif
		][=$classname] Splitter_[=$command.Name]([
			if not $command.UseRegex
				=$command.Separator.LiteralCppT
				if $command.Kind = "SplitSingle"
					if $command.SplitBase = 1], true[else], false[endif
				endif
			else
				=$command.RegexPattern.LiteralCppT], [
				if $command.MatchCase]true[else]false[endif
				if $command.IsFloating
					], [
					=$command.SeparatorForWriting.LiteralCppT
				endif
			endif
		]);
[		else ' fixed (counted)
			if $command.IsVertical
				$classname = "CSplitAtPosition"
			else ' horizontal
				$classname = "CSplitLines"
			endif
			$lOffset = $command.Offset
			if $command.Kind = "SplitSingle"
				if $command.SplitBase = 1 ' from end
					$lOffset = -$lOffset
				endif
			endif
			$lParams = $lParams & ", " & $command.Orientation & ", " & $lOffset
			][=$classname] Splitter_[=$command.Name]([=$lOffset]);
[		endif
	endif

	' ----------

	if $command.Kind = "Store"
		$lParams = $lParams & ", " & $command.TrimSide & ", " & $command.TrimCharSet.LiteralCppT
	endif

	' ----------

	if $command.Kind = "CSV" or $command.Kind = "FLF"
		$lParams = $lParams & ", " & $command.Columns.Length & ", Columns_" & $command.Name
		$lParams = $lParams & ", " & $command.UseFirstRowNames
		' generate store commands
		foreach $column in $command.Columns
			]CFlexCommandStore Store_[=$command.Name]_[=$column.Name]([=$column.OriginalName.LiteralCppT][
		 	if $command.Kind = "FLF"
				], [=$column.Alignment], [=$column.FillCharacter.LiteralCppT]);
[			else
				], 0, _T(""));
[			endif
		next
	endif

	' generate column list
	if $command.Kind = "CSV"
		]CFlexColumnDelimited Columns_[=$command.Name]\[\] = {
[
		foreach $column in $command.Columns
			]	{ &Store_[=$command.Name]_[=$column.Name], [=$column.OriginalName.LiteralCppT] },
[		next
		]};
[
		$lParams = $lParams & ", " & $command.RecordSeparator.LiteralCppT & ", " & $command.FieldSeparator.LiteralCppT
		$lParams = $lParams & ", " & $command.QuoteCharacter.LiteralCharCppT
		$lParams = $lParams & ", " & $command.EscapeCharacter.LiteralCharCppT
		if $command.RemoveEmpty
			$lParams = $lParams & ", true"
		else
			$lParams = $lParams & ", false"
		endif
		if $command.AlwaysQuote
			$lParams = $lParams & ", true"
		else
			$lParams = $lParams & ", false"
		endif
	endif

	if $command.Kind = "FLF"
		]CFlexColumnFixed Columns_[=$command.Name]\[\] = {
[
		foreach $column in $command.Columns
			]	{ &Store_[=$command.Name]_[=$column.Name], [=$column.Size], [=$column.FillCharacter.LiteralCharCppT], [=$column.Alignment], [=$column.OriginalName.LiteralCppT] },
[		next
		]};
[
		if $command.HasRecordDelimiter
			]CSplitLines Splitter_[=$command.Name](1, true);
[		else
			]CSplitAtPosition Splitter_[=$command.Name]([=$command.RecordSize]);
[		endif
		$lParams = $lParams & ", &Splitter_" & $command.Name
		if $command.RemoveEmpty
			$lParams = $lParams & ", true"
		else
			$lParams = $lParams & ", false"
		endif
	endif

	if $command.Kind = "Switch"
		if $command.Conditions.Length = 1
			$lParams = $lParams & ", 0, 0, " & $command.Mode
		else
			$lParams = $lParams & ", " & ($command.Conditions.Length-1) & ", conditions_" & $command.Name & ", " & $command.Mode
		' generate conditions
		]		CFlexCondition conditions_[=$command.Name]\[\] = {
[					foreach $condition in $command.Conditions
						if $condition.Mode <> "Default"
						]			CFlexCondition(_T(""), CFlexCondition::[=$condition.Mode], _T("[=$condition.Value.AsCppStringConstant]")),
[						endif
					next
					]		};
[
		endif
	endif
	
	]CFlexCommand[=$command.Kind] Command_[=$command.Name]([=$command.OriginalName.LiteralCppT][=$lParams]);
[
	foreach $connector in $command.Connectors
		foreach $subcommand in $connector.Commands
			call GenerateCommand($subcommand)
		next ' subcommand
	next ' connector
	
	if $command.Kind = "Switch"
		foreach $condition in $command.Conditions
			foreach $connector in $condition.Connectors
				foreach $subcommand in $connector.Commands
					call GenerateCommand($subcommand)
				next ' command
			next ' connector
		next ' condition
	endif
endsub

	
sub ConnectChildren(byref $functioncall, byref $connector)
	foreach $subcommand in $connector.Commands
		]	Command_[=$functioncall](&Command_[=$subcommand.Name]);
[			
		call LinkCommandChildren($subcommand)
	next ' command
endsub


sub LinkCommandChildren(byref $command)

	if $command.Kind = "SplitSingle"
		$functioncall = $command.Name & ".SetFirst"
		call ConnectChildren($functioncall, $command.Connector.0)
		$functioncall = $command.Name & ".SetNext"
		call ConnectChildren($functioncall, $command.Connector.1)
	else
		if $command.Kind = "Switch"
			foreach $condition in $command.Conditions
				if $condition.Mode = "Default"
					$functioncall = $command.Name & ".SetNext"
					foreach $connector in $condition.Connectors
						if $connector.IsFirst
							call ConnectChildren($functioncall, $connector)
						endif
					next
				else
					$functioncall = $command.Name & ".GetCondition(" & $condition.Index & ").SetNext"
					foreach $connector in $condition.Connectors
						if $connector.IsFirst
							call ConnectChildren($functioncall, $connector)
						endif
					next
				endif
			next
		else
			foreach $connector in $command.Connectors
				if $connector.IsFirst
					$functioncall = $command.Name & ".SetNext"
					call ConnectChildren($functioncall, $connector)
				endif
			next
		endif
	endif
endsub


call GenerateCommand($library.FlexProject)

]

////////////////////////////////////////////////////////////////////////
//	[=$module]Document
////////////////////////////////////////////////////////////////////////

[=$module]Document::[=$module]Document()
:	altova::text::flex::CTextDocument(0)
{
	m_pFlexProject = &Command_[=$library.FlexProject.Name];

[call LinkCommandChildren($library.FlexProject)
]
}

[=$module]Document::[=$module]Document(int lineend)
:	altova::text::flex::CTextDocument(lineend)
{
	m_pFlexProject = &Command_[=$library.FlexProject.Name];

[call LinkCommandChildren($library.FlexProject)
]
}

[=$module]Document::~[=$module]Document()
{}

bool [=$module]Document::Parse(const tstring& filename)
{
	return (ParseFile(filename));
}

void [=$module]Document::Save(const tstring& filename)
{
	CTextDocument::SaveFile(filename);
}
