//////////////////////////////////////////////////////////////////////////

class [=$module]_DECLSPECIFIER [=$module]Document : public altova::text::flex::CTextDocument
{
public:
	// construction and destruction
	[=$module]Document();
	[=$module]Document(int lineend);
	virtual ~[=$module]Document();

	bool Parse(const tstring& filename);
	void Save(const tstring& filename);

private:
	[=$module]Document(const [=$module]Document&);
	[=$module]Document& operator= (const [=$module]Document&);
};
