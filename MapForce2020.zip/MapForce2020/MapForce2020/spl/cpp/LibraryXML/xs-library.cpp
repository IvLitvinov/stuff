[call GenerateFileHeader($TheLibrary.Name & ".cpp")


	if $domtype = 1
		$nodeType = "MSXML2::IXMLDOMNodePtr"
		$typeLibrary = "MsxmlTreeOperations"
	else
		$nodeType = "xercesc::DOMNode*"
		$typeLibrary = "XercesTreeOperations"
	endif
]

#include "StdAfx.h"
#include <string.h>
#include "[=$TheLibrary.Name].h"
#include <algorithm>

[if $domtype = 2]
#include "../AltovaXML/XercesString.h"
[endif]

[if $libtype <> 1 and $domtype = 1]
#import "[=$msxml_dll]" implementation_only no_auto_exclude
[endif]

// turn off warning: "this" used in base initializer list
#pragma warning(disable:4355)


namespace [=$TheLibrary.Name]
{


[=$nodeType] TypeBase::GetElementNth(const altova::MemberInfo* member, unsigned index)
{
	for ([=$typeLibrary]::MemberIterator it = [=$typeLibrary]::GetElements(m_node, member); it; ++it)
	{
		if (index-- == 0)
			return *it;
	}
	return 0;
}

[=$nodeType] TypeBase::GetElementLast(const altova::MemberInfo* member)
{
	[=$nodeType] p;
	for ([=$typeLibrary]::MemberIterator it = [=$typeLibrary]::GetElements(m_node, member); it; ++it)
	{
		p = *it;
	}
	return p;
}

unsigned TypeBase::CountElement(const altova::MemberInfo* member)
{
	unsigned count = 0;
	for ([=$typeLibrary]::MemberIterator it = [=$typeLibrary]::GetElements(m_node, member); it; ++it)
	{
		++count;
	}
	return count;
}

void TypeBase::RemoveElement(const altova::MemberInfo* member)
{
	[=$typeLibrary]::RemoveElements(m_node, member);
}


int TypeBase::GetEnumerationIndex( const string_type sValue, const unsigned enumOffset, const unsigned enumCount)
{
	unsigned enumIndex = enumOffset;

	while( enumIndex < (enumOffset + enumCount) )
	{
		const FacetInfo* facet = GetTableEntry(facets, enumIndex);

		if( facet->StringValue == sValue)
			return enumIndex - enumOffset;
		enumIndex++;
	}
	return -1; //Invalid
}

string_type TypeBase::GetEnumerationValue( const int index, const unsigned enumOffset, const unsigned enumCount)
{
	unsigned enumIndex = enumOffset + index;

	if( enumIndex >= enumOffset && enumIndex < (enumOffset + enumCount) )
	{
		const FacetInfo* facet = GetTableEntry(facets, enumIndex);
		return facet->StringValue;
	}
	else
		throw altova::ConversionException( _T("Enumeration index out of range.") );
}

void ElementType::DeclareNamespace( const string_type prefix, const string_type namespaceURI )
{
	if ( namespaceURI.empty() )
		throw new altova::InvalidOperationException( _T( "DeclareNamespace requires non-empty namespaceURI." ) );
	string_type localName = _T( "xmlns" );
	if ( !prefix.empty() )
		localName = localName + _T( ":" ) + prefix;

	[=$typeLibrary]::SetAttribute(m_node, localName.c_str(), string_type(_T("http://www.w3.org/2000/xmlns/")), namespaceURI);
}

[
foreach $namespace in $TheLibrary.SchemaNamespaces 
	call BeginNamespace ($namespace)
	foreach $type in $namespace.Types
		if $type.IsSimpleType or $type.IsDocumentRootType
			$baseTypeName = "TypeBase"
		else
			$baseTypeName = "ElementType"
		endif
		$filterinherited = false
		if $type.IsDerivedByExtension
			$filterinherited = true
			if $type.BaseType.Namespace.CodeName <> ""
				$baseTypeName = "::" & $TheLibrary.Name & "::" & $type.BaseType.Namespace.CodeName & "::" & $type.BaseType.CodeName
			else
				$baseTypeName = "::" & $TheLibrary.Name & "::" & $type.BaseType.CodeName
			endif
		endif
]
[=$type.CodeName]::[=$type.CodeName]([=$nodeType] const& node)
: [=$baseTypeName](node)
[		foreach $member in $type.Attributes
			if not $filterinherited or $member.DeclaringType = $member.ContainingType
				if $member.LocalName <> ""
], [=$member.CodeName](*this)	// [$x = "@" & $member.LocalName : write $x.LiteralJava]
[				endif
			endif
		next
		foreach $member in $type.Elements
			if not $filterinherited or $member.DeclaringType = $member.ContainingType
				if $member.LocalName <> ""
], [=$member.CodeName](*this)	// [=$member.LocalName.LiteralJava]
[				endif
			endif
		next
]{
}

[=$type.CodeName]::[=$type.CodeName]([=$type.CodeName] const& other)
: [=$baseTypeName](other.GetNode())
[		foreach $member in $type.Attributes
			if not $filterinherited or $member.DeclaringType = $member.ContainingType
				if $member.LocalName <> ""
], [=$member.CodeName](*this)	// [$x = "@" & $member.LocalName : write $x.LiteralJava]
[				endif
			endif
		next
		foreach $member in $type.Elements
			if not $filterinherited or $member.DeclaringType = $member.ContainingType
				if $member.LocalName <> ""
], [=$member.CodeName](*this)	// [=$member.LocalName.LiteralJava]
[				endif
			endif
		next
]{
}

[		if not $type.IsSimpleType
			$useType = $type
			if $useType.IsAnonymous
				foreach $att in $type.Attributes
					if $att.LocalName = ""
						$useType = $att.DataType
					endif
				next
			endif
			if not $useType.IsAnonymous
]void [=$type.CodeName]::SetXsiType()
{
	[=$typeLibrary]::SetAttribute(m_node, _T("xsi:type"), _T("http://www.w3.org/2001/XMLSchema-instance"), 
		[=$useType.LocalName.LiteralCppT], [=$useType.Namespace.NamespaceURI.LiteralCppT]);
}
[
			endif
		endif

		if $type.IsDocumentRootType

]
[=$type.CodeName] [=$type.CodeName]::LoadFromFile(const string_type& fileName)
{
	return [=$type.CodeName]([=$typeLibrary]::LoadDocument(fileName));
}

[=$type.CodeName] [=$type.CodeName]::LoadFromString(const string_type& text)
{
	return [=$type.CodeName]([=$typeLibrary]::LoadXml(text));
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint)
{
	SaveToFile(fileName, prettyPrint, false);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, bool omitXmlDecl)
{
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, omitXmlDecl, _T("UTF-8"), false, false[if $XercesVersion > 2], _T("\\r\\n")[endif]);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, const string_type& encoding)
{
	std::vector<unsigned char> result;
	string_type sTmpEnc( encoding);
	std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0[if $XercesVersion > 2], _T("\\r\\n")[endif]);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding)
{
	std::vector<unsigned char> result;
	string_type sTmpEnc( encoding);
	std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, omitXmlDecl, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0[if $XercesVersion > 2], _T("\\r\\n")[endif]);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM)
{
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, encoding, bBigEndian, bBOM[if $XercesVersion > 2], _T("\\r\\n")[endif]);
}

[if $XercesVersion > 2]
void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, const string_type& encoding, const string_type& lineend)
{
	SaveToFile(fileName, prettyPrint, false, encoding, lineend);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding, const string_type& lineend)
{
	std::vector<unsigned char> result;
    string_type sTmpEnc( encoding);
    std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, omitXmlDecl, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0, lineend);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend)
{
	SaveToFile(fileName, prettyPrint, false, encoding, bBigEndian, bBOM, lineend);
}

void [=$type.CodeName]::SaveToFile(const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend)
{
	[=$typeLibrary]::SaveDocument(GetDocumentNode(), fileName, prettyPrint, omitXmlDecl, encoding, bBigEndian, bBOM, lineend);
}

string_type [=$type.CodeName]::SaveToString(bool prettyPrint, bool omitXmlDecl)
{
	return [=$typeLibrary]::SaveXml(GetDocumentNode(), prettyPrint, omitXmlDecl, _T("\\r\\n"));
}

[else]

string_type [=$type.CodeName]::SaveToString(bool prettyPrint, bool omitXmlDecl)
{
	return [=$typeLibrary]::SaveXml(GetDocumentNode(), prettyPrint, omitXmlDecl);
}

[endif]

string_type [=$type.CodeName]::SaveToString(bool prettyPrint)
{
	return SaveToString(prettyPrint,false);
}

[=$type.CodeName] [=$type.CodeName]::CreateDocument()
{
	return [=$typeLibrary]::CreateDocument();
}

void [=$type.CodeName]::DestroyDocument()
{
	[=$typeLibrary]::DocumentType doc = GetDocumentNode();
	[=$typeLibrary]::FreeDocument(doc);
	m_node = 0;
}

void [=$type.CodeName]::SetDTDLocation(const string_type& dtdLocation)
{
[if $domtype = 1]
	throw altova::InvalidOperationException(_T("This operation is not supported by MSXML."));
[else]
	xercesc::DOMDocument* document = (xercesc::DOMDocument*)GetNode();
	xercesc::DOMDocumentType* doctype = document->getDoctype();
	if (doctype != 0)
	{
		document->removeChild(doctype);
	}

	xercesc::DOMElement* rootElement = document->getDocumentElement();
	if (rootElement == 0)
		throw altova::InvalidOperationException(_T("You have to add a root element before setting DTD location."));

	doctype = document->createDocumentType(rootElement->getNodeName(), XercesStringTemp(_T("")), XercesStringTemp(dtdLocation));
	document->insertBefore(doctype, rootElement);
[endif]
}

void [=$type.CodeName]::SetSchemaLocation(const string_type& schemaLocation)
{
[if $domtype = 1]
	// find root element
	MSXML2::IXMLDOMNodePtr node = GetNode()->firstChild;
	while (node != 0 && node->nodeType != MSXML2::NODE_ELEMENT)
		node = node->nextSibling;

	if (node == 0)
		throw altova::InvalidOperationException(_T("You have to add a root element before setting schema location."));

	MSXML2::IXMLDOMElementPtr rootElement = node;
	string_type namespaceURI;
	if( rootElement->namespaceURI.length() > 0 )
		namespaceURI = rootElement->namespaceURI;

[else]
	xercesc::DOMDocument* document = (xercesc::DOMDocument*)GetNode();
	xercesc::DOMElement* rootElement = document->getDocumentElement();
	if (rootElement == 0)
		throw altova::InvalidOperationException(_T("You have to add a root element before setting schema location."));

	string_type namespaceURI = XercesUnstringTemp(rootElement->getNamespaceURI());
[endif]	
	
	if (namespaceURI.empty())
		[=$typeLibrary]::SetAttribute(rootElement, _T("xsi:noNamespaceSchemaLocation"), _T("http://www.w3.org/2001/XMLSchema-instance"), schemaLocation);
	else
		[=$typeLibrary]::SetAttribute(rootElement, _T("xsi:schemaLocation"), _T("http://www.w3.org/2001/XMLSchema-instance"), namespaceURI + _T(" ") + schemaLocation);

}

void [=$type.CodeName]::DeclareAllNamespacesFromSchema(ElementType& node)
{
	int i = 0;
	auto ns = ::[=$TheLibrary.Name]::namespaces\[i++\];
	while (ns.Binder)
	{
		if (!string_type(ns.NamespaceURI).empty())
			node.DeclareNamespace(ns.Prefix, ns.NamespaceURI);
		ns = ::[=$TheLibrary.Name]::namespaces\[i++\];
	}
}

[=$type.CodeName] [=$type.CodeName]::LoadFromBinary(const std::vector<unsigned char>& data)
{
	return [=$typeLibrary]::LoadFromBinary(data);
}

[if $XercesVersion > 2]
std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint)
{
	return [=$typeLibrary]::SaveToBinary(([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, _T("\\r\\n"));
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding)
{
	std::vector<unsigned char> result;
    string_type sTmpEnc( encoding);
    std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0, _T("\\r\\n"));
	return result;
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM)
{
	std::vector<unsigned char> result;
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, bBigEndian, bBOM, _T("\\r\\n"));
	return result;
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding, const string_type& lineend)
{
	return SaveToBinary(prettyPrint, false, encoding, lineend);
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, bool omitXmlDecl, const string_type& encoding, const string_type& lineend)
{
	std::vector<unsigned char> result;
    string_type sTmpEnc( encoding);
    std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0, lineend, !omitXmlDecl);
	return result;
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend)
{
	return SaveToBinary(prettyPrint, false, encoding, bBigEndian, bBOM, lineend );
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, bool omitXmlDecl, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend)
{
	std::vector<unsigned char> result;
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, bBigEndian, bBOM, lineend, !omitXmlDecl);
	return result;
}
[else]
std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint)
{
	return [=$typeLibrary]::SaveToBinary(([=$typeLibrary]::DocumentType)GetNode(), prettyPrint);
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding)
{
	std::vector<unsigned char> result;
    string_type sTmpEnc( encoding);
    std::transform( sTmpEnc.begin(), sTmpEnc.end(), sTmpEnc.begin(), _totupper);
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, _tcscmp(sTmpEnc.c_str(), _T("UTF-16BE")) == 0, _tcscmp(sTmpEnc.c_str(), _T("UTF-16")) == 0);
	return result;
}

std::vector<unsigned char> [=$type.CodeName]::SaveToBinary(bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM)
{
	std::vector<unsigned char> result;
	[=$typeLibrary]::SaveToBinary(result, ([=$typeLibrary]::DocumentType)GetNode(), prettyPrint, encoding, bBigEndian, bBOM);
	return result;
}
[endif]

[
		endif
	next
	call EndNamespace ($namespace)
next


foreach $namespace in $TheLibrary.SchemaNamespaces
	call BeginNamespace($namespace)

	foreach $type in $namespace.Types
		$filterinherited = $type.IsDerivedByExtension

		foreach $att in $type.Attributes
			if $att.LocalName = ""
				$attTargetType = "string_type"
				if $att.DataType.IsNativeBound
					$attTargetType = $att.DataType.NativeBinding.ValueType
				endif
				if not $filterinherited or $att.DeclaringType = $att.ContainingType
				
					$facets = $att.DataType.Facets
					if $facets <> 0 and $facets.Enumeration.Length > 0
						$enumOffset = GetEnumOffset($facets)]
int [=$type.CodeName]::GetEnumerationValue() {
	string_type sValue = CastAs<string_type>::Do(GetNode(), members + [=BuildMemberInfoIndexName($att)]);
	return TypeBase::GetEnumerationIndex( sValue, types\[[=BuildTypeInfoIndexName($att.DataType)]\].Facets + [=$enumOffset], [=$facets.Enumeration.Length]);
}

void [=$type.CodeName]::SetEnumerationValue(const int index) {
	const MemberInfo* member = members + [=BuildMemberInfoIndexName($att)];
	[=$typeLibrary]::SetValue(GetNode(), member, TypeBase::GetEnumerationValue(index, types\[[=BuildTypeInfoIndexName($att.DataType)]\].Facets + [=$enumOffset], [=$facets.Enumeration.Length]) );
}
[					endif]
void [=$type.CodeName]::operator=(const [=$attTargetType]& value) { 
	[=$typeLibrary]::SetValue(GetNode(), members + [=BuildMemberInfoIndexName($att)], value);
}

[=$type.CodeName]::operator [=$attTargetType]() {
	return CastAs<[=$attTargetType] >::Do(GetNode(), members + [=BuildMemberInfoIndexName($att)]);
}
[				else
					' the special text() member for derived types
]
void [=$type.CodeName]::operator=(const [=$attTargetType]& value) { 
	[=$type.BaseType.CodeName]::operator=(value);
}
[
				endif
			endif
		next ' $att

	next ' $type

	call EndNamespace($namespace)
next ' $namespace

]
}
