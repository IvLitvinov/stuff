[call GenerateFileHeader($TheLibrary.Name & ".h")

sub  WriteEnumConstants($facets)
	if $facets <> 0 and $facets.Enumeration.Length > 0]
	enum EnumValues {
		Invalid = -1,
[						foreach $enum in $facets.Enumeration
]		[=$enum.Name] = [=$enum.Index], // [=$enum.Value]
[						next
]		EnumValueCount
	};
[	endif
endsub

sub BeginNamespace($namespace)
	if $namespace.CodeName <> ""
]
namespace [=$namespace.CodeName]
{	
[
	endif
endsub


sub EndNamespace($namespace)
	if $namespace.CodeName <> ""
]
} // namespace [=$namespace.CodeName]

[
	endif
endsub

]
#ifndef _INCLUDED_[=$TheLibrary.Name]_H_
#define _INCLUDED_[=$TheLibrary.Name]_H_
[
	if $domtype = 1
		$nodeType = "MSXML2::IXMLDOMNodePtr"
		$typeLibrary = "MsxmlTreeOperations"
	else
		$nodeType = "xercesc::DOMNode*"
		$typeLibrary = "XercesTreeOperations"
	endif
]
#include "../Altova/xs-types.h"
#include "../AltovaXML/Node.h"
#include "[=$TheLibrary.Name]-typeinfo.h"

[	if $libtype = 2 ]
#if !defined( __GNUC__ )
#ifdef [=$TheLibrary.Name]_EXPORTS
#define [=$TheLibrary.Name]_EXPORT	__declspec(dllexport)
#else
#define [=$TheLibrary.Name]_EXPORT	__declspec(dllimport)
#endif
#else
#define [=$TheLibrary.Name]_EXPORT
#endif
[	else
]#define [=$TheLibrary.Name]_EXPORT	
[	endif
]

namespace [=$TheLibrary.Name]
{

	class TypeBase
	{
	protected:
		[=$nodeType] m_node;
	public:
		TypeBase([=$nodeType] const& node) : m_node(node) {}
		[=$nodeType] GetNode() const { return m_node; }

		[=$TheLibrary.Name]_EXPORT [=$nodeType] GetElementNth(const altova::MemberInfo* member, unsigned index);
		[=$TheLibrary.Name]_EXPORT [=$nodeType] GetElementLast(const altova::MemberInfo* member);
		[=$TheLibrary.Name]_EXPORT unsigned CountElement(const altova::MemberInfo* member);
		[=$TheLibrary.Name]_EXPORT void RemoveElement(const altova::MemberInfo* member);
		[=$TheLibrary.Name]_EXPORT static int GetEnumerationIndex( const string_type sValue, const unsigned enumOffset, const unsigned enumCount);
		[=$TheLibrary.Name]_EXPORT static string_type GetEnumerationValue( const int index, const unsigned enumOffset, const unsigned enumCount);
	};

	class ElementType : public TypeBase
	{
	public:
		ElementType([=$nodeType] const& node) : TypeBase( node ) {}

		[=$TheLibrary.Name]_EXPORT void DeclareNamespace( const string_type prefix, const string_type namespaceURI );
	};

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	class MemberAttribute
	{
		TypeBase& m_owner;
	public:
		typedef const MemberType& argument_type;
		typedef MemberType return_type;

		MemberAttribute(TypeBase& owner) : m_owner(owner) {}
		void operator=(argument_type value);
		operator return_type();
		bool exists();
		void remove();
		int GetEnumerationValue();
		void SetEnumerationValue(const int index);
		altova::meta::Attribute info() const { return altova::meta::Attribute(members + MemberIndex); }
	};

	template <typename MemberType>
	class CastAs 
	{
	public:
		static MemberType Do([=$nodeType] const& node, const altova::MemberInfo* pMember);
	};

	template <>
	inline bool CastAs<bool>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToBool(node, pMember);
	}

	template <>
	inline double CastAs<double>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToDouble(node, pMember);
	}

	template <>
	inline int CastAs<int>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToInt(node, pMember);
	}

	template <>
	inline unsigned CastAs<unsigned>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToUInt(node, pMember);
	}

	template <>
	inline __int64 CastAs<__int64>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToInt64(node, pMember);
	}

	template <>
	inline unsigned __int64 CastAs<unsigned __int64>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToUInt64(node, pMember);
	}

	template <>
	inline string_type CastAs<string_type>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToString(node, pMember);
	}

	template <>
	inline std::vector<unsigned char> CastAs<std::vector<unsigned char> >::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToBinary(node, pMember);
	}

	template <>
	inline altova::DateTime CastAs<altova::DateTime>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToDateTime(node, pMember);
	}

	template <>
	inline altova::Duration CastAs<altova::Duration>::Do([=$nodeType] const& node, const altova::MemberInfo* pMember)
	{
		return [=$typeLibrary]::CastToDuration(node, pMember);
	}

	template <typename DataType>
	class Iterator : public DataType
	{
		[=$typeLibrary]::MemberIterator m_it;
	public:
		Iterator(const [=$typeLibrary]::MemberIterator& it) : DataType(0), m_it(it) { if (m_it) this->m_node = *m_it; }
		bool operator++() { if (++m_it) { this->m_node = *m_it; return true; } return false; }
		operator bool() const { return m_it; }		

		DataType& operator*() { return *this; }
		DataType* operator->() { return this; }
	};

	template <typename MemberType, unsigned MemberIndex>
	class MemberElement
	{
		TypeBase& m_owner;
	public:
		MemberElement(TypeBase& owner) : m_owner(owner) {}
		MemberType operator\[\](unsigned index);
		MemberType first();
		MemberType last();
		MemberType append();
		MemberType appendWithPrefix(string_type prefix);
		bool exists();
		unsigned count();
		void remove();
		void remove(unsigned index);
		altova::meta::Element info() const { return altova::meta::Element(members + MemberIndex); }

		Iterator<MemberType> all() { return [=$typeLibrary]::GetElements(m_owner.GetNode(), members + MemberIndex); }
	};

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	void MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::operator=(argument_type value)
	{
		[=$typeLibrary]::SetValue(m_owner.GetNode(), members + MemberIndex, value);
	}

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::operator typename MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::return_type()
	{
		[=$nodeType] att = [=$typeLibrary]::FindAttribute(m_owner.GetNode(), members + MemberIndex);
		if (![=$typeLibrary]::IsValid(att))
			throw altova::InvalidOperationException(_T("Cannot read value of non-existent attribute."));
		return CastAs<MemberType>::Do(att, members + MemberIndex);
	}

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	bool MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::exists()
	{
		[=$nodeType] att = [=$typeLibrary]::FindAttribute(m_owner.GetNode(), members + MemberIndex);
		return [=$typeLibrary]::IsValid(att);
	}

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	void MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::remove()
	{
		[=$typeLibrary]::RemoveAttribute(m_owner.GetNode(), members + MemberIndex);
	}
	
	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	int MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::GetEnumerationValue() {
		[=$nodeType] att = [=$typeLibrary]::FindAttribute(m_owner.GetNode(), members + MemberIndex);
		if (![=$typeLibrary]::IsValid(att))
			throw altova::InvalidOperationException(_T("Cannot read value of non-existent attribute."));
		string_type sValue = CastAs<string_type>::Do(att, members + MemberIndex);
		return TypeBase::GetEnumerationIndex( sValue, types\[members\[MemberIndex\].DataType\].Facets + EnumOffset, EnumCount);
	}

	template <typename MemberType, unsigned MemberIndex, unsigned EnumOffset, unsigned EnumCount>
	void MemberAttribute<MemberType, MemberIndex, EnumOffset, EnumCount>::SetEnumerationValue(const int index) 
	{
		[=$typeLibrary]::SetValue(m_owner.GetNode(), members + MemberIndex, TypeBase::GetEnumerationValue(index, types\[members\[MemberIndex\].DataType\].Facets + EnumOffset, EnumCount) );
	}

	template <typename MemberType, unsigned MemberIndex>
	MemberType MemberElement<MemberType, MemberIndex>::operator\[\](unsigned index)
	{
		return m_owner.GetElementNth(members + MemberIndex, index);
	}

	template <typename MemberType, unsigned MemberIndex>
	MemberType MemberElement<MemberType, MemberIndex>::first()
	{
		return m_owner.GetElementNth(members + MemberIndex, 0);
	}

	template <typename MemberType, unsigned MemberIndex>
	MemberType MemberElement<MemberType, MemberIndex>::last()
	{
		return m_owner.GetElementLast(members + MemberIndex);
	}

	template <typename MemberType, unsigned MemberIndex>
	MemberType MemberElement<MemberType, MemberIndex>::append()
	{
		return [=$typeLibrary]::AddElement(m_owner.GetNode(), members + MemberIndex);
	}

	template <typename MemberType, unsigned MemberIndex>
	MemberType MemberElement<MemberType, MemberIndex>::appendWithPrefix( string_type prefix )
	{
		return [=$typeLibrary]::AddElement( m_owner.GetNode(), prefix, info().GetLocalName(), info().GetNamespaceURI() );
	}

	template <typename MemberType, unsigned MemberIndex>
	bool MemberElement<MemberType, MemberIndex>::exists()
	{
		return m_owner.GetElementNth(members + MemberIndex, 0) != 0;
	}

	template <typename MemberType, unsigned MemberIndex>
	unsigned MemberElement<MemberType, MemberIndex>::count()
	{
		return m_owner.CountElement(members + MemberIndex);
	}

	template <typename MemberType, unsigned MemberIndex>
	void MemberElement<MemberType, MemberIndex>::remove()
	{
		m_owner.RemoveElement(members + MemberIndex);
	}

	template <typename MemberType, unsigned MemberIndex>
	void MemberElement<MemberType, MemberIndex>::remove(unsigned index)
	{
		[=$typeLibrary]::RemoveElement(m_owner.GetNode(), members + MemberIndex, index);
	}

}

namespace [=$TheLibrary.Name]
{
[
foreach $namespace in $TheLibrary.SchemaNamespaces
]// Namespace: [=$namespace.NamespaceURI] 
// SchemaPrefix: [=$namespace.LocalName]
[
	call BeginNamespace($namespace)

	foreach $type in $namespace.Types
]class [=$type.CodeName];
[	next

	call EndNamespace($namespace)
next

]
}

// include individual types
[
	foreach $namespace in $TheLibrary.SchemaNamespaces
]
// namespace [=$namespace.NamespaceURI.LiteralJava]
[		foreach $type in $namespace.Types
]#include "type_[=$namespace.CodeName].[=$type.CodeName].h"
[		next
	next
]
// finished

#endif //_INCLUDED_[=$TheLibrary.Name]_H_
[
	close
	' create types in individual namespaces

sub GetMemberType($member)
	if $member.DataType.Namespace.CodeName = ""
		return $member.DataType.CodeName
	else
		return $member.DataType.Namespace.CodeName & "::" & $member.DataType.CodeName
	endif
endsub

foreach $namespace in $TheLibrary.SchemaNamespaces
	foreach $type in $namespace.Types
		$fn = $BasePath & "type_" & $namespace.CodeName & "." & $type.CodeName & ".h"
		create $fn
]#ifndef _ALTOVA_INCLUDED_[=$TheLibrary.Name]_ALTOVA_[=$namespace.CodeName]_ALTOVA_[=$type.CodeName]
#define _ALTOVA_INCLUDED_[=$TheLibrary.Name]_ALTOVA_[=$namespace.CodeName]_ALTOVA_[=$type.CodeName]

[
	
if $type.IsSimpleType or $type.IsDocumentRootType
	$baseTypeName = "TypeBase"
else
	$baseTypeName = "ElementType"
endif


	$filterinherited = false
	if $type.IsDerivedByExtension
		$filterinherited = true
]#include "type_[=$type.BaseType.Namespace.CodeName].[=$type.BaseType.CodeName].h"
[	
		if $type.BaseType.Namespace.CodeName <> ""
			$baseTypeName = "::" & $TheLibrary.Name & "::" & $type.BaseType.Namespace.CodeName & "::" & $type.BaseType.CodeName
		else
			$baseTypeName = "::" & $TheLibrary.Name & "::" & $type.BaseType.CodeName
		endif
	endif
]

namespace [=$TheLibrary.Name]
{
[
	call BeginNamespace($namespace)
]
class [=$type.CodeName] : public [=$baseTypeName]
{
public:
	[=$TheLibrary.Name]_EXPORT [=$type.CodeName]([=$nodeType] const& init);
	[=$TheLibrary.Name]_EXPORT [=$type.CodeName]([=$type.CodeName] const& init);
	void operator=([=$type.CodeName] const& other) { m_node = other.m_node; }
[		if $type.IsSimpleType
]	static altova::meta::SimpleType StaticInfo() { return altova::meta::SimpleType(types + [=BuildTypeInfoIndexName($type)]); }
[		else
]	static altova::meta::ComplexType StaticInfo() { return altova::meta::ComplexType(types + [=BuildTypeInfoIndexName($type)]); }
[		endif
		foreach $att in $type.Attributes
			$attTargetType = "string_type"
			if $att.DataType.IsNativeBound
				$attTargetType = $att.DataType.NativeBinding.ValueType
			endif
			if not $filterinherited or $att.DeclaringType = $att.ContainingType
				if $att.LocalName = ""	
					' the special text() member
					
					'enumeration
					$facets = $att.DataType.Facets
					if $facets <> 0 and $facets.Enumeration.Length > 0
					call WriteEnumConstants($facets)]
	
	[=$TheLibrary.Name]_EXPORT int GetEnumerationValue();
	[=$TheLibrary.Name]_EXPORT void SetEnumerationValue( const int index);
[					endif
]	[=$TheLibrary.Name]_EXPORT void operator=(const [=$attTargetType]& value);
	[=$TheLibrary.Name]_EXPORT operator [=$attTargetType]();
[
				else
					' a normal member
					$facets = $att.DataType.Facets
					if $facets <> 0 and $facets.Enumeration.Length > 0
						$enumOffset = GetEnumOffset($facets)
]	MemberAttribute<[=$attTargetType],[=BuildMemberInfoIndexName($att)], [=$enumOffset], [=$facets.Enumeration.Length]> [=$att.CodeName];	// [=$att.LocalName] [=$att.DataType.CodeName]
[					else]
	MemberAttribute<[=$attTargetType],[=BuildMemberInfoIndexName($att)], 0, 0> [=$att.CodeName];	// [=$att.LocalName] [=$att.DataType.CodeName]
[					endif
				endif
			else
				if $att.LocalName = ""
					' the special text() member for derived types
]	[=$TheLibrary.Name]_EXPORT void operator=(const [=$attTargetType]& value);
[
				endif
			endif
		next ' attribute

		foreach $el in $type.Elements
			if not $filterinherited or $el.DeclaringType = $el.ContainingType
]	MemberElement<[=GetMemberType($el)], [=BuildMemberInfoIndexName($el)]> [=$el.CodeName];
	struct [=$el.CodeName] { typedef Iterator<[=GetMemberType($el)]> iterator; };
[			endif
		next ' element
		
		' If this is a simple type then there was not a lot of code generated right now.
		' Do something about that.
		if $type.IsSimpleType
			'Enumerations
			call WriteEnumConstants($type.Facets)
			
			if $type.IsNativeBound
]	void operator= (const [=$type.NativeBinding.ValueType]& value) 
	{
		altova::XmlFormatter* Formatter = static_cast<altova::XmlFormatter*>([=$type.NativeBinding.ValueHandler]);
		[=$typeLibrary]::SetValue(GetNode(), Formatter->Format(value));
	}	
		
	operator [=$type.NativeBinding.ValueType]()
	{
		return CastAs<[=$type.NativeBinding.ValueType] >::Do(GetNode(), 0);
	}
[
			endif
		else  ' not IsSimpleType 
			$useType = $type
			if $useType.IsAnonymous
				foreach $att in $type.Attributes
					if $att.LocalName = ""
						$useType = $att.DataType
					endif
				next
			endif
			if not $useType.IsAnonymous
]	[=$TheLibrary.Name]_EXPORT void SetXsiType();
[
			endif 		
		endif ' not IsSimpleType

		if $type.IsDocumentRootType
]
	// document functions
	[=$TheLibrary.Name]_EXPORT static [=$type.CodeName] LoadFromFile(const string_type& fileName);
	[=$TheLibrary.Name]_EXPORT static [=$type.CodeName] LoadFromString(const string_type& xml);
	[=$TheLibrary.Name]_EXPORT static [=$type.CodeName] LoadFromBinary(const std::vector<unsigned char>& data);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, bool omitXmlDecl);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, const string_type& encoding);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding, bool bBigEndian, bool bBOM);
[if $XercesVersion > 2]
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, const string_type& encoding, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT void SaveToFile( const string_type& fileName, bool prettyPrint, bool omitXmlDecl, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend);
[endif]
	[=$TheLibrary.Name]_EXPORT string_type SaveToString(bool prettyPrint);
	[=$TheLibrary.Name]_EXPORT string_type SaveToString(bool prettyPrint, bool omitXmlDecl);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, const string_type& encoding);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM);
[if $XercesVersion > 2]
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, const string_type& encoding, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, bool omitXmlDecl, const string_type& encoding, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend);
	[=$TheLibrary.Name]_EXPORT std::vector<unsigned char> SaveToBinary(bool prettyPrint, bool omitXmlDecl, const string_type& encoding, bool bBigEndian, bool bBOM, const string_type& lineend);
[endif]
 	[=$TheLibrary.Name]_EXPORT static [=$type.CodeName] CreateDocument();
	[=$TheLibrary.Name]_EXPORT void DestroyDocument();
	[=$TheLibrary.Name]_EXPORT void SetDTDLocation(const string_type& dtdLocation);
	[=$TheLibrary.Name]_EXPORT void SetSchemaLocation(const string_type& schemaLocation);
	[=$TheLibrary.Name]_EXPORT static void DeclareAllNamespacesFromSchema(ElementType& node);
protected:
	[=$typeLibrary]::DocumentType GetDocumentNode() { return ([=$typeLibrary]::DocumentType)m_node; }
[		endif ' IsDocumentRootType
]};


[
		call EndNamespace($namespace)
]}	// namespace [=$TheLibrary.Name]

#endif // _ALTOVA_INCLUDED_[=$TheLibrary.Name]_ALTOVA_[=$namespace.CodeName]_ALTOVA_[=$type.CodeName]
[
		close
	next ' type

next ' namespace


]