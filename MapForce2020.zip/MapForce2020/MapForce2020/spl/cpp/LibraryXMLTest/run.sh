#!/bin/sh
BASEDIR=`cd "\\`dirname $0\\`";cd ..;pwd`
[if $libtype = 2 'DLL]
LD_LIBRARY_PATH=$BASEDIR/Altova:$BASEDIR/AltovaXML:$BASEDIR/[=$module]:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
[endif]
$BASEDIR/[=$module]Test/[=$module]Test