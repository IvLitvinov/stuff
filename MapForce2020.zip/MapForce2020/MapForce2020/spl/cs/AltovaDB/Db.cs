using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using Altova.Types;
using Altova.Mapforce;
using Altova.Functions;


namespace Altova.Db
{
	public class TParameter
	{
		public TParameter(System.Data.DbType t) { type = t; }
		public TParameter(System.Data.DbType t, int l, int p, int s, string n) { type = t; scale = s; precision = p; length = l; name = n; }
		public System.Data.DbType type;
		public int scale = -1;
		public int precision = -1;
		public int length = -1;
		public string name = null;
	}

	public class Record
	{
		public Dictionary<string, IEnumerable> fields	= new Dictionary<string, IEnumerable>();
		public Dictionary<string, IEnumerable> children	= new Dictionary<string, IEnumerable>();
	}
	
	public class Recordset
	{
		public IDataReader reader;
		public Catalog catalog;
		private IDbConnection connection;
		public IDbCommand command;

		public Recordset(Catalog catalog, IDataReader reader, IDbConnection conn, IDbCommand command)
		{
			this.catalog = catalog;
			this.reader = reader;
			this.connection = conn;
			this.command = command;
		}

		public void Close()
		{
			reader.Close();
			reader.Dispose();
			catalog.FreeConnection(connection);
		}
	}

	public class Statement
	{
		private IDbCommand command = null;
		private Catalog catalog= null;
		private List<TParameter> parameters = new List<TParameter>();
		private List<object> values = new List<object>();

		public Statement(Catalog cat, string statement)
		{
			catalog = cat;
			command = cat.MainConnection.CreateCommand();
			command.CommandText = statement;
			command.CommandType = CommandType.Text;
			command.CommandTimeout = cat.CommandTimeout;

['special code for teradata to be able to read identity (generated always) key values 
'			if (command.GetType().FullName.Equals("Teradata.Client.Provider.TdCommand")) {
'				const byte IdentityColumn = 67;//Teradata.Client.Provider.GeneratedDataBehavior.IdentityColumn
'				command.GetType().GetProperty("GeneratedDataBehavior").SetValue(command, IdentityColumn, null);
'			}
]		}

		public IDbCommand Command { get { return command; } }
		public IDbConnection Connection
		{
			get
			{
				return command.Connection;
			}
			set
			{
				if (command.Connection != value)
				{
					ICloneable c = command as ICloneable;
					if (c == null)
						throw new InvalidOperationException("Need to use a cloneable command");
					command = (IDbCommand)c.Clone();
					command.Connection = value;
				}
			}
		}
		public void AddParameter(TParameter par) { parameters.Add(par); }
		public TParameter GetParameter(int i) { return parameters\[i\]; }
		public void BindParameter(object val) { values.Add(val); }
		public void BindParameter(object val, int len, int precision, int scale)
		{
			values.Add(val);
			int i = values.Count - 1;
			parameters\[i\].length = len;
			parameters\[i\].precision = precision;
			parameters\[i\].scale = scale;
		}
		public int GetValueCount() { return values.Count; }
		public void Clear() { values.Clear(); }
		private bool UsePrepare() { if (parameters.Count == 0 && !command.CommandText.StartsWith("SELECT")) return false; return true; }
		public void Prepare()
		{
			foreach (TParameter p in parameters)
			{
				IDbDataParameter par = command.CreateParameter();
				par.DbType = p.type;
				if (p.type == DbType.Decimal && p.precision < 0) p.precision = 1;['decimal parameter from Where component]
				if (p.precision > 0) par.Precision = (byte) p.precision;
				if (p.type == DbType.Decimal && p.scale < 0) p.scale = 0;['decimal parameter from Where component]
				if (p.scale > 0) par.Scale = (byte) p.scale;
				par.Size = (p.length > 0) ? p.length : 2000;
				if (p.name != null && !p.name.Equals("?")) 
					par.ParameterName = p.name;

				command.Parameters.Add(par);
			}
			if( UsePrepare() ) { command.Prepare(); }
		}

		private void PreExecute()
		{
			for (int i = 0; i < values.Count; i++)
			{
				TParameter p = parameters\[i\];
				IDbDataParameter db = ((IDbDataParameter)command.Parameters\[i\]);
				if (p.precision > 0 && p.precision > db.Precision)
					db.Precision = (byte)p.precision;
				if (p.scale >= 0 && p.scale > db.Scale)
					db.Scale = (byte)p.scale;
				if (p.length > 0 && p.length > db.Size)
					db.Size = p.length;

				db.Value = values\[i\] != null ? values\[i\] : DBNull.Value;
			}

			command.Transaction = catalog.CurrentTransaction;
		}

		public Recordset Execute()
		{
			PreExecute();
			
			IDataReader reader = command.ExecuteReader();
			while (reader.IsClosed && reader.NextResult()) {}

			return new Recordset(catalog, reader, command.Connection, command);
		}

		public int ExecuteNonReader()
		{
			PreExecute();
			return command.ExecuteNonQuery();
		}
	}

	public class Catalog
	{
		private IDbConnection mainConnection = null;
		private Dictionary<int, Statement> map = new Dictionary<int, Statement>();
		private bool visible = true;
		private bool inUse = false;
		private IDbTransaction currentTransaction = null;
		private bool targetCatalog = false;
		private int commandTimeout = 60;
		
		public Catalog(IDbConnection connection, int queryTimeout, bool isTarget)
		{
			mainConnection = connection;
			commandTimeout = queryTimeout;
			targetCatalog = isTarget;
		}
		
		public Catalog(IDbConnection connection, int queryTimeout)
		{
			mainConnection = connection;
			commandTimeout = queryTimeout;
		}

		public Catalog(IDbConnection connection)
		{
			mainConnection = connection;
		}

		public void Close()
		{
			visible = false;
			if (!inUse) 
				mainConnection.Close();
		}

		public IDbConnection AllocateConnection()
		{
			if (targetCatalog)
				return mainConnection;
				
			if (inUse)
			{
				ICloneable cloneable = mainConnection as ICloneable;
				if (cloneable == null)
					throw new InvalidOperationException("Need to use a cloneable connection");

				IDbConnection use = (IDbConnection)cloneable.Clone();
				use.Open();
				return use;
			}
			else
			{
				IDbConnection use = mainConnection;
				if (use.State == ConnectionState.Closed)
					use.Open();

				inUse = true;
				return use;
			}
		}

		public void FreeConnection(IDbConnection conn)
		{
			if (conn == mainConnection)
			{
				inUse = false;
				if (!visible)
					mainConnection.Close();
			}
			else
				conn.Close();
		}

		public IDbConnection MainConnection { get { return mainConnection; } }

		public int CommandTimeout { get { return commandTimeout; } }

		public Statement GetStatement(int id) { return map\[id\]; }

		public Statement CreateStatement(int id, string statement_string)
		{
			Statement statement = new Statement(this, statement_string);
			map\[id\] = statement;
			return statement;
		}
		
		public IDbTransaction CurrentTransaction
		{
			get { return currentTransaction; }
			set { currentTransaction = value; }
		}
	}

	public class TransactionHelper
	{
		string beginTrans;
		string commitTrans;
		string rollbackTrans;
		string savepoint;
		string rollbackSavepoint;
		IDbConnection connection;
		IDbTransaction transaction;
		int depth;
		
		public IDbTransaction Transaction { get { return transaction; } }
		
		void ExecuteCommandString(string s)
		{
			IDbCommand comm = connection.CreateCommand();
			comm.CommandText = s;
			comm.Transaction = Transaction;
			comm.ExecuteNonQuery();
		}
		
		void ExecuteCommandString(string s, string replaceName)
		{
			ExecuteCommandString(s.Replace(" %%TRANSACTION_NAME%% ", replaceName));
		}
		
		public TransactionHelper(IDbConnection conne, string begin, string commit,	string rollback, string save, string rollbackSave)
		{
			connection = conne;
			beginTrans = begin;
			commitTrans = commit;
			rollbackTrans = rollback;
			savepoint = save;
			rollbackSavepoint = rollbackSave;
			depth = 0;
		}
		
		public void BeginTrans(string transName)
		{
			if (depth == 0)
			{
				try { transaction = connection.BeginTransaction(); }
				catch (Exception) { }// driver is not capable
				
				if (transaction == null && beginTrans.Length != 0)
					ExecuteCommandString(beginTrans);
			}
			else
			{
				if (savepoint.Length != 0)
					ExecuteCommandString(savepoint, transName);
			}
			++depth;
		}
		
		public void CommitTrans()
		{
			--depth;
			if (depth == 0)
			{
				if (transaction != null)
				{
					transaction.Commit();
					transaction = null;
				}
				else
				{
					if (commitTrans.Length != 0)
						ExecuteCommandString(commitTrans);
				}
			}
		}
		
		public void RollbackTrans(string transName)
		{
			--depth;
			if (depth == 0)
			{
				if (transaction != null)
				{
					transaction.Rollback();
					transaction = null;
				}
				else
				{
					if (rollbackTrans.Length != 0)
						ExecuteCommandString(rollbackTrans);
				}
			}
			else
			{
				if (savepoint.Length != 0)
					ExecuteCommandString(rollbackSavepoint, transName);
			}
		}
	}
	
	public class TransactionSentinel : System.IDisposable
	{
		private TransactionHelper tr;
		string name;
		
		public TransactionSentinel (TransactionHelper t, string name)
		{
			tr = t;
			this.name = name;
			tr.BeginTrans(name);
		}
		
		public void Commit()
		{
			if (tr != null)
			{
				tr.CommitTrans();
				tr = null;
			}
		}
		
		public void Rollback()
		{
			if (tr != null)
			{
				tr.RollbackTrans(name);
				tr = null;
			}
		}
		
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}
		protected virtual void Dispose(bool disposing)
		{
			Rollback();
		}
	}

	public class Dbs
	{
		class ForceOne : IEnumerable
		{
			object value;
			
			public ForceOne(IEnumerable seq)
			{
				IEnumerator en = seq.GetEnumerator();
				try 
				{
					if (en.MoveNext())
						this.value = en.Current;
				}
				finally
				{
					IDisposable disp = en as IDisposable;
					if (disp != null)
						disp.Dispose();
				}
			}
			
			class EmptyEnumerator : IEnumerator
			{
				public void Reset() {throw new InvalidOperationException(); }
				public bool MoveNext() { return false; }
				public object Current { get { throw new InvalidOperationException(); } }
			}

			class InfiniteEnumerator : IEnumerator
			{
				object o;
				public InfiniteEnumerator(object o) { this.o = o; }
				public void Reset() {throw new InvalidOperationException(); }
				public bool MoveNext() { return true; }
				public object Current { get { return o; } }
			}

			public IEnumerator GetEnumerator()
			{
				if (value != null) return new InfiniteEnumerator(value); else return new EmptyEnumerator();
			}
		}

		static public void WriteField(Record record, string field, IEnumerable value)
		{
			record.fields\[field\] = new ForceOne(value);
		}

		static public int ExecuteNonReader(Statement statement)
		{
			return statement.ExecuteNonReader();
		}
		
		static public void AddChildren(Record record, string field, IEnumerable children)
		{
			record.children\[field\] = children;
		}
		
		static public IEnumerable GetChildren(Record record, string field)
		{
			return record.children\[field\];
		}

		static public IEnumerable ReadField(Record record, string name)
		{
			return record.fields\[name\];
		}
		
		static public void BindParameter_empty(Statement command)
		{
			command.BindParameter(null);
		}
		
		static public void BindParameter_string_direct(Statement command, string value)
		{
			command.BindParameter(value);
		}

		static public void BindParameter_string(Statement command, string value)
		{
			command.BindParameter(value, value.Length, -1, -1);
		}
		
		static public void BindParameter_decimal_direct(Statement command, decimal value)
		{
			command.BindParameter(value);
		}

		static public void BindParameter_decimal(Statement command, decimal value)
		{
			int precision = 0;
			int scale = 0;
			bool inFraction = false;
			bool nonZeroSeen = false;

			string s = value.ToString(System.Globalization.CultureInfo.InvariantCulture);

			foreach (char c in s)
			{
				if (inFraction)
				{
					if (c != '0')
						nonZeroSeen = true;

					precision++;
					scale++;
				}
				else
				{
					if (c == '.')
					{
						inFraction = true;
					}
					else if (c != '-')
					{
						if (c != '0' || nonZeroSeen)
						{
							nonZeroSeen = true;
							precision++;
						}
					}
				}
			}

			// Handles cases where all digits are zeros.
			if (!nonZeroSeen)
				precision += 1;

			command.BindParameter((object)value, -1, precision, scale);
		}
		
		static public void BindParameter_DateTime(Statement command, Altova.Types.DateTime value)
		{
			command.BindParameter(value.Value);
		}
		
		static public void BindParameter_TimeSpan(Statement command, Altova.Types.DateTime value)
		{
			System.DateTime dt = value.Value; // extract time from datetime
			System.TimeSpan ts = new System.TimeSpan( 0, dt.Hour, dt.Minute, dt.Second, dt.Millisecond );
			BindParameter_TimeSpan( command, ts );
		}

		static public void BindParameter_TimeSpan(Statement command, System.TimeSpan value)
		{
			command.BindParameter(value);
		}

		static public void BindParameter_long(Statement command, long value)
		{
			command.BindParameter(value);
		}
		
		static public void BindParameter_ulong(Statement command, ulong value)
		{
			command.BindParameter(value);
		}
		
		static public void BindParameter_int(Statement command, int value)
		{
			command.BindParameter(value);
		}

		static public void BindParameter_double(Statement command, double value)
		{
			command.BindParameter(value);
		}
		
		static public void BindParameter_bool(Statement command, bool value)
		{
			command.BindParameter(value);
		}
		
		static public void BindParameter_binary(Statement command, byte\[\] value)
		{
			command.BindParameter(value, value.Length, -1, -1);
		}

		static public void BindParameter_IntervalDaySecond(Statement command, Duration d)
		{
			String s = d.IsNegative() ? "-" : "+";
			TimeSpan ts = d.IsNegative() ? d.Value.Negate() : d.Value;

			s += ts.Days;
			s += " ";

			s += ts.Hours;
			s += ":";
			s += ts.Minutes;
			s += ":";
			s += ts.Seconds;

			double partsecond = (System.Math.Abs(d.Value.Ticks) / 10000000.0) % 1.0;
			if (partsecond > 0.0 && partsecond < 1.0)
			{
				string sPartSecond = partsecond.ToString("0.##########");
				s += "." + sPartSecond.Substring(2, sPartSecond.Length - 2);
			}

			command.BindParameter(s, s.Length, 0, 0);
		}

		static public void BindParameter_IntervalYearMonth(Statement command, Duration d)
		{
			String s = d.IsNegative() ? "-" : "+";

			s += System.Math.Abs(d.Years);
			s += "-";
			s += System.Math.Abs(d.Months);

			command.BindParameter(s, s.Length, 0, 0);
		}

		static public void BindParameter_Interval(Statement command, Duration d, IntervalPart part)
		{
			String s = d.IsNegative() ? "-" : "";
			TimeSpan ts = d.IsNegative() ? d.Value.Negate() : d.Value;

			if ((part & (IntervalPart.Year|IntervalPart.Month)) != 0)
			{
				if ((part & IntervalPart.Year) == IntervalPart.Year)
				{
					s += System.Math.Abs(d.Years);
				}

				if (((part & IntervalPart.Year) == IntervalPart.Year)
				&& ((part & IntervalPart.Month) == IntervalPart.Month))
				{
					s += "-";
				}

				if ((part & IntervalPart.Month) == IntervalPart.Month)
				{
					if (part == IntervalPart.Month)
					{// for interval month to month
						int y = System.Math.Abs(d.Years);
						int m = System.Math.Abs(d.Months);
						s += (int)((y*12) + (m%12));
					}
					else 
					{
						s += System.Math.Abs(d.Months);
					}
				}
			}
			else
			{

				if ((part & IntervalPart.Day) == IntervalPart.Day) 
				{
					s += System.Math.Abs(ts.Days);
				}

				if(((part & IntervalPart.Day) == IntervalPart.Day)
				&& ((part & IntervalPart.Hour) == IntervalPart.Hour))
				{
					s += " ";
				}

				if ((part & IntervalPart.Hour) == IntervalPart.Hour)
				{
					if ((part & IntervalPart.Day) == IntervalPart.Day)
					{
						s += System.Math.Abs(ts.Hours).ToString("0#");
					}
					else
					{
						s += System.Math.Abs(System.Math.Truncate(ts.TotalHours)).ToString("0#");
					}
				}

				if (((part & IntervalPart.Hour) == IntervalPart.Hour)
				&& ((part & IntervalPart.Minute) == IntervalPart.Minute))
				{
					s += ":";
				}

				if ((part & IntervalPart.Minute) == IntervalPart.Minute)
				{
					if ((part & IntervalPart.Hour) == IntervalPart.Hour)
					{
						s += System.Math.Abs(ts.Minutes).ToString("0#");
					}
					else
					{
						s += System.Math.Abs(System.Math.Truncate(ts.TotalMinutes)).ToString("0#");
					}
				}

				if (((part & IntervalPart.Minute) == IntervalPart.Minute)
				&& ((part & IntervalPart.Second) == IntervalPart.Second))
				{
					s += ":";
				}

				if ((part & IntervalPart.Second) == IntervalPart.Second)
				{
					if ((part & IntervalPart.Minute) == IntervalPart.Minute)
					{
						s += System.Math.Abs(ts.Seconds).ToString("0#");
					}
					else
					{
						s += System.Math.Abs(System.Math.Truncate(ts.TotalSeconds)).ToString("0#");
					}
				}

				if ((part & IntervalPart.Fraction) == IntervalPart.Fraction)
				{
					int scale = command.GetParameter(command.GetValueCount()).scale;
					double partsecond = (System.Math.Abs(d.Value.Ticks) / 10000000.0) % 1.0;
					if (scale > 0 && (partsecond > 0.0 && partsecond < 1.0))
					{
						Decimal f = Convert.ToDecimal(Math.Pow(10, scale));
						Decimal dx = Math.Truncate(Math.Round(Convert.ToDecimal(partsecond) * f, 1));
						if (dx == f) dx -= 1.0m;// fix for rounding issue 
						s += "." + dx.ToString(new string('0', scale), System.Globalization.CultureInfo.InvariantCulture);
					} else if ((part == IntervalPart.Fraction) && (scale > 0) && (partsecond == 0.0)) {
						s += ".0";
					}
				}
			}

			command.BindParameter(s);
		}

		public static partial class Access // bind parameter
		{
		
			static public void BindParameter_DateTime(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.Value.ToOADate());
			}
			
		}// Access


		public static partial class PostgreSQL // bind parameter
		{
			
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime value)
			{
				value.TimezoneOffset = Altova.Types.DateTime.NoTimezone;
				command.BindParameter(value.ToString(DateTimeFormat.W3_time));
			}

			static public void BindParameter_TimeTZ(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.W3_time));
			}
			
			static public void BindParameter_Money(Statement command, double value)
			{
				command.BindParameter(value.ToString(System.Globalization.CultureInfo.InvariantCulture));
			}

			static public void BindParameter_Interval(Statement command, Duration d)
			{
				bool negative = d.IsNegative();
				TimeSpan ts = negative ? d.Value.Negate() : d.Value;

				String s = "";
				s += d.Years;
				s += " year ";
				s += d.Months;
				s += " month ";
				s += ts.Days;
				s += " day ";
				
				s += negative ? "-" : "";
				s += System.Math.Abs(ts.Hours);
				s += ":";
				s += System.Math.Abs(ts.Minutes);
				s += ":";
				s += System.Math.Abs(ts.Seconds);

				double partsecond = (System.Math.Abs(d.Value.Ticks) / 10000000.0) % 1.0;
				if (partsecond > 0.0 && partsecond < 1.0)
				{
					string sPartSecond = partsecond.ToString("0.##########");
					s += "." + sPartSecond.Substring(2, sPartSecond.Length - 2);
				}

				command.BindParameter(s, s.Length, 0, 0);
			}

			static public void BindParameter_Unicode(Statement command, string value)
			{
				System.Text.Encoding encoding = System.Text.Encoding.UTF8;
				byte\[\] buffer = encoding.GetBytes(value);
				command.BindParameter(buffer, buffer.Length, -1, -1);
			}
		
		}// PostgreSQL


		public static partial class MySQL // bind parameter
		{
			static public void BindParameter_Bitfield(Statement command, ulong value)
			{
				List<byte> bytes = new List<byte>(BitConverter.GetBytes( value ));
				int idx = bytes.FindLastIndex(delegate(byte b) { return b > 0; });
				if(idx >= 0) bytes.RemoveRange(idx+1, bytes.Count-1-idx);
				else bytes.RemoveRange(1, bytes.Count-1);
				bytes.Reverse();
				command.BindParameter(bytes.ToArray());
			}
		}// MySQL


		public static partial class MariaDB // bind parameter
		{
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					var cmd = command.Command as System.Data.Odbc.OdbcCommand;
					if (cmd.Connection.Driver.StartsWith("maodbc", true, System.Globalization.CultureInfo.InvariantCulture))
					{
						cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.AnsiString;
						Altova.Db.Dbs.BindParameter_string(command, value.ToString(DateTimeFormat.W3_time));
						return;
					}
				}
				Altova.Db.Dbs.BindParameter_TimeSpan(command, value);
			}

			static public void BindParameter_ubigint(Statement command, ulong value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					var cmd = command.Command as System.Data.Odbc.OdbcCommand;
					if (cmd.Connection.Driver.StartsWith("maodbc", true, System.Globalization.CultureInfo.InvariantCulture))
					{
						cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.AnsiString;
						Altova.Db.Dbs.BindParameter_string(command, value.ToString(System.Globalization.CultureInfo.InvariantCulture));
						return;
					}
					else if (cmd.Connection.Driver.StartsWith("myodbc3", true, System.Globalization.CultureInfo.InvariantCulture))
					{
						cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.Int64;
						command.BindParameter(value);
						return;
					}
				}
				Altova.Db.Dbs.BindParameter_ulong(command, value);
			}
		}// MariaDB


		public static partial class SQLServer // bind parameter
		{
			static public void BindParameter_Decimal(Statement command, decimal value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					System.Data.Odbc.OdbcCommand cmd = (System.Data.Odbc.OdbcCommand)command.Command;
					cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.AnsiString;['otherwise type clash]
					string specifier = "0." + new String('0', Math.Min((int)(cmd.Parameters\[command.GetValueCount()\].Scale),38));
					Altova.Db.Dbs.BindParameter_string(command, value.ToString(specifier, System.Globalization.CultureInfo.InvariantCulture));
					return;
				}
				
				TParameter p = command.GetParameter(command.GetValueCount());
				if (p.scale >= 0)
				{// truncate to scale decimal digits
					value = Decimal.Round(value, p.scale, MidpointRounding.AwayFromZero); 
				}
				command.BindParameter(value);
			}
			
			static public void BindParameter_Uniqueidentifier(Statement command, string value)
			{
				command.BindParameter(value != null ? (object)(new System.Guid(value)) : null);
			}

			static public void BindParameter_DateTime(Statement command, Altova.Types.DateTime value)
			{
				IDbDataParameter db = ((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]);

				System.DateTime a = value.Value;
				System.DateTime b = new System.DateTime(a.Year,a.Month,a.Day,a.Hour,a.Minute,a.Second,a.Kind);
				const decimal factor = 100.0E-9m; // DateTime precision is 100 nanoseconds
				Int64 fractionTicks = (Int64)(Math.Round((a.Ticks - b.Ticks) * factor, db.Scale) / factor);
				System.DateTime c = new System.DateTime(b.Ticks + fractionTicks);
				command.BindParameter(c, -1, -1, db.Scale);
			}
			
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.W3_time));
			}
			
			static public void BindParameter_DateTimeOffset(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.W3_dateTime));
			}
			
		}// SQLServer


		public static partial class Oracle // bind parameter
		{
			static public void BindParameter_IntervalDaySecond(Statement command, Duration d)
			{
				Altova.Db.Dbs.BindParameter_IntervalDaySecond(command, d);
			}

			static public void BindParameter_IntervalYearMonth(Statement command, Duration d)
			{
				Altova.Db.Dbs.BindParameter_IntervalYearMonth(command, d);
			}

			static private String Padded_FixedBufferLength(String s, int n)
			{
				byte\[\] buffer = System.Text.Encoding.UTF8.GetBytes(s);
				return s + new String(' ', Math.Max(n - buffer.Length, 0));
			}
			static private String Padded_FixedStringLength(String s, int n)
			{
				return s + new String(' ', Math.Max(n - s.Length, 0));
			}

			static public void BindParameter_Char(Statement command, String s)
			{
				IDbDataParameter db = ((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]);
				Altova.Db.Dbs.BindParameter_string(command, Padded_FixedBufferLength(s, db.Size));
			}

			static public void BindParameter_NChar(Statement command, String s)
			{
				IDbDataParameter db = ((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]);
				Altova.Db.Dbs.BindParameter_string(command, Padded_FixedStringLength(s, db.Size));
			}

		}// Oracle


		public static partial class DB2 // bind parameter
		{
			static public void BindParameter_decfloat(Statement command, decimal value)
			{
				command.BindParameter(Convert.ToDouble(value));
			}
			
		}// DB2


		public static partial class Informix // bind parameter
		{
			static public void BindParameter_Decimal(Statement command, decimal value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					System.Data.Odbc.OdbcCommand cmd = (System.Data.Odbc.OdbcCommand)command.Command;
					cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.String;
					Dbs.BindParameter_string(command, value.ToString(System.Globalization.CultureInfo.InvariantCulture));
					return;
				}
				Dbs.BindParameter_decimal(command, value);
			}

			static public void BindParameter_boolean(Statement command, bool value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					TParameter parameter = command.GetParameter(command.GetValueCount());
					if (parameter.type != DbType.Boolean) {// recompile prepared statement
						parameter.type = DbType.Boolean;
						command.Command.Parameters.Clear();
						Altova.Db.Dbs.PrepareStatement(command);
					}
					Dbs.BindParameter_bool(command, value);
					return;
				}
				
				// for IBM.Data.DB2 and IBM.Data.Informix
				Dbs.BindParameter_string(command, value ? "t" : "f");
			}

			static public void BindParameter_IntervalYearToYear(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Year);
			}
			static public void BindParameter_IntervalYearToMonth(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Year|IntervalPart.Month);
			}

			static public void BindParameter_IntervalMonthToMonth(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Month);
			}

			static public void BindParameter_IntervalDayToDay(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day);
			}
			static public void BindParameter_IntervalDayToHour(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour);
			}
			static public void BindParameter_IntervalDayToMinute(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void BindParameter_IntervalDayToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void BindParameter_IntervalDayToFraction(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalHourToHour(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour);
			}
			static public void BindParameter_IntervalHourToMinute(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void BindParameter_IntervalHourToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void BindParameter_IntervalHourToFraction(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalMinuteToMinute(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Minute);
			}
			static public void BindParameter_IntervalMinuteToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Minute|IntervalPart.Second);
			}
			static public void BindParameter_IntervalMinuteToFraction(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalSecondToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Second);
			}
			static public void BindParameter_IntervalSecondToFraction(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalFractionToFraction(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Fraction);
			}


			static public void BindParameter_DateTime(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.Value);
			}

			static public void BindParameter_DateTime_YearToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Year | IntervalPart.Month | IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_MonthToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Month | IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_DayToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_HourToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_MinuteToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_SecondToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void BindParameter_DateTime_FractionToFraction(Statement command, Altova.Types.DateTime value)
			{
				BindParameter_DateTime_Informix(command, value.Value, IntervalPart.Fraction);
			}

			static public void BindParameter_DateTime_Informix(Statement command, System.DateTime d, IntervalPart part)
			{
				String s = "";

				if ((part & IntervalPart.Year) == IntervalPart.Year)
				{
					s += System.Math.Abs(d.Year);
				}

				if (((part & IntervalPart.Year) == IntervalPart.Year)
				&& ((part & IntervalPart.Month) == IntervalPart.Month))
				{
					s += "-";
				}

				if ((part & IntervalPart.Month) == IntervalPart.Month)
				{
					s += System.Math.Abs(d.Month).ToString("0#");
				}

				if (((part & IntervalPart.Month) == IntervalPart.Month)
				&& ((part & IntervalPart.Day) == IntervalPart.Day))
				{
					s += "-";
				}

				if ((part & IntervalPart.Day) == IntervalPart.Day)
				{
					s += System.Math.Abs(d.Day).ToString("0#");
				}

				if (((part & IntervalPart.Day) == IntervalPart.Day)
				&& ((part & IntervalPart.Hour) == IntervalPart.Hour))
				{
					s += " ";
				}

				if ((part & IntervalPart.Hour) == IntervalPart.Hour)
				{
					s += System.Math.Abs(d.Hour).ToString("0#");
				}

				if (((part & IntervalPart.Hour) == IntervalPart.Hour)
				&& ((part & IntervalPart.Minute) == IntervalPart.Minute))
				{
					s += ":";
				}

				if ((part & IntervalPart.Minute) == IntervalPart.Minute)
				{
					s += System.Math.Abs(d.Minute).ToString("0#");
				}

				if (((part & IntervalPart.Minute) == IntervalPart.Minute)
				&& ((part & IntervalPart.Second) == IntervalPart.Second))
				{
					s += ":";
				}

				if ((part & IntervalPart.Second) == IntervalPart.Second)
				{
					s += System.Math.Abs(d.Second).ToString("0#");
				}

				if ((part & IntervalPart.Fraction) == IntervalPart.Fraction)
				{
					decimal partsecond = (d.Ticks / 10000000.0m);// % 1.0;
					partsecond = partsecond - System.Math.Truncate(partsecond);
					int scale = command.GetParameter(command.GetValueCount()).scale;
					if (scale > 0 && (partsecond > 0.0m && partsecond < 1.0m))
					{
						string f = new string('#', scale);
						string sPartSecond = partsecond.ToString("0." + f);
						s += "." + sPartSecond.Substring(2, sPartSecond.Length - 2);
					}
					else if (scale > 0 && partsecond.Equals(0.0m))
					{
						s += ".0";
					}
				}

				command.BindParameter(s);
			}
			
		}// Informix


		public static partial class iSeries
		{
			
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime value)
			{
				if (command.Command.GetType().FullName.StartsWith("IBM.Data.DB2.iSeries")) {
					command.BindParameter(value.ToString(DateTimeFormat.W3_time));
					return;
				}
				Altova.Db.Dbs.BindParameter_TimeSpan(command, value);
			}

		}// iSeries


		public static partial class Firebird // bind parameter
		{
			
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.W3_time));
			}

			static public void BindParameter_Timestamp(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.S_DateTime));
			}

		}// Firebird


		public static partial class Progress // bind parameter
		{
			static public void BindParameter_Numeric(Statement command, decimal value)
			{
				command.BindParameter(Decimal.ToDouble(value));
			}

			static public void BindParameter_TimestampWithTimezone(Statement command, Altova.Types.DateTime value)
			{
				command.BindParameter(value.ToString(DateTimeFormat.S_DateTime));
			}

		}// Progress

		public static partial class Sybase // bind parameter
		{
			static public void BindParameter_Decimal(Statement command, decimal value)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					System.Data.Odbc.OdbcCommand cmd = (System.Data.Odbc.OdbcCommand)command.Command;
					cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.String;
					Altova.Db.Dbs.BindParameter_string(command, value.ToString(System.Globalization.CultureInfo.InvariantCulture));
					return;
				}
				else if(command.Command is System.Data.OleDb.OleDbCommand)
				{
					System.Data.OleDb.OleDbCommand cmd = (System.Data.OleDb.OleDbCommand)command.Command;
					cmd.Parameters\[command.GetValueCount()\].DbType = System.Data.DbType.String;
					Altova.Db.Dbs.BindParameter_string(command, value.ToString(System.Globalization.CultureInfo.InvariantCulture));
					return;
				}
				Altova.Db.Dbs.BindParameter_decimal(command, value);
			}

		}// Sybase



		public static partial class Teradata // bind parameter
		{
			static public void BindParameter_Time(Statement command, Altova.Types.DateTime dt)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					String datetime = dt.Value.ToString("HH\\\\:mm\\\\:ss", System.Globalization.CultureInfo.InvariantCulture);
					String fraction = dt.Value.ToString("fffffff", System.Globalization.CultureInfo.InvariantCulture).TrimEnd(new char\[\] { '0' });
					if (fraction.Length > 0) datetime += "." + fraction;
					Altova.Db.Dbs.BindParameter_string(command, datetime);
				}
				else
				{
					((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]).DbType = System.Data.DbType.Time;
					BindParameter_TimeSpan(command, dt.Value.TimeOfDay);
				}
			}
			static public void BindParameter_TimeWithTimezone(Statement command, Altova.Types.DateTime dt)
			{
				string zone = "";
				if (dt.HasTimezone && dt.TimezoneOffset == 0) {
					dt = new Types.DateTime(dt.Value);
					zone = "+00:00";
				}
				command.BindParameter(dt.ToString(DateTimeFormat.W3_time)+zone);
			}
			static public void BindParameter_Timestamp(Statement command, Altova.Types.DateTime dt)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					String datetime = dt.Value.ToString("yyyy-MM-dd HH\\\\:mm\\\\:ss", System.Globalization.CultureInfo.InvariantCulture);
					String fraction = dt.Value.ToString("fffffff", System.Globalization.CultureInfo.InvariantCulture).TrimEnd(new char\[\]{'0'});
					if (fraction.Length > 0) datetime += "." + fraction;
					Altova.Db.Dbs.BindParameter_string(command, datetime);
				}
				else
				{
					((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]).DbType = System.Data.DbType.DateTime;
					Dbs.BindParameter_DateTime(command, dt);
				}
			}
			static public void BindParameter_TimestampWithTimezone(Statement command, Altova.Types.DateTime dt)
			{
				if (command.Command is System.Data.Odbc.OdbcCommand)
				{
					string zone = "+00:00";['problem with zulu time zone]
					if(dt.HasTimezone && dt.TimezoneOffset != 0) {
						zone = dt.TimezoneOffset < 0 ? "-" : "+";
						int offset = Math.Abs(dt.TimezoneOffset);
						int h = offset / 60;
						int m = offset % 60;
						zone += h.ToString("00") + ":" + m.ToString("00");
					}
					String datetime = dt.Value.ToString("yyyy-MM-dd HH\\\\:mm\\\\:ss", System.Globalization.CultureInfo.InvariantCulture);
					String fraction = dt.Value.ToString("fffffff", System.Globalization.CultureInfo.InvariantCulture).TrimEnd(new char\[\]{'0'});
					if (fraction.Length > 0) datetime += "." + fraction;['odbc bridge driver does not like the trailing zeroes]
					Altova.Db.Dbs.BindParameter_string(command, datetime+zone);
				}
				else
				{
					((IDbDataParameter)command.Command.Parameters\[command.GetValueCount()\]).DbType = System.Data.DbType.DateTimeOffset;
					command.BindParameter(new DateTimeOffset(dt.Value, new TimeSpan(dt.TimezoneOffset * TimeSpan.TicksPerMinute)));
				}
			}

			static public void BindParameter_IntervalYear(Statement command, Duration d)
			{
				command.BindParameter(d.Years.ToString("0000"));
			}
			static public void BindParameter_IntervalYearToMonth(Statement command, Duration d)
			{
				command.BindParameter(String.Format("{0}{1}-{2}", d.IsNegative() ? "-" : "", Math.Abs(d.Years).ToString("0000"), Math.Abs(d.Months).ToString("00")));
			}

			static public void BindParameter_IntervalMonth(Statement command, Duration d)
			{
				command.BindParameter(((d.Years*12) + d.Months).ToString("00"));
			}

			static public void BindParameter_IntervalDay(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day);
			}
			static public void BindParameter_IntervalDayToHour(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour);
			}
			static public void BindParameter_IntervalDayToMinute(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void BindParameter_IntervalDayToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalHour(Statement command, Duration d)
			{
				command.BindParameter(Convert.ToInt32(d.Value.TotalHours).ToString("00"));
			}
			static public void BindParameter_IntervalHourToMinute(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void BindParameter_IntervalHourToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalMinute(Statement command, Duration d)
			{
				command.BindParameter(Convert.ToInt32(d.Value.TotalMinutes).ToString("00"));
			}
			static public void BindParameter_IntervalMinuteToSecond(Statement command, Duration d)
			{
				Dbs.BindParameter_Interval(command, d, IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}

			static public void BindParameter_IntervalSecond(Statement command, Duration d)
			{
				command.BindParameter(d.Value.TotalSeconds.ToString("0.000000",System.Globalization.CultureInfo.InvariantCulture));
			}
			
		}// Teradata
		
		
		static public void AddParameter(Statement statement, TParameter p)
		{
			statement.AddParameter(p);
		}

		static public Statement NewQuery(Catalog catalog, int id)
		{
			Statement statement = catalog.GetStatement(id);
			statement.Connection = catalog.AllocateConnection();
			statement.Clear();
			return statement;
		}

		static public Statement NewStatement(Catalog catalog, int id, string statement)
		{
			return catalog.CreateStatement(id, statement);
		}

		static public void StoreStatement(Statement statement)
		{
		}
		
		static public void PrepareStatement(Statement statement)
		{
			statement.Prepare();
		}

		static public Recordset ExecuteQuery(Statement command)
		{
			return command.Execute();
		}

		static public Record NewRecord()
		{
			return new Record();
		}

		static public bool MoveNextRecord(Recordset recordset)
		{
			// bool more = recordset.reader.Read();
			// if (!more) DisposeRecordset(recordset);
			// return more;
			return recordset.reader.Read();
		}

		static public void DisposeRecordset(Recordset recordset)
		{
			if (recordset != null)
				recordset.Close();
		}

		static public void DisposeQuery(Statement query)
		{
			query.Clear();
		}

		class TResult : IEnumerable
		{
			Recordset recordset;
			MFInvoke lambda;
			bool firsttime = true;

			public TResult(Recordset rs, MFInvoke y)
			{
				recordset = rs;
				lambda = y;
			}

			public IEnumerator GetEnumerator()
			{
['#45279 - problem with oracle 10 odbc driver when used with group-by components.
]				if (firsttime) { firsttime = false; return new Enumerator(recordset, lambda); }
				IDbConnection newconn = recordset.catalog.AllocateConnection();
				IDbCommand newcomm = newconn.CreateCommand();
				newcomm.CommandType = recordset.command.CommandType;
				newcomm.CommandText = recordset.command.CommandText;
				newcomm.CommandTimeout = recordset.command.CommandTimeout;
				foreach (object o in recordset.command.Parameters) {
					System.Data.Common.DbParameter p = (System.Data.Common.DbParameter)o;
					System.Data.IDbDataParameter newparam = newcomm.CreateParameter();
					newparam.ParameterName = p.ParameterName;
					newparam.Direction = p.Direction;
					newparam.DbType = p.DbType;
					newparam.Size = p.Size;
					newparam.Value = p.Value;
					newcomm.Parameters.Add(newparam);
				}
				IDataReader reader = newcomm.ExecuteReader();
				while (reader.IsClosed && reader.NextResult()) { }
				recordset = new Recordset(recordset.catalog, reader, newconn, newcomm);
				return new Enumerator(recordset, lambda);
			}

			class Enumerator : IMFEnumerator
			{
				Recordset recordset;
				MFInvoke lambda;
				int pos = 0;
				object current;

				public Enumerator(Recordset rs, MFInvoke y)
				{
					recordset = rs;
					lambda = y;
				}

				public object Current { get { return current; } }

				public bool MoveNext() 
				{
					if (!recordset.reader.IsClosed)
					{
						if (recordset.reader.Read())
						{
							// current = Core.First(); // inlined here to avoid dependency
							System.Collections.IEnumerator r = lambda.Invoke(recordset).GetEnumerator(); 
							if (!r.MoveNext())
							{
								MFEnumerator.Dispose(r);
								throw new InvalidOperationException("Internal error: A lambda for recordset reading returned no result.");
							}
							current = r.Current; 
							MFEnumerator.Dispose(r);

							pos++;
							return true;
						}
						else
						{
							Dispose();
						}
					}
					return false; 
				}

				public int Position { get { return pos; } }

				public void Reset() { }
				public void Dispose() { recordset.Close(); }
			}
		}

		static public IEnumerable ReadRecordSet( Recordset recordset, MFInvoke lambda)
		{
			return new TResult(recordset, lambda);
		}

		// KBFs

		static public void Read_string(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			record.fields\[name\] = new MFSingletonSequence(recordset.reader.GetString(column));
		}
		
		static public void Read_sbyte(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			int value = System.Convert.ToInt32(recordset.reader.GetValue(column));	
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_byte(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			ulong value = System.Convert.ToUInt64(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_short(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}
			int value = System.Convert.ToInt32(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_ushort(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}
			ulong value = System.Convert.ToUInt64(recordset.reader.GetValue(column));	
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_int(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}
			
			int value = System.Convert.ToInt32(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_uint(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}
			
			ulong value = System.Convert.ToUInt64(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_long(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			long value = System.Convert.ToInt64(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_ulong(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			ulong value = System.Convert.ToUInt64(recordset.reader.GetValue(column));
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_float(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			// use type double for internal operation
			double value = 0.0;[' fix for real type]
			object o = recordset.reader.GetValue(column);
			if (o is double) { value = (double)(o); }
			else if (o is float) { value = (float)(o); }
			else if (o is decimal) { value = (float)(decimal)(o); }
			else { value = (double)(o);/*error?*/ }
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_double(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			double value = 0.0;[' fix for real type]
			object o = recordset.reader.GetValue(column);
			if (o is double) { value = (double)(o); }
			else if (o is float) { value = (float)(o); }
			else if (o is decimal) { value = (double)(decimal)(o); }
			else { value = Double.Parse(o.ToString());/*error?*/ }
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_decimal(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			decimal value = 0m;
			object o = recordset.reader.GetValue(column);
			if (o is double)
				value = (decimal)(double)o;
			else
				value = (decimal)o;
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_DateTime(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}
			record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime((System.DateTime)recordset.reader.GetDateTime(column)));
		}

		static public void Read_bool(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			bool value = false;
			object o = recordset.reader.GetValue(column);
			if (o is string) 
			{// special handling for PostgreSQL - value comes as string
				string s = (string)(o);// value is one of the following for true
				StringComparison c = StringComparison.InvariantCultureIgnoreCase;
				value = s.Equals("1",c) || s.Equals("t", c) || s.Equals("true", c)
					|| s.Equals("y", c) || s.Equals("yes", c) || s.Equals("on", c);
			} else 
			{// in any other case just convert it
				value = Convert.ToBoolean(o);
			}

			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_blob(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
			byte\[\] b = new byte\[l\];
			try
			{
				if(l > 0) recordset.reader.GetBytes(column, 0, b, 0, (int)l);
			}
			catch (System.InvalidCastException)
			{
				// Workaround for DB2 NULL values in XML. TODO is this needed?
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			record.fields\[name\] = new MFSingletonSequence(b);
		}

		// special handling

		static public void Read_string_ParseDate(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			string value = recordset.reader.GetString(column);
			Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_date;
			Altova.Types.DateTime dt = Altova.Types.DateTime.Parse( value, format);
			record.fields\[name\] = new MFSingletonSequence( dt );
		}

		static public void Read_string_ParseTime(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader is System.Data.Odbc.OdbcDataReader)
			{// MSSQL time(n) with Odbc - cannot cast from SS_TIME_EX
				bool fieldIsNull = true;
				try { fieldIsNull = (recordset.reader.GetString(column) == null); }
				catch (System.InvalidCastException) { fieldIsNull = true; }
				if (fieldIsNull)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				string value = recordset.reader.GetString(column);
				Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_time;
				Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(value, format);
				record.fields\[name\] = new MFSingletonSequence(dt);
			}
			else if (recordset.reader is System.Data.OleDb.OleDbDataReader)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				string value = recordset.reader.GetString(column);
				Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_time;
				Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(value, format);
				record.fields\[name\] = new MFSingletonSequence(dt);
			}
			else if (recordset.reader is System.Data.SqlClient.SqlDataReader)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				object o = recordset.reader.GetValue(column);
				if (o is string)
				{
					Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_time;
					Altova.Types.DateTime dt = Altova.Types.DateTime.Parse((string)o, format);
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
				else if (o is System.TimeSpan)
				{
					System.TimeSpan ts = (System.TimeSpan)o;
					const decimal factor = 100.0E-9m; // 100 ns
					decimal fraction = (ts.Ticks * factor);
					fraction -= System.Decimal.ToInt64(fraction);
					double second = ts.Seconds + System.Decimal.ToDouble(fraction);
					Altova.Types.DateTime dt = new Altova.Types.DateTime(1, 1, 1, ts.Hours, ts.Minutes, second);
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
				else
				{
					throw new System.InvalidCastException("unknown format");
				}
			}
			else
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				string value = recordset.reader.GetString(column);
				Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_time;
				Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(value, format);
				record.fields\[name\] = new MFSingletonSequence(dt);
			}
		}

		static public void Read_string_ParseDateTime(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			string value = recordset.reader.GetString(column);
			Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_dateTime;
			Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(value, format);
			record.fields\[name\] = new MFSingletonSequence(dt);
		}

		static public void Read_string_ParseDecimal(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			// remove trailing zeros to avoid 'invalid decimal'
			String value = recordset.reader.GetString(column);
			while (value.EndsWith("0") && value.Contains("."))
				value = value.Remove(value.Length - 1);

			Decimal native = Altova.CoreTypes.CastToDecimal(value);
			record.fields\[name\] = new MFSingletonSequence( native );
		}

		static public void Read_string_ParseDouble(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			// remove trailing zeros to avoid 'invalid decimal'
			String value = recordset.reader.GetString(column);
			if (!(value.Contains("e") || value.Contains("E")))
				while (value.EndsWith("0") && value.Contains("."))
					value = value.Remove(value.Length - 1);

			Double native = Altova.CoreTypes.CastToDouble(value);
			record.fields\[name\] = new MFSingletonSequence( native );
		}

		static public void Read_guid_BuildString(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			System.Guid guid = recordset.reader.GetGuid(column);
			string format = "B";//separated by hyphens, enclosed in brackets
			String value = guid.ToString(format).ToUpper();
			record.fields\[name\] = new MFSingletonSequence(value);
		}

		static public void Read_string_BuildGuidString(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			object value = recordset.reader.GetValue(column);
			if( value is string )
			{
				string s = (string)(value);
				if(!s.StartsWith("{")) s = "{" + s;
				if(!s.EndsWith("}")) s = s + "}";
				value = s.ToUpper();
			}
			else if( value is System.Guid )
			{
				System.Guid guid = (System.Guid)(value);
				string format = "B";//separated by hyphens, enclosed in brackets
				value = guid.ToString(format).ToUpper();
			}
			record.fields\[name\] = new MFSingletonSequence((string)(value));
		}

		static public void Read_TimeSpan_BuildTime(Record record, Recordset recordset, string name, int column)
		{
			if (recordset.reader.IsDBNull(column))
			{
				record.fields\[name\] = MFEmptySequence.Instance;
				return;
			}

			object o = recordset.reader.GetValue(column);
			if (o is System.TimeSpan)
			{
				System.TimeSpan ts = (System.TimeSpan)(o);['DB2, Teradata]
				System.DateTime dt = new System.DateTime(1,1,1);
				record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime(dt+ts));
			}
			else if (o is System.DateTime)
			{
				System.DateTime dt = (System.DateTime)(o);
				record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime(dt));
			}
			else
			{
				record.fields\[name\] = new MFSingletonSequence(Altova.Types.DateTime.Parse(o.ToString()));
			}
		}
		
		public enum IntervalPart
		{
			Year = 1 << 0,
			Month = 1 << 1,
			Day = 1 << 2,
			Date = Year|Month|Day,
			Hour = 1 << 3,
			Minute = 1 << 4,
			Second = 1 << 5,
			Fraction = 1 << 6,
			Time = Hour|Minute|Second|Fraction,
		}

		static public void Read_string_ParseInterval(Record record, Recordset recordset, string name, int column, IntervalPart part)
		{
			try
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
			}
			catch (System.Exception)
			{
			}

			string s = null;
			try { s = recordset.reader.GetString(column); }
			catch (System.InvalidCastException) { s = null; }
			if (s != null)
			{
				int n = 0;
				s = s.Trim();
				string e = s + " cannot be converted to a duration value";
				Altova.Types.DateTime.ParseContext context = new Altova.Types.DateTime.ParseContext(s);

				bool positive = true;// parse sign
				if (context.CheckAndAdvance('-')) positive = false;
				else if (context.CheckAndAdvance('+')) positive = true;
				if (!context.IsValid()) throw new StringParseException(e);

				int years = 0;
				int months = 0;
				int days = 0;
				int hours = 0;
				int minutes = 0;
				int seconds = 0;
				double fractions = 0.0;

				if( (part & (IntervalPart.Year | IntervalPart.Month)) != 0 )
				{
					if ((part & (IntervalPart.Year)) == (IntervalPart.Year))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { years = (years * 10) + n; n = 0; }
					}

					if ((part & (IntervalPart.Year | IntervalPart.Month)) == (IntervalPart.Year | IntervalPart.Month))
					{// check the year - month
						if (!context.IsValid()) throw new StringParseException(e);
						if (!context.CheckAndAdvance('-')) throw new StringParseException(e);
					}

					if ((part & (IntervalPart.Month)) == (IntervalPart.Month))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { months = (months * 10) + n; n = 0; }
					}
				}

				// there is no separator between year-month and day-fraction

				if( (part & (IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction)) != 0 )
				{

					if ((part & IntervalPart.Day) == IntervalPart.Day)
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { days = (days * 10) + n; n = 0; }
					}

					if ((part & (IntervalPart.Day | IntervalPart.Hour)) == (IntervalPart.Day | IntervalPart.Hour))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						if (!context.CheckAndAdvance(' ')) throw new StringParseException(e);
					}

					if ((part & (IntervalPart.Hour)) == (IntervalPart.Hour))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { hours = (hours * 10) + n; n = 0; }
					}

					if ((part & (IntervalPart.Hour | IntervalPart.Minute)) == (IntervalPart.Hour | IntervalPart.Minute))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						if (!context.CheckAndAdvance(':')) throw new StringParseException(e);
					}

					if ((part & (IntervalPart.Minute)) == (IntervalPart.Minute))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { minutes = (minutes * 10) + n; n = 0; }
					}

					if ((part & (IntervalPart.Minute | IntervalPart.Second)) == (IntervalPart.Minute | IntervalPart.Second))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						if (!context.CheckAndAdvance(':')) throw new StringParseException(e);
					}

					if ((part & (IntervalPart.Second)) == (IntervalPart.Second))
					{
						if (!context.IsValid()) throw new StringParseException(e);
						while (context.ReadDigitAndAdvance(ref n, 1, 9)) { seconds = (seconds * 10) + n; n = 0; }
					}

					if(context.IsValid())
					{// optional

						if ((part & (IntervalPart.Second | IntervalPart.Fraction)) == (IntervalPart.Second | IntervalPart.Fraction))
						{
							if (!context.IsValid()) throw new StringParseException(e);
							if (!context.CheckAndAdvance('.')) throw new StringParseException(e);
						}

						if ((part & (IntervalPart.Fraction)) == (IntervalPart.Fraction))
						{
							int i = 0;
							int fractionValue = 0;
							if (!context.IsValid()) throw new StringParseException(e);
							if (part == (IntervalPart.Fraction)) { context.CheckAndAdvance('.');/* for fraction to fraction only */}
							while (context.ReadDigitAndAdvance(ref n, 1, 9)) { fractionValue = (fractionValue * 10) + n; n = 0; ++i; }
							fractions = fractionValue / Math.Pow(10, i);

						}
					}
				}

				Duration duration = new Duration(years, months, days, hours, minutes, seconds, fractions, !positive);
				record.fields\[name\] = new MFSingletonSequence(duration);
			}
			else
			{
				record.fields\[name\] = MFEmptySequence.Instance;
			}
		}

		public static partial class DB2 // read recordset
		{
			
			static public void Read_dbclob(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader) && !(recordset.reader is System.Data.OleDb.OleDbDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				try
				{
					// don't call IsDBNull => Unknown SQL type - -97. 
					// an InvalidCastException is raised for DBNull values
					long l = recordset.reader.GetChars(column, 0, null, 0, 0);
					if( l >= 0 )
					{
						char\[\] chars = new char\[l\];
						if( l > 0 ) recordset.reader.GetChars(column, 0, chars, 0, (int)l);
						record.fields\[name\] = new MFSingletonSequence(new String(chars));
						return;
					}
				}
				catch (System.InvalidCastException)
				{
				}

				record.fields\[name\] = MFEmptySequence.Instance;
			}

			static public void Read_decfloat(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				decimal value = 0m;
				object o = recordset.reader.GetValue(column);
				if (o is decimal)
					value = (decimal)o;
				else if (o is double)
					value = (decimal)(double)o;
				else if (o is string)
					value = Decimal.Parse((string)o, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture);
				else
					value = Decimal.Parse(o.ToString(), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture);

				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_xml(Record record, Recordset recordset, string name, int column)
			{
				try
				{
					// avoid ERROR: Unknown SQL type - -98.
					long l = recordset.reader.GetBytes(column, 0, null, 0, 0);

					if (l <= 0)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
					}
					else
					{
						byte\[\] b = new byte\[l\];
						recordset.reader.GetBytes(column, 0, b, 0, (int)l);
						record.fields\[name\] = new MFSingletonSequence(b);
					}
				}
				catch (System.InvalidCastException)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
			}
		}// DB2


		public static partial class SQLServer
		{

			static public void Read_DateTimeOffset(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// MSSQL datetimeoffset(n) with Odbc - invalid sql type -155
					System.Object fieldValue = null;
					try { fieldValue = recordset.reader.GetDateTime(column); }
					catch (System.InvalidCastException) { fieldValue = null; }
					if (fieldValue == null)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
					record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime((System.DateTime)fieldValue));
				}
				else if (recordset.reader is System.Data.OleDb.OleDbDataReader)
				{// MSSQL datetimeoffset(n) with OleDb - invalid cast
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					string value = recordset.reader.GetString(column);
					string\[\] parts = value.Split(' ');// date, time, tz
					string amended = parts\[0\] + "T" + parts\[1\] + parts\[2\];
					Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_dateTime;
					Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(amended, format);
					record.fields\[name\] = new MFSingletonSequence(dt);
					return;
				}
				else if(recordset.reader is System.Data.SqlClient.SqlDataReader)
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					System.Data.SqlClient.SqlDataReader reader = (System.Data.SqlClient.SqlDataReader)recordset.reader;
					System.DateTimeOffset v = reader.GetDateTimeOffset(column);
					Altova.Types.DateTime dt = new Altova.Types.DateTime(v.DateTime);
					dt.TimezoneOffset = (short)v.Offset.TotalMinutes;
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
				else
				{
					Dbs.Read_DateTime(record, recordset, name, column);
				}
			}

			static public void Read_Variant(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				record.fields\[name\] = new MFSingletonSequence(recordset.reader.GetValue(column).ToString());
			}
	
['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlgeometry.stastext.aspx
]			public static void Read_Geometry_WKT(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				object value = recordset.reader.GetValue(column);
				if (value.GetType().FullName == "Microsoft.SqlServer.Types.SqlGeometry") 
				{
					object obj = value.GetType().GetMethod("STAsText").Invoke(value, null);
					string text = new string((char\[\])(obj.GetType().GetProperty("Value").GetValue(obj,null)));
					record.fields\[name\] = new MFSingletonSequence(text);
				}
				else
				{
					record.fields\[name\] = new MFSingletonSequence(value.ToString());
				}
			}
['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlgeometry.stasbinary.aspx
]			public static void Read_Geometry_WKB(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				object value = recordset.reader.GetValue(column);
				if (value.GetType().FullName == "Microsoft.SqlServer.Types.SqlGeometry") 
				{
					object obj = value.GetType().GetMethod("STAsBinary").Invoke(value, null);
					byte\[\] bytes = (byte\[\])(obj.GetType().GetProperty("Value").GetValue(obj, null));
					record.fields\[name\] = new MFSingletonSequence(bytes);
				}
				else
				{
					Dbs.Read_blob(record, recordset, name, column);
				}
			}

['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlgeography.stastext.aspx
]			public static void Read_Geography_WKT(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				object value = recordset.reader.GetValue(column);
				if (value.GetType().FullName == "Microsoft.SqlServer.Types.SqlGeography")
				{
					object obj = value.GetType().GetMethod("STAsText").Invoke(value, null);
					string text = new string((char\[\])(obj.GetType().GetProperty("Value").GetValue(obj, null)));
					record.fields\[name\] = new MFSingletonSequence(text);
				}
				else
				{
					record.fields\[name\] = new MFSingletonSequence(value.ToString());
				}
			}
['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlgeography.stasbinary.aspx
]			public static void Read_Geography_WKB(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				object value = recordset.reader.GetValue(column);
				if (value.GetType().FullName == "Microsoft.SqlServer.Types.SqlGeography")
				{
					object obj = value.GetType().GetMethod("STAsBinary").Invoke(value, null);
					byte\[\] bytes = (byte\[\])(obj.GetType().GetProperty("Value").GetValue(obj, null));
					record.fields\[name\] = new MFSingletonSequence(bytes);
				}
				else
				{
					Dbs.Read_blob(record, recordset, name, column);
				}
			}

['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlhierarchyid.tostring.aspx
]			public static void Read_HierarchyId_String(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				string value = recordset.reader.GetValue(column).ToString();
				record.fields\[name\] = new MFSingletonSequence(value);
			}
['//		https://msdn.microsoft.com/en-us/library/microsoft.sqlserver.types.sqlhierarchyid.write.aspx
]			public static void Read_HierarchyId_Binary(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				object value = recordset.reader.GetValue(column);
				if (value.GetType().FullName == "Microsoft.SqlServer.Types.SqlHierarchyId")
				{
					System.IO.MemoryStream stream = new System.IO.MemoryStream();
					using (System.IO.BinaryWriter writer = new System.IO.BinaryWriter(stream))
					{
						value.GetType().GetMethod("Write").Invoke(value, new object\[\] { writer });
						writer.Flush();
					}
					record.fields\[name\] = new MFSingletonSequence(stream.ToArray());
				}
				else
				{
					Dbs.Read_blob(record, recordset, name, column);
				}
			}

		}// SQLServer


		public static partial class PostgreSQL
		{

			static public void Parse_time(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				string s = recordset.reader.GetValue(column).ToString();
				Altova.Types.DateTime dt = new Altova.Types.DateTime();
				bool valid = dt.ParseDateTime(s, Altova.Types.DateTime.DateTimePart.Time);
				record.fields\[name\] = new MFSingletonSequence(dt);
			}

			static public void Parse_timeTZ(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				string value = recordset.reader.GetString(column);
				//Altova.Types.DateTimeFormat format = Altova.Types.DateTimeFormat.W3_time;
				//Altova.Types.DateTime dt = Altova.Types.DateTime.Parse(value, format);
				Altova.Types.DateTime.DateTimePart part = Altova.Types.DateTime.DateTimePart.Time;
				Altova.Types.DateTime.DateTimePart optional = Altova.Types.DateTime.DateTimePart.TimezoneMinute;
				Altova.Types.DateTime dt = new Altova.Types.DateTime();
				bool valid = dt.ParseDateTime(value, part, optional);
				record.fields\[name\] = new MFSingletonSequence(dt);
			}

			static public void Read_unicode(Record record, Recordset recordset, string name, int column)
			{
				try
				{
					// an InvalidCastException is raised for DBNull values
					if (!recordset.reader.IsDBNull(column))
					{
						long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
						if (l >= 0)
						{
							byte\[\] chars = new byte\[l\];
							if (l > 0) recordset.reader.GetBytes(column, 0, chars, 0, (int)l);
							System.Text.Encoding encoding = System.Text.Encoding.UTF8; // fix
							record.fields\[name\] = new MFSingletonSequence(encoding.GetString(chars));
							return;
						}
					}
				}
				catch (System.InvalidCastException)
				{
				}

				record.fields\[name\] = MFEmptySequence.Instance;
			}

			static public void Parse_Interval(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				// Format: YYYY/MM/DD/hh/mm/ss.ff9

				bool positive = true;
				int years = 0;
				int month = 0;
				int days = 0;
				int hours = 0;
				int minutes = 0;
				int seconds = 0;
				double fraction = 0.0;

				int n = 0;
				string s = recordset.reader.GetString(column);
				string e = s + " cannot be converted to a duration value";
				Altova.Types.DateTime.ParseContext context = new Altova.Types.DateTime.ParseContext(s.Trim());

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { years = (years * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				if (!context.CheckAndAdvance('/')) throw new StringParseException(e);

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { month = (month * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				if (!context.CheckAndAdvance('/')) throw new StringParseException(e);

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { days = (days * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				if (!context.CheckAndAdvance('/')) throw new StringParseException(e);

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { hours = (hours * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				if (!context.CheckAndAdvance('/')) throw new StringParseException(e);

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { minutes = (minutes * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				if (!context.CheckAndAdvance('/')) throw new StringParseException(e);

				if (context.CheckAndAdvance('-')) positive = false;
				if (!context.IsValid()) throw new StringParseException(e);
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { seconds = (seconds * 10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);
				if (context.CheckAndAdvance('.')) 
				{
					int temp = 0; // micoseconds
					if (!context.IsValid()) throw new StringParseException(e);
					while (context.ReadDigitAndAdvance(ref n, 1, 9)) { temp = (temp * 10) + n; n = 0; }
					fraction = temp / 1000000.0; 
				}

				Duration duration = new Duration(years, month, days, hours, minutes, seconds, fraction, !positive);
				record.fields\[name\] = new MFSingletonSequence(duration);
			}

			static public void Read_boolean(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				int value = recordset.reader.GetInt32(column);
				record.fields\[name\] = new MFSingletonSequence((bool)(value != 0));
			}
		
		}// PostgreSQL


		public static partial class MySQL
		{
			static public void Read_blob(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				try
				{
['workaround for MySQL binary types read with ODBC driver 3.51
]					long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
					byte\[\] b = new byte\[l\];// allocate required byte array
					if (l > 0) recordset.reader.GetBytes(column, 0, b, 0, (int)l);
					record.fields\[name\] = new MFSingletonSequence(b);
					return;
				}
				catch (System.InvalidCastException)
				{// cannot convert db null to byte\[\]
				}
				record.fields\[name\] = MFEmptySequence.Instance;
			}

			static public void Read_blob_Bitfield(Record record, Recordset recordset, string name, int column)
			{
['workaround for MySQL bit(n) types read with ODBC driver 3.51
]				if (recordset.command.Connection is System.Data.Odbc.OdbcConnection && (((System.Data.Odbc.OdbcConnection)(recordset.command.Connection)).Driver.Contains("odbc3")))
				{
					object o = null;
					try { o = recordset.reader.GetString(column); }
					catch (System.InvalidCastException) { o = null; }
					if (o == null)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
					ulong value = Convert.ToUInt64((string)o, 16);
					record.fields\[name\] = new MFSingletonSequence(value);
				}
				else
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					ulong value = 0;
					object o = recordset.reader.GetValue(column);
					if (o is bool) value = (ulong)((bool)(o)?1:0);['MySQL5 bit(1) comes as bool]
					else if (o is ulong) value = (ulong)(o);['MySQL Connector/NET bit(n) delivers ulong]
					else if (o is short) value = (ushort)(short)(o); ['MySQL4 bit(n) comes as short]
					else if (o is byte\[\]) 
					{
						int length = 8;
						byte\[\] buffer = new byte\[length\];
						long size = recordset.reader.GetBytes(column, 0, buffer, 0, length);
						for( long i = 0; i < size; ++i )
						{
							byte n = buffer\[i\];
							value = value << 8;
							value = value | n;
						}
					}
					record.fields\[name\] = new MFSingletonSequence( value );
				}
			}

			static public void Read_geometry(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{
					Read_blob(record, recordset, name, column);
					return;
				}

				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				object o = recordset.reader.GetValue(column);
				record.fields\[name\] = new MFSingletonSequence((byte\[\])o);
				return;
			}

			static public void Read_decimal(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

['				MySQL4 dec, decimal, numeric, fixed read invalid decimal
]				decimal value = recordset.reader.GetDecimal(column);
				int\[\] bits = decimal.GetBits(value); // workaround for 0.0
				if (((bits\[0\] == 0) && (bits\[1\] == 0) && (bits\[2\] == 0))
				&& ((bits\[3\] >> 16) & 0x000000FF) > 28)
					value = 0m;
				
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_float(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				// use type double for internal operation
				decimal dec = recordset.reader.GetDecimal(column);
				double value = Convert.ToDouble(dec);
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_bigint(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				object obj = null;
				try { obj = recordset.reader.GetInt64(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				long value = System.Convert.ToInt64(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_ubigint(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				object obj = null;
				try { obj = recordset.reader.GetString(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				ulong value = System.Convert.ToUInt64(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_tinyint(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				object obj = null;
				try { obj = recordset.reader.GetInt16(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				int value = System.Convert.ToInt32(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_utinyint(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				object obj = null;
				try { obj = recordset.reader.GetInt16(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				ulong value = System.Convert.ToUInt64(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}

			static public void Read_string(Record record, Recordset recordset, string name, int column)
			{
				if (!(recordset.reader is System.Data.Odbc.OdbcDataReader))
				{
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}

				object obj = null;
				try { obj = recordset.reader.GetString(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				record.fields\[name\] = new MFSingletonSequence(obj);
			}
			
		}// MySQL


		public static partial class MariaDB
		{
			static public void Read_ubigint(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.command is System.Data.Odbc.OdbcCommand)
				{
					var cmd = recordset.command as System.Data.Odbc.OdbcCommand;
					if (cmd.Connection.Driver.StartsWith("myodbc3", true, System.Globalization.CultureInfo.InvariantCulture))
					{
						Altova.Db.Dbs.MySQL.Read_ubigint(record, recordset, name, column);
						return;
					}
				}
				
				Altova.Db.Dbs.Read_ulong(record, recordset, name, column);
			}
		}// MariaDB


		public static partial class Oracle
		{
			static public void Parse_IntervalYearToMonth(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				int n = 0;
				string s = recordset.reader.GetString(column);
				string e = s + " cannot be converted to a duration value";
				Altova.Types.DateTime.ParseContext context = new Altova.Types.DateTime.ParseContext(s.Trim());

				bool positive = true; // parse sign
				if( context.CheckAndAdvance('-') ) positive = false;
				else if( context.CheckAndAdvance('+') ) positive = true;
				else throw new StringParseException(e + "Invalid or missing sign.");

				int years = 0; // parse year component
				if (!context.IsValid()) throw new StringParseException(e + "Missing year value.");
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { years = (years * 10) + n; n = 0; }

				// check year-month divider
				if (!context.IsValid()) throw new StringParseException(e + "Missing year-month divider.");
				if (!context.CheckAndAdvance('-')) throw new StringParseException(e + "Invalid year-month divider.");

				int month = 0; // parse month component
				if (!context.IsValid()) throw new StringParseException(e + "Missing month value.");
				while (context.ReadDigitAndAdvance(ref n, 1, 9)) { month = (month * 10) + n; n = 0; }

				Duration duration = new Duration(years, month, 0, 0, 0, 0, 0.0, !positive );
				record.fields\[name\] = new MFSingletonSequence( duration );
			}

			static public void Read_IntervalYearToMonth(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				long value = Convert.ToInt64(recordset.reader.GetValue(column));
				bool positive = value >= 0;
				if (!positive) value = -value;
				long years = value / 12;
				long month = value % 12;
				Duration duration = new Duration((int)years, (int)month, 0, 0, 0, 0, 0, !positive);
				record.fields\[name\] = new MFSingletonSequence(duration);
			}
			
			static public void Read_IntervalDayToSecond(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				System.TimeSpan value = (System.TimeSpan)(recordset.reader.GetValue(column));
				bool positive = value >= System.TimeSpan.Zero;
				if (!positive) value = value.Negate();
				Duration duration = new Duration(0, 0, value.Days, value.Hours, value.Minutes, value.Seconds, value.Milliseconds / 1000.0, !positive);
				record.fields\[name\] = new MFSingletonSequence(duration);
			}

			static public void Parse_IntervalDayToSecond(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				int n = 0;
				string s = recordset.reader.GetString(column);
				string e = s + " cannot be converted to a duration value";
				Altova.Types.DateTime.ParseContext context = new Altova.Types.DateTime.ParseContext(s.Trim());

				bool positive = true;// parse sign
				if (context.CheckAndAdvance('-')) positive = false;
				else if (context.CheckAndAdvance('+')) positive = true;
				else throw new StringParseException(e);
				if (!context.IsValid()) throw new StringParseException(e);

				int days = 0;// parse days component
				while( context.ReadDigitAndAdvance(ref n, 1, 9) ) { days = (days*10) + n; n = 0; }
				if (!context.IsValid()) throw new StringParseException(e);

				// check days-time divider
				if (!context.CheckAndAdvance(' ')) throw new StringParseException(e);
				if (!context.IsValid()) throw new StringParseException(e);

				string isotime = s.Substring( context.Index );// parse hours:minutes:seconds.fraction 
				Altova.Types.DateTime time = Altova.Types.DateTime.Parse(isotime, DateTimeFormat.W3_time);
				System.DateTime value = time.Value;

				Duration duration = new Duration(0, 0, days, value.Hour, value.Minute, value.Second, value.Millisecond / 1000.0, !positive);
				record.fields\[name\] = new MFSingletonSequence(duration);
			}
		}// Oracle


		public static partial class iSeries
		{
			
			static public void Read_bigint(Record record, Recordset recordset, string name, int column)
			{
				if((recordset.reader is System.Data.Odbc.OdbcDataReader)
				|| (recordset.reader is System.Data.OleDb.OleDbDataReader))
				{
					object o = null;
					try { o = recordset.reader.GetInt64(column); }
					catch (System.InvalidCastException) { o = null; }
					if (o == null)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					long value = System.Convert.ToInt64(o);
					record.fields\[name\] = new MFSingletonSequence(value);
				}
				else
				{
					Altova.Db.Dbs.Read_long(record, recordset, name, column);
				}
			}
			
			static public void Read_blob(Record record, Recordset recordset, string name, int column)
			{
				try
				{
					long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
					byte\[\] b = new byte\[l\];
					if (l > 0) recordset.reader.GetBytes(column, 0, b, 0, (int)l);
					record.fields\[name\] = new MFSingletonSequence(b);
				}
				catch (System.InvalidCastException)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
				}
			}
			
			static public void Read_rowid(Record record, Recordset recordset, string name, int column)
			{
				try
				{
					long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
					byte\[\] b = new byte\[l\];
					if (l > 0) recordset.reader.GetBytes(column, 0, b, 0, (int)l);
					record.fields\[name\] = new MFSingletonSequence(Altova.HexBinary.decode(b));
				}
				catch (System.InvalidCastException)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
				}
			}
			
			static public void Read_string(Record record, Recordset recordset, string name, int column)
			{
				if((recordset.reader is System.Data.Odbc.OdbcDataReader)
				|| (recordset.reader is System.Data.OleDb.OleDbDataReader))
				{
					string value = null;
					try { value = recordset.reader.GetString(column); }
					catch (System.InvalidCastException) { value = null; }
					if (value == null)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
					}
					else
					{
						record.fields\[name\] = new MFSingletonSequence(value);
					}
				}
				else
				{
					Altova.Db.Dbs.Read_string(record, recordset, name, column);
				}
			}
			
		}// iSeries


		public static partial class Informix // read recordset
		{
			
			static public void Read_bigint(Record record, Recordset recordset, string name, int column)
			{
				object obj = null;
				if (recordset.reader is System.Data.OleDb.OleDbDataReader)
				{// value comes as decimal - convert to long
					obj = recordset.reader.GetValue(column);
					if (obj != null && obj.Equals(DBNull.Value))
						obj = null;
				}
				else // recordset.reader is System.Data.Odbc.OdbcDataReader
				{
					try { obj = recordset.reader.GetInt64(column); }
					catch (System.OverflowException) { obj = null; }['VS2010 throws an overflow exception for dbnull values]
					catch (System.InvalidCastException) { obj = null; }['VS2008 throws an invalid cast exception for dbnull values]
				}
				if (obj == null)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				long value = System.Convert.ToInt64(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}
			
			static public void Read_int8(Record record, Recordset recordset, string name, int column)
			{
				object obj = null;
				try { obj = recordset.reader.GetValue(column); }
				catch (System.InvalidCastException) { obj = null; }
				if (obj == null || obj == System.DBNull.Value)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				long value = System.Convert.ToInt64(obj);
				record.fields\[name\] = new MFSingletonSequence(value);
			}
			
			static public void Read_blob(Record record, Recordset recordset, string name, int column)
			{ ['ODBC ERROR: Unknown SQL type - -102.]
				try
				{
					long l = recordset.reader.GetBytes(column, 0, null, 0, 0);
					byte\[\] b = new byte\[l\];
					if (l > 0) {
						recordset.reader.GetBytes(column, 0, b, 0, (int)l);
						record.fields\[name\] = new MFSingletonSequence(b);
						return;
					}
				}
				catch (System.InvalidCastException)
				{
				}
				record.fields\[name\] = MFEmptySequence.Instance;
			}
			
			static public void Read_clob(Record record, Recordset recordset, string name, int column)
			{ ['ODBC ERROR: Unknown SQL type - -103.]
				if (recordset.reader is System.Data.OleDb.OleDbDataReader)
				{// 
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					String obj = recordset.reader.GetString(column);
					record.fields\[name\] = new MFSingletonSequence(obj);
				}
				else // recordset.reader is System.Data.Odbc.OdbcDataReader
				{
					bool isnull = false;
					try { Read_string(record, recordset, name, column); }
					catch (System.ArgumentException) { isnull = true; }
					if (isnull)
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}
				}
			}

			static public void Read_text(Record record, Recordset recordset, string name, int column)
			{
				bool isnull = false;
				try { Read_string(record, recordset, name, column); }
				catch (System.ArgumentException) { isnull = true; }
				if (isnull)
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
			}
			

			static public void Parse_IntervalYearToYear(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Year);
			}
			static public void Parse_IntervalMonthToMonth(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Month);
			}
			static public void Parse_IntervalDayToDay(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day);
			}
			static public void Parse_IntervalHourToHour(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour);
			}
			static public void Parse_IntervalMinuteToMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Minute);
			}
			static public void Parse_IntervalSecondToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Second);
			}
			static public void Parse_IntervalFractionToFraction(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Fraction);
			}
			static public void Parse_IntervalYearToMonth(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Year | IntervalPart.Month);
			}
			static public void Parse_IntervalDayToHour(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour);
			}
			static public void Parse_IntervalDayToMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute);
			}
			static public void Parse_IntervalDayToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second);
			}
			static public void Parse_IntervalDayToFraction(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void Parse_IntervalHourToMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour | IntervalPart.Minute);
			}
			static public void Parse_IntervalHourToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second);
			}
			static public void Parse_IntervalHourToFraction(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void Parse_IntervalMinuteToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Minute | IntervalPart.Second);
			}
			static public void Parse_IntervalMinuteToFraction(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}
			static public void Parse_IntervalSecondToFraction(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Second | IntervalPart.Fraction);
			}

			static public void Read_DateTime_YearToYear(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year);
			}
			static public void Read_DateTime_YearToMonth(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month);
			}
			static public void Read_DateTime_YearToDay(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month|IntervalPart.Day);
			}
			static public void Read_DateTime_YearToHour(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour);
			}
			static public void Read_DateTime_YearToMinute(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void Read_DateTime_YearToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void Read_DateTime_YearToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Year|IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_MonthToMonth(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month);
			}
			static public void Read_DateTime_MonthToDay(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month|IntervalPart.Day);
			}
			static public void Read_DateTime_MonthToHour(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour);
			}
			static public void Read_DateTime_MonthToMinute(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void Read_DateTime_MonthToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void Read_DateTime_MonthToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Month|IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_DayToDay(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Day);
			}
			static public void Read_DateTime_DayToHour(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Day|IntervalPart.Hour);
			}
			static public void Read_DateTime_DayToMinute(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void Read_DateTime_DayToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void Read_DateTime_DayToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Day|IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_HourToHour(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Hour);
			}
			static public void Read_DateTime_HourToMinute(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Hour|IntervalPart.Minute);
			}
			static public void Read_DateTime_HourToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second);
			}
			static public void Read_DateTime_HourToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Hour|IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_MinuteToMinute(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Minute);
			}
			static public void Read_DateTime_MinuteToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Minute|IntervalPart.Second);
			}
			static public void Read_DateTime_MinuteToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Minute|IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_SecondToSecond(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Second);
			}
			static public void Read_DateTime_SecondToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Second|IntervalPart.Fraction);
			}
			static public void Read_DateTime_FractionToFraction(Record record, Recordset recordset, string name, int column)
			{
				Read_DateTime_Informix(record, recordset, name, column, IntervalPart.Fraction);
			}

			static public void Read_DateTime_Informix(Record record, Recordset recordset, string name, int column, IntervalPart part)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				object obj = recordset.reader.GetValue(column);// datetime or timespan instance
				int year=1200; int month=1; int day=1; int hour=0; int minute=0; double second=0.0;

				if ((part & IntervalPart.Year) == IntervalPart.Year)
				{
					if (obj is System.DateTime)
						year = ((System.DateTime)(obj)).Year;
				}
				if ((part & IntervalPart.Month) == IntervalPart.Month)
				{
					if (obj is System.DateTime)
						month = ((System.DateTime)(obj)).Month;
				}
				if ((part & IntervalPart.Day) == IntervalPart.Day)
				{
					if (obj is System.DateTime)
						day = ((System.DateTime)(obj)).Day;
					if (obj is System.TimeSpan)
						day = ((System.TimeSpan)(obj)).Days;
				}
				if ((part & IntervalPart.Hour) == IntervalPart.Hour)
				{
					if (obj is System.DateTime)
						hour = ((System.DateTime)(obj)).Hour;
					if (obj is System.TimeSpan)
						hour = ((System.TimeSpan)(obj)).Hours;
				}
				if ((part & IntervalPart.Minute) == IntervalPart.Minute)
				{
					if (obj is System.DateTime)
						minute = ((System.DateTime)(obj)).Minute;
					if (obj is System.TimeSpan)
						minute = ((System.TimeSpan)(obj)).Minutes;
				}
				if ((part & IntervalPart.Second | IntervalPart.Fraction) != 0)
				{
					if (obj is System.DateTime)
					{
						System.DateTime dt = (System.DateTime)(obj);
						const decimal factor = 100.0E-9m; // 100 ns
						decimal fraction = (dt.Ticks * factor);
						fraction -= System.Decimal.ToInt64(fraction);
						second = dt.Second + System.Decimal.ToDouble(fraction);
					}
					if (obj is System.TimeSpan)
					{
						System.TimeSpan ts = (System.TimeSpan)(obj);
						const decimal factor = 100.0E-9m; // 100 ns
						decimal fraction = (ts.Ticks * factor);
						fraction -= System.Decimal.ToInt64(fraction);
						second = ts.Seconds + System.Decimal.ToDouble(fraction);
					}
				}

				record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime(year, month, day, hour, minute, second));
			}
		
		}// Informix


		public static partial class Progress // read recordset
		{
			static public void Read_TimestampWithTimezone(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				
				object value = recordset.reader.GetValue(column);
				if (value is System.DateTime)
				{
					record.fields\[name\] = new MFSingletonSequence(new Altova.Types.DateTime((System.DateTime)value));

				}
				else if (value is System.String)
				{
					string pattern = @"(\\d{1,4})-(\\d{1,2})-(\\d{1,2}) (\\d{1,2}):(\\d{1,2}):(\\d{1,2}):(\\d+) (\\+|-) (\\d{1,2}):(\\d{1,2})";
					System.Text.RegularExpressions.Regex r = new System.Text.RegularExpressions.Regex(pattern);
					System.Text.RegularExpressions.Match m = r.Match((string)value);
					if (!m.Success) throw new FormatException("unknown timestamp with time zone format");

					int year = Int32.Parse(m.Groups\[1\].Value);
					int month = Int32.Parse(m.Groups\[2\].Value);
					int day = Int32.Parse(m.Groups\[3\].Value);
					int hour = Int32.Parse(m.Groups\[4\].Value);
					int minute = Int32.Parse(m.Groups\[5\].Value);
					double second = Double.Parse(m.Groups\[6\].Value + "." + m.Groups\[7\].Value, System.Globalization.NumberFormatInfo.InvariantInfo);
					bool neg = m.Groups\[8\].Value == "-";// tz sign
					int tzh = Int32.Parse(m.Groups\[9\].Value);
					int tzm = Int32.Parse(m.Groups\[10\].Value);
					int tz = (tzh * 60 + tzm) * (neg ? -1 : +1);
					Altova.Types.DateTime dt = new Altova.Types.DateTime(year,month,day, hour, minute, second, tz);
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
				else
				{
					throw new FormatException("unknown format while reading progress timestamp with time zone");
				}
			}
			
		}// Progress

		public static partial class Teradata // read recordset
		{
			static public void Read_Time(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_TimeSpan_BuildTime(record, recordset, name, column);
			}
			static public void Read_TimeWithTimezone(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}

				object value = recordset.reader.GetValue(column);
				Altova.Types.DateTime dt = new Altova.Types.DateTime();
				if (!dt.ParseDateTime(value.ToString(), Altova.Types.DateTime.DateTimePart.Time))
					throw new Altova.Types.StringParseException("invalid time value: " + value.ToString());
				record.fields\[name\] = new MFSingletonSequence(dt);
			}

			static public void Read_TimestampWithTimezone(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader.IsDBNull(column))
				{
					record.fields\[name\] = MFEmptySequence.Instance;
					return;
				}
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// Odbc bridge has no support for datetimeoffset
					object value = recordset.reader.GetValue(column);
					System.DateTime sdt = (System.DateTime)(value);
					Altova.Types.DateTime dt = new Altova.Types.DateTime(sdt);
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
				else
				{
					object value = recordset.reader.GetValue(column);
					System.DateTimeOffset dto = (System.DateTimeOffset)value;
					Altova.Types.DateTime dt = new Altova.Types.DateTime(dto.DateTime);
					dt.TimezoneOffset = Convert.ToInt16( dto.Offset.TotalMinutes );
					record.fields\[name\] = new MFSingletonSequence(dt);
				}
			}

			static public void Read_IntervalYear(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Year);
			}
			static public void Read_IntervalYearToMonth(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Year | IntervalPart.Month);
			}
			static public void Read_IntervalMonth(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Month);
			}

			static public void Read_IntervalDay(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day);
			}
			static public void Read_IntervalDayToHour(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour);
			}
			static public void Read_IntervalDayToMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute);
			}
			static public void Read_IntervalDayToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Day | IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}

			static public void Read_IntervalHour(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour);
			}
			static public void Read_IntervalHourToMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour | IntervalPart.Minute);
			}
			static public void Read_IntervalHourToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Hour | IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}

			static public void Read_IntervalMinute(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Minute);
			}
			static public void Read_IntervalMinuteToSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Minute | IntervalPart.Second | IntervalPart.Fraction);
			}

			static public void Read_IntervalSecond(Record record, Recordset recordset, string name, int column)
			{
				Dbs.Read_string_ParseInterval(record, recordset, name, column, IntervalPart.Second | IntervalPart.Fraction);
			}

			static private object GetString(System.Data.Odbc.OdbcDataReader reader, int column)
			{
				try
				{
					if (reader.IsDBNull(column))
						return null;
				}
				catch (System.ArgumentException)
				{
				}
				
				object value = null;
				try { value = reader.GetString(column); }
				catch (System.InvalidCastException) { }
				return value;
			}
			
			static private string HandlePeriod(string value)
			{
				foreach (char ch in new char\[\] { '\\'', '(', ')' })
					value = value.Replace(Convert.ToString(ch), "");

				string\[\] parts = value.Split(new char\[\] { ',' });
				return "(" + parts\[0\].Trim() + ", " + parts\[1\].Trim() + ")";
			}
			
			static public void Read_PeriodDate(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata period date
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(HandlePeriod(value.ToString())))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			static public void Read_PeriodTime(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata period time
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(HandlePeriod(value.ToString())))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			static public void Read_PeriodTimeWithTimezone(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata period time with time zone
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(HandlePeriod(value.ToString())))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			static public void Read_PeriodTimestamp(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata period timestamp 
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(HandlePeriod(value.ToString())))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			static public void Read_PeriodTimestampWithTimezone(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata period timestamp with time zone
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(HandlePeriod(value.ToString())))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}

			static public void Read_Json(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata json type
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(value.ToString()))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			
			static public void Read_Xml(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata xml type
					object value = GetString((System.Data.Odbc.OdbcDataReader)recordset.reader, column);
					record.fields\[name\] = (value != null)	? (IEnumerable)(new MFSingletonSequence(value.ToString()))
															: (IEnumerable)(MFEmptySequence.Instance);
					return;
				}
				Dbs.Read_string(record, recordset, name, column);
			}
			
			static public void Read_Decimal(Record record, Recordset recordset, string name, int column)
			{
				if (recordset.reader is System.Data.Odbc.OdbcDataReader)
				{// workaround for Odbc bridge to read teradata decimal type
					if (recordset.reader.IsDBNull(column))
					{
						record.fields\[name\] = MFEmptySequence.Instance;
						return;
					}

					// ensure the driver option 'Use Regional Settings for Decimal Symbol' is turned off.
					System.IFormatProvider formatProvider = System.Globalization.CultureInfo.InvariantCulture;
					record.fields\[name\] = new MFSingletonSequence(Convert.ToDecimal(recordset.reader.GetValue(column), formatProvider));
					return;
				}
				Dbs.Read_decimal(record, recordset, name, column);
			}
			
		}// Teradata
		
	}
}