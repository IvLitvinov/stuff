[call GenerateFileHeader("DateTimeFormatParser.cs")]

using System.Text;
using System;

namespace Altova.Functions
{

public class DateTimeFormatParser 
{

	public DateTimeFormatParser(string pattern)
	{
		mPattern = pattern;
		mFieldOpen = '\[';
		mFieldClose = '\]';
	}

	public string formatDateTime( Altova.Types.DateTime dt)
	{
		string sOutput = "";

		int nLength = mPattern.Length;
		ParseState state = ParseState.NORMAL;
		ArgumentState argState = ArgumentState.COMPONENT;
		FieldInfo fieldInfo = new FieldInfo();

		for (int i = 0; i < nLength; ++i)
		{
			char cCurrent = mPattern\[i\];
			char cNext = (char)(i + 1 < nLength ? mPattern\[i + 1\] : 0);

			switch (state)
			{
				case ParseState.NORMAL:
				{
					if (cCurrent == mFieldOpen)
					{
						if (cNext != mFieldOpen)
						{
							state = ParseState.INFIELD;
							argState = ArgumentState.COMPONENT;
							fieldInfo.Reset();
						}
						else
						{
							sOutput += cCurrent;
							i++;
						}
					}
					else if (cCurrent == mFieldClose)
					{
						if (cNext != mFieldClose)
						{
							//error something is wrong with the pattern
							throw new System.ArgumentException("Incorrect pattern: '" + mPattern + "'");
						}
						else
						{
							sOutput += cCurrent;
							i++;
						}
					}
					else
					{
						sOutput += cCurrent;
					}
				}
				break;
				case ParseState.INFIELD:
				{
					if (cCurrent == mFieldClose)
					{
						if (cNext != mFieldClose)
						{
							state = ParseState.NORMAL;

							if (fieldInfo.mComponent > 0)
							{
								string sValue = getComponentValue(dt, fieldInfo.mComponent);
								if ((fieldInfo.mComponent != 'z' && fieldInfo.mComponent != 'Z') || dt.HasTimezone)
									sValue = processFormatModifier(dt, sValue, fieldInfo);
								sValue = processWidth(sValue, fieldInfo);

								sOutput += sValue;
							}
						}
						else
						{
							//error ]] in field
							throw new System.ArgumentException("Incorrect pattern: '" + mPattern + "'");
						}
					}
					else
					{
						switch (argState)
						{
							case ArgumentState.COMPONENT:
							{
								fieldInfo.mComponent = cCurrent;
								argState = ArgumentState.FORMAT;
							}
							break;
							case ArgumentState.FORMAT:
							{
								if (cCurrent == ',')
									argState = ArgumentState.WIDTH;
								else
									fieldInfo.mModifier += cCurrent;
							}
							break;
							case ArgumentState.WIDTH:
							{
								fieldInfo.mWidth += cCurrent;
							}
							break;
						}
					}
				}
				break;
			}
		}

		if( state != ParseState.NORMAL )
			throw new System.ArgumentException("Incorrect pattern: '" + mPattern + "'");

		return sOutput;
	}

	protected string processFormatModifier(
		Altova.Types.DateTime dtData,
		string sValue,
		FieldInfo fieldInfo)
	{
		if( fieldInfo.mModifier.Length == 0 )
		{
			// set presentation defaults
			if (fieldInfo.mComponent == 'F' || fieldInfo.mComponent == 'P')
				fieldInfo.mModifier = "n";
			else if (fieldInfo.mComponent == 'm' || fieldInfo.mComponent == 's')
				fieldInfo.mModifier = "01";
			else
				fieldInfo.mModifier = "1";
		}

		string sResult = sValue;
		int nZeroPad = 0;
		while( fieldInfo.mModifier\[nZeroPad\] == '0' ) nZeroPad++;

		if( fieldInfo.mModifier.Substring(nZeroPad) == "1" )
		{
			StringBuilder sbResult = new StringBuilder(sValue);
			if( fieldInfo.mComponent == 'F' )
			{
				sbResult = new StringBuilder();
				DateTime dt = dtData.GetDateTime(true);
				int day = (int)dt.DayOfWeek;
				day = day == 0 ? 7 : day; //strange calendar
				sbResult.Append(day);
				fieldInfo.mComponent = 'D'; //prevent processWidth to handle the output as string
			}

			//add padding zeros
			int nLength = sbResult.Length;
			if( sbResult.Length < nZeroPad + 1 )
				for( int i = 0; i < nZeroPad + 1 - nLength; i++) sbResult.Insert(0, '0');
			sResult = sbResult.ToString();
		}
		else if( fieldInfo.mModifier == "N" 
				|| fieldInfo.mModifier == "n" 
				|| fieldInfo.mModifier == "Nn" )
		{
			sResult = getComponentNameValue( dtData, fieldInfo);
			if( fieldInfo.mModifier == "N" )
				sResult = sResult.ToUpper();
			else if( fieldInfo.mModifier == "n" )
				sResult = sResult.ToLower();
		}
		else
		{
			throw new System.ArgumentException("Unknown format modifier: '" + fieldInfo.mModifier + "'");
		}

		return sResult;
	}
	
	protected string processWidth(
		string sValue,
		FieldInfo fieldInfo)
	{
		if( fieldInfo.mWidth.Length == 0 )
			return sValue;

		StringBuilder sResult = new StringBuilder(sValue);

		fieldInfo.Analyze();
		int nLength = sResult.Length;
		if( fieldInfo.mMaxWidth > 0 )
		{
			if( fieldInfo.mMaxWidth >= fieldInfo.mMinWidth )
			{
				if( nLength > fieldInfo.mMaxWidth )
				{
					if( fieldInfo.mComponent != 'Y' )
						sResult.Remove( fieldInfo.mMaxWidth, nLength - fieldInfo.mMaxWidth );
					else
						sResult.Remove(0, nLength - fieldInfo.mMaxWidth);
				}
			}
		}

		if( fieldInfo.mMinWidth > nLength)
		{
			if( fieldInfo.mComponent != 'F' ) // F day of week, is currently the only text and should be padded with ' '
				for( int i = 0; i < fieldInfo.mMinWidth - nLength; i++) sResult.Insert(0, '0');
			else
				for( int i = 0; i < fieldInfo.mMinWidth - nLength; i++) sResult.Append(' ');
		}

		return sResult.ToString();
	}

	protected String getComponentNameValue(
		Altova.Types.DateTime dtData,
		FieldInfo fieldInfo)
	{
		String sValue;
		DateTime dt = dtData.GetDateTime(true);

		switch( fieldInfo.mComponent )
		{
			case 'M':
				sValue = MonthNames\[dt.Month - 1\]; 
				fieldInfo.mComponent = 'F'; //this allows the process width to handle the result as Text
			break;
			case 'D':
				sValue = DayNames\[ (int)dt.DayOfWeek \]; 
				fieldInfo.mComponent = 'F'; //this allows the process width to handle the result as Text	
			break;
			default:
				sValue = getComponentValue(dtData, fieldInfo.mComponent);
			break;
		}

		return sValue;
	}

	protected string getComponentValue(
		Altova.Types.DateTime dtData,
		char cComponent)
	{
		StringBuilder sValue = new StringBuilder();
		DateTime dt = dtData.GetDateTime(true);
		switch( cComponent )
		{
			case 'd': sValue.Append( dt.DayOfYear ); break;
			case 'D': sValue.Append( dt.Day ); break;
			case 'F': sValue.Append( DayNames\[ (int)dt.DayOfWeek \] ); break;
			case 'M': sValue.Append( dt.Month ); break;
			case 'Y': sValue.Append( dt.Year ); break;
			case 'W': 
			{
				System.Globalization.CultureInfo myCI = new System.Globalization.CultureInfo("en-US");
				sValue.Append(myCI.Calendar.GetWeekOfYear(dt,
				System.Globalization.CalendarWeekRule.FirstFourDayWeek,
				System.DayOfWeek.Monday));
			}
			break;
			case 'w': sValue.Append(dtData.GetWeekOfMonth()); break;
			case 'P': sValue.Append( dt.Hour < 12 ? "A.M." : "P.M." ); break;
			case 'H': sValue.Append(dt.Hour); break;
			case 'h':
			{
				long h = dt.Hour;
				if (h > 12)
					h -= 12;
				else if (h == 0)
					h = 12;
				sValue.Append(h);
			}
			break;
			case 'm': 
			{
				sValue.Append(dt.Minute);
				if( sValue.Length < 2)
					sValue.Insert( 0, '0' );
			}
			break;
			case 's':
			{
				sValue.Append( dt.Second );
				if( sValue.Length < 2)
					sValue.Insert( 0, '0' );
			}
			break;
			case 'f':
			{
				sValue.Append( String.Format("{0:000}", dtData.GetDateTime(true).Millisecond) );
			}
			break;
			case 'z':
			{
				if (dtData.HasTimezone)
				{
					sValue.Append("GMT");
					StringBuilder hour = new StringBuilder();
					hour.Append(Math.Abs(dtData.TimezoneOffset / 60));
					StringBuilder mins = new StringBuilder();
					mins.Append(Math.Abs(dtData.TimezoneOffset % 60));
					sValue.Append(dtData.TimezoneOffset >= 0 ? '+' : '-');
					sValue.Append(hour.Length < 2 ? '0' + hour.ToString() : hour.ToString());
					sValue.Append(':');
					sValue.Append(mins.Length < 2 ? '0' + mins.ToString() : mins.ToString());
				}
			}
			break;
			case 'Z':
			{
				if( dtData.HasTimezone)
				{
					StringBuilder hour = new StringBuilder();
					hour.Append(Math.Abs(dtData.TimezoneOffset / 60));
					StringBuilder mins = new StringBuilder();
					mins.Append(Math.Abs(dtData.TimezoneOffset % 60));
					sValue.Append(dtData.TimezoneOffset >= 0 ? '+' : '-');
					sValue.Append(hour.Length < 2 ? '0' + hour.ToString() : hour.ToString());
					sValue.Append(':');
					sValue.Append(mins.Length < 2 ? '0' + mins.ToString() : mins.ToString());
				}
			}
			break;
			default:
				throw new System.ArgumentException("Unknown component specifier: '" + cComponent + "'");
		}
		return sValue.ToString();
	}

	public Altova.Types.DateTime parseDateTime( string sInput)
	{
		string sPattern = mPattern.Trim();
		StringBuilder sbInput = new StringBuilder(sInput);
		ParseState state = ParseState.NORMAL;
		ArgumentState argState = ArgumentState.COMPONENT;
		FieldInfo fieldInfo = new FieldInfo();
		DateTimeData dt = new DateTimeData();

		int nLength = sPattern.Length;
		for( int i = 0; i < nLength; ++i)
		{
			char cCurrent = sPattern\[i\];
			char cNext = (char)(i + 1 < nLength ? sPattern\[i + 1\] : 0);

			switch( state )
			{
				case ParseState.NORMAL:
				{
					if( cCurrent == mFieldOpen )
					{
						if( cNext != mFieldOpen )
						{
							state = ParseState.INFIELD;
							argState = ArgumentState.COMPONENT;
							fieldInfo.Reset();
						}
						else
						{
							i++;
							if( cCurrent == sbInput\[0\] )
							{
								sbInput.Remove(0, 1);
							}
							else
							{
								throw new System.ArgumentException( "Pattern not matching field opening '" + mFieldOpen + "'. Unable to read: '" + sbInput.ToString() + "'");
							}
						}
					}
					else
					{
						if( cCurrent == sbInput\[0\] )
						{
							sbInput.Remove(0, 1);
						}
						else
						{
							throw new System.ArgumentException( "Pattern doesn't match! Unable to read: '" + sbInput.ToString() + "'");
						}
					}
				}
				break;
				case ParseState.INFIELD:
				{
					if( cCurrent == mFieldClose )
					{
						if( cNext != mFieldClose )
						{
							state = ParseState.NORMAL;

							if( fieldInfo.mComponent > 0 )
							{
								//Analyze field read min and max width
								fieldInfo.Analyze();
								//Read the field from input and apply correct value
								ReadField( dt, fieldInfo, sbInput, cNext);
							}
						}
						else
						{
							i++;
						}
					}
					else
					{
						switch( argState )
						{
							case ArgumentState.COMPONENT:
							{
								fieldInfo.mComponent = cCurrent;
								argState = ArgumentState.FORMAT;
							}
							break;
							case ArgumentState.FORMAT:
							{
								if( cCurrent == ',' )
									argState = ArgumentState.WIDTH;
								else
									fieldInfo.mModifier += cCurrent;
							}
							break;
							case ArgumentState.WIDTH:
							{
								fieldInfo.mWidth += cCurrent;
							}
							break;
						}
					}
				}
				break;
			}
		}

		int\[\] monthTable = System.DateTime.IsLeapYear( dt.Year ) ? monthStartLeap : monthStart;
		if( dt.DayOfYear > 0 && dt.DayOfYear <= monthTable\[12\] )
		{
			int i = 12;
			while( monthTable\[i\] >= dt.DayOfYear ) i--;
			dt.Day = dt.DayOfYear - monthTable\[i\];
			dt.Month = i + 1;
		}

		Boolean b2400 = dt.Hour == 24 && dt.Minute == 0 && dt.Second == 0;
		if (b2400)
			dt.Hour = 0;

		Altova.Types.DateTime result = new Altova.Types.DateTime();
		System.DateTime dtresult = new System.DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, dt.Minute, dt.Second);
		if (b2400)
			dtresult = dtresult.AddDays(1);
		dtresult = dtresult.AddTicks(dt.NanoSecond / 100);// add number of 100-nanosecond ticks. 
		result.Value = dtresult;
		result.TimezoneOffset = (short)dt.TimeZone;
		return result;
	}

	bool StringToRead( string sModifier)
	{
		if( sModifier == "N" || sModifier == "n" || sModifier == "Nn" )
			return true;
		else
			return false;
	}

	int ReadNumber( StringBuilder sbInput, int nMax )
	{
		StringBuilder sbNumber = new StringBuilder("");
		string sInput = sbInput.ToString().TrimStart( ' ', '\\t' ); //trim beginning spaces
		sbInput.Remove(0, sbInput.Length);
		sbInput.Append(sInput);
		int i = 0;

		nMax = nMax == 0 ? sbInput.Length : nMax > sbInput.Length ? sbInput.Length : nMax;
		for (;i < nMax && char.IsDigit( sbInput\[i\] ); ++i)
		{
			sbNumber.Append(sbInput\[i\]);
		}
		sbInput.Remove(0, i);

		int ret;
		try {
			ret = Int32.Parse( sbNumber.ToString());
		}
		catch (Exception) {
			ret = 0;
		}
		return ret;
	}

	int ReadFieldNumber( StringBuilder sbInput, FieldInfo fieldinfo )
	{
		int nMax = fieldinfo.mMaxWidth;
		StringBuilder sbNumber = new StringBuilder("");
		string sInput = sbInput.ToString().TrimStart( ' ', '\\t' ); //trim beginning spaces
		sbInput.Remove(0, sbInput.Length);
		sbInput.Append(sInput);
		int i = 0;

		nMax = nMax == 0 ? sbInput.Length : nMax > sbInput.Length ? sbInput.Length : nMax;
		for (;i < nMax && char.IsDigit( sbInput\[i\] ); ++i)
		{
			sbNumber.Append(sbInput\[i\]);
		}
		if( fieldinfo.mMinWidth > 0 && i < fieldinfo.mMinWidth )
		{
			throw new System.ArgumentException( "Pattern component '" + fieldinfo.mComponent + "' has minimum length of " + fieldinfo.mMinWidth + "! Unable to read: '" + sbInput + "'" );
		}
		sbInput.Remove(0, i);

		int ret;
		try {
			ret = Int32.Parse( sbNumber.ToString());
		}
		catch (Exception) {
			ret = 0;
		}
		return ret;
	}

	private decimal ReadFraction( StringBuilder sbInput, int nMax )
	{
		StringBuilder sbNumber = new StringBuilder("");
		sbNumber.Append("0.");// for decimal parsing
		string sInput = sbInput.ToString().TrimStart( ' ', '\\t' ); //trim beginning spaces
		sbInput.Remove(0, sbInput.Length);
		sbInput.Append(sInput);
		int i = 0;

		nMax = nMax == 0 ? sbInput.Length : nMax > sbInput.Length ? sbInput.Length : nMax;
		for (;i < nMax && char.IsDigit( sbInput\[i\] ); ++i)
		{
			sbNumber.Append(sbInput\[i\]);
		}
		sbInput.Remove(0, i);

		Decimal ret = 0m;
		Decimal.TryParse(sbNumber.ToString(), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out ret);
		return ret;
	}

	private String ReadStringUntil( StringBuilder sbInput, int nMax, char cUntil )
	{
		StringBuilder sbRead = new StringBuilder("");
		int i = 0;

		nMax = nMax == 0 ? sbInput.Length : nMax > sbInput.Length ? sbInput.Length : nMax;
		for (;i < nMax && sbInput\[i\] != cUntil; ++i)
		{
			sbRead.Append( sbInput\[i\] );
		}
		sbInput.Remove(0, i);

		return sbRead.ToString();
	}

	private void ReadField(
		DateTimeData dtData,
		FieldInfo fieldinfo,
		StringBuilder sbInput,
		char cNext)
	{
		string sInputBackup = sbInput.ToString();
		switch( fieldinfo.mComponent )
		{
		case 'd': //day of the year
		{
			dtData.DayOfYear = ReadFieldNumber(sbInput, fieldinfo);
		}
		break;

		case 'D':
		{
			if( !StringToRead(fieldinfo.mModifier) )
			{
				dtData.Day = ReadFieldNumber(sbInput, fieldinfo);
			}
		}
		break;
		case 'M':
		{
			if( !StringToRead(fieldinfo.mModifier) )
			{
				dtData.Month = ReadFieldNumber(sbInput, fieldinfo);
			}
			else
			{
				String sMonth = ReadStringUntil( sbInput, fieldinfo.mMaxWidth, cNext);

				//find the month from the table
				int i = 0;
				int nMax = fieldinfo.mMaxWidth == 0 ? sMonth.Length : fieldinfo.mMaxWidth;
				while( i < MonthNames.Length
					&& !sMonth.Equals(
						MonthNames\[i\].Substring(
							0,
							nMax > MonthNames\[i\].Length ? MonthNames\[i\].Length : nMax
						),
						StringComparison.CurrentCultureIgnoreCase
					)
				) i++;


				dtData.Month = i + 1;
			}

			if( dtData.Month > 12)
			{
				//restore sInput to give a better error message
				throw new System.ArgumentException( "Pattern component '" + fieldinfo.mComponent + "' doesn't match! Unable to read: '" + sInputBackup + "'");
			}
		}
		break;
		case 'Y':
		{
			dtData.Year = ReadFieldNumber(sbInput, fieldinfo);
			if( fieldinfo.mMaxWidth == 2)
			{
				 //change this in the year 2050;
				if( dtData.Year > 50)
					dtData.Year += 1900;
				else
					dtData.Year += 2000;
			}
		}
		break;
		case 'P':
		{
			String sPM = ReadStringUntil( sbInput, 4, (char)0);
			dtData.Hour += sPM.Equals( "p.m.", StringComparison.CurrentCultureIgnoreCase) && dtData.Hour != 12 ? 12 : 0;
		}
		break;
		case 'h':
		case 'H':
		{
			dtData.Hour = ReadFieldNumber(sbInput, fieldinfo);
		}
		break;
		case 'm':
		{
			dtData.Minute = ReadFieldNumber(sbInput, fieldinfo);
		}
		break;
		case 's':
		{
			dtData.Second = ReadFieldNumber(sbInput, fieldinfo);
		}
		break;
		case 'f':
		{
			decimal fraction = ReadFraction(sbInput, fieldinfo.mMaxWidth);
			fraction = Decimal.Multiply(fraction, 1000m*1000m*1000m); // to nanoseconds
			dtData.NanoSecond = Decimal.ToInt64( fraction );
		}
		break;
		case 'z':
		{
			if( sbInput.ToString().StartsWith( "GMT" ) )
				sbInput.Remove(0, 3);
			else
				throw new System.ArgumentException( "Pattern component '" + fieldinfo.mComponent + "' doesn't match! Unable to read: '" + sbInput.ToString() + "'");

			ParseTimeZone( sbInput, dtData);
		}
		break;
		case 'Z':
		{
			ParseTimeZone( sbInput, dtData);
		}
		break;
		case 'i':
		case 'I':
		{
			ReadStringUntil(sbInput, fieldinfo.mMaxWidth, cNext);
		}
		break;
		default:
			throw new System.ArgumentException( "Unknown component specifier: '" + fieldinfo.mComponent + "'");
		}
	}

	private void ParseTimeZone(StringBuilder sbInput, DateTimeData dtData)
	{
		int nMinus = 1;
		if( sbInput\[0\] == '-' )
			nMinus = -1;
		sbInput.Remove(0, 1);

		int nHour = ReadNumber(sbInput, 2);

		if( sbInput\[0\] != ':' )
		{
			throw new System.ArgumentException( "Pattern doesn't match! Unable to read: '" + sbInput.ToString() + "'");
		}
		else
			sbInput.Remove(0, 1);

		int nMinutes = ReadNumber(sbInput, 2);

		dtData.TimeZone = (nHour * 60 + nMinutes) * nMinus;
	}

	private int\[\] monthStart = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
	private int\[\] monthStartLeap = { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 };

	protected class FieldInfo
	{
		public char mComponent;
		public string mModifier;
		public string mWidth;
		public int mMinWidth;
		public int mMaxWidth;

		public FieldInfo()
		{
			Reset();
		}

		public void Reset()
		{
			mComponent = (char)0;
			mModifier = "";
			mWidth= "";
			mMinWidth = 0;
			mMaxWidth = 0;
		}

		public bool Analyze()
		{
			if( mWidth.Length == 0 )
				return false;

			int minusPos = mWidth.IndexOf( '-' );
			if( minusPos == -1 )
			{
				try {
					mMinWidth = Int32.Parse( mWidth );
				}
				catch (Exception) {
					mMinWidth = 0;
				}
			}
			else
			{
				try {
					mMinWidth = Int32.Parse(mWidth.Substring(0, minusPos));
				}
				catch (Exception)
				{
					mMinWidth = 0;
				}
				try {
					mMaxWidth = Int32.Parse(mWidth.Substring(minusPos + 1));
				}
				catch (Exception)
				{
					mMaxWidth = 0;
				}
			}

			return true;
		}

	};

	protected class DateTimeData
	{
		public DateTimeData() {
			Day = 1;
			Month = 1;
			Year = 1;
			Hour = 0;
			Minute = 0;
			Second = 0;
			TimeZone = Altova.Types.DateTime.NoTimezone;
			DayOfYear = 0;
		}

		public int Day;
		public int Month;
		public int Year;
		public int Hour;
		public int Minute;
		public int Second;
		public long NanoSecond;
		public int TimeZone;

		public int DayOfYear; //this value is stored for later processing
	};

	protected enum ParseState
	{
		NORMAL,
		INFIELD
	}

	protected enum ArgumentState
	{
		COMPONENT,
		FORMAT,
		WIDTH
	}

	private string\[\] DayNames = { 
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday"
	};

	private string\[\] MonthNames = {
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	};

	private string mPattern;
	private char mFieldOpen;
	private char mFieldClose;
}

}

