[call GenerateFileHeader("DataCompletion.cs")]
using System;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates completing data.
	/// </summary>
	public abstract class DataCompletion
	{
		#region Implementation Detail:
		/// <summary>
		/// The structure name.
		/// </summary>
		protected string mStructureName = "";
		/// <summary>
		/// Flag to indicate if completion of fields with single code in codelist is desired.
		/// </summary>
		protected bool mCompleteSingleValues = false;
		/// <summary>
		/// The textdocument reference.
		/// </summary>
		protected TextDocument mDocument = null;
		#endregion
		#region Descendant interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="structurename">the name of the structure to complete</param>
		protected static ITextNode MakeSureExists(ITextNode parent, string name, NodeClass cl)
		{
			ITextNodeCollection children = parent.Children;
			ITextNode result = children.GetFirstNodeByName( name);
			if (result == null)
			{
				result = new TextNode(parent, name);
				if (cl != NodeClass.Undefined)
					result.Class = cl;
				else if ((name == "GS") || (name == "GE") || (name == "ST")
					|| (name == "SE"))
					result.Class = NodeClass.Segment;
				else if (name.StartsWith("F"))
					result.Class = NodeClass.DataElement;
				else if (name.StartsWith("S"))
					result.Class = NodeClass.Composite;
				else if ((name.StartsWith("U")) && (3 == name.Length))
					result.Class = NodeClass.Segment;
				else if ((name.StartsWith("I")) && (3 == name.Length))
					result.Class = NodeClass.Segment;
				else
					result.Class = NodeClass.Group;
			}
			return result;
		}
		protected static ITextNode MakeSureExists(ITextNode parent, string name)
		{
			return MakeSureExists(parent, name, NodeClass.Undefined);
		}
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="textDocument">reference to the textdocument which should be completed.</param>
		/// <param name="structurename">the name of the structure to complete</param>
		protected DataCompletion(TextDocument textDocument, string structurename)
		{
			mDocument = textDocument;
			mStructureName = structurename;
		}
		/// <summary>
		/// Checks whether a node has a kid by a certain name.
		/// </summary>
		/// <param name="node">the node to check</param>
		/// <param name="name">the name to check for</param>
		/// <returns>true if the node has a kid named as specified, otherwise false</returns>
		protected static bool HasKid(ITextNode node, string name)
		{
			return (0 < node.Children.FilterByName(name).Length);
		}
		/// <summary>
		/// Returns a kid of a node by name.
		/// </summary>
		/// <param name="node">the node</param>
		/// <param name="name">the name of the kid to be returned</param>
		/// <returns>the named kid or null if none was found</returns>
		protected static ITextNode GetKid(ITextNode node, string name)
		{
			ITextNode\[\] kids = node.Children.FilterByName(name);
			if (kids.Length == 0)
				return null;
			return kids\[0\];
		}
		/// <summary>
		/// Sets the value of a node if it is yet empty.
		/// </summary>
		/// <param name="node">the node whose value is to be set</param>
		/// <param name="value">the new value</param>
		protected static void ConservativeSetValue(ITextNode node, string value)
		{
			if (0 == node.Value.Length)
				node.Value = value;
		}
		/// <summary>
		/// Gets the name of the structure this instance will complete.
		/// </summary>
		protected string StructureName
		{
			get
			{
				return mStructureName;
			}
		}
		/// <summary>
		/// Formats the current data in a way suitable for EDI messages.
		/// </summary>
		/// <returns>the formatted date string</returns>
		protected static string GetCurrentTimeAsEDIString()
		{
			return DateTime.Now.ToString("HHmm");
		}
		/// <summary>
		/// Formats the current time in a way suitable for EDI messages.
		/// </summary>
		/// <returns>the formatted time string</returns>
		protected static string GetCurrentDateAsEDIString(long syntaxVersion)
		{
			if (syntaxVersion < 4)
				return DateTime.Now.ToString("yyMMdd");
			else
				return DateTime.Now.ToString("yyyyMMdd");
		}
		/// <summary>
		/// Counts (recursively) all children of a node which are segment nodes.
		/// </summary>
		/// <param name="node">the node whose children to count</param>
		/// <returns>the number of children being segment nodes</returns>
		protected long GetSegmentChildrenCount(ITextNode node)
		{
			long result = (NodeClass.Segment == node.Class) ? 1 : 0;
			foreach (ITextNode kid in node.Children)
				result += GetSegmentChildrenCount(kid);
			return result;
		}

		/// <summary>
		/// Completes all mandatory items.
		/// </summary>
		protected static bool CompleteMandatory(ITextNode dataNode, Particle particle)
		{
			ITextNodeCollection dataChildren = dataNode.Children;
			StructureItem currentItem = particle.Node;
			dataNode.Class = currentItem.NodeClass;

			if (currentItem.NodeClass == NodeClass.DataElement)
				return dataNode.Value.Length != 0;
			else
			{
				int childCount = dataChildren.Count;
				bool anyExisted = false;
				bool bContainsSelect = false;

				foreach (Particle childParticle in currentItem.Children)
				{
					bContainsSelect = !bContainsSelect ? childParticle.Node.NodeClass == NodeClass.Select : true;
					int occurs = 0;
					string name = childParticle.Name;
					foreach (ITextNode childNode in dataChildren.FilterByName(name))
					{
						childCount -= 1;
						dataChildren.MoveNode(childNode, dataChildren.Count);
						bool childExists = CompleteMandatory(childNode, childParticle);
						anyExisted |= childExists;
						if (!childExists && childParticle.MergedEntries == 1)
							dataChildren.RemoveAt(dataChildren.Count-1);
						else
							++occurs;
					}

					if (currentItem.NodeClass == NodeClass.Group && childParticle.Node.NodeClass != NodeClass.Select && name != "Message" )
					{
						for (; occurs < childParticle.MinOccurs; ++occurs)
						{
							ITextNode node = new TextNode(dataNode, name, childParticle.Node.NodeClass);
							CompleteMandatory(node, childParticle);
						}
					}
				}
				if (!bContainsSelect)
				{
					for (; childCount != 0; )
					{
						dataChildren.RemoveAt(--childCount);
					}
				}
				else
					return true;

				return anyExisted;
			}
		
		}
		
		protected void CompleteConditionsAndValues(ITextNode node, Particle particle)
		{
			if (particle == null)
				throw new Exception ("Invalid parameter");

			node.Class = particle.Node.NodeClass;

			if (node.Class == NodeClass.Segment)
			{
				if (mCompleteSingleValues && particle.Node.ConditionPath.Length > 0)
				{
					ITextNode n = GetChildNodeByPath(node, particle.Node.ConditionPath);
					if (n == null)
						n = CreateTree(node, particle.Node.ConditionPath, particle);

					if (particle.Node.ConditionValue.Length > 0)
						ConservativeSetValue(n, particle.Node.ConditionValue);
					else
					{
						Particle p = GetParticleByPath(particle, particle.Node.ConditionPath);
						if (p != null && p.CodeValues.Length == 1)
							ConservativeSetValue(n, p.CodeValues\[0\]);
					}
				}
			}

			if (node.Class == NodeClass.Segment || node.Class == NodeClass.Composite)
			{
				foreach (Particle p in particle.Node.Children)
				{
					if (p.MinOccurs > 0)
					{
						if (p.Node.NodeClass == NodeClass.DataElement && p.CodeValues.Length != 1)
							continue;

						ITextNode n = MakeSureExists(node, p.Name, p.Node.NodeClass);
						CompleteConditionsAndValues(n, p);
					}
				}
			}
			else if (node.Class == NodeClass.DataElement)
			{
				if (mCompleteSingleValues && particle.CodeValues.Length == 1)
					ConservativeSetValue(node, particle.CodeValues\[0\]);
			}

			foreach (ITextNode n in node.Children)
				CompleteConditionsAndValues(n, GetParticleByPath(particle, n.Name));
		}

		protected Particle GetParticleByPath(Particle p, string path)
		{
			foreach (Particle childParticle in p.Node.Children)
			{
				string sName = childParticle.Name;
				int i = sName.IndexOf('/');
				if (i != -1)
				{
					if (childParticle.Name == path.Substring(0, i))
						return GetParticleByPath(childParticle, path.Substring(i + 1));
				}

				if (childParticle.Name == path)
					return childParticle;
			}

			return null;
		}

		protected ITextNode GetChildNodeByPath(ITextNode node, string path)
		{
			foreach (ITextNode n in node.Children)
			{
				int i = path.IndexOf('/');
				if (i != -1)
				{
					if (n.Name == path.Substring(0, i))
						return GetChildNodeByPath(n, path.Substring(i + 1));
				}

				if (n.Name == path)
					return n;
			}

			return null;
		}

		private ITextNode CreateTree(ITextNode node, string path, Particle particle)
		{
			int i = path.IndexOf('/');
			if (i != -1)
			{
				string name = path.Substring(0, i);
				Particle p = GetParticleByPath(particle, name);
				ITextNode n = MakeSureExists(node, name, p.Node.NodeClass);
				return CreateTree(n, path.Substring(i + 1), p);
			}

			return MakeSureExists(node, path, particle.Node.NodeClass);
		}
		
		#endregion
		#region Descendant obligations:
		/// <summary>
		/// Completes the hierarchy of nodes rooted in the passed node.
		/// </summary>
		/// <param name="dataroot">the root of the nodes to be completed</param>
		/// <param name="rootParticle">the structural root</param>
		public abstract void CompleteData(ITextNode dataroot, Particle rootParticle);
		#endregion
	}
}