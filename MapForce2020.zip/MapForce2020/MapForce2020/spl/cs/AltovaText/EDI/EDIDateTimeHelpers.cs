[call GenerateFileHeader("EDIDateTimeHelpers.cs")]

namespace Altova.TextParser.EDI
{
	public class EDIDateTimeHelpers
	{
		public static bool IsYearCorrect( string sRhs )
		{
			for (int i=0; i<sRhs.Length; ++i)
				if ( !System.Char.IsDigit( sRhs\[i\] ) ) return false;

			return true;
		}

		public static bool IsMonthCorrect( string sRhs )
		{
			long nMonth = Altova.CoreTypes.CastToInt( sRhs );
			if ( ( 1 > nMonth ) || ( 12 < nMonth ) ) return false;
			return true;
		}

		public static bool IsDayCorrect( string sRhs )
		{
			long nDay = Altova.CoreTypes.CastToInt( sRhs );
			if ( ( 1 > nDay ) || ( 31 < nDay ) ) return false;
			return true;
		}

		public static bool IsHourCorrect( string sRhs )
		{
			long nHour = Altova.CoreTypes.CastToInt( sRhs );
			if ( ( 0 > nHour ) || ( 23 < nHour ) ) return false;
			return true;
		}

		public static bool IsMinuteCorrect( string sRhs )
		{
			long nMinute = Altova.CoreTypes.CastToInt( sRhs );
			if ( ( 0 > nMinute ) || ( 59 < nMinute ) ) return false;
			return true;
		}

		public static bool IsDateCorrect( string sRhs )
		{
			// year can be YYYYMMDD or YYMMDD
			int yLen = 2;
			if ( sRhs.Length == 8)
				yLen = 4;
			else if (sRhs.Length == 6)
				yLen = 2;
			else if (sRhs.Length == 5) // special case for 0YMMDD where zero was removed because it is decimal type
				yLen = 1;
			else
				return false; // bad length

			if ( !IsYearCorrect( sRhs.Substring( 0, yLen ) ) ) return false;
			if (!IsMonthCorrect(sRhs.Substring(yLen, 2))) return false;
			if (!IsDayCorrect(sRhs.Substring(sRhs.Length - 2))) return false;
			return true;
		}

		public static bool IsTimeCorrect( string sRhs )
		{
			foreach( System.Char c in sRhs)
			{
				if( !System.Char.IsDigit(c))
					return false;
			}

			long len = sRhs.Length;

			// Time is HHMM\[SSd...d\]
			if ( !IsHourCorrect( sRhs.Substring( 0, 2 ) ) ) return false;
			if (!IsMinuteCorrect(sRhs.Substring(2, 2))) return false;
			if ( len > 4 ) // have secs?
				if (len < 6 || !IsMinuteCorrect(sRhs.Substring(4, 2))) return false; // seconds same as minutes 0..59

			return true;
		}
	}
} // namespace Altova.TextParser.EDI
