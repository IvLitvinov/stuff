[call GenerateFileHeader("EDIFixedDataCompletion.cs")]
using System.Globalization;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates auto completing data in a <see cref="ITextNode"/> hierarchy
	/// representing EDIFixed data.
	/// </summary>
	public class EDIFixedDataCompletion : DataCompletion
	{
		#region Implementation Detail:
		private EDIFixedSettings mSettings = null;
		#endregion

		#region Public Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="document">textdocument to complete</param>
		/// <param name="settings">the settings to use</param>
		/// <param name="structurename">the name of the EDIFixed structure which will be completed with this instance</param>
		public EDIFixedDataCompletion(TextDocument document, EDIFixedSettings settings, string structurename)
			: base(document, structurename)
		{
			mSettings = settings;
		}
		/// <summary>
		/// Completes/fills in missing data in a <see cref="ITextNode"/> hierarchy representing
		/// EDIFixed data.
		/// </summary>
		/// <param name="dataroot">the root node of the hierarchy to complete</param>
		/// <param name="rootParticle">the structural root</param>
		public override void CompleteData(ITextNode dataroot, Particle rootParticle)
		{
			CompleteMandatory(dataroot,rootParticle);
		}
		#endregion

		#region Implementation Detail

		#endregion
	}
}