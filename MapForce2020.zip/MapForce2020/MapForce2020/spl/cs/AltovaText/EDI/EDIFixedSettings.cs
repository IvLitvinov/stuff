[call GenerateFileHeader("EDIFixedSettings.cs")]
namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates EDIFixed specific settings
	/// </summary>
	public class EDIFixedSettings : EDISettings
	{
		#region Implementation Detail:
		#endregion
		#region Public Interface:
		public EDIFixedSettings () { mEDIStandard = EDIStandard.EDIFixed; }
		#endregion
	}
}