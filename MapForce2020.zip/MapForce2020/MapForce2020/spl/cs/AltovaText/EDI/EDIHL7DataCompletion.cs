[call GenerateFileHeader("EDIHL7DataCompletion.cs")]
using System.Globalization;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates auto completing data in a <see cref="ITextNode"/> hierarchy
	/// representing EDIHL7 data.
	/// </summary>
	public class EDIHL7DataCompletion : DataCompletion
	{
		#region Implementation Detail:
		private EDIHL7Settings mSettings = null;
		#endregion

		#region Public Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="document">textdocument to complete</param>
		/// <param name="settings">the settings to use</param>
		/// <param name="structurename">the name of the EDIHL7 structure which will be completed with this instance</param>
		public EDIHL7DataCompletion(TextDocument document, EDIHL7Settings settings, string structurename)
			: base(document, structurename)
		{
			mSettings = settings;
		}
		/// <summary>
		/// Completes/fills in missing data in a <see cref="ITextNode"/> hierarchy representing
		/// EDIHL7 data.
		/// </summary>
		/// <param name="dataroot">the root node of the hierarchy to complete</param>
		/// <param name="rootParticle">the structural root</param>
		public override void CompleteData(ITextNode dataroot, Particle rootParticle)
		{
			CompleteMandatory(dataroot,rootParticle);

			if (rootParticle.Node.Name == "GroupFHS") //batch format
			{
				CompleteDataGroupFHS(dataroot);
			}
			else
			{
				CompleteMSH( mSettings.MessageType, MakeSureExists(dataroot, "MSH"));
			}
		}
		#endregion

		#region Implementation Detail
		protected void CompleteDataGroupFHS(ITextNode gFHS)
		{
			if (HasKid(gFHS, "FTS"))
			{
				MakeSureExists(gFHS, "FHS");
			}
			if (HasKid(gFHS, "FHS"))
			{
				CompleteSegmentFHS(gFHS.Children.GetFirstNodeByName("FHS"));
				MakeSureExists(gFHS, "FTS");
			}

			CompleteGroupBHS(gFHS.Children.GetFirstNodeByName("GroupBHS"));

			if (HasKid(gFHS, "FTS"))
			{
				ITextNode fts = gFHS.Children.GetFirstNodeByName("FTS");
				ITextNode\[\] batchGroups = gFHS.Children.FilterByName("GroupBHS");
				ITextNode fts1 = MakeSureExists(fts, "FTS-1");
				fts1.Value = batchGroups.Length + "";
			}
		}

		protected void CompleteGroupBHS(ITextNode gBHS)
		{
			if( HasKid( gBHS, "BTS" ) )
			{
				MakeSureExists( gBHS, "BHS" );
			}
			if( HasKid( gBHS, "BHS" ) )
			{
				CompleteSegmentBHS( gBHS.Children.GetFirstNodeByName( "BHS" ) );
				MakeSureExists( gBHS, "BTS" );
			}

			ITextNode\[\] multimessages = null;
			foreach( string sMessageType in mDocument.MessageTypes) {
				multimessages = gBHS.Children.FilterByName("Message_" + sMessageType);
				foreach(ITextNode messageNode in multimessages) {
					CompleteMandatory(messageNode, mDocument.GetMessage(sMessageType).RootParticle);
					CompleteMSH(sMessageType, messageNode.Children.GetFirstNodeByName("MSH"));
				}
			}

			if( HasKid( gBHS, "BTS" ) )
			{
				int nMessages = multimessages != null ? multimessages.Length : 0;
				ITextNode bts = gBHS.Children.GetFirstNodeByName( "BTS" );
				ITextNode bts1 = MakeSureExists( bts, "BTS-1" );
				bts1.Value = nMessages + "";
			}
		}

		protected void CompleteSegmentFHS(ITextNode fhs)
		{
			//Data element separator
			ITextNode fhs1 = MakeSureExists(fhs, "FHS-1");
			//this value will be overwritten, it just needs to be set
			fhs1.Value = "-";

			//Encoding Characters
			ITextNode fhs2 = MakeSureExists(fhs, "FHS-2");
			//this value will be overwritten, it just needs to be set
			fhs2.Value = "#@!";

			//Date/Time of Message
			ITextNode fhs7 = MakeSureExists( fhs, "FHS-7");
			FillDateTime(fhs7);
		}

		protected void CompleteSegmentBHS(ITextNode bhs)
		{
			//Data element separator
			ITextNode bhs1 = MakeSureExists(bhs, "BHS-1");
			//this value will be overwritten, it just needs to be set
			bhs1.Value = "-";

			//Encoding Characters
			ITextNode bhs2 = MakeSureExists(bhs, "BHS-2");
			//this value will be overwritten, it just needs to be set
			bhs2.Value = "#@!";

			//Date/Time of Message
			ITextNode bhs7 = MakeSureExists( bhs, "BHS-7");
			FillDateTime(bhs7);
		}

		private void CompleteMSH(string sMessageType, ITextNode msh) {
			//MSH-1 Data element separator
			ITextNode msh1 = MakeSureExists( msh, "MSH-1");
			//this value will be overwritten, it just needs to be set
			ConservativeSetValue( msh1, "" + mSettings.ServiceChars.DataElementSeparator);

			//MSH-2 Encoding Characters
			ITextNode msh2 = MakeSureExists( msh, "MSH-2");
			//this value will be overwritten, it just needs to be set
			ConservativeSetValue(
					msh2,
					"" + mSettings.ServiceChars.ComponentSeparator +
					mSettings.ServiceChars.RepetitionSeparator +
					mSettings.ServiceChars.ReleaseCharacter +
					mSettings.ServiceChars.SubComponentSeparator
			);

			//MSH-7 Date/Time of Message
			ITextNode msh7 = MakeSureExists( msh, "MSH-7");
			FillDateTime(msh7);

			//MSH-9 Message Type
			ITextNode msh9 = MakeSureExists( msh, "MSH-9");
			CompleteMSG( sMessageType, msh9);

			//MSH-12 Version ID
			ITextNode msh12 = MakeSureExists( msh, "MSH-12");
			ITextNode vid1 = MakeSureExists( msh12 , "VID-1");
			ConservativeSetValue( vid1, mSettings.Release);
		}

		private void CompleteMSG( string sMessageType, ITextNode msg)
		{
			//the example MSG Type is: QBP_Z73
			string\[\] structure = sMessageType.Split('_');

			//Message Code: QBP
			ITextNode msg1 = MakeSureExists( msg, "MSG-1");
			ConservativeSetValue( msg1, structure\[0\]);

			//Trigger Event: Z73
			ITextNode msg2 = MakeSureExists( msg, "MSG-2");
			ConservativeSetValue( msg2, structure\[1\]);

			//Message Structure: QBP_Z73
			ITextNode msg3 = MakeSureExists( msg, "MSG-3");
			ConservativeSetValue( msg3, mStructureName);
		}

		private void FillDateTime(ITextNode dateField)
		{
			if( mSettings.Release == "2.6")
				ConservativeSetValue( dateField, GetCurrentDateAsEDIString(4) + GetCurrentTimeAsEDIString());
			else
			{
				ITextNode ts1 = MakeSureExists( dateField, "TS-1");
				ConservativeSetValue( ts1, GetCurrentDateAsEDIString(4) + GetCurrentTimeAsEDIString());
			}
		}
		#endregion
	}
}
