[call GenerateFileHeader("EDIHL7Settings.cs")]
namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates EDIHL7 specific settings
	/// </summary>
	public class EDIHL7Settings : EDISettings
	{
		#region Implementation Detail:
		#endregion
		#region Public Interface:
		public EDIHL7Settings () { mEDIStandard = EDIStandard.EDIHL7; }

		public const char cEscStartHighlight =			'H';
		public const char cEscNormalText =				'N';
		public const char cEscFieldSeparator =			'F';
		public const char cEscComponentSeparator =		'S';
		public const char cEscSubComponentSeparator = 	'T';
		public const char cEscRepetitionSeparator =		'R';
		public const char cEscEscapeSeparator =			'E';
		public const char cEscHexadecimalData =			'X';
		public const char cEscLocalEscapeSeq =			'Z';
		#endregion
	}
}