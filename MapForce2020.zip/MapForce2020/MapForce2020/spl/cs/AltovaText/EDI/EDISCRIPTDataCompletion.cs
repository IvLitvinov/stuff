[call GenerateFileHeader("EDISCRIPTDataCompletion.cs")]
using System;
using System.Globalization;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates auto completing data in a <see cref="ITextNode"/> hierarchy
	/// representing EDISCRIPT data.
	/// </summary>
	public class EDIScriptDataCompletion : DataCompletion
	{
		#region Implementation Detail:
		private EDIScriptSettings mSettings = null;
		#endregion

		#region Public Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="document">textdocument to complete</param>
		/// <param name="settings">the settings to use</param>
		/// <param name="structurename">the name of the EDISCRIPT structure which will be completed with this instance</param>
		public EDIScriptDataCompletion(TextDocument document, EDIScriptSettings settings, string structurename)
			: base(document, structurename)
		{
			mSettings = settings;
		}
		/// <summary>
		/// Completes/fills in missing data in a <see cref="ITextNode"/> hierarchy representing
		/// EDISCRIPT data.
		/// </summary>
		/// <param name="dataroot">the root node of the hierarchy to complete</param>
		/// <param name="rootParticle">the structural root</param>
		public override void CompleteData(ITextNode dataroot, Particle rootParticle)
		{
			CompleteMandatory(dataroot, rootParticle);
			CompleteEnvelope(dataroot, rootParticle);
		}
		#endregion
		
		#region Implementation Detail

		/// <summary>
		/// Completes envelope
		/// </summary>
		protected void CompleteEnvelope(ITextNode envelope, Particle rootParticle)
		{
			if (envelope.Name != rootParticle.Name)
				throw new MappingException("CompleteEnvelope: root node is not an envelope");
			
			Particle interchangeParticle = rootParticle.Node.Children\[0\];
			MakeSureExists(envelope, interchangeParticle.Name);

			ITextNode\[\] interchanges = envelope.Children.FilterByName(interchangeParticle.Name);
			for (int i=0; i< interchanges.Length; ++i)
				CompleteInterchange(interchanges\[i\], interchangeParticle);
		}

		/// <summary>
		/// Completes interchange
		/// </summary>
		protected void CompleteInterchange(ITextNode interchange, Particle interchangeParticle)
		{
			Particle interchangeHeader = interchangeParticle.GetFirstChildByName("UIB");
			Particle interchangeTrailer = interchangeParticle.GetFirstChildByName("UIZ");

			if (interchangeHeader != null && interchangeTrailer != null)
			{
				ITextNode header = interchange.Children.GetFirstNodeByName(interchangeHeader.Name);
				ITextNode trailer = interchange.Children.GetLastNodeByName(interchangeTrailer.Name);
				if (header != null || trailer != null)
				{
					header = MakeSureExists(interchange, interchangeHeader.Name);
					trailer = MakeSureExists(interchange, interchangeTrailer.Name);
				}

				foreach ( string sMessageType in mDocument.MessageTypes)
				{
					foreach (ITextNode node in interchange.Children.FilterByName("Message_" + sMessageType))
					{
						Particle messageParticle = mDocument.GetMessage(sMessageType).RootParticle;
						CompleteMandatory(node, messageParticle);
						CompleteMessage(sMessageType, node, messageParticle);
					}
				}

				if (header == null && trailer == null)
					return;

				CompleteInterchangeHeader(header, interchangeHeader);
				CompleteInterchangeTrailer(trailer, interchangeTrailer);
			}
		}

		/// <summary>
		/// Completes interchange header
		/// </summary>
		protected void CompleteInterchangeHeader(ITextNode header, Particle headerParticle)
		{
			ITextNode s001 = MakeSureExists(header, "S001");
			ITextNode s002 = MakeSureExists(header, "S002");
			ITextNode s003 = MakeSureExists(header, "S003");
			ITextNode s300 = MakeSureExists(header, "S300");

			CompleteS001(s001);
			CompleteS002(s002);
			CompleteS003(s003);
			CompleteS300(s300, headerParticle.GetFirstChildByName("S300"));

			if (headerParticle.GetFirstChildByName("S045") != null)
			{
				ITextNode s045 = MakeSureExists(header, "S045");
				CompleteS045(s045);
			}
		}

		/// <summary>
		/// Completes interchange trailer
		/// </summary>
		protected void CompleteInterchangeTrailer(ITextNode trailer, Particle trailerParticle)
		{
			ITextNode f0036 = MakeSureExists(trailer, "F0036");

			ConservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(trailer.Parent).ToString());
		}

		/// <summary>
		/// Completes Message
		/// </summary>
		protected void CompleteMessage(string sMessageType, ITextNode message, Particle messageParticle) 
		{
			Particle messageHeader = messageParticle.GetFirstChildByName("UIH");
			Particle messageTrailer = messageParticle.GetFirstChildByName("UIT");
			
			ITextNode header = MakeSureExists(message, messageHeader.Name);
			ITextNode trailer = MakeSureExists(message, messageTrailer.Name);

			CompleteMessageHeader(sMessageType, header, messageHeader);
			CompleteMessageTrailer(trailer, messageTrailer);
		}

		/// <summary>
		/// Completes Message header
		/// </summary>
		protected void CompleteMessageHeader(string sMessageType, ITextNode header, Particle headerParticle) 
		{
			ITextNode f0062 = MakeSureExists(header, "F0062");
			ITextNode s306 = MakeSureExists(header, "S306");
			ITextNode s300 = MakeSureExists(header, "S300");

			string referenceNumber = header.Parent.Children.FilterByName("UIT")\[0\].Value;
			if (referenceNumber.Length == 0)
				referenceNumber = "0";
			ConservativeSetValue(f0062, referenceNumber);
			CompleteS306(sMessageType, s306);
			CompleteS300(s300, headerParticle.GetFirstChildByName("S300"));
		}

		/// <summary>
		/// Completes message trailer
		/// </summary>
		protected void CompleteMessageTrailer(ITextNode trailer, Particle trailerParticle) 
		{
			ITextNode f0062 = MakeSureExists(trailer, "F0062");
			ITextNode f0074 = MakeSureExists(trailer, "F0074");

			ConservativeSetValue(f0062, trailer.Parent.Children.FilterByName("UIH")\[0\].Children.FilterByName("F0062")\[0\].Value.ToString());
			ConservativeSetValue(f0074, GetSegmentChildrenCount(trailer.Parent).ToString());
		}

		/// <summary>
		/// Completes S001 segment
		/// </summary>
		protected void CompleteS001(ITextNode s001)
		{
			ITextNode f0001 = MakeSureExists(s001, "F0001");
			ITextNode f0002 = MakeSureExists(s001, "F0002");

			ConservativeSetValue(f0001, mSettings.ControllingAgency + mSettings.SyntaxLevel);
			ConservativeSetValue(f0002, mSettings.SyntaxVersionNumber.ToString());
		}

		/// <summary>
		/// Completes S004 segment
		/// </summary>
		protected void CompleteS002(ITextNode s002) {
			ITextNode f0004 = MakeSureExists(s002, "F0004");
			ConservativeSetValue(f0004, "Sender");
		}
		
		/// <summary>
		/// Completes S003 segment
		/// </summary>
		protected void CompleteS003(ITextNode s003) {
			ITextNode f0010 = MakeSureExists(s003, "F0010");
			ConservativeSetValue(f0010, "Recipient");
		}
		
		/// <summary>
		/// Completes S045 segment
		/// </summary>
		protected void CompleteS045(ITextNode s045) {
			ITextNode f8006 = MakeSureExists(s045, "F8006");
			ITextNode f8007 = MakeSureExists(s045, "F8007");
			ITextNode f8008 = MakeSureExists(s045, "F8008");
			ConservativeSetValue(f8006, "Altova GmbH");
			ConservativeSetValue(f8007, "[=$HostShort]");
			ConservativeSetValue(f8008, "[=$HostVersionName]");
		}
		
		/// <summary>
		/// Completes S300 segment
		/// </summary>
		protected void CompleteS300(ITextNode s300, Particle particle)
		{
			Particle timeField = particle.GetFirstChildByName("F0114") ?? particle.GetFirstChildByName("F0314");
			ITextNode date = MakeSureExists(s300, "F0017");
			ITextNode time = MakeSureExists(s300, timeField.Name);

			ConservativeSetValue(date, DateTime.Now.ToString("yyyyMMdd"));
			ConservativeSetValue(time, DateTime.Now.ToString("HHmmss"));
		}

		/// <summary>
		/// Completes S306 segment
		/// </summary>
		protected void CompleteS306(string sMessageType, ITextNode s306)
		{
			ITextNode f0329 = MakeSureExists(s306, "F0329");
			ITextNode f0316 = MakeSureExists(s306, "F0316");
			ITextNode f0318 = MakeSureExists(s306, "F0318");
			ITextNode f0326 = MakeSureExists(s306, "F0326");
			
			ConservativeSetValue(f0329, "SCRIPT");
			ConservativeSetValue(f0316, mSettings.Version);
			ConservativeSetValue(f0318, mSettings.Release);
			ConservativeSetValue(f0326, sMessageType);
		}

		/// <summary>
		/// Returns number of messages or groups 
		/// </summary>
		long GetNumberOfFunctionGroupsOrMessages(ITextNode node)
		{
			int nUIH =0;
			int nUIT =0;

			foreach (string sMessageType in mDocument.MessageTypes)
			{
				foreach (ITextNode messageNode in node.Children.FilterByName("Message_" + sMessageType))
				{
					nUIH += messageNode.Children.FilterByName("UIH").Length;
					nUIT += messageNode.Children.FilterByName("UIT").Length;
				}
			}

			foreach (ITextNode messageNode in node.Children.FilterByName("Message"))
			{
				nUIH += messageNode.Children.FilterByName("UIH").Length;
				nUIT += messageNode.Children.FilterByName("UIT").Length;
			}
			
			if (nUIH != nUIT)
				throw new MappingException("Message header-trailer mismatch");

			return nUIH;
		}
		#endregion
	}
}