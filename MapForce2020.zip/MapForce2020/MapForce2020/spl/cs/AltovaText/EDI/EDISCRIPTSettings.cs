[call GenerateFileHeader("EDISCRIPTSettings.cs")]
namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates NCPDP SCRIPT specific settings
	/// </summary>
	public class EDIScriptSettings : EDIFactSettings
	{
		#region Implementation Detail:
		#endregion
		#region Public Interface:
		
		public EDIScriptSettings () 
		{
			mEDIStandard = EDIStandard.EDISCRIPT;
			mControllingAgency = "UNO";
			SyntaxVersionNumber = 0;
		}
		
		#endregion
	}
}