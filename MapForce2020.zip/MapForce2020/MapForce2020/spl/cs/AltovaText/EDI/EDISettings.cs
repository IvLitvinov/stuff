[call GenerateFileHeader("EDISettings.cs")]
namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates all settings relevant for exporting to EDI files in general.
	/// </summary>
	public class EDISettings
	{
		#region Implementation Detail:
		ServiceChars mServiceChars = new ServiceChars();
		bool mTerminateSegmentsWithLinefeed = false;
		bool mAutoCompleteData = true;
		int mLineEnd = 0;
		protected string mRelease = "";
		protected string mVersion = "";
		protected EDIStandard mEDIStandard = EDIStandard.Unknown;
		protected string mControllingAgency = "";
		string mMessageType = "";
		#endregion	
		
		#region Public Interface:	
		/// <summary>
		/// Get/sets whether an extra linefeed should be used to terminate segments for better readability.
		/// </summary>
		public bool TerminateSegmentsWithLinefeed
		{
			get
			{
				return mTerminateSegmentsWithLinefeed;
			}
			set
			{
				mTerminateSegmentsWithLinefeed = value;
			}
		}
		/// <summary>
		/// Get/sets whether auto completion of data should be used.
		/// </summary>
		public bool AutoCompleteData
		{
			get
			{
				return mAutoCompleteData;
			}
			set
			{
				mAutoCompleteData = value;
			}
		}
		/// <summary>
		/// Get/sets line end mode.
		/// </summary>
		public int LineEnd
		{
			get
			{
				return mLineEnd;
			}
			set
			{
				mLineEnd = value;
			}
		}
		/// <summary>
		/// Get the service string advice to be used.
		/// </summary>
		public ServiceChars ServiceChars
		{
			get
			{
				return mServiceChars;
			}
		}
		/// <summary>
		/// Gets or sets the version.
		/// </summary>
		public string Version
		{
			get
			{
				return mVersion;
			}
			set
			{
				mVersion = value;
			}
		}
		/// <summary>
		/// Gets or sets the release.
		/// </summary>
		public string Release
		{
			get
			{
				return mRelease;
			}
			set
			{
				mRelease = value;
			}
		}
		
		/// <summary>
		/// Get/sets the controlling agency.
		/// </summary>
		public string ControllingAgency
		{
			get
			{
				return mControllingAgency;
			}
			set
			{
				mControllingAgency = value;
			}
		}		
		
		/// <summary>
		/// Gets the EDIStanard of the Parser.
		/// </summary>
		public EDIStandard Standard { 
			get 
			{ 
				return mEDIStandard; 
			}
			set 
			{ 
				mEDIStandard = value; 
			} 
		}
		
		/// <summary>
		/// Get/sets the MessageType.
		/// </summary>
		public string MessageType
		{
			get
			{
				return mMessageType;
			}
			set
			{
				mMessageType = value;
			}
		}		
		#endregion
	}
}
