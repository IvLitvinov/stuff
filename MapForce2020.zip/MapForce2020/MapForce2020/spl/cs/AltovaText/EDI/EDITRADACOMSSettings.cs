[call GenerateFileHeader("EDITRADACOMSSettings.cs")]
namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates EDITRADACOMS specific settings
	/// </summary>
	public class EDITradacomsSettings : EDISettings
	{
		#region Implementation Detail:
		#endregion
		#region Public Interface:
		
		public EDITradacomsSettings () 
		{
			mEDIStandard = EDIStandard.EDITRADACOMS;
			mControllingAgency = "BIC";
			
		}
		
		#endregion
	}
}