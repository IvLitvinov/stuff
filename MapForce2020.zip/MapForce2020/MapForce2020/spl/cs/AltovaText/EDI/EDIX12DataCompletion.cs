[call GenerateFileHeader("EDIX12DataCompletion.cs")]
using System.Globalization;
using System;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates auto completing data in a <see cref="ITextNode"/> hierarchy
	/// representing EDIX12 data.
	/// </summary>
	public class EDIX12DataCompletion : DataCompletion
	{
		private int mHLSegmentCounter = 0;

		#region Public interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="document">textdocument to complete</param>
		/// <param name="settings">the settings to use</param>
		/// <param name="structurename">the name of the structure this instance will complete</param>
		public EDIX12DataCompletion(TextDocument document, EDIX12Settings settings, string structurename)
			: base(document, structurename)
		{
			mSettings = settings;
		}
		#endregion
		
		#region Implementing DataCompletion:
		/// <summary>
		/// Completes the hierarchy of nodes rooted in the passed node.
		/// </summary>
		/// <param name="dataroot">the root of the nodes to be completed</param>
		/// <param name="rootParticle">the root of the structure definition</param>
		public override void CompleteData(ITextNode dataroot, Particle rootParticle)
		{
			CompleteMandatory(dataroot,rootParticle);
			CompleteEnvelope( dataroot);
		}
		#endregion

		#region Implementation detail:
		EDIX12Settings mSettings = null;
		ITextNode mGroupRoot= null;


		void CompleteEnvelope(ITextNode envelope)
		{
			MakeSureExists( envelope, "Interchange");
			
			foreach (ITextNode interchange in envelope.Children.FilterByName("Interchange"))
				CompleteInterchange( interchange);
		}

		void CompleteInterchange(ITextNode node)
		{
			MakeSureExists(node, "ISA");
			mGroupRoot = MakeSureExists(node, "Group");
			MakeSureExists(node, "IEA");
			
			ITextNode isa = GetKid(node, "ISA");
			ITextNode iea = GetKid(node, "IEA");
			
			ITextNode FI01 = MakeSureExists(isa, "FI01");
			ConservativeSetValue(FI01, "00");
			ITextNode FI02 = MakeSureExists(isa, "FI02");
			ConservativeSetValue(FI02, "          ");
			ITextNode FI03 = MakeSureExists(isa, "FI03");
			ConservativeSetValue(FI03, "00");
			ITextNode FI04 = MakeSureExists(isa, "FI04");
			ConservativeSetValue(FI04, "          ");
			ITextNode FI05_1 = MakeSureExists(isa, "FI05_1");
			ConservativeSetValue(FI05_1, "ZZ");
			ITextNode FI05_2 = MakeSureExists(isa, "FI05_2");
			ConservativeSetValue(FI05_2, "ZZ");
			ITextNode FI08 = MakeSureExists(isa, "FI08");
			ConservativeSetValue(FI08, DateTime.Now.ToString("yyyyMMdd"));
			ITextNode FI09 = MakeSureExists(isa, "FI09");
			ConservativeSetValue(FI09, GetCurrentTimeAsEDIString());

			if( IsOldISAVersion() )
			{
				MakeSureExists(isa, "FI10");
			}
			else 
			{
				ITextNode FI65 = MakeSureExists(isa, "FI65");
				ConservativeSetValue(FI65, mSettings.ServiceChars.RepetitionSeparator.ToString(CultureInfo.InvariantCulture));
			}
			ITextNode FI11 = MakeSureExists(isa, "FI11");
			ConservativeSetValue(FI11, mSettings.InterchangeControlVersionNumber);
			ITextNode FI12 = MakeSureExists(isa, "FI12");
			ConservativeSetValue(FI12, "000000000");
			ITextNode FI13 = MakeSureExists(isa, "FI13");
			ConservativeSetValue(FI13, mSettings.RequestAcknowledgement ? "1" : "0");
			ITextNode FI14 = MakeSureExists(isa, "FI14");
			ConservativeSetValue(FI14, "P");
			ITextNode FI15 = MakeSureExists(isa, "FI15");
			ConservativeSetValue(FI15, mSettings.ServiceChars.ComponentSeparator.ToString(CultureInfo.InvariantCulture));

			foreach (ITextNode group in node.Children.FilterByName("Group"))
			{
				mGroupRoot= group;
				MakeSureExists(mGroupRoot, "GS");
				MakeSureExists(mGroupRoot, "GE");
				CompleteGroup();
			}

			ITextNode IEAFI16 = MakeSureExists(iea, "FI16");
			ConservativeSetValue(IEAFI16, node.Children.FilterByName("Group").Length.ToString(CultureInfo.InvariantCulture));
			ITextNode IEAFI12 = MakeSureExists(iea, "FI12");
			ConservativeSetValue(IEAFI12, FI12.Value.Trim());
		}
		void CompleteGroup()
		{
			int nMessageCount = 0;
			foreach (string sMessageType in mDocument.MessageTypes)
			{
				foreach (ITextNode messageNode in mGroupRoot.Children.FilterByName("Message_" + sMessageType))
				{
					MakeSureExists(messageNode, "ST");
					MakeSureExists(messageNode, "SE");
					CompleteMandatory(messageNode, mDocument.GetMessage(sMessageType).RootParticle);
					CompleteMessage(mDocument.GetMessage(sMessageType), messageNode);
					nMessageCount++;
				}
			}

			foreach (ITextNode message in mGroupRoot.Children.FilterByName("Message"))
			{
				MakeSureExists(message, "ST");
				MakeSureExists(message, "SE");
				CompleteMessage(mDocument.GetMessage(mSettings.MessageType), message);
				nMessageCount++;
			}

			ITextNode GS = GetKid(mGroupRoot, "GS");
			if (GS != null)
			{
				ITextNode GE = GetKid(mGroupRoot, "GE");
				ITextNode GSF373 = MakeSureExists(GS, "F373");
				ConservativeSetValue(GSF373, DateTime.Now.ToString("yyyyMMdd"));
				ITextNode GSF337 = MakeSureExists(GS, "F337");
				ConservativeSetValue(GSF337, GetCurrentTimeAsEDIString());
				ITextNode GSF28 = GetKid(GS, "F28");
				ITextNode GEF97 = MakeSureExists(GE, "F97");
				ConservativeSetValue(GEF97, nMessageCount + "");
				if (GSF28 != null)
				{
					ITextNode GEF28 = MakeSureExists(GE, "F28");
					ConservativeSetValue(GEF28, GSF28.Value);
				}
			}
		}
		void CompleteMessage(Message message, ITextNode messageNode)
		{
			string sMessageType = message.MessageType;

			ITextNode ST = MakeSureExists(messageNode, "ST");
			ITextNode SE = MakeSureExists(messageNode, "SE");
			ITextNode STF143 = MakeSureExists(ST, "F143");
			ConservativeSetValue(STF143, sMessageType.Substring(0, 3));
			ITextNode SEF96 = MakeSureExists(SE, "F96");
			long segmentcount = GetSegmentChildrenCount(ST.Parent);
			ConservativeSetValue(SEF96, segmentcount.ToString());
			ITextNode STF329 = MakeSureExists(ST, "F329");
			ITextNode SEF329 = MakeSureExists(SE, "F329");
			ConservativeSetValue(SEF329, STF329.Value);

			mHLSegmentCounter = 0;
			if (message.ShouldCompleteHLSegments)
				CompleteHLSegments(messageNode, 0, message.RootParticle);

			if (message.ShouldCompleteSingleConditions || message.ShouldCompleteSingleValues)
			{
				mCompleteSingleValues = message.ShouldCompleteSingleValues;
				CompleteConditionsAndValues(messageNode, message.RootParticle);
			}
		}

		bool CompleteHLSegments(ITextNode group, int parent, Particle particle)
		{
			bool hasChildren = false;

			ITextNode hl = group.Children.GetFirstNodeByName("HL");
			Particle hlParticle = GetParticleByPath(particle, "HL");

			if (hl != null)
			{
				// set parent and ID
				ITextNode hlID = MakeSureExists(hl, "F628");
				hlID.Value = (++mHLSegmentCounter).ToString();
				if (parent != 0)
				{
					ITextNode hlParentID = MakeSureExists(hl, "F734");
					hlParentID.Value = parent.ToString();
				}
			}

			parent = mHLSegmentCounter;

			foreach(ITextNode node in group.Children)
			{
				if (node.Class == NodeClass.Group)
				{
					Particle p = GetParticleByPath(particle, node.Name);
					hasChildren = CompleteHLSegments(node, parent, p);
				}
			}

			if (hl != null)
			{
				Particle p_F736 = GetParticleByPath(hlParticle, "F736");

				if (p_F736.MinOccurs > 0)
				{
					// Set has children flag
					ITextNode hlChildCode = MakeSureExists(hl, "F736");
					hlChildCode.Value = hasChildren ? "1" : "0";
				}
				return true;
			}

			return hasChildren;
		}

		bool IsOldISAVersion()
		{
			return mSettings.Release == "3040" ||
				mSettings.Release == "3050" ||
				mSettings.Release == "3060" ||
				mSettings.Release == "3070" ||
				mSettings.Release == "4010";
		}
		#endregion
	}
}
