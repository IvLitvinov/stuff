[call GenerateFileHeader("ErrorMessages.cs")]
using System;
using System.Text;

namespace Altova.TextParser.EDI
{
	public class ErrorMessages {
		public static String GetMissingSegmentMessage(String sSegment)
		{
			return "Missing segment '" + sSegment + "'.";
		}

		public static String GetMissingGroupMessage(String sGroup)
		{
			return "Missing group '" + sGroup + "'.";
		}

		public static String GetMissingFieldOrCompositeMessage(String sField)
		{
			return "Missing field or composite '" + sField + "'.";
		}

		public static String GetExtraDataMessage(String sNodeName, String sExtra)
		{
			return "Extra content detected in '" + sNodeName + "': '" + sExtra + "'";
		}

		public static String GetInvalidFieldValueMessage(String sNodeName, String sValue, String sType)
		{
			return "Type mismatch in field '" + sNodeName + "'. The value '" + sValue + "' is not of type '" + sType + "'";
		}

		public static String GetInvalidDateMessage( String sNodeName, String sValue, String sType)
		{
			return GetInvalidFieldValueMessage( sNodeName, sValue, sType);
		}

		public static String GetInvalidTimeMessage( String sNodeName, String sValue, String sType)
		{
			return GetInvalidFieldValueMessage( sNodeName, sValue, sType);
		}

		public static String GetExtraRepeatMessage( String sNodeName)
		{
			return "Extra repetition of '" + sNodeName + "'";
		}

		public static String GetNumericOverflowMessage( String sNodeName, String sValue)
		{
			return "Numeric overflow in field '" + sNodeName + "' with value: '" + sValue + "'";
		}

		public static String GetDataElementTooShortMessage( String sNodeName, long nMinLength, String sValue)
		{
			return "The content of '" + sNodeName 
				+ "' is shorter than the minimum length of " 
				+ nMinLength + " characters: '" + sValue + "'";
		}

		public static String GetDataElementTooLongMessage( String sNodeName, long nMaxLength, String sValue)
		{
			return "The content of '" + sNodeName 
				+ "' is longer than the maximum length of " 
				+ nMaxLength + " characters: '" + sValue + "'";
		}

		public static String GetUnexpectedEndOfFileMessage( )
		{
			return "Unexpected end of file";
		}

		public static String GetInvalidCodeListValueMessage( String sValue, String sItemList)
		{
			return "'" + sValue + "' is not a legal value. Legal values are: " + sItemList + ".";
		}
		
		public static String GetIncompleteCodeListValueMessage( String sValue, String sItemList)
		{
			return "'" + sValue + "' is not in code list but code list is incomplete. Legal values are: " + sItemList + ".";
		}
		
		public static String GetUnexpectedSegmentIDMessage( String sSegment)
		{
			return "Segment '" + sSegment + "' is unexpected.";
		}
		
		public static String GetUnrecognizedSegmentMessage(String sSegment)
		{
			return "Segment '" + sSegment + "' is unrecognized.";
		}
		
		public static String GetTextNotParsedMessage( String sText)
		{
			return "The following text was not parsed: '" + sText + "'";
		}
		
		public static String GetNotUsedPresent(String sText)
		{
			return "Implementation \\"Not Used\\" data element present: '" + sText + "'";
		}
	}
}
