[call GenerateFileHeader("Message.cs")]

using System.Collections;

namespace Altova.TextParser.EDI
{

public class Message
{
	private Hashtable mSegments = null;
	private string mMessageType;
	private Particle mRootParticle;
	bool mShouldCompleteSingleConditions = false;
	bool mShouldCompleteSingleValues = false;
	bool mShouldCompleteHLSegments = false;

	public Message(string sMessageType, Particle rootParticle, Hashtable segments, int completeHL, int completeSingleValues, int completeSingleConditions)
	{
		mMessageType = sMessageType;
		mSegments = segments;
		mRootParticle = rootParticle;
		mShouldCompleteHLSegments = completeHL == 1;
		mShouldCompleteSingleConditions = completeSingleConditions == 1;
		mShouldCompleteSingleValues = completeSingleValues == 1;
	}

	public Particle RootParticle
	{
		get { return mRootParticle; }
	}

	public string MessageType
	{
		get { return mMessageType; }
	}

	public bool HasSegment( string sSegmentName )
	{
		return mSegments.ContainsKey(sSegmentName);
	}

	public bool ShouldCompleteSingleConditions
	{
		get { return mShouldCompleteSingleConditions; }
	}

	public bool ShouldCompleteSingleValues
	{
		get { return mShouldCompleteSingleValues; }
	}

	public bool ShouldCompleteHLSegments
	{
		get { return mShouldCompleteHLSegments; }
	}
}

}
