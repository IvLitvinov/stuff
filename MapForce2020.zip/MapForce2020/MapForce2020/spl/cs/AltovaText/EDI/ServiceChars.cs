[call GenerateFileHeader("ServiceStringAdvice.cs")]
using System;
using System.IO;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Identification for individual service characters.
	/// </summary>
	public enum ServiceChar
	{
		/// <summary>
		/// No or invalid service character (default value).
		/// </summary>
		None,

		/// <summary>
		/// The component separator character.
		/// </summary>
		ComponentSeparator,

		/// <summary>
		/// The data element separator character.
		/// </summary>
		DataElementSeparator,

		/// <summary>
		/// The decimal mark.
		/// </summary>
		DecimalMark,

		/// <summary>
		/// The release character.
		/// </summary>
		ReleaseCharacter,

		/// <summary>
		/// The repetition separator.
		/// </summary>
		RepetitionSeparator,

		/// <summary>
		/// The segment tag separator.
		/// </summary>
		SegmentSeparator,

		/// <summary>
		/// The segment terminator.
		/// </summary>
		SegmentTerminator,

		/// <summary>
		/// The subcomponent separator character.
		/// </summary>
		SubComponentSeparator,
	}

	/// <summary>
	/// Encapsulates a service string advice (UNA) segment.
	/// </summary>
	public class ServiceChars
	{
		#region Implementation Detail:
		char mComponentSeparator = ':';
		char mDataElementSeparator = '+';
		char mSegmentSeparator = '+';
		char mSegmentTerminator = '\\'';
		char mRepetitionSeparator = '*';
		char mReleaseCharacter = '?';
		char mDecimalSeparator = '.';
		char mSubComponentSeparator = '&';
		#endregion
		#region Public Interface:
		/// <summary>
		/// Get/sets the composite data element separator.
		/// </summary>
		public char ComponentSeparator
		{
			get
			{
				return mComponentSeparator;
			}
			set
			{
				mComponentSeparator = value;
			}
		}
		/// <summary>
		/// Get/sets the data element separator.
		/// </summary>
		public char DataElementSeparator
		{
			get
			{
				return mDataElementSeparator;
			}
			set
			{
				mDataElementSeparator = value;
			}
		}
		/// <summary>
		/// Get/sets the segment tag separator.
		/// </summary>
		public char SegmentSeparator
		{
			get
			{
				return mSegmentSeparator;
			}
			set
			{
				mSegmentSeparator = value;
			}
		}
		/// <summary>
		/// Get/sets the segment terminator.
		/// </summary>
		public char SegmentTerminator
		{
			get
			{
				return mSegmentTerminator;
			}
			set
			{
				mSegmentTerminator = value;
			}
		}
		/// <summary>
		/// Get/sets the release character.
		/// </summary>
		public char ReleaseCharacter
		{
			get
			{
				return mReleaseCharacter;
			}
			set
			{
				mReleaseCharacter = value;
			}
		}
		/// <summary>
		/// Get/sets the decimal separator.
		/// </summary>
		public char DecimalSeparator
		{
			get
			{
				return mDecimalSeparator;
			}
			set
			{
				mDecimalSeparator = value;
			}
		}

		/// <summary>
		/// Gets/sets the repetition separator.
		/// </summary>
		public char RepetitionSeparator
		{
			get 
			{
				return mRepetitionSeparator;
			}
			set 
			{
				mRepetitionSeparator = value;
			}
		}

		/// <summary>
		/// Get/sets the subcomposite data element separator.
		/// </summary>
		public char SubComponentSeparator
		{
			get
			{
				return mSubComponentSeparator;
			}
			set
			{
				mSubComponentSeparator = value;
			}
		}

		/// <summary>
		/// Gets a service char by enum value.
		/// </summary>
		/// <param name="serviceChar"></param>
		/// <returns></returns>
		public char GetServiceChar (ServiceChar serviceChar) 
		{
			switch (serviceChar)
			{
				case ServiceChar.ComponentSeparator: return ComponentSeparator;
				case ServiceChar.DataElementSeparator: return DataElementSeparator;
				case ServiceChar.DecimalMark: return DecimalSeparator;
				case ServiceChar.ReleaseCharacter: return ReleaseCharacter;
				case ServiceChar.RepetitionSeparator: return RepetitionSeparator;
				case ServiceChar.SegmentSeparator: return SegmentSeparator;
				case ServiceChar.SegmentTerminator: return SegmentTerminator;
				case ServiceChar.SubComponentSeparator: return SubComponentSeparator;
				default: throw new ArgumentException ("Not a valid service character.");
			}
		}

		/// <summary>
		/// Sets a service char by enum value.
		/// </summary>
		/// <param name="serviceChar"></param>
		/// <param name="value"></param>
		public void SetServiceChar (ServiceChar serviceChar, char value)
		{
			switch (serviceChar)
			{
				case ServiceChar.ComponentSeparator: ComponentSeparator = value; break;
				case ServiceChar.DataElementSeparator: DataElementSeparator = value; break;
				case ServiceChar.DecimalMark: DecimalSeparator = value; break;
				case ServiceChar.ReleaseCharacter: ReleaseCharacter = value; break;
				case ServiceChar.RepetitionSeparator: RepetitionSeparator = value; break;
				case ServiceChar.SegmentSeparator: SegmentSeparator = value; break;
				case ServiceChar.SegmentTerminator: SegmentTerminator = value; break;
				case ServiceChar.SubComponentSeparator: SubComponentSeparator = value; break;
				default: throw new ArgumentException ("Not a valid service character.");
			}
		}


		/// <summary>
		/// Sets all members from a character array.
		/// </summary>
		/// <param name="rhs">the character array to set from</param>
		public void SetFromCharArray(char\[\] rhs)
		{
			mComponentSeparator = rhs\[0\];
			mDataElementSeparator = rhs\[1\];
			mSegmentSeparator = rhs\[1\];
			mDecimalSeparator = rhs\[2\];
			mReleaseCharacter = rhs\[3\];
			mRepetitionSeparator = rhs\[4\];
			mSegmentTerminator = rhs\[5\];
			mSubComponentSeparator = rhs\[6\];
		}
		/// <summary>
		/// Serializes this instance in EDIFact format to a stream.
		/// </summary>
		/// <param name="stream">the stream to serialize to</param>
		public int Serialize(TextWriter stream)
		{
			System.Text.StringBuilder sbOut = new System.Text.StringBuilder();
			sbOut.Append("UNA");
			sbOut.Append(mComponentSeparator);
			sbOut.Append(mDataElementSeparator);
			sbOut.Append(mDecimalSeparator);
			if( mReleaseCharacter != '\\0' )
				sbOut.Append(mReleaseCharacter);
			else
				sbOut.Append( ' ');
			if( mRepetitionSeparator != '\\0' )
				sbOut.Append(mRepetitionSeparator);
			else
				sbOut.Append( ' ');
			sbOut.Append(mSegmentTerminator);
			stream.Write(sbOut);
			return sbOut.Length;
		}
		#endregion
	}
}