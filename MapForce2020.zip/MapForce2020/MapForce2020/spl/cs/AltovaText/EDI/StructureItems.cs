[call GenerateFileHeader("StructureItems.cs")]
using System;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Represents a structural entity in an EDI file.
	/// </summary>
	public abstract class StructureItem
	{
		/// <summary>
		/// The node class of the structure item.
		/// </summary>
		protected NodeClass mNodeClass;

		/// <summary>
		/// The name of the structure item.
		/// </summary>
		protected string mName;

		/// <summary>
		/// The particles linking to children.
		/// </summary>
		protected Particle\[\] mChildren;

		/// <summary>
		/// Condition path
		/// </summary>
		protected string mConditionPath;

		/// <summary>
		/// Condition value (if embedded)
		/// </summary>
		protected string mConditionValue;

		/// <summary>
		/// Get condition path
		/// </summary>
		public string ConditionPath { get { return mConditionPath; } }

		/// <summary>
		/// Get condition value
		/// </summary>
		public string ConditionValue { get { return mConditionValue; } }

		/// <summary>
		/// Gets the node class of this node.
		/// </summary>
		public NodeClass NodeClass { get { return mNodeClass; } }

		/// <summary>
		/// Gets the current EDI Kind.
		/// </summary>
		public EDIStandard Standard
		{
			get { return EDIStandard.Unknown; }
		}

		/// <summary>
		/// Writes all children of the current node in the current context.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		/// <param name="separator"></param>
		protected void WriteChildren (Writer writer, ITextNode node, ServiceChar separator)
		{
			foreach (Particle particle in mChildren)
			{
				int toWrite = particle.MergedEntries;
				ServiceChar repSeparator = separator;
				if (particle.MaxOccurs > 1 || NodeClass == NodeClass.Group)
				{
					toWrite = int.MaxValue;

					if (NodeClass == NodeClass.Segment)
					{
						repSeparator = ServiceChar.RepetitionSeparator;
						if (writer.ServiceChars.RepetitionSeparator == '\\0')
							toWrite = 1;
						if (writer.EDIKind == EDIStandard.EDIFixed)
							toWrite = 1;
					}
				}

				
				ITextNode\[\] children = (node != null) ? node.Children.FilterByName(particle.NameOverride) : new ITextNode\[0\];
				
				if( children.Length > Math.Max( 
					particle.MaxOccurs, 
					particle.MergedEntries) )
				{
					writer.HandleError(node, ParserError.ExtraRepeat, ErrorMessages.GetExtraRepeatMessage(particle.Name));
				}
				
				for (int count = 0; count < toWrite; ++count)
				{
					if (count < children.Length)
					{
						particle.Node.Write(writer, children\[count\], particle);
					}
					else 
					{
						if (writer.EDIKind == EDIStandard.EDIFixed && NodeClass == NodeClass.Segment)
							particle.Node.Write(writer, node, particle);

						// selects name doesn't match the generator tree, so always write them.
						if (particle.Node.NodeClass == NodeClass.Select)
						{
							particle.Node.Write(writer, node, particle);
							break;
						}

						if (count < particle.MinOccurs)
						{
							if ( NodeClass == NodeClass.Group && particle.Name == "Message" )
							{
								//report error/warning
								writer.HandleError(node, ParserError.MissingGroup,
									ErrorMessages.GetMissingGroupMessage(particle.Name)
								);
							}
							else
							{
								//report error/warning
								writer.HandleError(node, ParserError.MissingFieldOrComposite,
									ErrorMessages.GetMissingFieldOrCompositeMessage(particle.Name)
								);
							}

							if (NodeClass == NodeClass.Group && particle.Name != "Message")
								particle.Node.Write(writer, node, particle);
						}
						else if (count >= particle.MergedEntries)
							break;
					}

					if( !(writer.EDIKind == EDIStandard.EDIHL7
						&& IsHL7SpecialField( particle.Name, "-1")))
						writer.AddSeparator(repSeparator);
				}
				
				if (separator != repSeparator)
				{
					writer.ClearPendingSeparators(repSeparator);
					writer.AddSeparator(separator);
				}
			}
			writer.ClearPendingSeparators(separator);
		}

		void HandleMissingSegmentOrGroup(Parser.Context context, Particle p)
		{
			if (context.Scanner.IsAtEnd)
			{
				context.HandleError(
					ParserError.UnexpectedEndOfFile,
					new ErrorPosition(context.Scanner),
					ErrorMessages.GetUnexpectedEndOfFileMessage()
				);
			}
			if (p.Node.NodeClass == NodeClass.Segment)
			{
				context.HandleError(
					ParserError.MissingSegment,
					new ErrorPosition(context.Scanner),
					ErrorMessages.GetMissingSegmentMessage(p.Name)
				);
			}
			else
				if (p.Node.NodeClass == NodeClass.Group)
				{
					context.HandleError(
						ParserError.MissingGroup,
						new ErrorPosition(context.Scanner),
						ErrorMessages.GetMissingGroupMessage(p.Name)
					);
				}
				else
					if (p.Node.NodeClass == NodeClass.Select)
					{
						context.HandleError(
							ParserError.MissingGroup,
							new ErrorPosition(context.Scanner),
							ErrorMessages.GetMissingGroupMessage("Message")
						);
					}
		}

		bool ParticlesEquivalent(int i_a, int i_b)
		{
			Particle a = mChildren\[i_a\];
			Particle b = mChildren\[i_b\];

			if (a.Node.NodeClass != b.Node.NodeClass)
				return false;

			if (a.Node.NodeClass == NodeClass.Segment)
				return a.Node.mName == b.Node.mName;

			if (a.Node.NodeClass == NodeClass.Group)
			{
				String s_a = a.Node.mName;
				String s_b = b.Node.mName;

				StringBuilder n_a = new StringBuilder();
				for (int i = 0; i < s_a.Length; i++)
					if (Char.IsDigit(s_a\[i\]))
						n_a.Append(s_a\[i\]);

				StringBuilder n_b = new StringBuilder();
				for (int i = 0; i < s_b.Length; i++)
					if (Char.IsDigit(s_b\[i\]))
						n_b.Append(s_b\[i\]);

				String ns_a = n_a.ToString();
				String ns_b = n_b.ToString();

				if (ns_a.Length > 0 && !ns_a.EndsWith("00") && ns_a == ns_b)
					return true;
			}
			return false;
		}

		bool IsRepeatingSequenceStarting(int it)
		{
			if (it == mChildren.Length)
				return false;

			if (it + 1 == mChildren.Length)
				return false;

			return ParticlesEquivalent(it, it + 1);
		}

		protected bool ReadChildren(Parser.Context context, ServiceChar separator)
		{
			if (NodeClass == NodeClass.Group)
				return ReadChildrenOfGroup(context, separator);
			else
				return ReadChildrenOfSegment(context, separator);
		}

		protected bool ReadChildrenOfGroup(Parser.Context context, ServiceChar separator)
		{
			Dictionary<Particle, int> readMap = new Dictionary<Particle, int>();
			Scanner scanner = context.Scanner;

			int it = 0;
			int repeatingStart = mChildren.Length;

			while (it != mChildren.Length)
			{
				if (repeatingStart != mChildren.Length)
				{
					if (ParticlesEquivalent(it, repeatingStart))
					{
						;
					}
					else
					{
						foreach ( Particle p in readMap.Keys )
						{
							Parser.Context ctx = new Parser.Context(context, p);
							
							if ( readMap\[p\] < p.MinOccurs )
							{
								HandleMissingSegmentOrGroup(ctx, p);
							}
						}
					
						repeatingStart = mChildren.Length;
						readMap.Clear();
					}
				}
		
				if(repeatingStart == mChildren.Length && IsRepeatingSequenceStarting(it))
				{
					repeatingStart = it;
				}
			
				bool inRepeatingSequence = repeatingStart != mChildren.Length;
			
				Particle currentParticle = mChildren\[it\];
				if (context.Parser.Settings.Standard == EDIStandard.EDIX12 && currentParticle.Node.NodeClass == NodeClass.Group)
				{
					if( it > 0 )
					{
						Particle precedingParticle = mChildren\[it-1\];

						if( precedingParticle.Node.NodeClass == NodeClass.Segment && precedingParticle.Name == "LS" )
							currentParticle.BoundedGroup = true;
					}
				}
				
				if (inRepeatingSequence && !readMap.ContainsKey(currentParticle))
					readMap\[currentParticle\] = 0;

				int toRead = currentParticle.MergedEntries;
				ServiceChar repSeparator = separator;
				if (toRead == 1) // no merged entry
				{
					toRead = currentParticle.RespectMaxOccurs ?
							currentParticle.MaxOccurs : // read only max occurs
							int.MaxValue; // try to read as much as possible -> errors are reported anyways

					if (currentParticle.MaxOccurs <= 1)
					{
						toRead = 1;
					}
				}

				Parser.Context childContext = new Parser.Context(context, currentParticle);

				bool advance = true;
				bool readSuccess = true;
				for (int count = 0; count < toRead; ++count)
				{
					childContext.Occurence = count + 1;
				
					Scanner.State preservedState = scanner.CurrentState;
				
					readSuccess = !scanner.IsAtEnd && currentParticle.Node.Read(childContext);
				
					if ( !readSuccess )
					{
						if ( count >= currentParticle.MinOccurs)
						{
							break; // read enough
						}
						if (context.Parser.Settings.Standard == EDIStandard.EDITRADACOMS && currentParticle.Node.NodeClass == NodeClass.Select)
						{
							return false; // select failed because it was not read, report upwards
						}
						
					
						if ( !inRepeatingSequence )
						{
							if ( count < currentParticle.MinOccurs)
							{
								scanner.CurrentState = preservedState;
								string sSeg = ReadSegmentTag(context);
								context.HandleError(
									ParserError.SegmentUnexpected,
									new ErrorPosition(context.Scanner),
									ErrorMessages.GetUnexpectedSegmentIDMessage(sSeg)
									);
							}
						}
					}

					int readSoFar = inRepeatingSequence ? readMap\[currentParticle\] : count;
					if (readSuccess && currentParticle.MergedEntries == 1 && readSoFar >= currentParticle.MaxOccurs)
					{
						childContext.HandleError(
									ParserError.ExtraRepeat,
									new ErrorPosition(preservedState),
									ErrorMessages.GetExtraRepeatMessage(currentParticle.Name)
								);
					}

					if (readSuccess)
					{
						advance = false;
						if (inRepeatingSequence)
							readMap\[currentParticle\] = readMap\[currentParticle\] + 1;
					}
				}

				if (inRepeatingSequence && !advance) // we are in repeating sequence
				{
					it = repeatingStart;
				}
				else
					++it;
			}

			return true;
		}

		/// <summary>
		/// Reads all children of the current node in the current context.
		/// </summary>
		/// <param name="context"></param>
		/// <param name="separator"></param>
		/// <returns></returns>
		protected bool ReadChildrenOfSegment (Parser.Context context, ServiceChar separator)
		{
			Scanner scanner = context.Scanner;

			for (int childIndex = 0; childIndex != ChildCount; ++childIndex)
			{
				Particle currentParticle = Children\[childIndex\];

				if (childIndex != 0 && separator != ServiceChar.None && scanner.IsAtSeparator(separator))
					scanner.RawConsumeChar();

				int toRead = currentParticle.MergedEntries;
				ServiceChar repSeparator = separator;
				if (toRead == 1) // no merged entry
				{
					toRead = currentParticle.RespectMaxOccurs ?
							currentParticle.MaxOccurs
						:	int.MaxValue; // try to read as much as possible -> errors are reported anyways
					if (NodeClass == NodeClass.Segment)
					{
						repSeparator = ServiceChar.RepetitionSeparator;
						if (scanner.ServiceChars.RepetitionSeparator == '\\0')
						{
							toRead = 1;
							repSeparator = ServiceChar.None;
						}
						else if(context.Parser.Settings.Standard == EDIStandard.EDIHL7
							&& IsHL7SpecialField(currentParticle.Name, "-1"))
						{
							toRead = 1;
							repSeparator = ServiceChar.None;
						}
						else
						{
							toRead = int.MaxValue;
						}
					}
					else if (currentParticle.MaxOccurs <= 1)
					{
						toRead = 1;
						repSeparator = ServiceChar.None;
					}
				}
				
				switch( context.Particle.Node.NodeClass )
				{
					case NodeClass.Segment: context.Parser.DataElementPosition++; break;
					case NodeClass.Composite: context.Parser.ComponentDataElementPosition++; break;
				}

				Parser.Context childContext = new Parser.Context(context, currentParticle);
				for (int count = 0; count < toRead && !scanner.IsAtEnd; ++count)
				{
					childContext.Occurence = count + 1;
					// consume the proper separator. otherwise the children won't find anything to read and fail anyways.
					if (count != 0 && repSeparator != ServiceChar.None)
					{
						if (scanner.IsAtSeparator(repSeparator))
							scanner.RawConsumeChar ();
						else
							break;
					}

					Scanner.State preservedState = scanner.CurrentState;
					bool readSuccess = currentParticle.Node.Read (childContext);

					if (!readSuccess && (repSeparator == ServiceChar.None || currentParticle.MinOccurs > 0))
					{
						//scanner.CurrentState = preservedState;
						if (count >= currentParticle.MinOccurs)
						{
							if (count >= currentParticle.MergedEntries)
								break; // enough read
						}
						else
						{
							if (currentParticle.Node.NodeClass == NodeClass.Segment)
							{
								childContext.HandleError (
									ParserError.MissingSegment,
									new ErrorPosition( preservedState),
									ErrorMessages.GetMissingSegmentMessage( currentParticle.Name )
								);
							}
							else
							if (currentParticle.Node.NodeClass == NodeClass.Group)
							{
								childContext.HandleError (
									ParserError.MissingGroup,
									new ErrorPosition( preservedState),
									ErrorMessages.GetMissingGroupMessage( currentParticle.Name )
								);
							}
							else
							if (currentParticle.Node.NodeClass == NodeClass.Select)
							{
								childContext.HandleError (
									ParserError.MissingGroup,
									new ErrorPosition( preservedState),
									ErrorMessages.GetMissingGroupMessage( "Message" )
								);
							}
							else
								childContext.HandleError (
									ParserError.MissingFieldOrComposite,
									new ErrorPosition( preservedState),
									ErrorMessages.GetMissingFieldOrCompositeMessage( currentParticle.Name )
								);
						}
					}

					if (currentParticle.MergedEntries == 1 && count >= currentParticle.MaxOccurs)
					{
						if ( currentParticle.MaxOccurs != 0 || readSuccess )
						{
							if (currentParticle.MaxOccurs == 0 && count == 0)
							{
								childContext.HandleError(
									ParserError.UsingNotUsed,
									new ErrorPosition(preservedState),
									ErrorMessages.GetNotUsedPresent(currentParticle.Name)
								);
							}
							else
							{
								childContext.HandleError (
									ParserError.ExtraRepeat,
									new ErrorPosition( preservedState),
									ErrorMessages.GetExtraRepeatMessage(currentParticle.Name)
								);
							}
						}
					}

					if (repSeparator != ServiceChar.None)
					{
						string sExtra = scanner.ConsumeString(repSeparator, true);
						if (sExtra.Length > 0)
							childContext.HandleError (
								ParserError.ExtraData,
								new ErrorPosition( preservedState),
								ErrorMessages.GetExtraDataMessage(currentParticle.Name, sExtra)
							);
					}

				}

			}

			return true;
		}

		/// <summary>
		/// Returns if the group this item stands for starts at the current position.
		/// </summary>
		/// <param name="context"></param>
		/// <returns></returns>
		protected bool IsAtGroup (Parser.Context context)
		{
			if (mConditionPath != null && mConditionPath.Length > 0 && !CheckConditionValue(context, mConditionPath, mConditionValue))
			{ 
				return false; 
			}
			
			if (context.Particle.BoundedGroup)
			{
				string loopID = mName;
				if (loopID.StartsWith("Loop"))
					loopID = loopID.Substring(4);
					
				if (loopID.Length > 4)
					loopID = loopID.Substring(0, 4);
					
				if (loopID.Length == 0 || loopID != context.Parser.F447)
					return false;
			}
			
			StructureItem node = this;
			Particle particle = node.Children\[0\];
			while (particle.Node.NodeClass == NodeClass.Group)
			{
				node = particle.Node;
				particle = node.Children\[0\];
			}

			// for the special Interchange and Envelope groups different behavior is needed.
			for( int nIndex = 0; nIndex < node.ChildCount; ++nIndex)
			{
				particle = node.Children\[nIndex\];
				
				StructureItem child = particle.Node;
				if (child.NodeClass == NodeClass.Segment)
				{
					// try to find out whether this segment appears here.
					Scanner.State preservedState = context.Scanner.CurrentState;
					bool result = child.IsSegmentStarting (context);
					context.Scanner.CurrentState = preservedState;
					if (result)
						return true;
				}
				else // shouldn't be anything else.
				{
					if (child.IsAtGroup (context))
						return true;
				}

				// the segment is mandatory -> the group cannot occur here.
				if (particle.MinOccurs > 0)
					return false;
			}
			// this could happen in cases where groups have no indicator segment.
			return false;
		}

		/// <summary>
		/// Reads a segment tag.
		/// </summary>
		/// <param name="context"></param>
		/// <returns></returns>
		protected string ReadSegmentTag (Parser.Context context)
		{
			StringBuilder sRet = new StringBuilder();
			Scanner scanner = context.Scanner;
			scanner.SkipWhitespace(); // skip whitespace before/between segments

			if (mName == "UNA" || mName == "ISA" || IsHL7SpecialSegment(mName) || 
				context.Parser.Settings.Standard == EDIStandard.EDIFixed)
			{
				// check segment tag - character by character because separators are not known yet
				for (int i = 0; i < mName.Length; ++i)
				{
					char c = scanner.RawConsumeChar();
					if( c != 0 )
						sRet.Append(c);
				}
			}
			else
				sRet.Append(scanner.ConsumeString(ServiceChar.ComponentSeparator, true) );

			return sRet.ToString();
		}
		
		/// <summary>
		/// Checks if the segment item is starting in the current position and eats the segment tag.
		/// </summary>
		/// <param name="context"></param>
		/// <returns></returns>
		protected bool IsSegmentStarting (Parser.Context context)
		{
			return ReadSegmentTag(context) == mName && CheckSegmentCondition(context);
		}

		protected bool CheckSegmentCondition(Parser.Context context)
		{
			if (mConditionPath.Length == 0)
				return true;
			return CheckConditionValue(context, mConditionPath, mConditionValue);
		}

		protected bool CheckConditionValue(Parser.Context ctx, string conditionPath, string conditionValue)
		{
			Scanner.State preservedState = ctx.Scanner.CurrentState;

			foreach (Particle particle in Children)
			{
				if (ctx.Scanner.IsAtEnd || ctx.Scanner.IsAtSeparator(ServiceChar.SegmentTerminator))
				{
					ctx.Scanner.CurrentState = preservedState;
					return false;
				}

				if (ctx.Scanner.IsAtAnySeparator())
					ctx.Scanner.RawConsumeChar();

				if (particle.Node.NodeClass == NodeClass.DataElement)
				{
					if (ctx.Scanner.IsAtEnd || ctx.Scanner.IsAtSeparator(ServiceChar.SegmentTerminator))
					{
						ctx.Scanner.CurrentState = preservedState;
						return false;
					}

					ServiceChar separator;
					switch (NodeClass)
					{
						case NodeClass.Segment:
							separator = ServiceChar.DataElementSeparator;
							break;

						case NodeClass.Composite:
							separator = ServiceChar.ComponentSeparator;
							break;

						case NodeClass.SubComposite:
							separator = ServiceChar.SubComponentSeparator;
							break;

						default:
							ctx.Scanner.CurrentState = preservedState;
							return false;
					}

					string value = ctx.Scanner.ConsumeString(separator, true);

					if (particle.Name == conditionPath)
					{
						ctx.Scanner.CurrentState = preservedState;
						if (conditionValue.Length > 0 && value == conditionValue)
							return true;
			
						foreach (string s in particle.CodeValues)
							if (s == value)
								return true;

						return false;
					}
				}
				else if (particle.Node.NodeClass == NodeClass.Composite)
				{
					int i = conditionPath.IndexOf(('/'));
					if (i > 0)
					{
						string path = conditionPath.Substring(i+1);
						if (particle.Name == conditionPath.Substring(0, i))
						{
							bool result = particle.Node.CheckConditionValue(ctx, path, conditionValue);
							ctx.Scanner.CurrentState = preservedState;
							return result;
						}
					}

					// skip composite
					for (; ; )
					{
						ctx.Scanner.RawConsumeChar();

						if (ctx.Scanner.IsAtEnd || ctx.Scanner.IsAtSeparator(ServiceChar.SegmentTerminator))
						{
							ctx.Scanner.CurrentState = preservedState;
							return false;
						}
						if (ctx.Scanner.IsAtSeparator(ServiceChar.DataElementSeparator))
							break;
					}
				}
				else if (particle.Node.NodeClass == NodeClass.Segment)
				{
					int i = conditionPath.IndexOf(('/'));
					if (i > 0)
					{
						if (particle.Name == conditionPath.Substring(0, i) && particle.Name == particle.Node.ReadSegmentTag(ctx))
						{
							string path = conditionPath.Substring(i + 1);
							bool result = particle.Node.CheckConditionValue(ctx, path, conditionValue);

							ctx.Scanner.CurrentState = preservedState;
							return result;
						}
					}

					// skip segment
					for (;;)
					{
						ctx.Scanner.RawConsumeChar();

						if (ctx.Scanner.IsAtEnd)
						{
							ctx.Scanner.CurrentState = preservedState;
							return false;
						}
						if (ctx.Scanner.IsAtSeparator(ServiceChar.SegmentTerminator))
						{
							ctx.Scanner.RawConsumeChar();
							break;
						}
					}
				}
			}

			ctx.Scanner.CurrentState = preservedState;
			return false;
		}

		/// <summary>
		/// Checks if a segment is special to HL7
		/// </summary>
		/// <param name="sSegmentName">Name of the segment</param>
		/// <returns>true if special else false</returns>
		protected bool IsHL7SpecialSegment(string sSegmentName)
		{
			return sSegmentName == "MSH" || sSegmentName == "FHS" || sSegmentName == "BHS";
		}

		/// <summary>
		/// Checks if a field is special to HL7
		/// </summary>
		/// <param name="sFieldName">Name of the field</param>
		/// <param name="sFieldIndex">Field index as string with - eg. "-1"</param>
		/// <returns>true if special else false</returns>
		protected bool IsHL7SpecialField(string sFieldName, string sFieldIndex)
		{
			if (sFieldName.IndexOf('-') != -1)
				return IsHL7SpecialSegment(sFieldName.Substring(0, sFieldName.IndexOf('-'))) && sFieldName.EndsWith(sFieldIndex);
			else
				return false;
		}

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public abstract bool Read (Parser.Context context);

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public abstract void Write (Writer writer, ITextNode node, Particle particle);

		/// <summary>
		/// Gets the name of the node.
		/// </summary>
		public string Name { get { return mName; } }

		/// <summary>
		/// Gets all children bindings.
		/// </summary>
		public Particle\[\] Children { get { return mChildren; } }

		/// <summary>
		/// Gets the number of children.
		/// </summary>
		public int ChildCount { get { return mChildren.Length; } }

		/// <summary>
		/// Initializes a new instance of StructureItem.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="cls"></param>
		protected StructureItem (string name, NodeClass cls)
		{
			this.mName = name;
			this.mChildren = null;
			this.mNodeClass = cls;
		}

		/// <summary>
		/// Initializes a new instance of StructureItem.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="cls"></param>
		/// <param name="children"></param>
		protected StructureItem (string name, NodeClass cls, Particle\[\] children)
			: this(name, cls)
		{
			this.mChildren = children;
		}

		/// <summary>
		/// Initializes a new instance of StructureItem.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="cls"></param>
		/// <param name="conditionPath"></param>
		/// <param name="conditionValue"></param>
		/// <param name="children"></param>
		protected StructureItem (string name, NodeClass cls, string conditionPath, string conditionValue, Particle\[\] children)
			: this(name, cls, children)
		{
			this.mConditionPath = conditionPath;
			this.mConditionValue = conditionValue;
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing a data element.
	/// </summary>
	/// <remarks>
	/// Data elements are leaf nodes.
	/// </remarks>
	public abstract class DataElementBase : StructureItem
	{
		/// <summary>
		/// Initializes a new instance of DataElementBase.
		/// </summary>
		protected DataElementBase (string name)
			: base(name, NodeClass.DataElement)
		{
		}
	}


	/// <summary>
	/// A <see cref="DataElementBase"/> representing a normal data element.
	/// </summary>
	public class DataElement : DataElementBase
	{
		DataTypeValidator mValidator;

		/// <summary>
		/// Initializes a new instance of DataElement.
		/// </summary>
		public DataElement (string name, DataTypeValidator validator) : base(name)
		{
			this.mValidator = validator;
		}

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			string s;
			Scanner.State beforeReadState = context.Scanner.CurrentState;

			if( context.Parser.Settings.Standard == EDIStandard.EDIFixed )
			{
				StringBuilder sBuilder = new StringBuilder(mValidator.MaxLength);
				while (sBuilder.Length < mValidator.MaxLength && !context.Scanner.IsAtEnd &&
						context.Scanner.CurrentChar != context.Scanner.ServiceChars.SegmentTerminator)
				{
					char c = context.Scanner.RawConsumeChar();
					if (context.Scanner.CurrentChar == '\\n')
					{
						if (c != '\\r')
							sBuilder.Append(c);
					}
					else
						sBuilder.Append(c);
				}

				s = sBuilder.ToString();
				mValidator.MakeValidOnRead(ref s, context, beforeReadState);
				
				if (s.Length == 0)
					return false; // data element is absent

				context.Generator.InsertElement(context.Particle.Name, s, mNodeClass);
				return true;
			}

			if (context.Parser.Settings.Standard == EDIStandard.EDIHL7
				&& IsHL7SpecialField(context.Particle.Name, "-2"))
			{
				char c = context.Scanner.RawConsumeChar();
				context.Scanner.ServiceChars.ComponentSeparator = c;
				s = "" + c;

				s += c = context.Scanner.RawConsumeChar();
				context.Scanner.ServiceChars.RepetitionSeparator = c;
				if( context.Scanner.CurrentChar != context.Scanner.ServiceChars.DataElementSeparator)
				{
					s += c = context.Scanner.RawConsumeChar();
					context.Scanner.ServiceChars.ReleaseCharacter = c;
				}
				if( context.Scanner.CurrentChar != context.Scanner.ServiceChars.DataElementSeparator)
				{
					s += c = context.Scanner.RawConsumeChar();
					context.Scanner.ServiceChars.SubComponentSeparator = c;
				}
				while (context.Scanner.CurrentChar != context.Scanner.ServiceChars.DataElementSeparator)
				{
					s += c = context.Scanner.RawConsumeChar();
				}
			}
			else
			{
				s = context.Scanner.ConsumeString(ServiceChar.ComponentSeparator, true);
				if ( s.Length == 0 )
					return false; // data element is absent

				if( context.Parser.Settings.Standard == EDIStandard.EDIX12 )
				{
					if (context.Particle.Name == "F447" && context.GetCurrentSegmentName() == "LS")
						context.Parser.F447 = s;
				}

				mValidator.MakeValidOnRead (ref s, context, beforeReadState);

				//codelist validate
				if (!mValidator.HasValue( s.ToString()))
				{
					if (!mValidator.IsIncomplete())
					{
						context.HandleError(
							ParserError.CodeListValueWrong,
							new ErrorPosition(beforeReadState),
							ErrorMessages.GetInvalidCodeListValueMessage(s, mValidator.GetCodeListValues()),
							s.ToString()
						);
					}
					else
					{
						context.HandleWarning(
							ParserError.CodeListValueWrong,
							new ErrorPosition(beforeReadState),
							ErrorMessages.GetIncompleteCodeListValueMessage(s, mValidator.GetCodeListValues())
						);
					}
				}
				
				// embedded codelist validate
				if (!EmbeddedCodeListValidate(s, context.Particle))
					context.HandleError(
						ParserError.CodeListValueWrong,
						new ErrorPosition(beforeReadState),
						ErrorMessages.GetInvalidCodeListValueMessage(s, EmbeddedCodeListValueList(context.Particle)),
						s);
				
				//edi validate
				string sError = context.Validator.Validate( context.Parent.Particle.NameOverride, context.Particle.NameOverride, s );
				if( sError.Length > 0)
					context.HandleError(
						ParserError.SemanticWrong,
						new ErrorPosition(beforeReadState),
						sError,
						s.ToString()
					);
			}

			context.Generator.InsertElement (context.Particle.Name, s, mNodeClass);
			return true;
		}

		static ServiceChar\[\] specialChars = new ServiceChar\[\]
		{
			ServiceChar.ComponentSeparator,
			ServiceChar.DataElementSeparator,
			ServiceChar.ReleaseCharacter,
			ServiceChar.RepetitionSeparator,
			ServiceChar.SegmentSeparator,
			ServiceChar.SegmentTerminator,
			ServiceChar.SubComponentSeparator
		};

		static bool IsSpecialChar (Writer writer, char c)
		{
			foreach (ServiceChar sc in specialChars)
			{
				char ch = writer.ServiceChars.GetServiceChar (sc);
				if (ch != 0 && ch != ' ' && ch == c)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			string value = "";
			string name = "";
			
			if (node != null)
			{
				value = node.Value;
				name = node.Name;
			}
			
			mValidator.MakeValidOnWrite (ref value, node, writer);
			string sError = writer.Validator.Validate( node.Parent.Name, name, value );

			//codelist validate
			if (!mValidator.HasValue( value.ToString()))
			{
				if (!mValidator.IsIncomplete())
					writer.HandleError(
						node,
						ParserError.CodeListValueWrong,
						ErrorMessages.GetInvalidCodeListValueMessage( value, mValidator.GetCodeListValues())
					);
				else
					writer.HandleWarning(
						node,
						ErrorMessages.GetIncompleteCodeListValueMessage( value, mValidator.GetCodeListValues())
					);
			}

			// embedded codelist validate
			if (!EmbeddedCodeListValidate(value, particle))
				writer.HandleError(
					node,
					ParserError.CodeListValueWrong,
					ErrorMessages.GetInvalidCodeListValueMessage(value, EmbeddedCodeListValueList(particle))
					);

			//edi validate
			if (sError.Length > 0)
				writer.HandleError(node, ParserError.SemanticWrong, sError);

			if (value.Length == 0)
				return; // do not write empty values

			StringBuilder bld = new StringBuilder ();

			if (writer.EDIKind == EDIStandard.EDIHL7)
			{
				if (IsHL7SpecialField(name, "-2"))
				{
					bld.Append(writer.ServiceChars.ComponentSeparator);
					bld.Append(writer.ServiceChars.RepetitionSeparator);
					if (writer.ServiceChars.ReleaseCharacter != 0)
					{
						bld.Append(writer.ServiceChars.ReleaseCharacter);
						if (writer.ServiceChars.SubComponentSeparator != 0)
							bld.Append(writer.ServiceChars.SubComponentSeparator);
					}
				}
				else // HL7 escaping
				{
					bool skipEscape = false;

					for(int i=0; i < value.Length; i++)
					{
						char ch = value\[i\];
						if (IsSpecialChar(writer, ch) && !skipEscape)
						{
							if (writer.ServiceChars.ReleaseCharacter != 0)
							{
								char chNext = i + 1 < value.Length ? value\[i + 1\] : (char)0;
								if( ch == writer.ServiceChars.ReleaseCharacter
									&& (chNext == EDIHL7Settings.cEscNormalText
									|| chNext == EDIHL7Settings.cEscStartHighlight
									|| chNext == EDIHL7Settings.cEscHexadecimalData
									|| chNext == EDIHL7Settings.cEscLocalEscapeSeq))
								{
									skipEscape = true;
									bld.Append(ch);
								}
								else
								{
									bld.Append(writer.ServiceChars.ReleaseCharacter);

									if (ch == writer.ServiceChars.DataElementSeparator) bld.Append(EDIHL7Settings.cEscFieldSeparator);
									else if (ch == writer.ServiceChars.SubComponentSeparator) bld.Append(EDIHL7Settings.cEscSubComponentSeparator);
									else if (ch == writer.ServiceChars.ComponentSeparator) bld.Append(EDIHL7Settings.cEscComponentSeparator);
									else if (ch == writer.ServiceChars.ReleaseCharacter) bld.Append(EDIHL7Settings.cEscEscapeSeparator);
									else if (ch == writer.ServiceChars.RepetitionSeparator) bld.Append(EDIHL7Settings.cEscRepetitionSeparator);

									bld.Append(writer.ServiceChars.ReleaseCharacter);
								}
							}
							else
								bld.Append(' ');
						}
						else
						{
							skipEscape = skipEscape && ch != writer.ServiceChars.ReleaseCharacter;
							bld.Append(ch);
						}
					}
				}
			}
			else
			{
				foreach (char c in value)
				{
					if (IsSpecialChar(writer, c))
					{
						if (writer.ServiceChars.ReleaseCharacter != 0 )
						{
							bld.Append(writer.ServiceChars.ReleaseCharacter);
							bld.Append(c);
						}
						else
							bld.Append(' ');
					}
					else
					{
						bld.Append(c);
					}
				}
			}
			writer.Write (bld.ToString());
		}

		private bool EmbeddedCodeListValidate(String value, Particle particle)
		{
			if (particle.CodeValues.Length == 0)
				return true;

			foreach (string s in particle.CodeValues)
				if (s == value)
					return true;

			return false;
		}

		private string EmbeddedCodeListValueList(Particle particle)
		{
			StringBuilder validList = new StringBuilder();
			foreach (string s in particle.CodeValues)
				validList.Append(", '" + s + "'");

			return validList.ToString().Substring(2);
		}
	}


	/// <summary>
	/// A <see cref="DataElementBase"/> representing an unescaped one character wide field.
	/// </summary>
	public class SingleCharElement : DataElementBase
	{
		/// <summary>
		/// Initializes a new instance of SingleCharElement.
		/// </summary>
		public SingleCharElement (string name)
			: base(name)
		{
		}

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			if (context.Scanner.IsAtEnd)
				return false;
			string s = "" + context.Scanner.RawConsumeChar ();

			if (context.Parser.Settings.Standard == EDIStandard.EDIHL7
				&& IsHL7SpecialField(context.Particle.Name, "-1"))
			{
				context.Scanner.ServiceChars.DataElementSeparator = s\[0\];
				context.Scanner.ServiceChars.SegmentSeparator = s\[0\];
				context.Scanner.ServiceChars.RepetitionSeparator = '\\0';
			}

			context.Generator.InsertElement (context.Particle.Name, s, mNodeClass);
			return true;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			string value = "";
			string name = "";
			
			if (node != null)
			{
				value = node.Value;
				name = node.Name;
			}
			
			if (value.Length == 0)
				value = " ";
				
			if (writer.EDIKind == EDIStandard.EDIHL7 && IsHL7SpecialField(name, "-1"))
				writer.Write ("" + writer.ServiceChars.DataElementSeparator);
			else
				writer.Write (value.Substring(0,1));
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing a composite element.
	/// </summary>
	/// <remarks>
	/// Composite elements consist of a collection of data elements.
	/// </remarks>
	public class Composite : StructureItem
	{
		/// <summary>
		/// Initializes a new instance of Composite.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="children"></param>
		public Composite (string name, Particle\[\] children) : base(name, NodeClass.Composite, children) { }

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			context.Scanner.MoveNextSignificantChar();
			if (context.Scanner.IsAtAnySeparator() &&
				!context.Scanner.IsAtSeparator(ServiceChar.ComponentSeparator))
				return false;

			context.Parser.ComponentDataElementPosition = 0;
				
			Generator generator = context.Generator;
			generator.EnterElement (context.Particle.Name, mNodeClass);
			if (!ReadChildren (context, ServiceChar.ComponentSeparator))
			{
				generator.LeaveElement (context.Particle.Name);
				return false;
			}

			generator.LeaveElement (context.Particle.Name);
			return true;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			WriteChildren (writer, node, ServiceChar.ComponentSeparator);
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing a composite element.
	/// </summary>
	/// <remarks>
	/// SubComposite elements consist of a collection of data elements.
	/// </remarks>
	public class SubComposite : StructureItem
	{
		/// <summary>
		/// Initializes a new instance of Composite.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="children"></param>
		public SubComposite (string name, Particle\[\] children) : base(name, NodeClass.SubComposite, children) { }

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			context.Scanner.MoveNextSignificantChar();
			if (context.Scanner.IsAtAnySeparator() &&
				!context.Scanner.IsAtSeparator(ServiceChar.SubComponentSeparator))
				return false;

			Generator generator = context.Generator;
			generator.EnterElement (context.Particle.Name, mNodeClass);
			if (!ReadChildren (context, ServiceChar.SubComponentSeparator))
			{
				generator.LeaveElement (context.Particle.Name);
				return false;
			}

			generator.LeaveElement (context.Particle.Name);
			return true;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			WriteChildren (writer, node, ServiceChar.SubComponentSeparator);
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing a segment.
	/// </summary>
	/// <remarks>
	/// Segments end with a segment terminator and are built from data elements and composites
	/// separated by the data element separator.
	/// </remarks>
	public class Segment : StructureItem
	{
		/// <summary>
		/// Initializes a new instance of Segment.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="children"></param>
		public Segment (string name, string conditionPath, string conditionValue, Particle\[\] children) : base(name, NodeClass.Segment, conditionPath, conditionValue, children) { }

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			Scanner scanner = context.Scanner;
			Scanner.State preserved = scanner.CurrentState;
			
			// check if current segment starts here.
			if (!IsSegmentStarting (context))
			{
				scanner.CurrentState = preserved;
				if (context.Particle.MinOccurs > 0)
				{
					preserved = scanner.CurrentState; //reclone
					string sSeg = ReadSegmentTag(context);
					if (sSeg.Length != 0)
					{
						if (!context.Parser.StandardSegments.ContainsKey(sSeg))
						{
							context.HandleError(
								ParserError.SegmentUnrecognized,
								new ErrorPosition( preserved),
								ErrorMessages.GetUnrecognizedSegmentMessage(sSeg),
								sSeg
							);
							return false;
						}
						else if (context.Parser.CurrentMessageType != null
							&& !context.Parser.CurrentMessage.HasSegment(sSeg))
						{
							context.HandleError(
								ParserError.SegmentUnexpected,
								new ErrorPosition( preserved),
								ErrorMessages.GetUnexpectedSegmentIDMessage(sSeg),
								sSeg
							);
							return false;
						}
					}
					scanner.CurrentState = preserved;
				}
				return false;
			}

			context.Parser.DataElementPosition = 0;
			context.Parser.ComponentDataElementPosition = 0;
			
			switch( context.Parser.Settings.Standard )
			{
				case EDIStandard.EDIFact:
				case EDIStandard.EDISCRIPT:
				{
					if (mName == "UNA") // read EDIFACT service string advice
						return scanner.ReadUNA ();
				}
				break;
				case EDIStandard.EDIX12:
				{
					if (mName == "ISA") // X12 ISA segment defines the data element separator here
					{
						if (!scanner.ReadISASegmentStart())
							return false;
					}
					
					if (mName == "ST")
					{
						//transaction restarts
						context.Parser.CurrentSegmentPosition = 1;
						
						//increment transaction count
						context.Parser.TransactionSetCount++;
						
						// default that everything will be ok.
						context.Parser.F717 = 'A';
					}
					else if (mName == "GS")
					{
						context.Parser.F715 = 'A';
					}
					else
					{
						//increment segment counter
						context.Parser.CurrentSegmentPosition++;
					}
					
					//reset current loop identifier code, if segment is LE
					if (mName == "LE")
						context.Parser.F447 = "";
				}
				break;
			}

			// skip data element separator eventually following and do sanity checks
			if (scanner.IsAtSeparator (ServiceChar.SegmentSeparator) ||
				context.Parser.Settings.Standard == EDIStandard.EDIFixed)
			{
				if ( context.Parser.Settings.Standard != EDIStandard.EDIFixed )
				{
					if ( !(context.Parser.Settings.Standard == EDIStandard.EDIHL7 && IsHL7SpecialSegment(mName)))
						scanner.RawConsumeChar();
				}
			}
			else if (!scanner.IsAtSeparator (ServiceChar.SegmentTerminator))
				return false;		// invalid input character.

			context.Generator.EnterElement (context.Particle.Name, mNodeClass);	// begin node construction

			context.Validator.Segment( mName);

			ReadChildren (context, ServiceChar.DataElementSeparator);
			
			if (context.Parser.Settings.Standard == EDIStandard.EDIX12)
			{
				if (mName == "SE")
				{
					if (context.Parser.F717 == 'A' || context.Parser.F717 == 'E')
						context.Parser.TransactionSetAccepted++;
				}
				
				if (mName == "ISA") // X12 ISA segment defines the segment terminator here
				{
					if (!scanner.ReadISASegmentEnd())
					{
						context.Generator.LeaveElement (context.Particle.Name);
						return false;
					}

					ITextNode fi15 = context.Generator.CurrentNode.Children.GetFirstNodeByName("FI15");
					if (null != fi15 && fi15.Value.Length != 0)
						context.Scanner.ServiceChars.ComponentSeparator = fi15.Value\[0\];

					ITextNode fi65 = context.Generator.CurrentNode.Children.GetFirstNodeByName("FI65");
					if (null != fi65 && fi65.Value.Length != 0)
					{
						context.Scanner.ServiceChars.RepetitionSeparator = fi65.Value\[0\];
						if (Char.IsLetterOrDigit(context.Scanner.ServiceChars.RepetitionSeparator))
							context.Scanner.ServiceChars.RepetitionSeparator = '\\0';
					}
				}
			}

			if (!scanner.IsAtSeparator(ServiceChar.SegmentTerminator))
			{
				Scanner.State beforeReadState = scanner.CurrentState;
				string sExtraContent = scanner.ForwardToSegmentTerminator();
				if ( sExtraContent.Length > 0)
					context.HandleError(
						ParserError.ExtraData,
						new ErrorPosition(beforeReadState),
						ErrorMessages.GetExtraDataMessage(mName, sExtraContent)
					);

				if (scanner.IsAtEnd)
					context.HandleError(
						ParserError.UnexpectedEndOfFile,
						new ErrorPosition(beforeReadState),
						ErrorMessages.GetUnexpectedEndOfFileMessage()
					);
			}

			scanner.RawConsumeChar();
			context.Generator.LeaveElement (context.Particle.Name);
			return true;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			string value = "";
			string name = "";
			
			if (node != null)
			{
				value = node.Value;
				name = node.Name;
			}
			
			// write out name and separator
			writer.Write (mName);
			writer.Validator.Segment(mName);

			// even this could be omitted according to spec:
			if( !(writer.EDIKind == EDIStandard.EDIHL7 && IsHL7SpecialSegment(name)))
				writer.AddSeparator (ServiceChar.SegmentSeparator);

			WriteChildren (writer, node, ServiceChar.DataElementSeparator);
			// now no superfluous separators are left, therefore write the segment terminator.
			writer.ClearPendingSeparators();
			writer.AddSeparator (ServiceChar.SegmentTerminator);

			if (writer.NewlineAfterSegments)
				writer.Write (writer.GetLineEnd());
			else
				writer.Write (""); // flushes out the segment terminator, so it won't be lost.

		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing a group.
	/// </summary>
	/// <remarks>
	/// Groups are logical collections of segments. Typically a particular segment indicates
	/// the start of the group, with more, often optional segments following.
	/// </remarks>
	public class Group : StructureItem
	{
		/// <summary>
		/// Initializes a new instance of Group.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="children"></param>
		public Group (string name, string conditionPath, string conditionValue, Particle\[\] children) : base(name, NodeClass.Group, conditionPath, conditionValue, children) { }

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			if (!IsAtGroup (context))
				return false;
			Generator generator = context.Generator;
			generator.EnterElement (context.Particle.Name, mNodeClass);

			if ( mName == "Group" )
			{
				context.Parser.TransactionSetCount = 0;
				context.Parser.TransactionSetAccepted = 0;
			}

			if ( mName == "Message" )
			{
				context.Parser.CurrentMessageType = context.Parser.FirstMessage.MessageType;
			}

			if (!ReadChildren (context, ServiceChar.None))
			{
				ITextNode node = generator.CurrentNode;
		 		if ( mName == "Message" )
		 		{
		 			context.Parser.CurrentMessageType = null;
		 		}
				generator.LeaveElement (context.Particle.Name);
				if ( mName == "Batch" && node.Children.Count == 0 )
				{
					generator.CurrentNode.Children.RemoveAt(generator.CurrentNode.Children.Count - 1);
				}
				return false;
			}

			if ( mName == "Message" )
			{
				context.Parser.CurrentMessageType = null;
			}

			generator.LeaveElement (context.Particle.Name);
			return true;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			WriteChildren (writer, node, ServiceChar.None);
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing the select element.
	/// </summary>
	/// <remarks>
	/// The select element switches messages by a defined field value
	/// </remarks>
	public class Select : StructureItem
	{
		private string msField;
		private string msPrefix;
		private string msType;

		/// <summary>
		/// Initializes a new instance of Group.
		/// </summary>
		/// <param name="name"></param>
		/// <param name="children"></param>
		public Select (string name, string sPrefix, string sField, string sType, Particle\[\] children) : base(name, NodeClass.Select, children) 
		{
			msField = sField;
			msPrefix = sPrefix;
			msType = sType;
		}

		/// <summary>
		/// Reads the node from the current position.
		/// </summary>
		/// <param name="context">The current context.</param>
		/// <returns><b>true</b> on success.</returns>
		public override bool Read (Parser.Context context)
		{
			Scanner tmpScanner = new Scanner(context.Scanner.Text, context.Scanner.ServiceChars, context.Parser.Settings.Standard);
			tmpScanner.CurrentState = context.Scanner.CurrentState;
			Generator tmpGenerator = new Generator();
			EDISettings tmpSettings = new EDISettings();
			EDISemanticValidator tmpValidator = new EDISemanticValidator(tmpSettings); // no validation
			Parser.Context preScanCtx = new Parser.Context(context.Parser, tmpScanner, mChildren\[0\], tmpGenerator, tmpValidator);

			//backup parseinfo data
			Parser.ParseInfo parseInfoBackup = (Parser.ParseInfo) context.Parser.ParseInformation.Clone();
			if (mChildren\[0\].Node.Read(preScanCtx))
			{
				string sMessage;

				if (msField == "@HL7_old")
				{
					sMessage = preScanCtx.Generator.GetNodeValueByPath("MSH/MSH-9/CM_MSG-1") + "_" +
						preScanCtx.Generator.GetNodeValueByPath("MSH/MSH-9/CM_MSG-2");
				}
				else if (msField == "@HL7")
				{
					sMessage = preScanCtx.Generator.GetNodeValueByPath("MSH/MSH-9/MSG-1") + "_" +
						preScanCtx.Generator.GetNodeValueByPath("MSH/MSH-9/MSG-2");
				}
				else if (msField.Contains("+"))
				{
					string\[\] fields = msField.Split('+');
					sMessage = "";
					foreach (string field in fields)
					{
						if (sMessage.Length > 0) sMessage += "_";
						sMessage += preScanCtx.Generator.GetNodeValueByPath(field);
					}
				}
				else
				{
					sMessage = preScanCtx.Generator.GetNodeValueByPath(msField);
				}

				//restore parseinfo
				context.Parser.ParseInformation = parseInfoBackup;
				if (sMessage != null && sMessage.Length > 0)
				{
					ArrayList filtered = context.Parser.FilterMessages(sMessage);
					foreach (Message m in filtered)
						if (m.RootParticle.Node.Read(new Parser.Context(context, m.RootParticle)))
							return true;
				}
				
				if (context.Parser.Settings.Standard == EDIStandard.EDITRADACOMS && sMessage == "RSGRSG")
				{
					context.Parser.ParseInformation = parseInfoBackup;
					return false; // this message is handled at interchange level
				}

				throw new MappingException("Message type '" + sMessage + "' unknown.");
			}

			//restore parseinfo
			context.Parser.ParseInformation = parseInfoBackup;

			return false;
		}

		/// <summary>
		/// Writes a node.
		/// </summary>
		/// <param name="writer"></param>
		/// <param name="node"></param>
		public override void Write (Writer writer, ITextNode node, Particle particle)
		{
			bool anyMessageWritten = false;
			if ( node != null )
			{
				foreach( string key in writer.Messages.Keys)
				{
					ITextNode\[\] children = node.Children.FilterByName(msPrefix + key);
					for( int i = 0; i < children.Length; i++)
					{
						writer.Validator.CurrentMessageType = key;
						Particle p = ((Message)writer.Messages\[key\]).RootParticle;
						p.Node.Write(writer, children\[i\], p);
						anyMessageWritten = true;
					}
				}
			}
			
			if( !anyMessageWritten )
			{
				 writer.HandleError(node, ParserError.MissingGroup,
				ErrorMessages.GetMissingGroupMessage("Message")
			);
			}
		}
	}

	/// <summary>
	/// A <see cref="StructureItem"/> representing an error list node.
	/// </summary>
	public class ErrorList : StructureItem
	{

		public ErrorList (String name, Particle\[\] children) : base(name, NodeClass.ErrorList, children) { }

		public override bool Read( Parser.Context context )
		{
			Generator gen = context.Parent.GeneratorForErrors;
			if( mName.Equals( "ParserErrors_Group" ) )
			{
				gen.EnterElement("MF_AK9", NodeClass.Group);

				if (context.Parser.F715 == 'R' && context.Parser.TransactionSetAccepted > 0)
					gen.InsertElement("F715", "" + 'P', NodeClass.DataElement);
				else
					gen.InsertElement("F715", "" + context.Parser.F715, NodeClass.DataElement);

				//F97: Number of Transaction Sets Included
				gen.InsertElement("F97", "" + context.Parser.TransactionSetCount, NodeClass.DataElement);
				//F123: Number of Received Transaction Sets
				gen.InsertElement("F123", "" + context.Parser.TransactionSetCount, NodeClass.DataElement);
				//F2: Number of Accepted Transaction Sets
				gen.InsertElement("F2", "" + context.Parser.TransactionSetAccepted, NodeClass.DataElement);
				
				gen.LeaveElement( "MF_AK9");
			}
			else if( mName.Equals( "ParserErrors_Message" ) )
			{
				gen.EnterElement("MF_AK5", NodeClass.Group);
				
				gen.InsertElement( "F717", "" + context.Parser.F717, NodeClass.DataElement);
				
				gen.LeaveElement( "MF_AK5");
			}

			if( gen.Children.Count > 0 )
			{
				context.Generator.CurrentNode.Children.Add( gen.RootNode );
				context.Parent.GeneratorForErrors = new Generator();
				context.Parent.GeneratorForErrors.EnterElement( mName, NodeClass.ErrorList );
			}
			return true;
		}

		public override void Write(Writer writer, ITextNode node, Particle particle)
		{ }
	}
}

