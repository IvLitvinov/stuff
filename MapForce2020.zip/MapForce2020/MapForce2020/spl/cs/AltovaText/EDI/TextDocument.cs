[call GenerateFileHeader("TextDocument.cs")]
using Altova.TextParser;

using System;
using System.IO;
using System.Text;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Encapsulates the different EDI standards.
	/// </summary>
	public enum EDIStandard
	{
		/// <summary>
		/// Unknown EDI standard
		/// </summary>
		Unknown,
		/// <summary>
		/// UN/EDIFact standard
		/// </summary>
		EDIFact,
		/// <summary>
		/// The American EDI/X12 standard.
		/// </summary>
		EDIX12,
		/// <summary>
		/// The Health Level 7 standard.
		/// </summary>
		EDIHL7,
		/// <summary>
		/// Fixed length files.
		/// </summary>
		EDIFixed,
		/// <summary>
		/// TRADACOMS standard.
		/// </summary>
		EDITRADACOMS,
		/// <summary>
		/// NCPDP SCRIPT standard.
		/// </summary>
		EDISCRIPT
	}

	/// <summary>
	/// Encapsulates parsing a complex text format file.
	/// </summary>
	public abstract class TextDocument : Parser
	{
		#region Implementation Detail:
		Generator mGenerator = new Generator();
		private string m_Encoding = "UTF-8";
		private bool m_bBigEndian = false;
		private bool m_bBOM = false;
		string mStructureName = "";
		Particle mRootParticle;
		#endregion
		#region Public Interface:
		/// <summary>
		/// Gets the encoding parameters used by this instance.
		/// </summary>
		public void GetEncoding( out string encoding, out bool bBigEndian, out bool bBOM )
		{
			encoding = m_Encoding;
			bBigEndian = m_bBigEndian;
			bBOM = m_bBOM;
		}

		/// <summary>
		/// Sets the encoding parameters used by this instance.
		/// </summary>
		public void SetEncoding( string encoding, bool bBigEndian, bool bBOM )
		{
			m_Encoding = encoding;
			m_bBigEndian = bBigEndian;
			m_bBOM = bBOM;
		}

		/// <summary>
		/// Get/sets the name of the EDIFact structure represented by this instance.
		/// </summary>
		public string StructureName
		{
			get
			{
				return mStructureName;
			}
			set
			{
				mStructureName = value;
			}
		}
		/// <summary>
		/// Gets the generator used by this instance.
		/// </summary>
		public Generator Generator
		{
			get
			{
				return mGenerator;
			}
		}
		
		/// <summary>
		/// Loads and parses from input.
		/// </summary>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading</exception>
		/// <exception cref="MappingException">thrown when the file could not be parsed</exception>
		public void Parse (Altova.IO.Input input)
		{
			switch (input.Type)
			{
				case Altova.IO.Input.InputType.Stream:
					Parse(input.Stream);
					break;
				case Altova.IO.Input.InputType.Reader:
					Parse(input.Reader);
					break;
				case Altova.IO.Input.InputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot have xml document as input");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown input type");
			}
		}
		
		/// <summary>
		/// Loads and parses the file specified.
		/// </summary>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading the file</exception>
		/// <exception cref="MappingException">thrown when the file could not be parsed</exception>
		public void Parse(string filename)
		{
			using (System.IO.Stream stream = System.IO.File.OpenRead(filename))
				Parse(stream);
		}
		
		/// <summary>
		/// Loads and parses the stream specified.
		/// </summary>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading the stream</exception>
		/// <exception cref="MappingException">thrown when the stream could not be parsed</exception>
		public void Parse(System.IO.Stream stream)
		{
			System.Text.Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
			try
			{
				using (StreamReader sr = new StreamReader(stream, encoding))
					Parse(sr);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException(
					string.Format ("Encoding {0} is not supported on this system.", m_Encoding),
					x);
			}
			catch (Exception x)
			{
				throw new Altova.Types.DataSourceUnavailableException("Error while trying to read from stream", x);
			}
		}
		
		/// <summary>
		/// Loads and parses from the reader specified.
		/// </summary>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading</exception>
		/// <exception cref="MappingException">thrown when the stream could not be parsed</exception>
		public void Parse(System.IO.TextReader reader)
		{
			string content = reader.ReadToEnd().TrimStart();
			base.Parse(mRootParticle, content, mGenerator, Settings);
			mGenerator.ResetToRoot();
		}

		
		/// <summary>
		/// finds out the true nature of output and calls appropriate handlers.
		/// </summary>
		/// <param name="output">output whose contents are to be serialized</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with output
		/// </exception>
		public void Save(Altova.IO.Output output)
		{
			switch (output.Type)
			{
				case Altova.IO.Output.OutputType.Stream:
					Save(output.Stream);
					break;
				case Altova.IO.Output.OutputType.Writer:
					Save(output.Writer);
					break;
				case Altova.IO.Output.OutputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot save into xml document");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown output type");
			}
		}
		
		/// <summary>
		/// Saves the document in EDIFact format.
		/// </summary>
		public void Save(string filename)
		{
			using (System.IO.Stream stream = new System.IO.FileStream(filename, System.IO.FileMode.Create))
				Save(stream);
		}
		
		/// <summary>
		/// Saves the document in EDIFact format.
		/// </summary>
		public void Save(System.IO.TextWriter writer)
		{
			ITextNodeCollection rootnodes = mGenerator.RootNodes;
			
			if (this.Settings.AutoCompleteData)
			{
				DataCompletion datacompletion = null;
				switch (this.Settings.Standard)
				{
				case EDIStandard.EDIFact:
					datacompletion = new EDIFactDataCompletion(this, (EDIFactSettings) this.Settings, mStructureName);
					break;
				case EDIStandard.EDISCRIPT:
					datacompletion = new EDIScriptDataCompletion(this, (EDIScriptSettings) this.Settings, mStructureName);
					break;
				case EDIStandard.EDIX12:
					datacompletion = new EDIX12DataCompletion(this, (EDIX12Settings) this.Settings, mStructureName);
					break;
					case EDIStandard.EDIHL7:
					datacompletion = new EDIHL7DataCompletion(this, (EDIHL7Settings) this.Settings, mStructureName);
					break;
				case EDIStandard.EDIFixed:
					datacompletion = new EDIFixedDataCompletion(this, (EDIFixedSettings) this.Settings, mStructureName);
					break;
				case EDIStandard.EDITRADACOMS:
					datacompletion = new EDITradacomsDataCompletion(this, (EDITradacomsSettings) this.Settings, mStructureName);
					break;
				}
				
				if( datacompletion != null)
				{
					foreach( ITextNode root in rootnodes )
					{
						datacompletion.CompleteData(root, mRootParticle);
					}
				}
				else
					Console.WriteLine( "No data completion will be performed");
			}

			EDISemanticValidator validator = new EDISemanticValidator(this.Settings);
			Writer ediWriter = new Writer (writer, mMessages, this.Settings, validator, this.ErrorSettings, this.Settings.LineEnd);
			ediWriter.NewlineAfterSegments = this.Settings.TerminateSegmentsWithLinefeed;

			foreach( ITextNode root in rootnodes )
			{
				mRootParticle.Node.Write (ediWriter, root, mRootParticle);
			}
			writer.Flush();
		}
		
		/// <summary>
		/// Saves the document in EDIFact format.
		/// </summary>
		public void Save(System.IO.Stream stream)
		{
			StreamWriter writer;
			try
			{
				System.Text.Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
				using (writer = new StreamWriter(stream, encoding))
					Save(writer);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException("Encoding " + m_Encoding +
					" is not supported on this system", x);
			}
			catch (Exception x)
			{
				throw new MappingException("Could not save to stream.", x);
			}
		}

		/// <summary>
		/// Constructs a text document.
		/// </summary>
		protected TextDocument (Particle rootParticle)
		{
			this.mRootParticle = rootParticle;
		}

		#endregion
		#region Descendant Obligations:
		#endregion

		#region Helper functions
		
		/// <summary>
		/// Returns Encoding object created from encoding name, endianess and BOM.
		/// </summary>
		private static System.Text.Encoding GetEncodingObject( string encoding, bool bBigEndian, bool bBOM )
		{
			int unisize = GetUnicodeSizeFromEncodingName( encoding );

			if( unisize == 1 )
				return new System.Text.UTF8Encoding( bBOM );

			if( unisize == 2 )
				return new System.Text.UnicodeEncoding( bBigEndian, bBOM );

			return System.Text.Encoding.GetEncoding( encoding );
		}

		/// <summary>
		/// Returns Encoding object created from encoding name
		/// </summary>
		private static int GetUnicodeSizeFromEncodingName( string encoding )
		{
			if( encoding == null ) return 0;
			encoding = encoding.ToUpper();

			if( encoding.IndexOf("UTF-8") >= 0 )
				return 1;

			if( encoding.IndexOf("UTF-16") >= 0 || encoding.IndexOf("UCS-2") >= 0 )
				return 2;

			return 0;
		}
		#endregion
	}
}
