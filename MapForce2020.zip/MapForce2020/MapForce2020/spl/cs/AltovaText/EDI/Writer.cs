[call GenerateFileHeader("Writer.cs")]
using System;
using System.Collections;
using System.Text;
using System.IO;

namespace Altova.TextParser.EDI
{
	/// <summary>
	/// Used for formatting EDI output.
	/// </summary>
	public class Writer
	{
		TextWriter mOutput;
		StringBuilder mPendingSeparators = new StringBuilder ();
		bool mNewlineAfterSegments = true;
		SortedList mMessages;
		
		EDISettings mSettings;
		EDISemanticValidator mValidator;
		
		long mLine;
		long mPosition;
		long mLineStart;
		int mLineEnd = 0;
		
		ParserAction\[\] mErrorSettings = new ParserAction\[(int)ParserError.Count\] { 
			ParserAction.ActionStop,
			ParserAction.ActionStop,
			ParserAction.ActionStop,
			ParserAction.ActionStop,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionStop,
			ParserAction.ActionReportReject,
			ParserAction.ActionReportReject,
			ParserAction.ActionStop,
			ParserAction.ActionStop,
			ParserAction.ActionStop,
			ParserAction.ActionStop
		};

		/// <summary>
		/// Gets the service character set used for writing.
		/// </summary>
		public ServiceChars ServiceChars
		{
			get { return mSettings.ServiceChars; }
		}

		/// <summary>
		/// Gets or sets if segments are followed by a newline (CRLF) sequence.
		/// </summary>
		public bool NewlineAfterSegments
		{
			get { return mNewlineAfterSegments; }
			set { mNewlineAfterSegments = value; }
		}

		public EDIStandard EDIKind
		{
			get { return mSettings.Standard; }
		}

		public EDISemanticValidator Validator
		{
			get { return mValidator; }
		}

		public SortedList Messages
		{
			get { return mMessages;  }
		}

		public long Line { get { return mLine + 1; } }
		public long Column { get { return mPosition - mLineStart + mPendingSeparators.Length + 1; } }
		public long Position { get { return mPosition + mPendingSeparators.Length; } }

		public string GetLineEnd()
		{
			switch (mLineEnd)
			{
				case 0:
				case 1: return "\\r\\n";
				case 2: return "\\n";
				case 3: return "\\r";
				default: return "\\r\\n";
			}
		}
		
		/// <summary>
		/// Initializes a new instance of the Writer class.
		/// </summary>
		/// <param name="output">The target.</param>
		/// <param name="ediKind">EDI Type defined in EDIStandard.</param>
		/// <param name="serviceChars">The service character set.</param>
		public Writer (TextWriter output, SortedList messages, EDISettings settings, EDISemanticValidator validator, ParserAction\[\] errorSettings, int lineend)
		{
			this.mOutput = output;
			this.mSettings = settings;
			this.mValidator = validator;
			//all this code just for acccessing the first element...
			IEnumerator enumMessages = messages.Values.GetEnumerator();
			enumMessages.MoveNext();
			this.mValidator.CurrentMessageType = ((Message)enumMessages.Current).MessageType;
			this.mErrorSettings = errorSettings;
			this.mMessages = messages;
			this.mLineEnd = lineend;

			mLine = 0;
			mLineStart = 0;
			mPosition = 0;

			if (settings.Standard == EDIStandard.EDIFact)
			{
				EDIFactSettings edisettings= (EDIFactSettings) settings;
				if (edisettings.WriteUNA)
				{
					mPosition = settings.ServiceChars.Serialize(output);
					if (settings.TerminateSegmentsWithLinefeed)
						Write( GetLineEnd() );
				}
			}
			else if (settings.Standard == EDIStandard.EDISCRIPT)
			{
				EDIScriptSettings edisettings= (EDIScriptSettings) settings;
				if (edisettings.WriteUNA)
				{
					mPosition = settings.ServiceChars.Serialize(output);
					if (settings.TerminateSegmentsWithLinefeed)
						Write( GetLineEnd() );
				}
			}
		}

		/// <summary>
		/// Writes a string; flushes out all pending separators.
		/// </summary>
		/// <param name="s"></param>
		/// <remarks>
		/// The text is not escaped using this method.
		/// </remarks>
		public void Write (string s)
		{
			mOutput.Write (mPendingSeparators);
			mOutput.Write (s);
			mPosition += mPendingSeparators.Length + s.Length;
			checkNewLines( mPendingSeparators + s);
			ClearPendingSeparators();
		}

		public void checkNewLines( String s)
		{
			for( int i = 0; i < s.Length; i++)
			{
				if (s\[i\] == '\\n' || (s\[i\] == '\\r' && SafeCharAt(s, i + 1) != '\\n'))
				{
					mLine++;
					mLineStart = mPosition;
				}
			}
		}

		static private char SafeCharAt( String s, int index)
		{
			if (index < s.Length)
				return s\[index\];
			else
				return (char)0;
		}
		
		/// <summary>
		/// Adds a separator.
		/// </summary>
		/// <param name="serviceChar">The separator to add.</param>
		/// <remarks>
		/// This method does not honor NewlineAfterSegments, as it does not immediately
		/// output the separator, but rather records it for later output.
		/// </remarks>
		public void AddSeparator (ServiceChar serviceChar)
		{
			if (serviceChar != ServiceChar.None && mSettings.ServiceChars.GetServiceChar(serviceChar) != '\\0')
				mPendingSeparators.Append (mSettings.ServiceChars.GetServiceChar(serviceChar));
		}

		/// <summary>
		/// Clears specific separators that are recorded, but not yet written.
		/// </summary>
		public void ClearPendingSeparators (ServiceChar serviceChar)
		{
			if (serviceChar == ServiceChar.None)
				return;

			// search for the separator
			char sep = mSettings.ServiceChars.GetServiceChar(serviceChar);
			int lastIndex = mPendingSeparators.Length;
			while (lastIndex > 0 && mPendingSeparators\[lastIndex - 1\] == sep)
				--lastIndex;

			// remove from the string
			mPendingSeparators.Remove (lastIndex, mPendingSeparators.Length - lastIndex);
		}

		/// <summary>
		/// Clears all separators that are recorded, but not yet written.
		/// </summary>
		public void ClearPendingSeparators()
		{
			mPendingSeparators = new StringBuilder();
		}

		/// <summary>
		/// Called when an error happens during writting.
		/// </summary>
		public void HandleError (ITextNode node, ParserError error, string message)
		{
			string location = node != null ? node.Name : "";
			ITextNode parent = node != null ?  node.Parent : null;
			while (parent != null)
			{
				if( parent.Name != null)
					location = parent.Name + " / " + location;
				parent = parent.Parent;
			}
			
			String lineLoc = String.Format(
				"Line {0} column {1} (offset 0x{2:X}): ",
				Line,
				Column,
				Position
			);
			location = lineLoc + location;

			switch( mErrorSettings\[(int)error\] )
			{
				case ParserAction.ActionStop:
				{
					throw new MappingException (location + ": " + message);
				}
				case ParserAction.ActionReportReject:
				case ParserAction.ActionReportAccept:
				{
					System.Console.Error.WriteLine(location + ": " + message);
				}
				break;
				case ParserAction.ActionIgnore: break;
			}
		}

		/// <summary>
		/// Called when a warning happens during writting.
		/// </summary>
		public void HandleWarning (ITextNode node, string message)
		{
			string location = node != null ? node.Name : "";
			ITextNode parent = node != null ?  node.Parent : null;
			while (parent != null)
			{
				if( parent.Name != null)
					location = parent.Name + " / " + location;
				parent = parent.Parent;
			}
			
			String lineLoc = String.Format(
				"Line {0} column {1} (offset 0x{2:X}): ",
				Line,
				Column,
				Position
			);
			location = lineLoc + location;

			System.Console.Error.WriteLine(location + ": Warning: " + message);
		}
	}
}

