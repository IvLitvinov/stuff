[call GenerateFileHeader("Splitter.cs")]
using Altova.TextParser;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace Altova.TextParser.Flex
{
	/// <summary>
	/// A range inside a string
	/// </summary>
	public class Range
	{
		/// <summary>
		/// start offset of this range in content
		/// </summary>
		public int start;
		/// <summary>
		/// end offset of this range in content
		/// </summary>
		public int end;
		private string content;
		
		/// <summary>
		/// constructor to create a range for a substring
		/// </summary>
		public Range(String text, int contentStart, int contentEnd)
		{
			content = text;
			start = contentStart;
			end = contentEnd;
		}
		/// <summary>
		/// constructor to create a range for complete string
		/// </summary>
		public Range(String text)
		{
			content = text;
			start = 0;
			end = content.Length;
		}
		
		/// <summary>
		/// copy constructor
		/// </summary>
		public Range(Range r) : this(r.GetContent(), r.start, r.end) {}
		
		/// <summary>
		/// returns true if range is valid and not empty, false otherwise
		/// </summary>
		public bool IsValid()
		{
			return (start < end);
		}
		/// <summary>
		/// returns text "contained" in this range
		/// </summary>
		public override string ToString()
		{
			return content.Substring(start, end - start);
		}
		/// <summary>
		/// returnes content used in this range
		/// </summary>
		public string GetContent()
		{
			return content;
		}
		
		/// <summary>
		/// Length of range
		/// </summary>
		public int Length
		{
			get
			{
				return end - start;
			}
		}
		
		/// <summary>
		/// returns nth character of content
		/// </summary>
		public char At(int i)
		{
			return content\[i\];
		}

		/// <summary>
		/// returns true if range is not empty and starts with ch
		/// </summary>
		public bool StartsWith(char ch)
		{
			return (IsValid() && content\[start\] == ch);
		}

		/// <summary>
		/// returns true if range is not empty and ends with ch
		/// </summary>
		public bool EndsWith(char ch)
		{
			return (IsValid() && content\[end-1\] == ch);
		}

		/// <summary>
		/// returns true if range starts with str
		/// </summary>
		public bool StartsWith(string str)
		{
			return (Length >= str.Length && GetContent().Substring(start, str.Length) == str);
		}
		
		/// <summary>
		/// returns true if range contains str
		/// </summary>
		public bool Contains(string str)
		{
			return (Length >= str.Length && GetContent().IndexOf(str, start, end-start) != -1);
		}
		
		/// <summary>
		/// append range to a string
		/// </summary>
		public void AppendTo(StringBuilder str)
		{
			str.Append(content.Substring(start, end - start));
		}
	}
	
	/// <summary>
	/// Interface to append some text
	/// </summary>
	public interface Appender
	{
		/// <summary>
		/// Append text to output
		/// </summary>
		void AppendText(string addtext);
		void AppendLineEnd();
	}
	/// <summary>
	/// base class for splitter
	/// </summary>
	public abstract class Splitter
	{
		/// <summary>CR character constant</summary>
		protected const char CR = '\\r';
		/// <summary>LF character constant</summary>
		protected const char LF = '\\n';
		/// <summary>TAB character constant</summary>
		protected const char TAB = '\\t';

		/// <summary>
		/// split off some portion from range r and return it, r is modified to contain the rest
		/// </summary>
		public abstract Range Split(Range r);
		
		/// <summary>
		/// append delimiter to output
		/// </summary>
		public abstract void AppendDelimiter(Appender output);
	
		/// <summary>
		/// prepares the upper string for writing.
		/// </summary>
		/// <param name="buffer"></param>
		public virtual void PrepareUpper(StringBuilder buffer,int lineend) {}

		/// <summary>
		/// prepares the lower string for writing.
		/// </summary>
		/// <param name="buffer"></param>
		public virtual void PrepareLower(StringBuilder buffer,int lineend) {}
	}
	
	/// <summary>
	/// Split at given position
	/// </summary>
	public class SplitAtPosition : Splitter
	{
		private int position;
			
		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtPosition(int pos)
		{
			position = pos;
		}
		
		/// <summary>
		/// implementation of split for this splitter
		/// </summary>
		public override Range Split(Range range)
		{
			Range result;
			if (position < 0) // from right
			{
				int n = Math.Min(-position, range.Length);
				result = new Range(range.GetContent(), range.start, range.end - n);
			}
			else // from left
				result = new Range(range.GetContent(), range.start, range.start+Math.Min(position, range.Length));
			range.start = result.end;
			return result;
		}
		
		/// <summary>
		/// nop - no delimiter here
		/// </summary>
		public override void AppendDelimiter(Appender output)
		{}

		public override void PrepareUpper(StringBuilder buffer,int lineend)
		{
			if (position > 0)
			{
				if (buffer.Length > position)
				{
					buffer.Length = position;
				}
				else
				{
					while (buffer.Length < position)
						buffer.Append(' ');
				}
			}
		}

		public override void PrepareLower(StringBuilder buffer,int lineend)
		{
			if (position < 0)
			{
				if (buffer.Length > -position)
				{
					buffer.Length = -position;
				}
				else if (buffer.Length < -position)
				{
					buffer.Insert(0, new string(' ', -position - buffer.Length));
				}				
			}
		}
	}
	
	/// <summary>
	/// Split number of lines from top or bottom
	/// </summary>
	public class SplitLines : Splitter
	{
		private int nLines;
		private bool removeDelimiter;
	
		/// <summary>
		/// constructor
		/// </summary>
		public SplitLines(int nLines, bool removeDelimiter)
		{
			this.nLines = nLines;
			this.removeDelimiter = removeDelimiter;
		}
		/// <summary>
		/// constructor
		/// </summary>
		public SplitLines(int nLines) : this(nLines, false) {}
		
		/// <summary>
		/// implementation of split for this instance
		/// </summary>
		public override Range Split(Range range)
		{
			string content = range.GetContent();
			Range result = new Range(content, range.start, range.start);
			int p = 0;
			
			if (nLines >= 0)
			{
				// count from top
				p = result.end;
				for (int nLinesLeft = nLines; nLinesLeft > 0 && p != range.end; ++p)
				{
					if (content\[p\] == CR || content\[p\] == LF)
					{
						if (content\[p\] == CR && p != range.end-1 && content\[p+1\] == LF)
							++p;
						--nLinesLeft;
					}
				}
			}
			else
			{
				// count from bottom
				result.end = range.end;
				p = result.end;
				int nLinesLeft = -nLines;
				if (result.IsValid() && (content\[p-1\] == CR || content\[p-1\] == LF))
					nLinesLeft++;

				for (; p > range.start; --p)
				{
					if (content\[p-1\] == CR || content\[p-1\] == LF)
					{
						if (--nLinesLeft == 0)
							break;
						if (nLinesLeft > 0 && content\[p-1\] == LF && p > range.start+1 && content\[p-2\] == CR)
							--p;
					}
				}
			}
			result.end = p;
			range.start = result.end;
			if (removeDelimiter)
			{
				if (result.EndsWith(LF))
					--result.end;
				if (result.EndsWith(CR))
					--result.end;
			}
			return result;
		}
		
		static void makeBufferNLines(StringBuilder buffer, int n, int lineend)
		{
			int p = 0;
			for (int nLinesLeft = n; nLinesLeft > 0;)
			{
				if (p < buffer.Length)
				{
					if (buffer\[p\] == CR || buffer\[p\] == LF)
					{
						if (buffer\[p\] == CR && p != buffer.Length-1 && buffer\[p+1\] == LF)
							++p;
						--nLinesLeft;
						if (nLinesLeft == 0) // remove anything yet following
						{
							buffer.Remove(p+1, buffer.Length-p-1);
							break;
						}
					}
					++p;
				}
				else
				{
					switch (lineend)
					{
						case 0:
						case 1: buffer.Append(CR); buffer.Append(LF); break;
						case 2: buffer.Append(LF); break;
						case 3: buffer.Append(CR); break;
						default:
							buffer.Append(CR); buffer.Append(LF); break;
					}

					--nLinesLeft;
				}
			}								
		}
		
		/// <summary>
		/// appends CRLF 
		/// </summary>
		public override void AppendDelimiter(Appender output)
		{
			if (removeDelimiter)
				output.AppendLineEnd();
		}

		/// <summary>
		/// prepares the upper buffer making it appropriately long
		/// </summary>
		/// <param name="buffer"></param>
		public override void PrepareUpper(StringBuilder buffer,int lineend)
		{
			if (nLines >= 0)
			{
				makeBufferNLines(buffer, nLines, lineend);
			}			
		}

		/// <summary>
		/// prepares the lower buffer making it appropriately long
		/// </summary>
		/// <param name="buffer"></param>
		public override void PrepareLower(StringBuilder buffer,int lineend)
		{
			if (nLines < 0)
			{
				makeBufferNLines(buffer, -nLines, lineend);
			}
		}

	}
	/// <summary>
	/// Split text around delimiter string
	/// </summary>
	public class SplitAtDelimiter : Splitter
	{
		/// <summary>
		/// delimiter used in this splitter
		/// </summary>
		protected string delimiter;
		
		/// <summary>
		/// true if searching backwards
		/// </summary>
		protected bool reverse;
		
		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtDelimiter(String delimiter, bool reverse)
		{
			this.delimiter = delimiter;
			this.reverse = reverse;
		}

		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtDelimiter(String delimiter) : this(delimiter, false)
		{
		}
		
		/// <summary>
		/// split implementation for this splitter
		/// </summary>
		public override Range Split(Range range)
		{
			Range result = new Range(range);
			
			if (delimiter.Length == 0)
			{
				range.start = range.end;
				return result;
			}
			
			result.end = range.start;
					
			int pos;
			if (reverse)
				pos = range.GetContent().LastIndexOf(delimiter, range.end - 1, range.end - range.start);
			else
				pos = range.GetContent().IndexOf(delimiter, range.start, range.end - range.start);
			if (pos != -1)
			{
				result.end = pos;
				range.start = result.end + delimiter.Length;
			}
			else
			{
				result.end = range.end;
				range.start = result.end;
			}
			return result;
		}
		
		/// <summary>
		/// appends delimiter
		/// </summary>
		public override void AppendDelimiter(Appender output)
		{
			output.AppendText(delimiter);
		}
	}

	public class SplitAtDelimiterRegex : Splitter
	{
		protected string pattern;
		protected bool matchcase;
		protected string separatorforwriting;

		public SplitAtDelimiterRegex( string pattern, bool matchcase, string separatorforwriting )
		{
			this.pattern = pattern;
			this.matchcase = matchcase;
			this.separatorforwriting = separatorforwriting;
		}

		// splits input range to result containing the head section and range the tail section
		// if no match occured, the head section contains all and the tail is empty (result.end == range.end)
		public override Range Split( Range range )
		{
			Range result = new Range(range);
			
			if ( pattern.Length == 0 )
			{
				range.start = range.end;
				return result;
			}
			
			result.end = range.start;

			RegexOptions flag = RegexOptions.ECMAScript;
			if ( !matchcase )
				flag |= RegexOptions.IgnoreCase;
			Regex re = new Regex( pattern, flag );
			Match m = re.Match( range.GetContent(), range.start, range.Length );

			if ( m.Success )
			{
				result.end = m.Index;
				range.start = m.Index + m.Length;
			}
			else
			{
				// full range in the head section
				result.end = range.end;
				range.start = result.end;
			}

			return result;
		}

		public override void AppendDelimiter( Appender output )
		{
			output.AppendText( separatorforwriting );
		}
	}
	
	/// <summary>
	/// Split at start of line containing delimiter string
	/// </summary>
	public class SplitAtDelimiterLineBased : SplitAtDelimiter
	{
		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtDelimiterLineBased(string delimiter, bool reverse) : base(delimiter, reverse)
		{
		}
		
		/// <summary>
		/// split implementation for this splitter
		/// </summary>
		public override Range Split(Range range)
		{
			if (delimiter.Length == 0)
			{
				Range result1 = new Range(range);
				range.start = range.end;
				return result1;
			}
			
			Range result = base.Split(range);
			
			String content = range.GetContent();
			while (result.IsValid() && content\[result.end-1\] != CR && content\[result.end-1\] != LF)
				--result.end;
			range.start = result.end;
			return result;
		}
		
		/// <summary>
		/// nop - delimiter is in content
		/// </summary>
		public override void AppendDelimiter(Appender output)
		{}
	}

	public class SplitAtDelimiterLineBasedRegex : SplitAtDelimiterRegex
	{
		public SplitAtDelimiterLineBasedRegex( string pattern, bool matchcase ) : base( pattern, matchcase, null )
		{}
		
		public override Range Split( Range range )
		{
			if ( pattern.Length == 0 )
			{
				Range result1 = new Range(range);
				range.start = range.end;
				return result1;
			}
			
			Range result = base.Split( range );
			
			String content = range.GetContent();
			while ( result.IsValid() && content\[result.end-1\] != CR && content\[result.end-1\] != LF )
				--result.end;
			range.start = result.end;
			return result;
		}
		
		public override void AppendDelimiter( Appender output )
		{}
	}
	
	/// <summary>
	/// Split at start of line containing delimiter string (ignoring delimiter in the first line)
	/// </summary>
	public class SplitAtDelimiterLineBasedMultiple : SplitAtDelimiterLineBased
	{
		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtDelimiterLineBasedMultiple(string delimiter) : base(delimiter, false)
		{
		}
		
		/// <summary>
		/// split implementation for this splitter
		/// </summary>
		public override Range Split(Range range)
		{
			SplitLines splitAtFirstLine = new SplitLines(1);
			bool firstLine = true;
			Range result = new Range(range);
			while (true)
			{
				Range line = splitAtFirstLine.Split(range);
				if (!line.IsValid())
				{
					result.end = line.start;
					break;
				}
				if (line.GetContent().IndexOf(delimiter, line.start, line.end-line.start) >= 0)
				{
					if (!firstLine)
					{
						result.end = line.start;
						break;
					}
				}
				firstLine = false;
			}
			range.start = result.end;
			return result;
		}
	}

	public class SplitAtDelimiterLineBasedMultipleRegex : SplitAtDelimiterLineBasedRegex
	{
		public SplitAtDelimiterLineBasedMultipleRegex( string pattern, bool matchcase ) : base( pattern, matchcase )
		{}
		
		public override Range Split( Range range )
		{
			SplitLines splitAtFirstLine = new SplitLines(1);
			bool firstLine = true;
			Range result = new Range( range );
			SplitAtDelimiterRegex splitter = new SplitAtDelimiterRegex( pattern, matchcase, null );
			while ( true )
			{
				Range line = splitAtFirstLine.Split( range );
				if ( !line.IsValid() )
				{
					result.end = line.start;
					break;
				}
				Range head = splitter.Split( line );
				if ( head.end != line.end )
				{
					if (!firstLine)
					{
						result.end = head.start;
						break;
					}
				}
				firstLine = false;
			}
			range.start = result.end;
			return result;
		}
	}

	/// <summary>
	/// Split at start of line containing delimiter string
	/// </summary>
	public class SplitAtDelimiterLineStartsWith : SplitAtDelimiter
	{
		protected bool consumeFirstLine;

		/// <summary>
		/// constructor
		/// </summary>
		public SplitAtDelimiterLineStartsWith(string delimiter) : base(delimiter, false)
		{
			consumeFirstLine = false;
		}

		public SplitAtDelimiterLineStartsWith(string delimiter, bool reverse) : base(delimiter, reverse)
		{
			consumeFirstLine = false;
		}

		/// <summary>
		/// split implementation for this splitter
		/// </summary>
		public override Range Split(Range range)
		{
			if ( !reverse )
			{
				Range result = new Range(range);

				if ( delimiter == "" )
				{
					range.start = range.end;
					return result;
				}

				SplitLines splitAtFirstLine = new SplitLines(1);
				bool firstLine = consumeFirstLine;
				while (true)
				{
					Range line = splitAtFirstLine.Split(range);
					if (!line.IsValid())
					{
						result.end = line.start;
						break;
					}
					if (line.StartsWith(delimiter))
					{
						if (!firstLine)
						{
							result.end = line.start;
							break;
						}
					}
					firstLine = false;
				}
				range.start = result.end;
				return result;
			}
			else
			{
				Range result = new Range(range);

				if ( delimiter == "" )
				{
					result.end = result.start;
					return result;
				}

				SplitLines splitAtLastLine = new SplitLines(-1);
				Range pre = new Range(range);
				while (true)
				{
					Range line = splitAtLastLine.Split(pre);
					if (!line.IsValid())
					{
						result.end = line.start;
						break;
					}
					if (pre.StartsWith(delimiter))
					{
						result.end = pre.start;
						break;
					}
					pre = line;
				}
				range.start = result.end;
				return result;
			}
		}

		/// <summary>
		/// nop - delimiter is in content
		/// </summary>
		public override void AppendDelimiter( Appender output )
		{}
	}

	/// <summary>
	/// Split at start of line containing delimiter string (ignoring delimiter in the first line)
	/// </summary>
	public class SplitAtDelimiterLineStartsWithMultiple : SplitAtDelimiterLineStartsWith
	{
		public SplitAtDelimiterLineStartsWithMultiple(string delimiter) : base(delimiter)
		{
			consumeFirstLine = true;
		}
	}

	public class SplitAtDelimiterLineStartsWithRegex : SplitAtDelimiterRegex
	{
		protected bool consumeFirstLine;

		public SplitAtDelimiterLineStartsWithRegex( string pattern, bool matchcase ) : base( pattern, matchcase, null )
		{
			consumeFirstLine = false;
		}

		public override Range Split( Range range )
		{
			Range result = new Range(range);

			if ( pattern.Length == 0 )
			{
				range.start = range.end;
				return result;
			}

			SplitLines splitAtFirstLine = new SplitLines(1);
			bool firstLine = consumeFirstLine;
			while ( true )
			{
				Range line = splitAtFirstLine.Split( range );
				if ( !line.IsValid() )
				{
					result.end = line.start;
					break;
				}
				Range head = base.Split( line );
				if ( head.end != line.end && head.start == head.end )
				{
					if (!firstLine)
					{
						result.end = head.start;
						break;
					}
				}
				firstLine = false;
			}
			range.start = result.end;
			return result;
		}

		public override void AppendDelimiter( Appender output )
		{}
	}

	public class SplitAtDelimiterLineStartsWithMultipleRegex : SplitAtDelimiterLineStartsWithRegex
	{
		public SplitAtDelimiterLineStartsWithMultipleRegex( string pattern, bool matchcase ) : base( pattern, matchcase )
		{
			consumeFirstLine = true;
		}
	}
}
