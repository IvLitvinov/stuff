[call GenerateFileHeader("TextDocument.cs")]
using Altova.TextParser;
using System;
using System.IO;
using System.Text;

namespace Altova.TextParser.Flex
{
	/// <summary>
	/// Encapsulates parsing a complex text format file.
	/// </summary>
	public abstract class TextDocument
	{
		#region Implementation Detail:
		Generator generator = new Generator();
		private string m_Encoding = "UTF-8";
		private bool m_bBigEndian = false;
		private bool m_bBOM = false;
		protected int m_LineEnd = 0;
		/// <summary>
		/// root command
		/// </summary>
		protected CommandProject rootCommand;
		
		void ParseString(string buffer)
		{
			if (rootCommand == null)
				throw new System.InvalidOperationException("No syntax definition");
			DocumentReader doc = new DocumentReader(buffer, generator);
			rootCommand.ReadText(doc);
		}

		#endregion
		#region Public Interface:
		
		/// <summary>
		/// Gets the encoding parameters used by this instance.
		/// </summary>
		public void GetEncoding( out string encoding, out bool bBigEndian, out bool bBOM )
		{
			encoding = m_Encoding;
			bBigEndian = m_bBigEndian;
			bBOM = m_bBOM;
		}

		/// <summary>
		/// Sets the encoding parameters used by this instance.
		/// </summary>
		public void SetEncoding( string encoding, bool bBigEndian, bool bBOM )
		{
			m_Encoding = encoding;
			m_bBigEndian = bBigEndian;
			m_bBOM = bBOM;
		}

		/// <summary>
		/// Get/sets the generator used by this instance.
		/// </summary>
		public Generator Generator
		{
			get
			{
				return generator;
			}
		}
		
				/// <summary>
		/// Loads and parses the file specified.
		/// </summary>
		/// <param name="filename">the name of the file to read</param>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading the file</exception>
		/// <exception cref="MappingException">thrown when the file could not be parsed</exception>
		public virtual void Parse(string filename)
		{
			using (System.IO.Stream stream = System.IO.File.OpenRead(filename))
				Parse(stream);
		}
		
				/// <summary>
		/// Loads and parses from input.
		/// </summary>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading</exception>
		/// <exception cref="MappingException">thrown when the file could not be parsed</exception>
		public void Parse(Altova.IO.Input input)
		{
			switch (input.Type)
			{
				case Altova.IO.Input.InputType.Stream:
					Parse(input.Stream);
					break;
				case Altova.IO.Input.InputType.Reader:
					Parse(input.Reader);
					break;
				case Altova.IO.Input.InputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot have xml document as input");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown input type");
			}
		}

		/// <summary>
		/// Loads and parses the reader specified.
		/// </summary>
		/// <param name="reader">the name of the file to read</param>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading the stream</exception>
		/// <exception cref="MappingException">thrown when the stream could not be parsed</exception>
		public virtual void Parse(System.IO.TextReader reader)
		{
			string content = reader.ReadToEnd();
			this.ParseString(content);
			if (null == generator.RootNode)
				throw new MappingException("Stream could not be parsed.");
		}

		/// <summary>
		/// Loads and parses the stream specified.
		/// </summary>
		/// <param name="filename">the name of the file to read</param>
		/// <exception cref="AltovaException">thrown when there is a problem with loading/reading the stream</exception>
		/// <exception cref="MappingException">thrown when the stream could not be parsed</exception>
		public virtual void Parse(System.IO.Stream stream)
		{
			try
			{
				Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
				using (StreamReader sr = new StreamReader(stream, encoding))
					Parse(sr);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException(string.Format ("Encoding {0} is not supported on this system.", m_Encoding),	x);
			}
			catch (Exception x)
			{
				throw new Altova.Types.DataSourceUnavailableException("Error while trying to read from stream", x);
			}
		}
		
		/// <summary>
		/// Saves the text document
		/// </summary>
		/// <param name="filename">the file to save to</param>
		public void Save(string filename)
		{
			using (System.IO.Stream stream = new System.IO.FileStream(filename, System.IO.FileMode.Create))
				Save(stream);
		}
		
		/// <summary>
		/// Writes the text document into stream
		/// </summary>
		/// <param name="stream">the stream to save to</param>
		public void Save(System.IO.Stream stream)
		{ 
			try
			{
				System.Text.Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
				using (StreamWriter writer = new StreamWriter(stream, encoding))
					Save(writer);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException("Encoding " + m_Encoding +
					" is not supported on this system.", x);
			}
			catch (Exception x)
			{
				throw new MappingException("Could not save to stream.", x);
			}
		}

		/// <summary>
		/// Writes the text document into writer
		/// </summary>
		/// <param name="writer">the writer to save to</param>
		public void Save(System.IO.TextWriter writer)
		{
			if (rootCommand == null)
				throw new System.InvalidOperationException("No syntax definition");

			if(generator.RootNode != null)
			{
				StringBuilder text = new StringBuilder();
				DocumentWriter doc = new DocumentWriter(generator.RootNode, text, m_LineEnd);
				rootCommand.WriteText(doc);

				writer.Write(text);
				writer.Flush();
			}
		}

		/// <summary>
		/// finds out the true nature of output and calls appropriate handlers.
		/// </summary>
		/// <param name="output">output whose contents are to be serialized</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with output
		/// </exception>
		public void Save(Altova.IO.Output output)
		{
			switch (output.Type)
			{
				case Altova.IO.Output.OutputType.Stream:
					Save(output.Stream);
					break;
				case Altova.IO.Output.OutputType.Writer:
					Save(output.Writer);
					break;
				case Altova.IO.Output.OutputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot save into xml document");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown output type");
			}
		}
		
		#endregion

		#region Helper functions
		private static System.Text.Encoding GetEncodingObject( string encoding, bool bBigEndian, bool bBOM )
		{
			int unisize = GetUnicodeSizeFromEncodingName( encoding );

			if( unisize == 1 )
				return new System.Text.UTF8Encoding( bBOM );

			if( unisize == 2 )
				return new System.Text.UnicodeEncoding( bBigEndian, bBOM );

			return System.Text.Encoding.GetEncoding( encoding );
		}

		private static int GetUnicodeSizeFromEncodingName( string encoding )
		{
			if( encoding == null ) return 0;
			encoding = encoding.ToUpper();

			if( encoding.IndexOf("UTF-8") >= 0 )
				return 1;

			if( encoding.IndexOf("UTF-16") >= 0 || encoding.IndexOf("UCS-2") >= 0 )
				return 2;

			return 0;
		}
		#endregion
	}
}
