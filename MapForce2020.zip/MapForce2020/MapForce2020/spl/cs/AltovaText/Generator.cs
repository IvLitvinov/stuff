[call GenerateFileHeader("Generator.cs")]
using System;
using System.IO;
namespace Altova.TextParser
{
	/// <summary>
	/// Encapsulates methods needed to build a tree of <see cref="TextNode"/>s,
	/// methods needed by some <see cref="Flex.Condition"/>s and methods
	/// for saving the created tree to an XML file.
	/// </summary>
	public class Generator : ITextNode
	{
		#region Implementation Detail:
		ITextNode mCurrent= null;

		ITextNodeCollection mChildren;

		public Generator() 
		{
			mChildren = new TextNodeCollection(this);
		}

		void SwitchToParent()
		{
			if (mCurrent.Parent != null) 
				mCurrent = mCurrent.Parent;
		}

		public ITextNode Root { get { return this; } set { }}
		public ITextNode Parent { get { return null; } set { }}
		public ITextNode SearchUpwardsByName(string s) { return null; }
		public ITextNodeCollection Children {
			get { return mChildren; }
			 set { }
		}
		public string Name { get { return null; } set { }}
		public string Value { get { return null; } set { }}
		public NodeClass Class { get { return NodeClass.Undefined; } set { }}
		#endregion
		#region Public Interface:
		/// <summary>
		/// Initializes the generator.
		/// </summary>
		public void Init()
		{
			mCurrent= null;
		}
		/// <summary>
		/// Resets the generator to the root node of the tree.
		/// </summary>
		public void ResetToRoot()
		{
			mCurrent = mCurrent.Root;
		}
		/// <summary>
		/// Adds a new node to the children of the current node and tries to assign it the specified name.
		/// </summary>
		/// <param name="name">the name to assign</param>
		/// <param name="eClass">the name of the node's class</param>
		/// <remarks>
		/// If the new node doesn't already have a name assigned, the current node will be set to
		/// the newly created.
		/// </remarks>
		public void EnterElement(string name, NodeClass eClass)
		{
			TextNode node = new TextNode(mCurrent, name, eClass);
			if (mCurrent == null) 
				mChildren.Add(node);
			mCurrent = node;
		}
		
		/// <summary>
		/// Leaves the current node by climbing upwards in the hierarchy.
		/// </summary>
		/// <param name="name">the name of the node to leave</param>
		public void LeaveElement(string name)
		{
			if (name == null || name.Length == 0 || name != mCurrent.Name)
				throw new ArgumentNullException ("this is useless behavior. do therefore not use.");

			mCurrent = mCurrent.Parent;
		}
		
		/// <summary>
		/// Inserts a new node into the hierarchy as the child of the current node and 
		/// assigns it the specified name and value.
		/// </summary>
		/// <param name="name">the name to assign</param>
		/// <param name="val">the value to assign</param>
		/// <param name="eClass">the name of the node's class</param>
		public void InsertElement(string name, string val, NodeClass eClass)
		{
			TextNode node = new TextNode(mCurrent, name, eClass);
			node.Value = val;
		}
		/// <summary>
		/// Checks whether the current node's name property equals the specified name.
		/// </summary>
		/// <param name="name">the name to compare to</param>
		/// <returns>true if the name matches, otherwise false</returns>
		public bool DoesNameEqual(string name)
		{
			return (name == mCurrent.Name);
		}
		/// <summary>
		/// Checks whether there is a node among the current node's children whose name
		/// matches a specified parameter. 
		/// </summary>
		/// <param name="name">the name to match</param>
		/// <returns>true if a child with matching name was found, otherwise false</returns>
		public bool DoesNamedChildExist(string name)
		{
			return (0 < mCurrent.Children.FilterByName(name).Length);
		}
		/// <summary>
		/// Gets the root nodes of the contained hierarchy. May be empty.
		/// </summary>
		public ITextNodeCollection RootNodes
		{
			get
			{
				return mChildren;
			}
		}
		/// <summary>
		/// Gets the root node of the contained hierarchy. May be null.
		/// </summary>
		public ITextNode RootNode
		{
			get
			{
				return mChildren\[0\];
			}
		}
		/// <summary>
		/// Sets the root node of the contained hierarchy.
		/// </summary>
		/// <param name="rhs"></param>
		public void SetRootNode(ITextNode rhs)
		{
			mCurrent = rhs;
			mChildren.Add(mCurrent);
		}
		/// <summary>
		/// Gets the current node of the contained hierarchy. Maybe null.
		/// </summary>
		public ITextNode CurrentNode
		{
			get
			{
				return mCurrent;
			}
		}

		/// <summary>
		/// Searchs a node value by the given path, returns "" if node not found.
		/// </summary>
		public string GetNodeValueByPath(string sPath)
		{
			ITextNode node = mCurrent;

			if (node.Name != null && node.Name == sPath)
				return node.Value;

			foreach (string sPart in sPath.Split('/'))
			{
				node = node.Children.GetFirstNodeByName(sPart);
				if (node == null)
					return "";
			}

			return node.Value;
		}
		#endregion
	}
}
