[call GenerateFileHeader("Interfaces.cs")]
using System.Collections;

namespace Altova.TextParser
{
	/// <summary>
	/// Encapsulates the kind a <see cref="ITextNode"/> has.
	/// </summary>
	public enum NodeClass
	{
		/// <summary>
		/// The class has not been initialized.
		/// </summary>
		Undefined,
		/// <summary>
		/// The <see cref="ITextNode"/> represents a data element.
		/// </summary>
		DataElement,
		/// <summary>
		/// The <see cref="ITextNode"/> represents a composite.
		/// </summary>
		Composite,
		/// <summary>
		/// The <see cref="ITextNode"/> represents a segment.
		/// </summary>
		Segment,
		/// <summary>
		/// The <see cref="ITextNode"/> represents a group.
		/// </summary>
		Group,
		/// <summary>
		/// The <see cref="ITextNode"/> represents a subcomposite.
		/// </summary>
		SubComposite,
		/// <summary>
		/// The <see cref="ITextNode"/> represents an error list node.
		/// </summary>
		ErrorList,
		/// <summary>
		/// The <see cref="ITextNode"/> represents an select node.
		/// </summary>
		Select,
	}

	/// <summary>
	/// Defines the properties and methods making up a text node.
	/// </summary>
	public interface ITextNode
	{
		/// <summary>
		/// Gets the root node of this instance.
		/// </summary>
		ITextNode Root { get; }
		/// <summary>
		/// Get/sets the parent node of this instance.
		/// </summary>
		ITextNode Parent { get; set; }
		/// <summary>
		/// Looks for a node with a specified name in the ancestry of this instance.
		/// </summary>
		/// <param name="name">the name to find a node for</param>
		/// <returns>the node found</returns>
		ITextNode SearchUpwardsByName(string name);
		/// <summary>
		/// Gets a collection containing all the child nodes of this instance.
		/// </summary>
		ITextNodeCollection Children { get; }
		/// <summary>
		/// Get/sets the name of this instance.
		/// </summary>
		string Name { get; set; }
		/// <summary>
		/// Get/sets the value of this instance.
		/// </summary>
		string Value { get; set; }
		/// <summary>
		/// Get/sets the kind of this instance.
		/// </summary>
		NodeClass Class { get; set; }
	}

	/// <summary>
	/// Defines the properties and methods making up a container of <see cref="ITextNode"/>s.
	/// </summary>
	public interface ITextNodeCollection : IEnumerable
	{
		/// <summary>
		/// Gets the number of contained <see cref="ITextNode"/>s.
		/// </summary>
		int Count { get; }
		/// <summary>
		/// Get/sets contained <see cref="ITextNode"/>s per index.
		/// </summary>
		ITextNode this\[int index\] { get; set; }
		/// <summary>
		/// Filters the contained nodes by their name.
		/// </summary>
		/// <param name="name">nodes whose name not equals this parameter will be filtered out</param>
		/// <returns>a new collection containing all the nodes not filtered out</returns>
		ITextNode\[\] FilterByName(string name);
		/// <summary>
		/// Adds a new <see cref="ITextNode"/> to the collection.
		/// </summary>
		/// <param name="rhs">the node to be added</param>
		/// <returns>
		/// true if successful, false if the node is already contained in the collection or in the
		/// children of one of the contained nodes
		/// </returns>
		bool Add(ITextNode rhs);
		/// <summary>
		/// Inserts a node at a given position.
		/// </summary>
		/// <param name="rhs">the node to be inserted</param>
		/// <param name="index">the position where to insert the node</param>
		void Insert(ITextNode rhs, int index);
		/// <summary>
		/// Checks whether a node is already contained, either directly or as a child, grandchild etc.
		/// of one of the contained nodes.
		/// </summary>
		/// <param name="rhs">the node to check for</param>
		/// <returns>true if the node is already contained, otherwise false</returns>
		bool Contains(ITextNode rhs);
		/// <summary>
		/// Removes the node at the specified index from this instance.
		/// </summary>
		/// <param name="index">the index</param>
		void RemoveAt(int index);
		
		/// <summary>
		/// Removes nodes by name.
		/// </summary>
		void RemoveByName(string name);

		/// <summary>
		/// Moves the node to a different index.
		/// </summary>
		/// <param name="rhs">the node</param>
		/// <param name="index">the index</param>
		void MoveNode(ITextNode rhs, int index);

		/// <summary>
		/// Retrieves the first node with the specified name.
		/// </summary>
		ITextNode GetFirstNodeByName (string name);
		
		/// <summary>
		/// Retrieves the last node with the specified name.
		/// </summary>
		ITextNode GetLastNodeByName (string name);
	}
}