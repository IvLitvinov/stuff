[call GenerateFileHeader("CSVParser.cs")]
using System;
using System.Collections.Specialized;

namespace Altova.TextParser.TableLike.CSV
{
	/*
	internal class BadFormatException : Exception
	{
		public BadFormatException(string msg) : base(msg)
		{}
	}
*/

	/// <summary>
	/// Encapsulates parsing a CSV format as exported by MS-Excel.
	/// </summary>
	public class CSVParser : RecordBasedParser
	{
		#region Implementation Detail:
		CSVFormat mFormat = null;
		string mBuffer = "";
		int mCurrentOffset = 0;
		ParserState mCurrentState = null;
		ParserStates mStates = null;
		string mToken = "";
		StringCollection mFields = new StringCollection();
		int mFirstRecordFieldCount = 0;
		int mRecordCount = 0;

		#endregion
		#region Internal Interface:
		internal bool IsEndOfBuffer
		{
			get
			{
				return (mCurrentOffset >= mBuffer.Length);
			}
		}

		internal bool WasLastCharacterFieldDelimiter
		{
			get
			{
				if (0 < mCurrentOffset)
					return mFormat.IsFieldDelimiter(mBuffer\[mCurrentOffset - 1\]);
				else
					return false;
			}
		}

		internal bool WasLastCharacterQuote
		{
			get
			{
				if (0 < mCurrentOffset)
					return mFormat.IsQuoteCharacter(mBuffer\[mCurrentOffset - 1\]);
				else
					return false;
			}
		}

		internal char CurrentCharacter
		{
			get
			{
				return mBuffer\[mCurrentOffset\];
			}
		}

		internal void MoveNext()
		{
			++mCurrentOffset;
		}

		internal string Token
		{
			get
			{
				return mToken;
			}
			set
			{
				mToken = value;
			}
		}

		private bool HasAnyFieldsWithContent
		{
			get
			{
				foreach ( string f in mFields )
					if ( f != null && f.Length > 0 )
						return true;
				return false;
			}
		}

		internal void NotifyAboutEndOfRecord()
		{
			if (0 < mFields.Count)
			{
				if ( HasAnyFieldsWithContent )
				{
					if (0 == mRecordCount)
						mFirstRecordFieldCount = mFields.Count;

					/* uncomment this for stricter format checking:
					else if (mFields.Count!=mFirstRecordFieldCount)
						throw new BadFormatException("Field count doesn't match the field count of the first record.");
					*/
					++mRecordCount;
					if (null != OnRecordFound)
					{
						Record record = new Record(mFields);
						OnRecordFound(record);
					}
				}
				mFields.Clear();
			}
		}

		internal void NotifyAboutTokenComplete()
		{
			if (mFormat.RemoveEmpty && mToken == "")
				mToken = null;				
			mFields.Add(mToken);
			mToken = "";
		}

		#endregion
		#region Public Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="format">the format information to use</param>
		/// <param name="header">the header to use</param>
		public CSVParser(CSVFormat format, Header header) : base(header)
		{
			mFormat = format;
			mStates = new ParserStates(this);
		}

		/// <summary>
		/// Gets the format specification used when parsing.
		/// </summary>
		public CSVFormat Format
		{
			get
			{
				return mFormat;
			}
		}

		#endregion
		#region Implementing RecordBasedParser:
		/// <summary>
		/// Parses the input string as CSV.
		/// </summary>
		/// <param name="buffer">the input data</param>
		/// <returns>the number of records parsed</returns>
		/// <exception cref="CSVParserException">
		/// Thrown when encountering a record whose number of fields does not equal the number of fields
		/// of the first record in the input data, or if encountering a quote character in an unquoted field.
		/// </exception>
		public override int Parse(string buffer)
		{
			mBuffer = buffer;
			mCurrentOffset = 0;
			mToken = "";
			mFirstRecordFieldCount = 0;
			mRecordCount = 0;
			mCurrentState = mStates.WaitingForField;
			try
			{
				while (!this.IsEndOfBuffer)
				{
					char current = this.CurrentCharacter;
					if (mFormat.IsFieldDelimiter(current))
						mCurrentState = mCurrentState.ProcessFieldDelimiter(current);
					else if (mFormat.IsRecordDelimiter(current))
						mCurrentState = mCurrentState.ProcessRecordDelimiter(current);
					else if (mFormat.IsQuoteCharacter(current))
						mCurrentState = mCurrentState.ProcessQuoteCharacter(current);
					else
						mCurrentState = mCurrentState.Process(current);
				}
				this.NotifyAboutTokenComplete();
				this.NotifyAboutEndOfRecord();
			}
			catch (Exception x)
			{
				throw new CSVParserException(x, mRecordCount);
			}
			return mRecordCount;
		}
		#endregion
	}
}