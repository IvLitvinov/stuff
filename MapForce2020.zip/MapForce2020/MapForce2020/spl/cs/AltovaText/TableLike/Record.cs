[call GenerateFileHeader("Record.cs")]
using System.Collections;
using System.Collections.Specialized;

namespace Altova.TextParser.TableLike
{
	/// <summary>
	/// Encapsulates a record in a table-like formatted file.
	/// </summary>
	public class Record : IDataElement
	{
		#region Implementation Detail:
		string\[\] mFields = null;
		Table mOwner= null;
		#endregion
		#region Package Interface:
		internal Record(StringCollection fields)
		{
			mFields = new string\[fields.Count\];
			fields.CopyTo(mFields, 0);
		}
		internal Record(string\[\] fields)
		{
			mFields = new string\[fields.Length\];
			fields.CopyTo(mFields, 0);
		}
		internal Table Owner
		{
			get { return mOwner; }
			set { mOwner= value; }
		}
		#endregion
		#region Public Interface:
		
		/// <summary>
		/// Gets the table.
		/// </summary>
		public Table Table { get { return mOwner; } }
		
		/// <summary>
		/// Constructs an instance of this class from a number of fields.
		/// </summary>
		/// <param name="fieldcount">the number of fields this record instance will/should hold</param>
		public Record(int fieldcount)
		{
			mFields = new string\[fieldcount\];
		}
		/// <summary>
		/// Copy constructor.
		/// </summary>
		/// <param name="rhs">the other record from which to copy construct</param>
		public Record(Record rhs)
		{
			mFields = new string\[rhs.mFields.Length\];
			rhs.mFields.CopyTo(mFields, 0);
			mOwner = rhs.mOwner;
		}
		/// <summary>
		/// Constructs an instance of this class from another implementation of <see cref="IDataElement"/>.
		/// </summary>
		/// <param name="rhs"></param>
		public Record(IDataElement rhs)
		{
			int length= 0;
			IEnumerator enumerator= rhs.Children.GetEnumerator();
			while (enumerator.MoveNext()) ++length;
				
			mFields= new string\[length\];
			enumerator.Reset();
			for (int i= 0; i<length; ++i)
			{
				enumerator.MoveNext();
				mFields\[i\]= ((IDataElement) enumerator.Current).Value;
			}
		}
		/// <summary>
		/// Get/sets fields per index.
		/// </summary>
		/// <param name="index">the index used to specify which field</param>
		public string this\[int index\]
		{
			get
			{
				if (index >= mFields.Length) return null;
				return mFields\[index\];
			}
			set
			{
				mFields\[index\] = value;
			}
		}
		/// <summary>
		/// Gets the number of fields contained by this record.
		/// </summary>
		public int Size
		{
			get
			{
				return mFields.Length;
			}
		}
		#endregion
		#region IDataElement Members
		/// <summary>
		/// Implements <see cref="IDataElement.Name"/>.
		/// </summary>
		public string Name
		{
			get
			{
				return "Record";
			}
		}
		/// <summary>
		/// Implements <see cref="IDataElement.Value"/>.
		/// </summary>
		public string Value
		{
			get
			{
				return "";
			}
		}
		/// <summary>
		/// Implements <see cref="IDataElement.Children"/>.
		/// </summary>
		public IEnumerable Children
		{
			get
			{
				Field\[\] result= new Field\[mFields.Length\];
				for (int i= 0; i<mFields.Length; ++i)
				{
					result\[i\]= new Field(mOwner.Header\[i\].Name, mFields\[i\]);
				}
				return result;
			}
		}
		#endregion
	}
	internal class Field : IDataElement
	{
		#region Implementation detail:
		string mName= "";
		string mValue= "";
		#endregion
		#region Public interface:
		public Field(string name, string value)
		{
			mName= name;
			mValue= value;
		}
		#endregion
		#region IDataElement Members
		public string Name
		{
			get
			{
				return mName;
			}
		}
		public string Value
		{
			get
			{
				return mValue;
			}
		}
		public IEnumerable Children
		{
			get
			{
				return null;
			}
		}
		#endregion
	}

}