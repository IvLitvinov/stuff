[call GenerateFileHeader("Serializer.cs")]
using System;
using System.IO;
using System.Text;

namespace Altova.TextParser.TableLike
{
	/// <summary>
	/// Defines the methods expected from a class for de/serializing from/to a certain format.
	/// </summary>
	public interface ISerializer
	{
		//// <summary>
		/// Serializes to stream.
		/// </summary>
		/// <param name="stream">stream to serialize to</param>
		void Serialize(System.IO.Stream stream);
		/// <summary>
		/// Serializes to writer.
		/// </summary>
		/// <param name="writer">writer to serialize to</param>
		void Serialize(System.IO.TextWriter writer);
		/// <summary>
		/// Deserializes from a stream.
		/// </summary>
		/// <param name="stream">stream to deserialize from</param>
		void Deserialize(System.IO.Stream stream);
		/// <summary>
		/// Deserializes from a reader.
		/// </summary>
		/// <param name="writer">writer to deserialize from</param>
		void Deserialize(System.IO.TextReader reader);
		/// <summary>
		/// Gets the encoding parameters used by this instance.
		/// </summary>
		void GetEncoding( out string encoding, out bool bBigEndian, out bool bBOM );
		/// <summary>
		/// <summary>
		/// Sets the encoding parameters used by this instance.
		/// </summary>
		void SetEncoding( string encoding, bool bBigEndian, bool bBOM );
	}

	/// <summary>
	/// Encapsulates common functionality needed by concrete implementations of <see cref="ISerializer"/>.
	/// </summary>
	public abstract class Serializer : ISerializer
	{
		#region Implementation Detail:
		Table mTable = null;
		TextWriter mStream = null;
		private string m_Encoding = "UTF-8";
		private bool m_bBigEndian = false;
		private bool m_bBOM = false;

		void OnRecordFound(Record record)
		{
			if (this.DoStoreRecord(record))
				mTable.Add(record);
		}
		
		#endregion
		#region Public Interface:
		#endregion
		#region Descendant Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="table">the table to be used for de/serializing</param>
		protected Serializer(Table table)
		{
			mTable = table;
		}
		/// <summary>
		/// Gets the table to be used for de/serializing.
		/// </summary>
		protected Table Table
		{
			get
			{
				return mTable;
			}
		}
		/// <summary>
		/// Gets the stream to be written to.
		/// </summary>
		protected TextWriter Stream
		{
			get
			{
				return mStream;
			}
		}
		#endregion
		#region Descendant Obligations:
		/// <summary>
		/// Does the actual serializing after the stream has already been opened and initialized.
		/// Does not need to catch exceptions as this will be done when calling this method.
		/// </summary>
		protected abstract void DoSerialize();
		/// <summary>
		/// Creates a concrete parser to be used.
		/// </summary>
		/// <returns>the concrete parser</returns>
		protected abstract RecordBasedParser CreateParser();
		/// <summary>
		/// Asks a descendant class whether a specific record should be stored in the table.
		/// </summary>
		/// <param name="record">the record in question</param>
		/// <returns>true if the record is to be stored in the table, otherwise false</returns>
		protected abstract bool DoStoreRecord(Record record);
		#endregion
		#region ISerializer Members:
		/// <summary>
		/// See <see cref="ISerializer.Serialize"/>().
		/// </summary>
		/// <param name="stream">See <see cref="ISerializer.Serialize"/>().</param>
		public void Serialize(System.IO.Stream stream)
		{
			try
			{
				Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
				using (mStream = new StreamWriter(stream, encoding))
					Serialize(mStream);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException("Encoding " + m_Encoding +
					" is not supported on this system.", x);
			}
			catch (Exception x)
			{
				throw new MappingException("Could not save save CSV format to stream.", x);
			}
		}
		
		/// <summary>
		/// See <see cref="ISerializer.Serialize"/>().
		/// </summary>
		/// <param name="writer">See <see cref="ISerializer.Serialize"/>().</param>
		public void Serialize(System.IO.TextWriter writer)
		{
			try
			{
				mStream = writer;
				this.DoSerialize();
				mStream.Flush();
			}
			catch (Exception x)
			{
				throw new MappingException("Could not save to stream.", x);
			}
		}
		
		/// <summary>
		/// See <see cref="ISerializer.Deserialize"/>().
		/// </summary>
		/// <param name="filename">See <see cref="ISerializer.Deserialize"/>().</param>
		public void Deserialize(System.IO.Stream stream)
		{
			try
			{
				Encoding encoding = GetEncodingObject( m_Encoding, m_bBigEndian, m_bBOM );
				using (StreamReader sr = new StreamReader(stream, encoding))
					Deserialize(sr);
			}
			catch (NotSupportedException x)
			{
				throw new MappingException("Encoding " + m_Encoding +
					" is not supported on this system.", x);
			}
			catch (Exception x)
			{
				throw new MappingException("Error while reading from stream", x);
			}
		}
		
		/// <summary>
		/// See <see cref="ISerializer.Deserialize"/>().
		/// </summary>
		/// <param name="reader">See <see cref="ISerializer.Deserialize"/>().</param>
		public void Deserialize(System.IO.TextReader reader)
		{
			mTable.Clear();
			RecordBasedParser parser = this.CreateParser();
			parser.OnRecordFound = new RecordFoundDelegate(this.OnRecordFound);
			string buffer = reader.ReadToEnd();
			parser.Parse(buffer);
		}

		/// <summary>
		/// See <see cref="ISerializer.GetEncoding"/>().
		/// </summary>
		public void GetEncoding( out string encoding, out bool bBigEndian, out bool bBOM )
		{
			encoding = m_Encoding;
			bBigEndian = m_bBigEndian;
			bBOM = m_bBOM;
		}

		/// <summary>
		/// See <see cref="ISerializer.SetEncoding"/>().
		/// </summary>
		public void SetEncoding( string encoding, bool bBigEndian, bool bBOM )
		{
			m_Encoding = encoding;
			m_bBigEndian = bBigEndian;
			m_bBOM = bBOM;
		}
		#endregion

		#region Helper functions
		private static System.Text.Encoding GetEncodingObject( string encoding, bool bBigEndian, bool bBOM )
		{
			int unisize = GetUnicodeSizeFromEncodingName( encoding );

			if( unisize == 1 )
				return new System.Text.UTF8Encoding( bBOM );

			if( unisize == 2 )
				return new System.Text.UnicodeEncoding( bBigEndian, bBOM );

			return System.Text.Encoding.GetEncoding( encoding );
		}

		private static int GetUnicodeSizeFromEncodingName( string encoding )
		{
			if( encoding == null ) return 0;
			encoding = encoding.ToUpper();

			if( encoding.IndexOf("UTF-8") >= 0 )
				return 1;

			if( encoding.IndexOf("UTF-16") >= 0 || encoding.IndexOf("UCS-2") >= 0 )
				return 2;

			return 0;
		}
		#endregion
	}

}