[call GenerateFileHeader("Table.cs")]
using System;
using System.Collections;

namespace Altova.TextParser.TableLike
{
	/// <summary>
	/// Encapsulates a table-like text format and its contents.
	/// </summary>
	public abstract class Table : IEnumerable, IDataElement
	{
		#region Implementation Detail:
		protected Altova.TypeInfo.TypeInfo tableType;
		protected int mLineEnd = 0;
		Header mHeader = new Header();
		ArrayList mRecords = new ArrayList();
		protected ISerializer mSerializer = null;
		#endregion
		#region Public Interface:
		/// <summary>
		/// Gets the Typeinfo used by this instance.
		/// </summary>
		public Altova.TypeInfo.TypeInfo TableType
		{
			get
			{
				return tableType;
			}
		}
		/// <summary>
		/// Gets the header used by this instance.
		/// </summary>
		public Header Header
		{
			get
			{
				return mHeader;
			}
		}
		/// <summary>
		/// Gets the number of records stored in this instance.
		/// </summary>
		public int Count
		{
			get
			{
				return mRecords.Count;
			}
		}

		/// <summary>
		/// Gets the encoding parameters to be used for reading/writing data.
		/// </summary>
		public void GetEncoding( out string encoding, out bool bBigEndian, out bool bBOM )
		{
			mSerializer.GetEncoding( out encoding, out bBigEndian, out bBOM );
		}

		/// <summary>
		/// Sets the encoding parameters to be used for reading/writing data.
		/// </summary>
		public void SetEncoding( string encoding, bool bBigEndian, bool bBOM )
		{
			mSerializer.SetEncoding( encoding, bBigEndian, bBOM );
		}

		/// <summary>
		/// Adds a record to this instance.
		/// </summary>
		/// <param name="rhs">the record to add</param>
		public void Add(Record rhs)
		{
			mRecords.Add(rhs);
			rhs.Owner= this;
		}
		/// <summary>
		/// Gets a record containe by this instance per index.
		/// </summary>
		/// <param name="index">the index</param>
		public Record this\[int index\]
		{
			get
			{
				return (Record) mRecords\[index\];
			}
		}
		/// <summary>
		/// Clears this instance from all records.
		/// </summary>
		public void Clear()
		{
			mRecords.Clear();
		}
		
		/// <summary>
		/// finds out the true nature of input and calls appropriate handlers.
		/// </summary>
		/// <param name="input">input whose contents are to be parsed and loaded</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with input
		/// </exception>
		public void Parse (Altova.IO.Input input)
		{
			switch (input.Type)
			{
				case Altova.IO.Input.InputType.Stream:
					Parse(input.Stream);
					break;
				case Altova.IO.Input.InputType.Reader:
					Parse(input.Reader);
					break;
				case Altova.IO.Input.InputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot have xml document as input");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown input type");
			}
		}
		
		/// <summary>
		/// Parses from reader and reads the contained records into this instance.
		/// </summary>
		/// <param name="reader">the reader from which the contents are to be parsed and loaded</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with opening the file or parsing it
		/// </exception>
		public void Parse(System.IO.TextReader reader)
		{
			try
			{
				mSerializer.Deserialize(reader);
			}
			catch (MappingException x)
			{
				throw new Altova.Types.DataSourceUnavailableException("Error while reading from reader", x);
			}
		}

		/// <summary>
		/// Parses a stream and reads the contained records into this instance.
		/// </summary>
		/// <param name="stream">the stream whose contents are to be parsed and loaded</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with reading the stream or parsing it
		/// </exception>
		public void Parse(System.IO.Stream stream)
		{
			try
			{
				mSerializer.Deserialize(stream);
			}
			catch (MappingException x)
			{
				throw new Altova.Types.DataSourceUnavailableException("Error while reading from stream", x);
			}
		}
		
		/// <summary>
		/// finds out the true nature of output and calls appropriate handlers.
		/// </summary>
		/// <param name="output">output whose contents are to be serialized</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with output
		/// </exception>
		public void Save(Altova.IO.Output output)
		{
			switch (output.Type)
			{
				case Altova.IO.Output.OutputType.Stream:
					Save(output.Stream);
					break;
				case Altova.IO.Output.OutputType.Writer:
					Save(output.Writer);
					break;
				case Altova.IO.Output.OutputType.XmlDocument:
					throw new Altova.Types.DataSourceUnavailableException("This is text, cannot save into xml document");

				default:
					throw new Altova.Types.DataSourceUnavailableException("Unknown output type");
			}
		}
		
		/// <summary>
		/// Saves the records contained in this instance into a file.
		/// </summary>
		/// <param name="filename">the file where to save the records to</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with opening or writing the file.
		/// </exception>
		public void Save(System.IO.Stream stream)
		{
			try
			{
				mSerializer.Serialize(stream);
			}
			catch (MappingException x)
			{
				throw new Altova.Types.DataTargetUnavailableException("Error while writing into stream", x);
			}
		}
		
		/// <summary>
		/// Writes the records contained in this instance into writer.
		/// </summary>
		/// <param name="writer">writer to save the records to</param>
		/// <exception cref="AltovaException">
		/// thrown when there is a problem with writing.
		/// </exception>
		public void Save(System.IO.TextWriter writer)
		{
			try
			{
				mSerializer.Serialize(writer);
			}
			catch (MappingException x)
			{
				throw new Altova.Types.DataTargetUnavailableException("Error while writing into writer", x);
			}
		}
		#endregion
		#region Descendant Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		protected Table()
		{
		}

		protected Table(bool b, int lineend)
		{
			mLineEnd = lineend;
		}

		protected void Init()
		{
			this.InitHeader(mHeader);
			mSerializer = this.CreateSerializer();
		}
		#endregion
		#region Descendant Obligations:
		/// <summary>
		/// Create a format-specific concrete implementation of <see cref="ISerializer"/>.
		/// </summary>
		/// <returns>the concrete instance</returns>
		protected abstract ISerializer CreateSerializer();
		/// <summary>
		/// Initialize the <see cref="Header"/> with needed information like the name of columns etc.
		/// </summary>
		/// <param name="header">
		/// the header to fill, provided for comfort reasons, as descendant could just access the header via
		/// the property <see cref="Header"/>.
		/// </param>
		protected abstract void InitHeader(Header header);
		#endregion
		#region IEnumerable Members
		/// <summary>
		/// See <see cref="IEnumerable.GetEnumerator"/>().
		/// </summary>
		/// <returns>See <see cref="IEnumerable.GetEnumerator"/>().</returns>
		public IEnumerator GetEnumerator()
		{
			return mRecords.GetEnumerator();
		}
		#endregion
		#region IDataElement Members
		/// <summary>
		/// Implements <see cref="IDataElement.Name"/>.
		/// </summary>
		public string Name
		{
			get
			{
				return "Table";
			}
		}
		/// <summary>
		/// Implements <see cref="IDataElement.Value"/>.
		/// </summary>
		public string Value
		{
			get
			{
				return "";
			}
		}
		/// <summary>
		/// Implements <see cref="IDataElement.Children"/>.
		/// </summary>
		public IEnumerable Children
		{
			get
			{
				return mRecords;
			}
		}
		#endregion
	}

	public class FLFTable : Table
	{

		public FLFTable(Altova.TypeInfo.TypeInfo tableType):this(tableType,0){}
		public FLFTable(Altova.TypeInfo.TypeInfo tableType, int lineend) 
			: base(false,lineend)
		{
			this.tableType = tableType;
			Init();
		}

		public Altova.TextParser.TableLike.FLF.FLFFormat Format { get { return ((Altova.TextParser.TableLike.FLF.FLFSerializer)mSerializer).Format; } }

		protected override ISerializer CreateSerializer()
		{
			return new Altova.TextParser.TableLike.FLF.FLFSerializer(this,mLineEnd);
		}

		private static int getLength(Altova.TypeInfo.MemberInfo member)
		{
			if (member.DataType.facets.Value != null)
			{
				foreach (Altova.TypeInfo.FacetInfo facet in member.DataType.facets.Value)
				{
					if (facet.facetName == "length" || facet.facetName == "maxLength")
						return facet.intValue; 
				}
			}
			return int.MaxValue;
		}

		protected override void InitHeader(Header header)
		{
			foreach (Altova.TypeInfo.MemberInfo member in tableType.Members)
			{
				header.Add(
					new Altova.TextParser.TableLike.ColumnSpecification(member.LocalName, getLength(member.DataType.Members\[0\])));
			}
		}
	}

	public class CSVTable : Altova.TextParser.TableLike.Table
	{
		public CSVTable(Altova.TypeInfo.TypeInfo tableType):this(tableType,0){}
		public CSVTable(Altova.TypeInfo.TypeInfo tableType, int lineend) 
			: base(false,lineend)
		{
			this.tableType = tableType;
			Init();
		}

		public Altova.TextParser.TableLike.CSV.CSVFormat Format { get { return ((Altova.TextParser.TableLike.CSV.CSVSerializer)mSerializer).Format; } }

		protected override ISerializer CreateSerializer()
		{
			return new Altova.TextParser.TableLike.CSV.CSVSerializer(this,mLineEnd);
		}

		protected override void InitHeader(Header header)
		{
			foreach (Altova.TypeInfo.MemberInfo member in tableType.Members)
			{
				header.Add(new Altova.TextParser.TableLike.ColumnSpecification(member.LocalName));
			}
		}
	}
}