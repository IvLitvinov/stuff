[call GenerateFileHeader("TextNode.cs")]
namespace Altova.TextParser
{
	/// <summary>
	/// Encapsulates a text node in a tree as needed by parsing text input files.
	/// </summary>
	public class TextNode : ITextNode
	{
		#region Implementation Detail:
		ITextNode mParent= null;
		string mName = "";
		string mValue = "";
		ITextNodeCollection mChildren = null;
		NodeClass mClass = NodeClass.Undefined;
		#endregion
		#region Public Interface:
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="parent">the parent of this node</param>
		/// <param name="name">the name this instance should have</param>
		/// <remarks>
		/// Note that this instance will be automatically added to the children of the specified parent
		/// unless it's null.
		/// </remarks>
		public TextNode(ITextNode parent, string name): this(parent, name, NodeClass.Undefined)
		{
		}
		/// <summary>
		/// Constructs an instance of this class.
		/// </summary>
		/// <param name="parent">the parent of this node</param>
		/// <param name="name">the name this instance should have</param>
		/// <param name="eClass">the name of the node's class</param>
		/// <remarks>
		/// Note that this instance will be automatically added to the children of the specified parent
		/// unless it's null.
		/// </remarks>
		public TextNode(ITextNode parent, string name, NodeClass eClass)
		{
			mName= name;
			mParent = parent;
			if (mParent != null)
				mParent.Children.Add(this);
			mClass = eClass;
		}
		/// <summary>
		/// Gets the root node of the hierarchy where this instance resides.
		/// If this instance has no parent (<see cref="Parent"/>==null),
		/// it's its own root node.
		/// </summary>
		public virtual ITextNode Root
		{
			get
			{
				if (mParent == null) return this;
				else return mParent.Root;
			}
		}
		/// <summary>
		/// Gets the parent node of this instance. May return null if the node has no parent.
		/// </summary>
		public virtual ITextNode Parent
		{
			get
			{
				return mParent;
			}
			set
			{
				mParent = value;
			}
		}
		/// <summary>
		/// Searches for a node with the specfied name moving upwards in the tree.
		/// </summary>
		/// <param name="name">the name of the node to search for</param>
		/// <returns>the first node matching the specified name or null if no match was found</returns>
		public virtual ITextNode SearchUpwardsByName(string name)
		{
			if (name == mName) return this;
			return mParent.SearchUpwardsByName(name);
		}
		/// <summary>
		/// Gets the children of this instance.
		/// </summary>
		public virtual ITextNodeCollection Children
		{
			get
			{
				if (mChildren == null)
					mChildren = new TextNodeCollection(this);
				return mChildren;
			}
		}
		/// <summary>
		/// Get/sets the name of this instance.
		/// </summary>
		public virtual string Name
		{
			get
			{
				return mName;
			}
			set
			{
				mName = value;
			}
		}
		/// <summary>
		/// Get/sets the value of this instance.
		/// </summary>
		public virtual string Value
		{
			get
			{
				return mValue;
			}
			set
			{
				mValue = value;
			}
		}

		/// <summary>
		/// Get/sets the kind of this instance.
		/// </summary>
		public NodeClass Class
		{
			get
			{
				return mClass;
			}
			set
			{
				mClass = value;
			}
		}
		#endregion
	}

}