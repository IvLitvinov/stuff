[call GenerateFileHeader($module & ".cs")

$BaseType = "Altova.Xml.TypeBase"
$NodeKind = "System.Xml.XmlNode"
$DocumentKind = "System.Xml.XmlDocument"
$FallbackStringHandler = "Altova.Xs.XsString"
$Operations = "Altova.Xml.XmlTreeOperations"

sub  WriteEnumConstants($facets)
	if $facets <> 0 and $facets.Enumeration.Length > 0]
		public enum EnumValues
		{
[			foreach $enum in $facets.Enumeration
]			[=$enum.Name] = [=$enum.Index], // [=$enum.Value]
[			next
]			Invalid = -1, // Invalid value
		};
[	endif
endsub

sub BeginNamespace($namespace)
	if $namespace.CodeName <> ""
]
namespace [=$namespace.CodeName]
{	
[
	endif
endsub


sub EndNamespace($namespace)
	if $namespace.CodeName <> ""
]
} // namespace [=$namespace.CodeName]

[
	endif
endsub

sub GetMemberType($member)
	if $member.DataType.Namespace.CodeName = ""
		return $member.DataType.CodeName
	else
		return $member.DataType.Namespace.CodeName & "." & $member.DataType.CodeName
	endif
endsub

sub instantiateAttributes(byref $att)
	if $att.LocalName <> ""
		$attTargetType = ""
		if $att.DataType.IsNativeBound
			$attTargetType = $att.DataType.NativeBinding.ValueType
		else
			$attTargetType = "string"
		endif
		$attFullTargetType = "MemberAttribute_" & $att.CodeName
]			[=$att.CodeName] = new [=$attFullTargetType] (this, [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($att)]\]);
[	endif
endsub	


sub GetCastName($type)
	switch $type
	case "sbyte"
	case "short"
	case "int"
		return "CastToInt"
	case "long"
		return "CastToInt64"
	case "double"
	case "float"
		return "CastToDouble"
	case "string"
		return "CastToString"
	case "ushort"
	case "byte"
	case "uint"
		return "CastToUInt"
	case "ulong"
		return "CastToUInt64"
	case "bool"
		return "CastToBool"
	case "Altova.Types.DateTime"
		return "CastToDateTime"
	case "Altova.Types.Duration"
		return "CastToDuration"
	case "decimal"
		return "CastToDecimal"
	case "byte\[\]"
		return "CastToBinary"
	endswitch
	return "CastToString"
endsub

sub defineAttributes(byref $att)
	$attTargetType = ""
	$attTargetTypeHandler = ""
	if $att.DataType.IsNativeBound
		$attTargetType = $att.DataType.NativeBinding.ValueType
		$attTargetTypeHandler = $att.DataType.NativeBinding.ValueHandler
	else
		$attTargetType = "string"
		$attTargetTypeHandler = $FallbackStringHandler
	endif
	$attFullTargetType = "MemberAttribute_" & $att.CodeName
	if $att.LocalName = ""	
		' the special text() member	

		'Enumeration
		$facets = $att.DataType.Facets
		if $facets <> 0 and $facets.Enumeration.Length > 0
			$enumOffset = GetEnumOffset($facets)
			call WriteEnumConstants($facets)]

		public EnumValues EnumerationValue
		{
			get
			{
				Altova.TypeInfo.MemberInfo member = [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($att)]\];			
				return (EnumValues)GetEnumerationIndex(member, [=$Operations].CastToString(Node, member), [=$enumOffset], [=$facets.Enumeration.Length]);
			}
			
			set
			{
				Altova.TypeInfo.MemberInfo member = [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($att)]\];			
				if( (int)value >= 0 && (int)value < [=$facets.Enumeration.Length]) ['as the offset is added to the value we have to check for index bounds ourself]
					[=$Operations].SetValue(Node, member, member.DataType.facets.Value\[(int)value + [=$enumOffset]\].stringValue);
				else
					throw new System.IndexOutOfRangeException();
			}
		}
[		endif
]		public [=$attTargetType] Value
		{
			get 
			{
				Altova.TypeInfo.MemberInfo member = [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($att)]\];
				return ([=$attTargetType])[=$Operations].[=GetCastName($attTargetType)](Node, member);
			}
			set
			{
				Altova.TypeInfo.MemberInfo member = [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($att)]\];
				[=$Operations].SetValue(Node, member, value);
			}
		}
[	else
		'normal attribute
]		public [=$attFullTargetType] [=$att.CodeName];
		public class [=$attFullTargetType]
		{
			private [=$BaseType] owner;
			private Altova.TypeInfo.MemberInfo info; 
			public [=$attFullTargetType] ([=$BaseType] owner, Altova.TypeInfo.MemberInfo info) {this.owner = owner; this.info = info;}
			public [=$attTargetType] Value { get {
				return ([=$attTargetType])[=$Operations].[=GetCastName($attTargetType)]([=$Operations].FindAttribute(owner.Node, info), info);			
			}
			set {	
				[=$Operations].SetValue(owner.Node, info, value);		
			} }
			public bool Exists() {return owner.GetAttribute(info) != null;}
			public void Remove() {owner.RemoveAttribute(info);} 

			public Altova.Xml.Meta.Attribute Info { get { return new Altova.Xml.Meta.Attribute(info); } }
[		'Enumeration
		$facets = $att.DataType.Facets
		if $facets <> 0 and $facets.Enumeration.Length > 0
			$enumOffset = GetEnumOffset($facets)]

			public [=GetMemberType($att)].EnumValues EnumerationValue
			{
				get
				{			
					return ([=GetMemberType($att)].EnumValues)GetEnumerationIndex(info, [=$Operations].CastToString([=$Operations].FindAttribute(owner.Node, info), info), [=$enumOffset], [=$facets.Enumeration.Length]);
				}
				
				set
				{
					if( (int)value >= 0 && (int)value < [=$facets.Enumeration.Length]) ['as the offset is added to the value we have to check for index bounds ourself]
						[=$Operations].SetValue(owner.Node, info, info.DataType.facets.Value\[(int)value + [=$enumOffset]\].stringValue);
					else
						throw new System.IndexOutOfRangeException();
				}
			}
[		endif
]		}
[	endif
endsub

]		
namespace [=$module]
{
	abstract class EnumeratorBase : System.Collections.IEnumerator
	{
		System.Collections.IEnumerator inner;

		protected object InnerCurrent { get { return inner.Current; } }

		public EnumeratorBase(System.Collections.IEnumerator inner)
		{
			this.inner = inner;
		}

		public abstract object Current { get; }// { return new NumberType((System.Xml.XmlNode)inner.Current); } }
		public bool MoveNext() { return inner.MoveNext(); }
		public void Reset() { inner.Reset(); }
	}


[foreach $namespace in $TheLibrary.SchemaNamespaces
	call BeginNamespace($namespace)
	foreach $type in $namespace.Types
]	public class [=$type.CodeName] [
		if $type.IsDerivedByExtension
			$filterinherited = true
]: [if $type.BaseType.Namespace.CodeName <> ""][=$type.BaseType.Namespace.CodeName].[endif][=$type.BaseType.CodeName]
[		else
			$filterinherited = false
]: [		if $type.IsSimpleType or $type.IsDocumentRootType
				][=$BaseType][
			else
				]Altova.Xml.ElementType[
			endif]
[		endif
]	{
[	if $type.IsSimpleType
]		public static Altova.Xml.Meta.SimpleType StaticInfo { get { return new Altova.Xml.Meta.SimpleType([
	else
]		public static [if $filterinherited]new [endif]Altova.Xml.Meta.ComplexType StaticInfo { get { return new Altova.Xml.Meta.ComplexType([
	endif
][=$module]_TypeInfo.binder.Types\[[=$module]_TypeInfo.[=BuildTypeInfoIndexName($type)]\]); }}

[	if $type.IsDocumentRootType
]
		public static [=$type.CodeName] LoadFromFile(string filename) 
		{
			return new [=$type.CodeName]([=$Operations].LoadDocument(filename));			
		}

		public static [=$type.CodeName] LoadFromString(string xmlstring) 
		{
			return new [=$type.CodeName]([=$Operations].LoadXml(xmlstring));			
		}

		public static [=$type.CodeName] LoadFromBinary(byte\[\] binary) 
		{
			return new [=$type.CodeName]([=$Operations].LoadXmlBinary(binary));			
		}

		public void SaveToFile(string filename, bool prettyPrint)
		{
			SaveToFileWithLineEnd(filename, prettyPrint, false, "\\r\\n");
		}

		public void SaveToFile(string filename, bool prettyPrint, bool omitXmlDecl)
		{
			SaveToFileWithLineEnd(filename, prettyPrint, omitXmlDecl, "\\r\\n");
		}

		public void SaveToFileWithLineEnd(string filename, bool prettyPrint, bool omitXmlDecl, string lineend)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			if (doc.FirstChild is System.Xml.XmlDeclaration) 
			{
				string encoding = ((System.Xml.XmlDeclaration) doc.FirstChild).Encoding;
				if( encoding == System.String.Empty )
					[=$Operations].SaveDocument(doc, filename, "UTF-8", false, false, prettyPrint, omitXmlDecl, lineend);
				else
					[=$Operations].SaveDocument(doc, filename, encoding, prettyPrint, omitXmlDecl, lineend);
			}
			else
				[=$Operations].SaveDocument(doc, filename, "UTF-8", false, false, prettyPrint, omitXmlDecl, lineend);
		}

		public void SaveToFile(string filename, bool prettyPrint, bool omitXmlDecl, string encoding)
		{
			SaveToFile( filename, prettyPrint, omitXmlDecl, encoding, "\\r\\n" );
		}

		public void SaveToFile(string filename, bool prettyPrint, string encoding, string lineend)
		{
			SaveToFile( filename, prettyPrint, false, encoding, lineend );
		}

		public void SaveToFile(string filename, bool prettyPrint, bool omitXmlDecl, string encoding, string lineend)
		{
			SaveToFile( filename, prettyPrint, omitXmlDecl, encoding, System.String.Compare(encoding, "UTF-16BE", true) == 0, System.String.Compare(encoding, "UTF-16", true) == 0, lineend );
		}

		public void SaveToFile(string filename, bool prettyPrint, bool omitXmlDecl, string encoding, bool bBigEndian, bool bBOM, string lineend)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			[=$Operations].SaveDocument(doc, filename, encoding, bBigEndian, bBOM, prettyPrint, omitXmlDecl, lineend);
		}

		public string SaveToString(bool prettyPrint)
		{
			return SaveToString( prettyPrint, false);
		}

		public string SaveToString(bool prettyPrint, bool omitXmlDecl)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			return [=$Operations].SaveXml(doc, prettyPrint, omitXmlDecl);
		}

		public byte\[\] SaveToBinary(bool prettyPrint)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			if (doc.FirstChild is System.Xml.XmlDeclaration) 
			{
				string encoding = ((System.Xml.XmlDeclaration) doc.FirstChild).Encoding;
				if( encoding == System.String.Empty )
					return [=$Operations].SaveXmlBinary(doc, "UTF-8", false, false, prettyPrint);
				else
					return [=$Operations].SaveXmlBinary(doc, encoding, prettyPrint);
			}
			else
				return [=$Operations].SaveXmlBinary(doc, "UTF-8", false, false, prettyPrint);
		}

		public byte\[\] SaveToBinary(bool prettyPrint, string encoding)
		{
			return SaveToBinary( prettyPrint, encoding, System.String.Compare(encoding, "UTF-16BE", true) == 0, System.String.Compare(encoding, "UTF-16", true) == 0 );
		}

		public byte\[\] SaveToBinary(bool prettyPrint, string encoding, bool bBigEndian, bool bBOM)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			return [=$Operations].SaveXmlBinary(doc, encoding, bBigEndian, bBOM, prettyPrint);
		}

		public static [=$type.CodeName] CreateDocument()
		{	
			return CreateDocument("UTF-8");
		}

		public static [=$type.CodeName] CreateDocument(string encoding)
		{
			[=$DocumentKind] doc = new [=$DocumentKind]();
			doc.AppendChild(doc.CreateXmlDeclaration("1.0", encoding, null));
			return new [=$type.CodeName](doc);
		}

		public void SetDTDLocation(string dtdLocation)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			string publicId = null;
			string internalSubset = null;
			if (doc.DocumentElement == null)
				throw new System.InvalidOperationException("SetDTDLocation requires a root element.");
			if (doc.DocumentType != null)
			{
				publicId = doc.DocumentType.PublicId;
				internalSubset = doc.DocumentType.InternalSubset;

				doc.RemoveChild(doc.DocumentType);
			}
			doc.InsertBefore(doc.DocumentElement, doc.CreateDocumentType(doc.DocumentElement.Name, publicId, dtdLocation, internalSubset));
		}

		public void SetSchemaLocation(string schemaLocation)
		{
			[=$DocumentKind] doc = ([=$DocumentKind]) Node;
			if (doc.DocumentElement == null)
				throw new System.InvalidOperationException("SetSchemaLocation requires a root element.");
			System.Xml.XmlAttribute att;
			if (doc.DocumentElement.NamespaceURI == "")
			{
				att = doc.CreateAttribute("xsi", "noNamespaceSchemaLocation", "http://www.w3.org/2001/XMLSchema-instance");
				att.Value = schemaLocation;
			}	
			else
			{
				att = doc.CreateAttribute("xsi", "schemaLocation", "http://www.w3.org/2001/XMLSchema-instance");
				att.Value = doc.DocumentElement.NamespaceURI + " " + schemaLocation;
			}
			doc.DocumentElement.Attributes.Append(att);
		}

		static public void DeclareAllNamespacesFromSchema(Altova.Xml.ElementType node)
		{
			foreach (var ns in [=$module]_TypeInfo.binder.Namespaces)
				if (ns.namespaceURI != "")
					node.DeclareNamespace(ns.prefix, ns.namespaceURI);
		}

[	endif
	'Enumerations
	if $type.IsSimpleType
		call WriteEnumConstants($type.Facets)
	endif
]
		public [=$type.CodeName]([=$NodeKind] init) : base(init)
 		{
			instantiateMembers();
		} 
		
		private void instantiateMembers()
		{
[foreach $att in $type.Attributes
	if $att.CodeName <> "" and (not $filterinherited or $att.DeclaringType = $att.ContainingType)
		'if $att.DataType.IsDerivedByUnion
			'foreach $nativeBinding in $type.NativeBindings
				'call instantiateAttributes($att, $att.DataType)
			'next
		'else
			call instantiateAttributes($att)
		'endif
	endif
next]
[foreach $el in $type.Elements
	if $el.CodeName <> "" and (not $filterinherited or $el.DeclaringType = $el.ContainingType)
		$elTargetType = "MemberElement_" & $el.CodeName
]			[=$el.CodeName] = new [=$elTargetType] (this, [=$module]_TypeInfo.binder.Members\[[=$module]_TypeInfo.[=BuildMemberInfoIndexName($el)]\]);
[
	endif
next
]		}

[
if not $type.IsSimpleType
]		internal [if $filterinherited]new [endif]class Enumerator : EnumeratorBase { 
			public Enumerator(System.Collections.IEnumerator inner) : base(inner) {}
			public override object Current { get { return new [=$type.CodeName](([=$NodeKind])InnerCurrent); } }
		}
[
endif
]
		// Attributes
[foreach $att in $type.Attributes
	if (not $filterinherited or $att.DeclaringType = $att.ContainingType)
		'if $att.DataType.IsDerivedByUnion
			'foreach $nativeBinding in $type.DataType.NativeBindings
			'	call instantiateAttributes($att, $att.DataType)
			'next
		'else
			call defineAttributes($att)
		'endif
	endif
next]

		// Elements
[foreach $el in $type.Elements
	if $el.CodeName <> "" and (not $filterinherited or $el.DeclaringType = $el.ContainingType)
]	
		public MemberElement_[=$el.CodeName] [=$el.CodeName];
		public class MemberElement_[=$el.CodeName] : System.Collections.IEnumerable
		{
			private [=$BaseType] owner;
			private Altova.TypeInfo.MemberInfo info;
			public MemberElement_[=$el.CodeName] ([=$BaseType] owner, Altova.TypeInfo.MemberInfo info) { this.owner = owner; this.info = info;}
			public [=GetMemberType($el)] this \[int i\] { get { return At(i);} } 
			public [=GetMemberType($el)] At(int index) {return new [=GetMemberType($el)](owner.GetElementAt(info, index));}
			public [=GetMemberType($el)] First { get  {return new [=GetMemberType($el)](owner.GetElementFirst(info));} }
			public [=GetMemberType($el)] Last { get {return new [=GetMemberType($el)](owner.GetElementLast(info));} }
			public [=GetMemberType($el)] Append(){return new [=GetMemberType($el)](owner.CreateElement(info));}
			public [=GetMemberType($el)] AppendWithPrefix(string prefix) {return new [=GetMemberType($el)](owner.CreateElement(prefix, info.LocalName, info.NamespaceURI));}
			public bool Exists { get {return Count > 0;} }
			public int Count { get {return owner.CountElement(info);} }
			public void Remove() {owner.RemoveElement(info);}
			public void RemoveAt(int index) { owner.RemoveElementAt(info, index); }

			public System.Collections.IEnumerator GetEnumerator()
			{
				return new [=GetMemberType($el)].Enumerator(Altova.Xml.XmlTreeOperations.GetElements(owner.Node, info).GetEnumerator());
			}

			public Altova.Xml.Meta.Element Info { get { return new Altova.Xml.Meta.Element(info); } }
		}[
	endif
next
if not $type.IsSimpleType
	$useType = $type
	if $useType.IsAnonymous
		foreach $att in $type.Attributes
			if $att.LocalName = ""
				$useType = $att.DataType
			endif
		next
	endif
	if not $useType.IsAnonymous
]	
		public [if $filterinherited]new [endif]void SetXsiType() 
		{ 
			[=$Operations].SetAttribute(Node, "xsi:type", "http://www.w3.org/2001/XMLSchema-instance", 
				new System.Xml.XmlQualifiedName([=$useType.LocalName.LiteralJava], [=$useType.Namespace.NamespaceURI.LiteralJava])); 				
		}
[	endif
endif

]		
	} // class [=$type.CodeName]

[	next
	call EndNamespace($namespace)
next
]
}
