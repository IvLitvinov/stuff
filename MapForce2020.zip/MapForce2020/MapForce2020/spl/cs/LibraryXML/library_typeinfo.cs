// [=$module]_typeinfo.cs
// This file contains generated code and will be overwritten when you rerun code generation.

//using <some stuff>
[
call GenerateTypeInfo($TheLibrary)
' to isolate local variables

sub GenerateTypeInfo($library)
]
using System;
using Altova.TypeInfo;

namespace [=$module]
{
	public class [=$module]_TypeInfo
	{
		// namespaces indices
[	$enum = 0
foreach $namespace in $library.SchemaNamespaces
]		public static readonly int [=BuildNamespaceInfoIndexName($namespace)] = [=$enum];
[	$enum = $enum+1;
next]

		// typeinfo indices
[$enum = 0
$previous = ""
foreach $namespace in $library.SchemaNamespaces
	$name = CombineNames("_altova_tif", $namespace.CodeName)
]		public static readonly int [=$name][if $previous <> ""] = [=$previous][else] = [=$enum] [$enum = $enum+1 : endif];
[	
	$previous = $name
	foreach $type in $namespace.Types
]		public static readonly int [=BuildTypeInfoIndexName($type)][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];
[		$previous = ""
	next
	$name = CombineNames("_altova_til", $namespace.CodeName)
]		public static readonly int [=$name][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];

[	
	$previous = $name
next
]

		// memberinfo indices
[$enum = 0
$previous = ""
foreach $namespace in $library.SchemaNamespaces
	foreach $type in $namespace.Types
		$name = CombineNames(CombineNames(CombineNames("_altova_mif", $namespace.CodeName), "altova"), $type.CodeName)
]		public static readonly int [=$name][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];
[		$previous = $name
		foreach $att in $type.Attributes
]		public static readonly int [=BuildMemberInfoIndexName($att)][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];
[			$previous = ""
		next ' $att
		foreach $el in $type.Elements
]		public static readonly int [=BuildMemberInfoIndexName($el)][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];
[			$previous = ""
		next ' $el
		$name = CombineNames(CombineNames(CombineNames("_altova_mil", $namespace.CodeName), "altova"), $type.CodeName)
]		public static readonly int [=$name][if $previous <> ""] = [=$previous] [else] = [=$enum] [$enum = $enum+1 : endif];

[		
		$previous = $name
	next ' $class
next ' $namespace
]	

		public class InfoBinder : InfoBinderInterface
		{
			public NamespaceInfo\[\] Namespaces { get {return namespaces;} }
			public TypeInfo\[\] Types { get { return types;} }
			public MemberInfo\[\] Members { get { return members;} }
		}
	
		public static InfoBinderInterface binder = new InfoBinder();
		
		// array of all namespaces with poin... references to types
		public static NamespaceInfo\[\] namespaces = 
		{
[		foreach $namespace in $library.SchemaNamespaces
]			new NamespaceInfo(binder, [=$namespace.NamespaceURI.LiteralJava], [=$namespace.LocalName.LiteralJava], [=CombineNames("_altova_tif", $namespace.CodeName)], [=CombineNames("_altova_til", $namespace.CodeName)]),
[		next
]		};

		// array of all types with references to members
		public static TypeInfo\[\] types = 
		{
[	foreach $namespace in $library.SchemaNamespaces
		foreach $class in $namespace.Types
]			new TypeInfo( binder, [=BuildNamespaceInfoIndexName($class.Namespace)], [=$class.LocalName.LiteralJava], [
		if $class.IsDerived ][=BuildTypeInfoIndexName($class.BaseType)][else]0[endif
			$basename = CombineNames(CombineNames($namespace.CodeName, "altova"), $class.CodeName)
		], [=CombineNames("_altova_mif", $basename)], [=CombineNames("_altova_mil", $basename)], [
			if $class.IsSimpleType and $class.Facets <> 0] 
				new Lazy<FacetInfo\[\]>(() => new FacetInfo\[\]
				{
[					foreach $facet in $class.Facets.List
					$checker = $facet.FacetCheckerName
					if $checker = "" 
						$checker = "null"
					endif
					switch $facet.FacetType
					case "valuespace-length"
]					new FacetInfo ([=$checker], [=$facet.LocalName.LiteralJava], "[=$facet.FacetValue]", [=$facet.FacetValue] ), 
[					case "valuespace-enum"
					case "lexicalspace"
					case "valuespace-range"
]					new FacetInfo ([=$checker], [=$facet.LocalName.LiteralJava], [=$facet.FacetValue.LiteralJava], 0 ), 
[					default
]					new FacetInfo ([=$checker], [=$facet.LocalName.LiteralJava], [=$facet.FacetValue.LiteralJava], 0 ),
[					endswitch		
				next
]				}),
[			else
				] null, [
			endif
]				[
			if $class.IsSimpleType
				switch $class.Whitespace
				case "preserve"
					write "WhitespaceType.Preserve"
				case "replace"
					write "WhitespaceType.Replace"
				case "collapse"
					write "WhitespaceType.Collapse"
				default
					write "WhitespaceType.Unknown"
				endswitch
				if $class.IsNativeBound
					write ", " & $class.NativeBinding.ValueHandler
				endif
			else
				write "WhitespaceType.Unknown"
				foreach $member in $class.Attributes 
					if $member.LocalName = ""
						if $member.DataType.IsNativeBound
							write ", " & $member.DataType.NativeBinding.ValueHandler
						endif
					endif
				next
			endif

			] ),
[		next
]
[	next
]			
		};
		
		// array of all members
		public static MemberInfo\[\] members = 
		{
[	foreach $namespace in $library.SchemaNamespaces
		foreach $class in $namespace.Types
			$emitempty = false
			foreach $member in $class.Attributes
				$emitempty = true
				$flags = "MemberFlags.None"
				if $member.IsSpecialName
					$flags = $flags & "|MemberFlags.SpecialName"
				endif
				$flags = $flags & "|MemberFlags.IsAttribute"
]			new MemberInfo (binder, [=$member.NamespaceURI.LiteralJava], [=$member.LocalName.LiteralJava], [=BuildTypeInfoIndexName($class)], [=BuildTypeInfoIndexName($member.DataType)], [=$flags], [=$member.MinOccurs], [=$member.MaxOccurs]),
[			next
			foreach $member in $class.Elements
				$emitempty = true
				$flags = "MemberFlags.None"
				if $member.IsSpecialName
					$flags = $flags & "|MemberFlags.SpecialName"
				endif
]			new MemberInfo (binder, [=$member.NamespaceURI.LiteralJava], [=$member.LocalName.LiteralJava], [=BuildTypeInfoIndexName($class)], [=BuildTypeInfoIndexName($member.DataType)], [=$flags], [=$member.MinOccurs], [=$member.MaxOccurs]),
[			next
			if $emitempty
]
[			endif
		next
	next
]		};	
	}
}
[
endsub  ' GenerateTypeInfo
]