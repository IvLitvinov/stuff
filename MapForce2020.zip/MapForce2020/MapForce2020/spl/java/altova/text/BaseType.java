[call GenerateFileHeader("BaseType.java")]
package com.altova.text;

public class BaseType {
	protected ITextNode m_Node = null;

	public ITextNode getNode() {
		return m_Node;
	}

	public BaseType(ITextNode node) {
		m_Node = node;
	}
}