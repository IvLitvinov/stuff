[call GenerateFileHeader("ITextNode.java")]
package com.altova.text;

public interface ITextNode {
	final static byte Undefined = 0;

	final static byte DataElement = 1;

	final static byte Composite = 2;

	final static byte Segment = 3;

	final static byte Group = 4;
	
	final static byte SubComposite = 5;
	
	final static byte ErrorList = 6;

	final static byte Select = 7;

	ITextNode getRoot();

	ITextNode getParent();

	void setParent(ITextNode rhs);

	ITextNodeList getChildren();

	String getName();

	void setName(String name);

	String getValue();

	void setValue(String value);

	byte getNodeClass();

	void setNodeClass(byte rhs);
}