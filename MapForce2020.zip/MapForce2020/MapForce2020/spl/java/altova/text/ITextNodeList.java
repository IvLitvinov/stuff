[call GenerateFileHeader("ITextNodeList.java")]
package com.altova.text;

public interface ITextNodeList {
	void add(ITextNode rhs);

	int size();

	ITextNode getAt(int index);

	boolean contains(ITextNode rhs);

	TextNodeList filterByName(String name);

   	void removeByName(String name);

	void insertAt(ITextNode rhs, int index);

	void removeAt(int index);

	public ITextNode getFirstNodeByName(String name);

	public ITextNode getLastNodeByName(String name);

	public void moveNode(ITextNode node, int index);
}