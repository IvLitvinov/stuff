[call GenerateFileHeader("TableAsMFNodeAdapter.java")]
package com.altova.text;

import javax.xml.namespace.QName;
import com.altova.mapforce.IEnumerable;
import com.altova.mapforce.IEnumerator;
import com.altova.mapforce.IMFNode;
import com.altova.mapforce.MFNode;
import com.altova.mapforce.IMFDocumentNode;
import com.altova.mapforce.MFEmptySequence;
import com.altova.mapforce.MFSingletonSequence;
import com.altova.mapforce.MFNodeByKindAndQNameFilter;
import com.altova.mapforce.MFNodeByKindAndNodeNameFilter;

import com.altova.text.tablelike.ColumnSpecification;
import com.altova.text.tablelike.Header;
import com.altova.text.tablelike.Record;
import com.altova.text.tablelike.Table;

public class TableAsMFNodeAdapter implements IMFNode, IMFDocumentNode {
	static class FieldAdapter implements IMFNode {
		private ColumnSpecification spec;
		String value;
		
		public FieldAdapter(ColumnSpecification spec, String value) {this.spec=spec; this.value=value;}
		public String getLocalName() {return spec.getName();}
		public String getNamespaceURI() {return "";}
		public String getPrefix() {return "";}
		public String getNodeName() { return spec.getName(); }
		public int getNodeKind() {return MFNodeKind_Element;}
		public QName getQName() {return new QName(getNamespaceURI(), getLocalName());}

		public IEnumerable select(int mfQueryKind, Object query) {
			switch (mfQueryKind) {
				case MFQueryKind_All:
				case MFQueryKind_AllChildren:
					return new MFSingletonSequence(value);
				case MFQueryKind_AllAttributes:
				case MFQueryKind_AttributeByQName:
				case MFQueryKind_ChildrenByQName:
				case MFQueryKind_ChildrenByNodeName:
					return new MFEmptySequence();

				case MFQueryKind_SelfByQName:
					if (((QName)query).getLocalPart().equals(spec.getName()))
						return new MFSingletonSequence(this);
					else
						return new MFEmptySequence();

				default:
					throw new UnsupportedOperationException("Unsupported query type.");
			}
		}

		public String value() throws Exception {
			return value;
		}
		
		public javax.xml.namespace.QName qnameValue() {
			return null;
		}
		
		public Object typedValue() throws Exception {
			return MFNode.collectTypedValue(select(IMFNode.MFQueryKind_AllChildren, null));
		}
	}
	
	static class FieldsAdapter implements IEnumerable {
		static class Enumerator implements IEnumerator {
			private Header header;
			private Record record;
			private int index = -1;
			private int pos = 0;
			
			public Enumerator(Header header, Record record) {this.record=record; this.header = header;}

			public Object current() {
				if (index < 0 || index >= header.size())
					throw new UnsupportedOperationException("Out of bounds.");						

				return new FieldAdapter(header.getAt(index), record.getAt(index));
			}
			
			public int position() {return pos;}

			public boolean moveNext() throws Exception {
				while (true) {
					if (++index >= header.size()) {
						index = header.size();
						return false;
					}
					if (record.getAt(index) != null) {
						pos++;
						return true;
					}
				}
			}
			
			public void close() {}
		}
		
		private Header header;
		private Record record;
		
		public FieldsAdapter(Header header, Record record) {this.record=record; this.header = header;}

		public IEnumerator enumerator() throws Exception {return new Enumerator(header, record);}
	}
	
	static class RecordAdapter implements IMFNode {
		private Header header;
		private Record record;
		public RecordAdapter(Header header, Record record) { this.header = header; this.record = record; }
		public String getLocalName() {return "Rows";}
		public String getNamespaceURI() {return "";}
		public String getPrefix() {return "";}
		public String getNodeName() { return "Rows"; }
		public int getNodeKind() {return IMFNode.MFNodeKind_Element;}
		public QName getQName() {return new QName(getNamespaceURI(), getLocalName());}
		public IEnumerable select(int mfQueryKind, Object query) {
			switch (mfQueryKind) {
				case MFQueryKind_All:
				case MFQueryKind_AllChildren:
					return new FieldsAdapter(header, record);
				case MFQueryKind_ChildrenByQName:
					return new MFNodeByKindAndQNameFilter(select(MFQueryKind_AllChildren, null), MFNodeKind_Element,
						(QName) query);
				case MFQueryKind_ChildrenByNodeName:
					return new MFNodeByKindAndNodeNameFilter(select(MFQueryKind_AllChildren, null), MFNodeKind_Element,
						(String) query);

				case MFQueryKind_AttributeByQName:
					return new MFNodeByKindAndQNameFilter(select(MFQueryKind_AllAttributes, null), MFNodeKind_Attribute,
						(QName)query);

				case MFQueryKind_SelfByQName:
					if (((QName)query).getLocalPart().equals("Rows"))
						return new MFSingletonSequence(this);
					else
						return new MFEmptySequence();

				case MFQueryKind_AllAttributes:
					return new MFEmptySequence();

				default:
					throw new UnsupportedOperationException("Unsupported query type.");
			}
		}
		public String value() throws Exception {
			return null;
		}
		
		public javax.xml.namespace.QName qnameValue() {
			return null;
		}	
		
		public Object typedValue() throws Exception {
			return MFNode.collectTypedValue(select(IMFNode.MFQueryKind_AllChildren, null));
		}
	}
	
	static class RecordsAdapter implements IEnumerable {
		static class Enumerator implements IEnumerator {
			private Table table;
			private int index = -1;
			private int pos = 0;
			
			public Enumerator(Table table) { this.table = table; }
			
			public boolean moveNext() {
				if (++index >= table.size()) {
					index = table.size();
					return false;
				}
				pos++;
				return true;
			}
			
			public Object current() {
				if (index < 0 || index >= table.size()) throw new UnsupportedOperationException("You're way out of line, young man!");
				return new RecordAdapter(table.getHeader(), table.getAt(index));
			}
			
			public int position() {return pos;}
			
			public void close() {}
		}
		
		private Table table;
		
		public RecordsAdapter(Table table) { this.table = table; }
		public IEnumerator enumerator() {return new Enumerator(table);}
	}
	Table table;
	String filename;
	
	public TableAsMFNodeAdapter(Table table, String filename) {this.table = table; this.filename = filename;}
	public String getDocumentUri() {return filename;}
	public String getLocalName() {return "";}
	public String getNamespaceURI() {return "";}
	public String getPrefix() {return "";}
	public String getNodeName() { return ""; }

	public int getNodeKind() {return IMFNode.MFNodeKind_Element;}
	public QName getQName() {return new QName(getNamespaceURI(), getLocalName());}

	public IEnumerable select(int mfQueryKind, Object query) {
		switch (mfQueryKind) {
			case MFQueryKind_All:
			case MFQueryKind_AllAttributes:
			case MFQueryKind_AttributeByQName:
			case MFQueryKind_SelfByQName:
				return new MFEmptySequence();

			case MFQueryKind_AllChildren:
			case MFQueryKind_ChildrenByQName:
			case MFQueryKind_ChildrenByNodeName:
				return new RecordsAdapter(table);

			default:
				throw new UnsupportedOperationException("Unsupported query type.");
		}
	}

	public String value() throws Exception {
		return null;
	}
	
	public javax.xml.namespace.QName qnameValue() {
		return null;
	}
	
	public Object typedValue() throws Exception {
		return MFNode.collectTypedValue(select(IMFNode.MFQueryKind_AllChildren, null));
	}
}

