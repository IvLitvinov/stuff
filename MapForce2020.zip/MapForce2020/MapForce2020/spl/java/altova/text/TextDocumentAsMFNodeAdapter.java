[call GenerateFileHeader("TextDocumentAsMFNodeAdapter.java")]

package com.altova.text;

import com.altova.mapforce.IMFDocumentNode;

public class TextDocumentAsMFNodeAdapter extends TextNodeAsMFNodeAdapter implements IMFDocumentNode {
	private String filename;
	
	public TextDocumentAsMFNodeAdapter(ITextNode node, String filename) {
		super(node);
		this.filename = filename;
	}
	
	public String getDocumentUri() {return filename;}
}
