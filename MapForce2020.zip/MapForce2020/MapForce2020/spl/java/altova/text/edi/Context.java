[call GenerateFileHeader("Context.java")]
package com.altova.text.edi;

import com.altova.text.Generator;

public class Context
{
	Particle mParticle;
	Parser mParser;
	Scanner mScanner;
	Generator mGenerator;
	Context mParent = null;

	public Particle getParticle() {
		return mParticle;
	}

	public Parser getParser() {
		return mParser;
	}

	public Scanner getScanner() {
		return mScanner; 
	}

	public Generator getGenerator() {
		return mGenerator; 
	}

	public Context getParent() {
		return mParent; 
	}

	public Context (Parser parser, Scanner scanner, Particle rootParticle, Generator generator)
	{
		this.mParticle = rootParticle;
		this.mParser = parser;
		this.mScanner = scanner;
		this.mGenerator = generator;
	}

	public Context (Context parent, Particle newParticle)
	{
		this.mParticle = newParticle;
		this.mParser = parent.mParser;
		this.mScanner = parent.mScanner;
		this.mGenerator = parent.mGenerator;
		this.mParent = parent;
	}
	
	
}