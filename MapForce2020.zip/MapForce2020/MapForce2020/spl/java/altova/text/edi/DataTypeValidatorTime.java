[call GenerateFileHeader("DataTypeValidatorTime.java")]
package com.altova.text.edi;

import com.altova.text.ITextNode;

public class DataTypeValidatorTime extends DataTypeValidator {

	public DataTypeValidatorTime (int minLength, int maxLength) {
		super (minLength, maxLength, null);
	}

	public boolean makeValidOnRead (StringBuffer s, Parser.Context context, Scanner.State beforeRead) {
		String sValue = s.toString();
		int effLen = effectiveLength(s, context.getScanner().getServiceChars().getReleaseCharacter());
		validateLength(effLen, sValue, context, beforeRead);
		if (!EDIDateTimeHelpers.IsTimeCorrect( sValue))
			context.handleError( 
				Parser.ErrorType.InvalidTime,
				ErrorMessages.GetInvalidTimeMessage(
					context.getParticle().getName(),
					sValue,
					"time"
				),
				new ErrorPosition( beforeRead ),
				sValue
			);
			
		while (Character.isWhitespace(s.charAt(0)))
			s.deleteCharAt(0);

		int len = s.length();
		s.insert(2, ':');
		if (len > 4)
			s.insert(5, ':');
		else
			s.append(":00");
		if (len > 6)
			s.insert(8, '.');

		return true;
	}

	public boolean makeValidOnWrite (StringBuffer s, ITextNode node, Writer writer, boolean esc) {
		return makeValidOnWrite(s, node, writer);
	}

	public boolean makeValidOnWrite (StringBuffer s, ITextNode node, Writer writer) {
		// TOD: local time?????
		int i=0;
		while (i < s.length())
			if (s.charAt(i) == ':' || s.charAt(i) == '.')
				s.deleteCharAt(i);
			else
				i++;

		i = s.indexOf("Z");
		if (i == -1)
			i = s.indexOf("-");
		if (i == -1)
			i = s.indexOf("+");
		if (i != -1)
			s.setLength(i);

		if (s.length() > getMaxLength()) {
			if (getMaxLength() > 6 && s.charAt(getMaxLength()) >= '5') {
				java.math.BigDecimal d = new java.math.BigDecimal("0." + s.substring(6));
				d = d.setScale(getMaxLength() - 6, java.math.RoundingMode.HALF_UP);
				s.setLength(6);
				String frac = d.toString();
				s.append(frac.substring(2));
			} else
				s.setLength(getMaxLength());
		}

		while (s.length() > 6 && s.charAt(s.length()-1) == '0')
			s.setLength(s.length()-1);

		return true;
	}
}
