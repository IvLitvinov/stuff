[call GenerateFileHeader("DataValueSubCodeListValidator.java")]
package com.altova.text.edi;

public class DataValueSubCodeListValidator extends DataValueCodeListValidator {
	int mPosOffset;
	int mPosLength;
	
	public DataValueSubCodeListValidator(boolean complete, int posOffset, int posLength, String\[\] codeList) {
		super(complete, codeList);
		mPosOffset = posOffset;
		mPosLength = posLength;
	}

	public boolean hasValue(String value) {
		if (mCodeList != null) {
			if (mPosOffset > 0) {
				value = value.substring( mPosOffset - 1, mPosOffset - 1 + mPosLength );
			}
			for (int i = 0; i < mCodeList.length; i++) {
				if (value.equals( mCodeList\[i\]))
					return true;
			}
		} else
			return true;
		
		return false;
	}

}
