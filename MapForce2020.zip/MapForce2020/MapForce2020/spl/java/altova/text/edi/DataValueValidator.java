[call GenerateFileHeader("DataValueValidator.java")]
package com.altova.text.edi;

public class DataValueValidator {

	public boolean isIncomplete() {
		return false;
	}

	public boolean hasValue(String value) {
		return true;
	}

	public String getCodeListValues() {
		return "";
	}

}
