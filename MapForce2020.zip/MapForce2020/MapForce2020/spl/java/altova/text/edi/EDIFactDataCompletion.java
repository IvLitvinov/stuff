[call GenerateFileHeader("EDIFactDataCompletion.java")]
package com.altova.text.edi;

import com.altova.text.*;

public class EDIFactDataCompletion extends DataCompletion {
		private EDIFactSettings mSettings = null;
		

		public EDIFactDataCompletion(TextDocument document, EDIFactSettings settings, String structurename) {
			super(document, structurename);
			mSettings = settings;
		}

		public void completeData(ITextNode dataroot, Particle rootParticle) {
			completeMandatory(dataroot, rootParticle);
			completeEnvelope(dataroot, rootParticle);
		}
		
		protected void completeEnvelope (ITextNode envelope, Particle rootParticle) {
			if (!envelope.getName().equals(rootParticle.getName()))
				throw new com.altova.AltovaException("completeEnvelope: root node is not an envelope");

			Particle interchangeParticle = rootParticle.getNode().getChildren()\[0\];
			makeSureExists(envelope, interchangeParticle.getName());

			TextNodeList interchanges = envelope.getChildren().filterByName(interchangeParticle.getName());
			for (int i=0; i< interchanges.size(); ++i)
				completeInterchange(interchanges.getAt(i), interchangeParticle);
		}

		protected void completeInterchange(ITextNode interchange, Particle interchangeParticle) {
			
			Particle interchangeHeader = interchangeParticle.getFirstChildByName("UNB") != null ? interchangeParticle.getFirstChildByName("UNB") : interchangeParticle.getFirstChildByName("UIB");
			Particle interchangeTrailer = interchangeParticle.getFirstChildByName("UNZ") != null ? interchangeParticle.getFirstChildByName("UNZ") : interchangeParticle.getFirstChildByName("UIZ");
			Particle group = interchangeParticle.getFirstChildByName("Group");

			if (interchangeHeader != null && interchangeTrailer != null) {
				
				ITextNode header = interchange.getChildren().getFirstNodeByName(interchangeHeader.getName());
				ITextNode trailer = interchange.getChildren().getLastNodeByName(interchangeTrailer.getName());
				if (header == null && trailer == null) {
					if (group != null)
						makeSureExists(interchange, group.getName());
				} else {
					header = makeSureExists(interchange, interchangeHeader.getName());
					if (group != null)
						makeSureExists(interchange, group.getName());
					trailer = makeSureExists(interchange, interchangeTrailer.getName());
				}
								
				if (group != null) {
					ITextNodeList groups = interchange.getChildren().filterByName("Group");
					for (int i=0; i< groups.size(); ++i)
						completeGroup(groups.getAt(i), group);
				} else {
					completeGroup(interchange, interchangeParticle);
				}

				if (header == null && trailer == null)
					return;

				completeInterchangeHeader(header);
				completeInterchangeTrailer(trailer);
			}
		}

		protected void completeInterchangeHeader(ITextNode header) {
			
			if (header.getName().equals("UNB")) {
				ITextNode s001 = makeSureExists(header, "S001");
				ITextNode s002 = makeSureExists(header, "S002");
				ITextNode s003 = makeSureExists(header, "S003");
				ITextNode s004 = makeSureExists(header, "S004");
				ITextNode f0020 = makeSureExists(header, "F0020"); // why it was commented out?

				completeS001(s001);
				completeS002(s002);
				completeS003(s003);
				completeS004(s004);
			} else if (header.getName().equals("UIB")) {
				ITextNode s001 = makeSureExists(header, "S001");
				ITextNode s002 = makeSureExists(header, "S002");
				ITextNode s003 = makeSureExists(header, "S003");

				completeS001(s001);
				completeS002(s002);
				completeS003(s003);
			}			
		}

		protected void completeInterchangeTrailer(ITextNode trailer) {
			if (trailer.getName().equals("UNZ")) {
				ITextNode f0036 = makeSureExists(trailer, "F0036");
				ITextNode f0020 = makeSureExists(trailer, "F0020");

				conservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(trailer.getParent(), false));
				ITextNode unb = trailer.getParent().getChildren().getFirstNodeByName("UNB");
				ITextNodeList unbChildren = unb.getChildren().filterByName("F0020");
				String ctrlRef = unbChildren.size() > 0 ? unbChildren.getAt(unbChildren.size()-1).getValue() : new String();
				conservativeSetValue(f0020, ctrlRef);
			} else if (trailer.getName().equals("UIZ")) {
				ITextNode f0036 = makeSureExists(trailer, "F0036");

				conservativeSetValue(f0036, GetNumberOfFunctionGroupsOrMessages(trailer.getParent(), true));
				ITextNode uib = trailer.getParent().getChildren().getFirstNodeByName("UIB");
				ITextNodeList uibChildren = uib.getChildren().filterByName("S302");
				if (uibChildren.size() > 0) {
					ITextNode uib_s302 = uibChildren.getAt(0);
					ITextNode s302 = makeSureExists(trailer, "S302");
					completeS302(s302, uib_s302);
				}
			}
		}

		protected void completeGroup(ITextNode group, Particle groupParticle) {
			
			Particle groupHeader = groupParticle.getFirstChildByName("UNG");
			Particle groupTrailer = groupParticle.getFirstChildByName("UNE");

			ITextNode header = null;
			ITextNode trailer = null;
			if (groupHeader != null && groupTrailer != null) {
				header = group.getChildren().getFirstNodeByName( groupHeader.getName() );
				trailer = group.getChildren().getFirstNodeByName( groupTrailer.getName() );

				if (header != null) {
					trailer = makeSureExists(group, groupTrailer.getName());
				} else if (trailer != null) {
					header = makeSureExists(group, groupHeader.getName());
				}
			}

			for (String sMessageType : m_Document.getMessageTypes()) {
				ITextNodeList messages  = group.getChildren().filterByName("Message_" + sMessageType);
				for (int i=0; i< messages.size(); ++i) {
					Particle messageParticle = m_Document.getMessage(sMessageType).getRootParticle();
					completeMandatory(messages.getAt(i), messageParticle);
					completeMessage(sMessageType, messages.getAt(i), messageParticle);
				}
			}
			ITextNodeList messages  = group.getChildren().filterByName("Message");
			for (int i=0; i< messages.size(); ++i)
				completeMessage(mSettings.getMessageType(), messages.getAt(i), m_Document.getFirstMessage().getRootParticle());

			if (header != null && trailer != null) {
				completeGroupHeader(header);
				completeGroupTrailer(trailer);
			}
		}

		protected void completeGroupHeader(ITextNode ung) {
			if (ung == null)
				return;

			/*ITextNode s006 = */makeSureExists(ung, "S006");
			/*ITextNode s007 = */makeSureExists(ung, "S007");
			ITextNode s004 = makeSureExists(ung, "S004");
			ITextNode f0048 = makeSureExists(ung, "F0048");
			ITextNode f0051 = makeSureExists(ung, "F0051");
			/*ITextNode s008 = */makeSureExists(ung, "S008");
			/*ITextNode f0058 = */makeSureExists(ung, "F0058");
			
			completeS004(s004);
			
			ITextNode une_f0048 =  ung.getParent().getChildren().getFirstNodeByName("UNE").getChildren().getFirstNodeByName("F0048");
			if (une_f0048 != null)
				conservativeSetValue(f0048, une_f0048.getValue());
				
			
			conservativeSetValue(f0051, mSettings.getControllingAgency().substring(0,2));
		}

		protected void completeGroupTrailer(ITextNode une) {
			if (une == null)
				return;

			ITextNode f0060 = makeSureExists(une, "F0060");
			ITextNode f0048 = makeSureExists(une, "F0048");

			int nMsg = une.getParent().getChildren().filterByName("Message").size();
			for (String sMessageType : m_Document.getMessageTypes()) {
				ITextNodeList messages  = une.getParent().getChildren().filterByName("Message_" + sMessageType);
				nMsg += messages.size();
			}
			conservativeSetValue(f0060, nMsg);
			ITextNode ung_f0048 = une.getParent().getChildren().getFirstNodeByName("UNG").getChildren().getFirstNodeByName("F0048");
			if (ung_f0048 != null)
				conservativeSetValue(f0048, ung_f0048.getValue());
		}

		protected void completeMessage(String sMessageType, ITextNode message, Particle messageParticle) {
			Particle messageHeader = messageParticle.getFirstChildByName("UNH") != null ? messageParticle.getFirstChildByName("UNH") : messageParticle.getFirstChildByName("UIH");
			Particle messageTrailer = messageParticle.getFirstChildByName("UNT") != null ? messageParticle.getFirstChildByName("UNT") : messageParticle.getFirstChildByName("UIT");

			ITextNode header = makeSureExists(message, messageHeader.getName());
			ITextNode trailer = makeSureExists(message, messageTrailer.getName());

			completeMessageHeader(sMessageType, header, messageHeader);
			completeMessageTrailer(trailer, messageTrailer);
		}

		protected void completeMessageHeader(String sMessageType, ITextNode header, Particle headerParticle) {
			if (headerParticle.getName().equals("UNH")) {
				ITextNode f0062 = makeSureExists(header, "F0062");
				ITextNode s009 = makeSureExists(header, "S009");

				String referenceNumber = header.getParent().getChildren().getFirstNodeByName("UNT").getValue();

				if (referenceNumber.length() == 0)
					referenceNumber = "0";

				conservativeSetValue(f0062, referenceNumber);
				completeS009(sMessageType, s009);
			} else if (headerParticle.getName().equals("UIH")) {
				ITextNode f0340 = makeSureExists(header,"F0340");
				ITextNode s306 = makeSureExists(header,"S306");

				String referenceNumber = header.getParent().getChildren().getFirstNodeByName("UIT").getValue();

				if (referenceNumber.length() == 0)
					referenceNumber = "0";

				conservativeSetValue(f0340, referenceNumber);
				completeS306(sMessageType, s306);


				ITextNodeList interchange_uib = header.getParent().getParent().getChildren().filterByName("UIB");
				if (interchange_uib.size() > 0) {
					ITextNode uib = interchange_uib.getAt(0);
					ITextNodeList uibChildren =  uib.getChildren().filterByName("S302");
					if (uibChildren.size() > 0) {
						ITextNode uib_s302 = uibChildren.getAt(0);
						ITextNode s302 = makeSureExists(header, "S302");
						completeS302(s302, uib_s302);
					}
				}
			}
		}

		protected void completeMessageTrailer(ITextNode trailer, Particle trailerParticle) {
			if (trailerParticle.getName().equals("UNT")) {
				ITextNode f0074 = makeSureExists(trailer, "F0074");
				ITextNode f0062 = makeSureExists(trailer, "F0062");

				conservativeSetValue(f0074, getSegmentChildrenCount(trailer.getParent()));
				conservativeSetValue(f0062, trailer.getParent().getChildren().getFirstNodeByName("UNH").getChildren().getFirstNodeByName("F0062").getValue());
			} else if (trailerParticle.getName().equals("UIT")) {
				ITextNode f0340 = makeSureExists(trailer, "F0340");
				ITextNode f0074 = makeSureExists(trailer, "F0074");

				conservativeSetValue(f0340, trailer.getParent().getChildren().getFirstNodeByName("UIH").getChildren().getFirstNodeByName("F0340").getValue());
				conservativeSetValue(f0074, getSegmentChildrenCount(trailer.getParent()));
			}
		}

		protected void completeS001(ITextNode s001) {
			ITextNode f0001 = makeSureExists(s001, "F0001");
			ITextNode f0002 = makeSureExists(s001, "F0002");

			conservativeSetValue(f0001, mSettings.getControllingAgency() + mSettings.getSyntaxLevel());
			conservativeSetValue(f0002, mSettings.getSyntaxVersionNumber());
		}

		protected void completeS002(ITextNode s002) {
			ITextNode f0004 = makeSureExists(s002, "F0004");
			conservativeSetValue(f0004, "Sender");
		}
		
		protected void completeS003(ITextNode s003) {
			ITextNode f0010 = makeSureExists(s003, "F0010");
			conservativeSetValue(f0010, "Recipient");
		}
		
		protected void completeS004(ITextNode s004) {
			ITextNode f0017 = makeSureExists(s004, "F0017");
			ITextNode f0019 = makeSureExists(s004, "F0019");

			conservativeSetValue(f0017, getCurrentDateAsEDIString(mSettings.getSyntaxVersionNumber()));
			conservativeSetValue(f0019, getCurrentTimeAsEDIString());
		}

		protected void completeS009(String sMessageType, ITextNode s009) {
			ITextNode f0065 = makeSureExists(s009, "F0065");
			ITextNode f0052 = makeSureExists(s009, "F0052");
			ITextNode f0054 = makeSureExists(s009, "F0054");
			ITextNode f0051 = makeSureExists(s009, "F0051");
			
			conservativeSetValue(f0065, sMessageType);
			conservativeSetValue(f0051, mSettings.getControllingAgency().substring(0, 2));
			conservativeSetValue(f0052, mSettings.getVersion());
			conservativeSetValue(f0054, mSettings.getRelease());
		}

		protected void completeS302(ITextNode s302, ITextNode uib_s302) {
			for (int i = 0; i < uib_s302.getChildren().size(); i++) {
				ITextNode node = makeSureExists(s302, uib_s302.getChildren().getAt(i).getName());
				conservativeSetValue(node, uib_s302.getChildren().getAt(i).getValue());
			}
		}

		protected void completeS306(String sMessageType, ITextNode s306) {
			completeS009(sMessageType, s306);
		}

		long GetNumberOfFunctionGroupsOrMessages(ITextNode node, boolean interactive) {
			int nUNH =0;
			int nUNT =0;
			int nUNG =0;
			int nUNE =0;

			ITextNodeList groups = node.getChildren().filterByName("Group");
			if (interactive) {
				for (String sMessageType : m_Document.getMessageTypes()) {
					ITextNodeList messages  = node.getChildren().filterByName("Message_" + sMessageType);
					for (int j=0; j< messages.size(); ++j) {
						nUNH += messages.getAt(j).getChildren().filterByName("UIH").size();
						nUNT += messages.getAt(j).getChildren().filterByName("UIT").size();
					}
				}
				ITextNodeList messages = node.getChildren().filterByName("Message");
				for (int j=0; j< messages.size(); ++j) {
					nUNH += messages.getAt(j).getChildren().filterByName("UIH").size();
					nUNT += messages.getAt(j).getChildren().filterByName("UIT").size();
				}
			} else {			
				for (int i=0; i< groups.size(); ++i) {
					nUNG += groups.getAt(i).getChildren().filterByName("UNG").size();
					nUNE += groups.getAt(i).getChildren().filterByName("UNE").size();

					ITextNodeList messages = groups.getAt(i).getChildren().filterByName("Message");
					for (int j=0; j< messages.size(); ++j) {
						nUNH += messages.getAt(j).getChildren().filterByName("UNH").size();
						nUNT += messages.getAt(j).getChildren().filterByName("UNT").size();						
					}
			
					for (String sMessageType : m_Document.getMessageTypes()) {
						ITextNodeList messages_  = groups.getAt(i).getChildren().filterByName("Message_" + sMessageType);
						for (int j=0; j< messages_.size(); ++j) {
							nUNH += messages_.getAt(j).getChildren().filterByName("UNH").size();
							nUNT += messages_.getAt(j).getChildren().filterByName("UNT").size();
						}
					}
				}
			}
			
			if (nUNH != nUNT)
				throw new com.altova.AltovaException("Message header-trailer mismatch");
			if (nUNG != nUNE)
				throw new com.altova.AltovaException("Group header-trailer mismatch");

			return nUNG == 0 ? nUNH : nUNG;
		}
}
