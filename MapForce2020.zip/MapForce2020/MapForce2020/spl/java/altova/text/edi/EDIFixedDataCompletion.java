[call GenerateFileHeader("EDIFixedDataCompletion.java")]
package com.altova.text.edi;

import com.altova.text.ITextNode;

public class EDIFixedDataCompletion extends DataCompletion {
//	private EDIFixedSettings mSettings = null;

	public EDIFixedDataCompletion(TextDocument document, EDIFixedSettings settings, String structurename) {
		super(document, structurename);
//		mSettings = settings;
	}

	public void completeData(ITextNode dataroot, Particle rootParticle) {
		completeMandatory(dataroot, rootParticle);
	}
}
