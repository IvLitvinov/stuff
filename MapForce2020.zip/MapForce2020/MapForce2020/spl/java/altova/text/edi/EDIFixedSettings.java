[call GenerateFileHeader("EDIFixedSettings.java")]
package com.altova.text.edi;

public class EDIFixedSettings extends EDISettings {

	public EDIFixedSettings() {
		super.mEDIStandard = EDIStandard.EDIFixed;
	}	
}
