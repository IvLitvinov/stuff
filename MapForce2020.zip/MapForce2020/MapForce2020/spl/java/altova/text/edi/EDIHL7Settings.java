[call GenerateFileHeader("EDIHL7Settings.java")]
package com.altova.text.edi;

public class EDIHL7Settings extends EDISettings {

	public static final char cEscStartHighlight =			'H';
	public static final char cEscNormalText =				'N';
	public static final char cEscFieldSeparator =			'F';
	public static final char cEscComponentSeparator =		'S';
	public static final char cEscSubComponentSeparator = 	'T';
	public static final char cEscRepetitionSeparator =		'R';
	public static final char cEscEscapeSeparator =			'E';
	public static final char cEscHexadecimalData =			'X';
	public static final char cEscLocalEscapeSeq =			'Z';

	public EDIHL7Settings() {
		super.mEDIStandard = EDIStandard.EDIHL7;
	}	
}
