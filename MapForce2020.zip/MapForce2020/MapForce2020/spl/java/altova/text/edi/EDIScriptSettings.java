[call GenerateFileHeader("EDIScriptSettings.java")]
package com.altova.text.edi;

// Encapsulates NCPDP SCRIPT specific settings

public class EDIScriptSettings extends EDIFactSettings {

	public EDIScriptSettings() {
		super.mEDIStandard = EDIStandard.EDISCRIPT;
		setControllingAgency( "UNO" );
		setSyntaxVersionNumber( 0 );
	}	
	
}
