[call GenerateFileHeader("EDISettings.java")]
package com.altova.text.edi;

public class EDISettings {
	public enum EDIStandard {
		EDIUnknown,
		EDIFACT,
		EDIX12,
		EDIHL7,
		EDIFixed,
		EDITRADACOMS,
		EDISCRIPT
	}

	private ServiceChars m_ServiceChars = new ServiceChars();

	private boolean m_TerminateSegmentsWithLinefeed = false;
	private boolean m_AutoCompleteData = true;
	private int m_LineEnd = 0;

	protected String mVersion = "";
	protected String mRelease = "";
	protected String mControllingAgency = "UNO";
	private String mMessageType = "";
	protected EDIStandard mEDIStandard = EDIStandard.EDIUnknown;

	public ServiceChars getServiceChars() {
		return m_ServiceChars;
	}

	public boolean getTerminateSegmentsWithLinefeed() {
		return m_TerminateSegmentsWithLinefeed;
	}

	public boolean getAutoCompleteData() {
		return m_AutoCompleteData;
	}

	public void setTerminateSegmentsWithLinefeed(boolean rhs) {
		m_TerminateSegmentsWithLinefeed = rhs;
	}

	public void setAutoCompleteData(boolean rhs) {
		m_AutoCompleteData = rhs;
	}

	public void setLineEnd(int lineend) {
		m_LineEnd = lineend;
	}

	public int getLineEnd() {
		return m_LineEnd;
	}

	public void setVersion(String ver) {
		mVersion=ver;
	}

	public String getVersion() {
		return mVersion;
	}

	public void setRelease(String rel) {
		mRelease = rel;
	}

	public String getRelease() {
		return mRelease;
	}
	
	public EDIStandard getStandard() {
		return mEDIStandard;
	}
	
	public String getControllingAgency() {
		return mControllingAgency;
	}

	public void setControllingAgency(String rhs) {
		mControllingAgency = rhs;
	}
	
	public String getMessageType() {
		return mMessageType;
	}

	public void setMessageType(String rhs) {
		mMessageType = rhs;
	}
}
