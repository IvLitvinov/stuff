[call GenerateFileHeader("EDITRADACOMSSettings.java")]
package com.altova.text.edi;

public class EDITradacomsSettings extends EDISettings {

	public EDITradacomsSettings() {
		super.mEDIStandard = EDIStandard.EDITRADACOMS;
	}	
	
}
