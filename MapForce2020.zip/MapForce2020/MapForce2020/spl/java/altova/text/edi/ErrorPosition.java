[call GenerateFileHeader("ErrorPosition.java")]
package com.altova.text.edi;

public class ErrorPosition {
	private long mLine;
	private long mColumn;
	private long mPosition;
	
	public ErrorPosition( Scanner scanner) {
		mLine = scanner.getLine() - 1;
		mColumn = scanner.getColumn();
		mPosition = scanner.getPosition();
	}
	
	public ErrorPosition( Scanner.State scannerState) {		
		mLine = scannerState.CurrentLine;
		mColumn = scannerState.Current - scannerState.LineStart;
		mPosition = scannerState.Current;
	}
	
	public ErrorPosition( final long line, final long column, final long position) {
		mLine = line;
		mColumn = column;
		mPosition = position;
	}
	
	public long getLine() {
		return mLine + 1;
	}
	public long getColumn() {
		return mColumn;
	}
	public long getPosition() {
		return mPosition;
	}
}
