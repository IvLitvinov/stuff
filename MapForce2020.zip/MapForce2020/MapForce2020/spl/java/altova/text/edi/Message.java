[call GenerateFileHeader("Message.java")]
package com.altova.text.edi;

import java.util.HashSet;

public class Message {
	private HashSet<String> mSegments;
	private Particle mRootParticle;
	private String msMessageType;
	private boolean mShouldCompleteSingleConditions = false;
	private boolean mShouldCompleteSingleValues = false;
	private boolean mShouldCompleteHLSegments = false;

	public Message(String sMessageType, Particle rootParticle, HashSet<String> segments, int completeHL, int completeSingleValues, int completeSingleConditions) {
		msMessageType = sMessageType;
		mRootParticle = rootParticle;
		mSegments = segments;
		mShouldCompleteHLSegments = completeHL == 1;
		mShouldCompleteSingleConditions = completeSingleConditions == 1;
		mShouldCompleteSingleValues = completeSingleValues == 1;
	}

	public Particle getRootParticle() {
		return mRootParticle;
	}
	
	public boolean hasSegment( String sSegmentName ) {
		return mSegments.contains(sSegmentName);
	}

	public String getMessageType() {
		return msMessageType;
	}

	public boolean shouldCompleteSingleConditions() {
		return mShouldCompleteSingleConditions;
	}

	public boolean shouldCompleteSingleValues() {
		return mShouldCompleteSingleValues;
	}

	public boolean shouldCompleteHLSegments() {
		return mShouldCompleteHLSegments;
	}
}
