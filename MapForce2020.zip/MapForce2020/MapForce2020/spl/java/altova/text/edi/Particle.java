[call GenerateFileHeader("Particle.java")]

package com.altova.text.edi;

public class Particle {
	int mMinOccurs = 0;
	int mMaxOccurs = Integer.MAX_VALUE;
	int mMergedEntries = 1;
	boolean mRespectMaxOccurs = true;
	StructureItem mNode = null;
	String mNameOverride = null;
	String\[\] mCodeValues = null;

	public boolean boundedGroup = false;
	
	public int getMinOccurs() { 
		return mMinOccurs; 
	}

	public int getMaxOccurs() {
		return mMaxOccurs;
	}

	public int getMergedEntries() { 
		return mMergedEntries; 
	}

	public StructureItem getNode() {
		return mNode; 
	}

	public String getNameOverride() {
		return mNameOverride;
	}

	public String getName() {
		if (mNameOverride == null)
			return mNode.getName();

		return mNameOverride; 
	}

	public String\[\] getCodeValues() {
		return mCodeValues;
	}

	public Particle (String nameOverride, StructureItem node, int minOccurs, int maxOccurs, int mergedEntries, boolean respectMaxOccurs, String\[\] codeValues)	{
		this.mNameOverride = nameOverride;
		this.mNode = node;
		this.mMinOccurs = minOccurs;
		this.mMaxOccurs = maxOccurs;
		this.mMergedEntries = mergedEntries;
		this.mRespectMaxOccurs = respectMaxOccurs;
		this.mCodeValues = codeValues;
	}
	
	public Particle getFirstChildByName( String name ) {
		for (int i = 0; i < getNode().getChildCount(); i++) {
			Particle childParticle = getNode().getChildren()\[i\];
			if (childParticle.getName() == name)
				return childParticle;
		}
		return null;
	}
}
	
