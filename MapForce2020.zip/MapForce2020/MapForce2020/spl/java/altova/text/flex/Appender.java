[call GenerateFileHeader("Appender.java")]
package com.altova.text.flex;

public interface Appender {
	public void appendText(String addtext);
	public void appendLineEnd();
}
