[call GenerateFileHeader("DocumentWriter.java")]
package com.altova.text.flex;

import com.altova.text.*;

public class DocumentWriter implements Appender {
	private ITextNode current;
	private StringBuffer content;
	private int lineEnd;
	
	public DocumentWriter(ITextNode tree, StringBuffer buff, int lineEnd) {
		this.content = buff;
		this.current = tree;
		this.lineEnd = lineEnd;
	}

	public int getLineEnd() {
		return lineEnd;
	}

	public ITextNode getCurrentNode() {
		return current;
	}
	
	public void appendText(String text) {
		content.append(text);
	}
	
	public void appendText(StringBuffer text) {
		content.append(text.toString());
	}

	public void appendLineEnd() {
		String s;
		switch (lineEnd) {
			case 0: s = java.lang.System.getProperty("line.separator"); break;
			case 1: s = "\\r\\n"; break;
			case 2: s = "\\n"; break;
			case 3: s = "\\r"; break;
			default: s = "\\r\\n"; break;
		}
		
		content.append(s);
	}
}
