[call GenerateFileHeader("SplitAtDelimiterLineBasedMultiple.java")]
package com.altova.text.flex;

public class SplitAtDelimiterLineBasedMultiple extends SplitAtDelimiterLineBased {
	public SplitAtDelimiterLineBasedMultiple(String delimiter) {
		super(delimiter, false);
	}
	
	public Range split(Range range) {
		SplitLines splitAtFirstLine = new SplitLines(1);
		boolean firstLine = true;
		Range result = new Range(range);
		while (true) {
			Range line = splitAtFirstLine.split(range);
			if (!line.isValid()) {
				result.end = line.start;
				break;
			}
			if (line.toString().indexOf(delimiter) >= 0) {
				if (!firstLine) {
					result.end = line.start;
					break;
				}
			}
			firstLine = false;
		}
		range.start = result.end;
		return result;
	}
	
	public void appendDelimiter(Appender output) {}
}
