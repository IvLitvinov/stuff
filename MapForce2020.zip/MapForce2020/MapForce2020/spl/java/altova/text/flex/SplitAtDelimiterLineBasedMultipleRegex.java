[call GenerateFileHeader("SplitAtDelimiterLineBasedMultipleRegex.java")]
package com.altova.text.flex;

public class SplitAtDelimiterLineBasedMultipleRegex extends SplitAtDelimiterLineBasedRegex {
	public SplitAtDelimiterLineBasedMultipleRegex( String pattern, boolean matchcase ) {
		super( pattern, matchcase );
	}
	
	public Range split( Range range ) {
		SplitLines splitAtFirstLine = new SplitLines(1);
		boolean firstLine = true;
		Range result = new Range(range);
		SplitAtDelimiterRegex splitter = new SplitAtDelimiterRegex( pattern, matchcase, null );
		while (true) {
			Range line = splitAtFirstLine.split( range );
			if (!line.isValid()) {
				result.end = line.start;
				break;
			}
			Range head = splitter.split( line );
			if (head.end != line.end) {
				if (!firstLine) {
					result.end = head.start;
					break;
				}
			}
			firstLine = false;
		}
		range.start = result.end;
		return result;
	}
}
