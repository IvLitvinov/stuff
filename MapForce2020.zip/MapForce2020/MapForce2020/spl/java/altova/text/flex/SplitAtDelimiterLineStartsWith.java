[call GenerateFileHeader("SplitAtDelimiterLineStartsWith.java")]
package com.altova.text.flex;

public class SplitAtDelimiterLineStartsWith extends SplitAtDelimiter {
	protected boolean consumeFirstLine;

	public SplitAtDelimiterLineStartsWith(String delimiter) {
		super(delimiter, false);
		consumeFirstLine = false;
	}
	
	public SplitAtDelimiterLineStartsWith(String delimiter, boolean reverse) {
		super(delimiter, reverse);
		consumeFirstLine = false;
	}
	
	public Range split(Range range) {
		if (!reverse) {
			Range result = new Range(range);

			if (delimiter == "") {
				range.start = range.end;
				return result;
			}

			SplitLines splitAtFirstLine = new SplitLines(1);
			boolean firstLine = consumeFirstLine;
			while (true) {
				Range line = splitAtFirstLine.split(range);
				if (!line.isValid()) {
					result.end = line.start;
					break;
				}
				if (line.toString().indexOf(delimiter) == 0) {
					if (!firstLine) {
						result.end = line.start;
						break;
					}
				}
				firstLine = false;
			}
			range.start = result.end;
			return result;
		} else {
			Range result = new Range(range);

			if (delimiter == "") {
				result.end = result.start;
				return result;
			}

			SplitLines splitAtLastLine = new SplitLines(-1);
			Range pre = new Range(range);
			while (true) {
				Range line = splitAtLastLine.split(pre);
				if (!line.isValid()) {
					result.end = line.start;
					break;
				}
				if (pre.toString().indexOf(delimiter) == 0) {
					result.end = pre.start;
					break;
				}
				pre = line;
			}
			range.start = result.end;
			return result;
		}
	}
	
	public void appendDelimiter(Appender output) {}
}
