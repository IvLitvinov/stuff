[call GenerateFileHeader("SplitAtDelimiterLineStartsWithMultiple.java")]
package com.altova.text.flex;

public class SplitAtDelimiterLineStartsWithMultiple extends SplitAtDelimiterLineStartsWith {
	public SplitAtDelimiterLineStartsWithMultiple(String delimiter) {
		super(delimiter);
		consumeFirstLine = true;
	}
}
