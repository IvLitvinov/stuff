[call GenerateFileHeader("SplitAtDelimiterLineStartsWithMultipleRegex.java")]
package com.altova.text.flex;

public class SplitAtDelimiterLineStartsWithMultipleRegex extends SplitAtDelimiterLineStartsWithRegex {
	public SplitAtDelimiterLineStartsWithMultipleRegex( String pattern, boolean matchcase ) {
		super( pattern, matchcase );
		consumeFirstLine = true;
	}
}
