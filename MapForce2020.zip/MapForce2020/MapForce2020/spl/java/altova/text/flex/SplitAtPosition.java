[call GenerateFileHeader("SplitAtPosition.java")]
package com.altova.text.flex;

public class SplitAtPosition extends Splitter {
	private int position;
	
	public SplitAtPosition(int pos) {
		this.position = pos;
	}
	
	public Range split(Range range) {
		Range result;
		if (position < 0) {
			// from right
			int n = Math.min(-position, range.length());
			result = new Range(range.getContent(), range.start, range.end - n);
		} else {
			// from left
			result = new Range(range.getContent(), range.start, range.start + Math.min(position, range.length()));
		}
		range.start = result.end;
		return result;
	}
	public void prepareUpper(StringBuffer buffer, int lineEnd) { 
		if (position > 0) {
			if (buffer.length() > position) {
				buffer.delete(position, buffer.length());
			} else {
				while (buffer.length() < position)
					buffer.append(' ');
			}				
		}
	}
	public void prepareLower(StringBuffer buffer, int lineEnd) { 
		if (position < 0) {
			if (buffer.length() > -position) {
				buffer.delete(-position, buffer.length());
			} else {
				buffer.reverse();
				while (buffer.length() < -position)
					buffer.append(' ');
				buffer.reverse();
			}				
		}
	}
	
	public void appendDelimiter(Appender output) {}
}
