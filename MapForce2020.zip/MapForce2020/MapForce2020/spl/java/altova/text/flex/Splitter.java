[call GenerateFileHeader("Splitter.java")]
package com.altova.text.flex;

public abstract class Splitter {
	public static final char CR = '\\r';
	public static final char LF = '\\n';
	
	public abstract Range split(Range r);
	public abstract void appendDelimiter(Appender output);
	public void prepareUpper(StringBuffer buffer, int lineEnd) { }
	public void prepareLower(StringBuffer buffer, int lineEnd) { }
}
