[call GenerateFileHeader("ISerializer.java")]
package com.altova.text.tablelike;

public interface ISerializer {
	void serialize(java.io.OutputStream stream) throws MappingException;
	void serialize(java.io.Writer writer) throws MappingException;
	void deserialize(java.io.InputStream stream) throws MappingException;
	void deserialize(java.io.Reader reader) throws MappingException;

	void setEncoding(String encoding, boolean bBigEndian, boolean bBOM);
}