[call GenerateFileHeader("Table.java")]
package com.altova.text.tablelike.flf;

import com.altova.text.tablelike.ISerializer;

public class Table extends com.altova.text.tablelike.Table {
	private int m_lineEnd = 0;

	public Table(com.altova.typeinfo.TypeInfo tableType, int lineEnd) {
		super(false);
		this.tableType = tableType;
		this.m_lineEnd = lineEnd;
		init();
	}

	public Format getFormat() { return ((Serializer) m_Serializer).getFormat(); }

	protected ISerializer createSerializer() {
		return new Serializer(this,m_lineEnd);
	}

	private static int getLength(com.altova.typeinfo.MemberInfo member) {
		com.altova.typeinfo.TypeInfo ti = member.getDataType();
		if (ti.facets != null) {
			for (int iFacet = 0 ; iFacet < ti.facets.length ; ++iFacet) {
				if (ti.facets\[iFacet\].facetName.equals("length") || ti.facets\[iFacet\].facetName.equals("maxLength"))
					return ti.facets\[iFacet\].intValue; 
			}
		}
		return Integer.MAX_VALUE;
	}

	protected void initHeader(com.altova.text.tablelike.Header header) {
		for (int iMember = 0 ; iMember < tableType.getMembers().length ; ++iMember) {
			com.altova.typeinfo.MemberInfo member = tableType.getMembers()\[iMember\];
			header.add(
				new com.altova.text.tablelike.ColumnSpecification(member.getLocalName(), getLength(member.getDataType().getMembers()\[0\])));
		}
	}
}
